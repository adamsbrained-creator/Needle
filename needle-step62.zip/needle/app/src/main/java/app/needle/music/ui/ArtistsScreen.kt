package app.needle.music.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song
import app.needle.music.data.artistKey
import app.needle.music.data.isKnownArtist
import kotlinx.coroutines.launch

private class ArtistEntry(val name: String, val cover: Song, val albums: Int, val songs: Int) {
    val letter: String
        get() = name.trim().firstOrNull()?.uppercaseChar()?.takeIf { it.isLetter() }?.toString() ?: "#"
}

/**
 * Every artist in the library, A to Z, with a round picture (the cover of one of their songs) and a letter index on the right.
 * Opened from Library > Artists and from "See all" on the Home artists row (Black & Green).
 */
@Composable
fun ArtistsScreen(
    songs: List<Song>?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onSearch: () -> Unit,
    onOpenArtist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val artists = remember(songs) {
        songs.orEmpty()
            .filter { isKnownArtist(it.artist) }
            .groupBy { artistKey(it.artist) }
            .values
            .map { g -> ArtistEntry(g.first().artist, g.first(), g.map { it.albumId }.toSet().size, g.size) }
            .sortedBy { it.name.lowercase() }
    }
    val letters = remember(artists) { artists.map { it.letter }.distinct() }
    val listState = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Box(modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(bottom = bottomPadding)) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Artists", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                        Text("${artists.size} artists", color = Palette.Muted, fontSize = 13.sp)
                    }
                    RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)
                }
            }
            itemsIndexed(artists, key = { _, a -> artistKey(a.name) }) { _, a ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { onOpenArtist(a.name) }
                        .padding(start = 18.dp, end = 36.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(Modifier.size(52.dp).clip(CircleShape)) { Cover(a.cover, Modifier.fillMaxSize()) }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            a.name, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            "${a.albums} album${if (a.albums == 1) "" else "s"} · ${a.songs} song${if (a.songs == 1) "" else "s"}",
                            color = Palette.Muted, fontSize = 12.sp
                        )
                    }
                }
            }
        }
        if (letters.size > 1) {
            Column(
                Modifier.align(Alignment.CenterEnd).padding(end = 4.dp, bottom = 80.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(0.dp)
            ) {
                letters.forEach { l ->
                    Text(
                        l, color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier
                            .clickable {
                                val at = artists.indexOfFirst { it.letter == l } + 1
                                scope.launch { listState.animateScrollToItem(at) }
                            }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
        }
    }
}
