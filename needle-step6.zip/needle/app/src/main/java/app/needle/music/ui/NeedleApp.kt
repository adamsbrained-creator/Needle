package app.needle.music.ui

import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.music.data.HomeViewModel
import app.needle.music.data.LibraryViewModel
import app.needle.music.playback.PlayerViewModel

@Composable
fun NeedleApp() {
    val library: LibraryViewModel = viewModel()
    val homeVm: HomeViewModel = viewModel()
    val player: PlayerViewModel = viewModel()
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    var homeTab by rememberSaveable { mutableStateOf(HomeTab.POPULAR) }
    var showSingles by rememberSaveable { mutableStateOf(false) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        library.refreshPermission()
    }

    // Ask once on launch; scan whenever access becomes available.
    LaunchedEffect(Unit) {
        if (!library.hasPermission) permissionLauncher.launch(library.audioPermission)
    }
    LaunchedEffect(library.hasPermission) {
        if (library.hasPermission) library.scan()
    }

    BackHandler(enabled = destination != Destination.HOME) { destination = Destination.HOME }
    BackHandler(enabled = showSingles) { showSingles = false }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = showQueue) { showQueue = false } // registered last, so it wins

    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        if (!library.hasPermission) {
            PermissionScreen(onRequest = { permissionLauncher.launch(library.audioPermission) })
        } else {
            val songs by library.songs.collectAsState()
            val sort by library.sort.collectAsState()
            val home by homeVm.home.collectAsState()
            val newState by homeVm.newState.collectAsState()
            val singlesState by homeVm.singles.collectAsState()

            // Singles opens as its own page; the other pills switch the Home page itself.
            val selectTab: (HomeTab) -> Unit = { tab ->
                if (tab == HomeTab.SINGLES) {
                    showSingles = true
                } else {
                    homeTab = tab
                }
            }

            // The dock floats over every screen: room to scroll past it (with / without the player row).
            val dockPadding = if (player.hasMedia) 160.dp else 100.dp

            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                when {
                    showSingles -> SinglesScreen(
                        state = singlesState,
                        bottomPadding = dockPadding,
                        onBack = { showSingles = false },
                        onPlay = { list, index -> player.playSongs(list, index) }
                    )
                    destination == Destination.SONGS -> SongsScreen(
                        songs = songs,
                        isScanning = library.isScanning,
                        currentMediaId = player.currentMediaId,
                        sort = sort,
                        bottomPadding = dockPadding,
                        onSongClick = { index -> songs?.let { player.playSongs(it, index) } },
                        onShuffleAll = { songs?.let { player.shuffleAll(it) } },
                        onSortSelected = library::setSort,
                        onRescan = library::scan
                    )
                    else -> when (homeTab) {
                        HomeTab.NEW -> NewScreen(
                            state = newState,
                            bottomPadding = dockPadding,
                            onPlay = { list, index -> player.playSongs(list, index) },
                            onShuffle = { list -> player.shuffleAll(list) },
                            onTabSelected = selectTab
                        )
                        else -> HomeScreen(
                            home = home,
                            bottomPadding = dockPadding,
                            onPlay = { list -> player.playSongs(list, 0) },
                            onTabSelected = selectTab
                        )
                    }
                }
                NeedleDock(
                    selected = destination,
                    // Albums and Library have no pages yet, so those two buttons do nothing for now.
                    onSelect = {
                        if (it == Destination.HOME || it == Destination.SONGS) {
                            destination = it
                            showSingles = false
                        }
                    },
                    player = player,
                    onOpenPlayer = { showPlayer = true },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            AnimatedVisibility(
                visible = showPlayer,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                NowPlayingScreen(
                    vm = player,
                    onClose = { showPlayer = false },
                    onOpenQueue = { showQueue = true },
                    // swallow taps so they don't reach the list underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }

            AnimatedVisibility(
                visible = showQueue,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                QueueScreen(
                    vm = player,
                    onClose = { showQueue = false },
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
        }
    }
}
