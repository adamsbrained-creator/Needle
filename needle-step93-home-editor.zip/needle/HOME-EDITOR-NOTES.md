# Home editor (rows you can add, drag, hide and style)

Home is now a stack of **rows**. The editor changes that stack; every change is saved at once and can be undone.
Open it from **Edit Home** (the pill at the end of the Home page) or Settings > Customization > Home layout.

## What you get
- **Visual mode**: the real rows in frames. Drag by the handle, tap a row to Settings / Duplicate / Hide / Delete.
- **List mode**: the same rows as a compact list (Showing / Hidden), with switches.
- **Row settings**: live preview on top, tabs below (Content, Layout, Header, Style). Only tabs a row has are shown.
  Footer: Copy from..., Apply style to all, Reset row.
- **Add row**: gallery with search and categories, a small picture of each row type.
- **Pills**: show, hide, reorder the pills under the title; which page Home opens on.
- **Layouts**: presets, save your own, export / import a `.json` file, copy, share, restore default.
- **Undo** (top bar) covers rows, options, pills and applying a layout.

## How it is built (and how to extend it)
Everything the editor knows about a row lives in **`data/HomeRows.kt`** (`RowRegistry`): name, description, category,
supported layouts, options with limits and defaults. The settings sheet and the gallery are generated from it.
A row on the page is a `HomeRow(id, type, visible, options)`; `options` holds only what the person changed, so a better
default in the registry improves every untouched row.

**Add a new row type**
1. `data/HomeRows.kt`: add a `RowType(...)` to `RowRegistry.types` (options use the `toggle/slider/stepper` helpers).
2. `ui/HomeRows.kt`: add one branch to `HomeRowView` and a small composable. For anything cover-with-title shaped,
   build a list of `Item` and call `ItemsLayout(...)`: carousel, big, grid and list come for free.
3. If it needs data Home does not have yet, add a field to `HomeRowContext` and pass it in `NeedleApp` (HomeScreen call
   and the editor's `HomeRowContext(...)`).
Nothing in the editor changes.

**Add an option to an existing type**: one line in its `own = listOf(...)`; read it in the renderer with
`row.intOpt("key") / boolOpt / strOpt / listOpt`.

**Add a preset layout**: drop a layout file in `app/src/main/assets/home_presets/` (sorted by file name).

## The layout file (`needle-home-layout`, version 2)
```json
{ "format": "needle-home-layout", "version": 2, "name": "My Home", "start": "POPULAR",
  "tabs": [ { "id": "NEW", "visible": true }, ... ],
  "pages": { "POPULAR": [ { "id": "roulette", "type": "roulette", "visible": true,
                            "options": { "layout": "big", "size": 165, "max": 10, "headerText": "Top Picks" } } ],
             "NEW": [ ... ] } }
```
Unknown types and bad option values are dropped or clamped when a file is read, so a hand-written file cannot break Home.
Old layouts (the saved order/hidden list, and old backups) are read and converted automatically.
Backups still carry the layout under `homeLayout` (now the v2 document).

## Row types in this version
Latest Moments, Play now cards, Your albums (tiles / carousel / grid / list), This week (stat cards / one card),
Rediscover (with "not played for"), Artists (circles / chips / list), Roulette (random daily / newest / A-Z),
Mixes, Radio, Shortcuts (pick which links; chips / grid / list). The New page's four sections can be shown, hidden and
reordered (NewScreen still draws them). Defaults reproduce the Home as it was.

## Files
New: `data/HomeRows.kt`, `data/HomePresets.kt`, `ui/HomeRows.kt`, `ui/HomeEditor.kt`, `ui/HomeRowSettings.kt`,
`ui/HomeAddRow.kt`, `ui/HomeLayouts.kt`, `assets/home_presets/*.json`.
Rewritten: `data/HomeLayout.kt` (same entry points: `init`, `visibleSectionIds`, `visibleTabs`, `startTab`, `reset`,
`toJson`, `fromJson`), `ui/HomeScreen.kt` (the section loop is now `HomeRowView`).
Edited: `ui/NeedleApp.kt` (editor route, back handler, dock hidden while editing, Shortcuts / Mixes / Radio wiring),
`ui/SettingsScreen.kt` (the old section list page is now a doorway to the editor).

## Not done yet
- **Smart rows** (a row built from your own source / filter / sort) and a row for **Track moods**.
- Editing the Home header itself (greeting, avatar) and the New page's own row options.
- Row names are set in the Header tab (Header text); there is no separate rename.

## Honest status
Written without a compiler available, against the step 92 sources: every external symbol, signature and icon it uses was
checked against the project, but it has **not been built or run**. Expect a first-build fix or two. Please try:
open the editor; drag a row (also near the top/bottom edge); hide, duplicate, delete, then Undo; change a row's layout and
size and watch the preview; add Shortcuts / Roulette / Mixes / Radio; switch to the New page; apply a preset; export,
then import the file; restore a backup made before this version.
