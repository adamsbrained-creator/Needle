package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeAlbum
import app.needle.music.data.HomeRow
import app.needle.music.data.HomeState
import app.needle.music.data.MixData
import app.needle.music.data.PinnedArtists
import app.needle.music.data.RadioStation
import app.needle.music.data.RowLayout
import app.needle.music.data.Song
import app.needle.music.data.WeekStats
import app.needle.music.data.artistKey
import app.needle.music.data.formatListened
import app.needle.music.data.isKnownArtist
import app.needle.music.data.notPlayedLabel
import app.needle.music.playback.PlayerViewModel

/**
 * Everything a Home row needs to draw itself and to react to taps. Home passes the real thing; the editor passes
 * the same data with the default do-nothing callbacks, because rows in the editor are only for looking at.
 */
class HomeRowContext(
    val home: HomeState?,
    val albums: List<HomeAlbum>? = null,
    val moments: List<Song> = emptyList(),
    val momentsPlayer: PlayerViewModel? = null,
    val mixes: List<MixData> = emptyList(),
    val stations: List<RadioStation> = emptyList(),
    val onPlay: (List<Song>) -> Unit = {},
    val onOpenAlbum: (List<Song>) -> Unit = {},
    val onViewAllAlbums: (() -> Unit)? = null,
    val onOpenStats: (() -> Unit)? = null,
    val onOpenArtist: ((String) -> Unit)? = null,
    val onOpenArtists: (() -> Unit)? = null,
    val onShortcut: (String) -> Unit = {},
    val onOpenMix: (String) -> Unit = {},
    val onPlayStation: (RadioStation) -> Unit = {},
    val onPlayMoment: (Song) -> Unit = {},
    val onMomentToPlaylist: (Song) -> Unit = {}
)

/** Draws one row of the Home page. With [preview] (the editor) an empty row says what it needs instead of vanishing. */
@Composable
internal fun HomeRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean = false) {
    when (row.type) {
        "moments" -> MomentsRowView(row, ctx, preview)
        "pop_heroes" -> HeroesRowView(row, ctx, preview)
        "pop_albums" -> AlbumsRowView(row, ctx, preview)
        "pop_week" -> WeekRowView(row, ctx)
        "pop_rediscover" -> RediscoverRowView(row, ctx, preview)
        "artists" -> ArtistsRowView(row, ctx, preview)
        "roulette" -> RouletteRowView(row, ctx, preview)
        "mixes" -> MixesRowView(row, ctx, preview)
        "radios" -> RadiosRowView(row, ctx, preview)
        "shortcuts" -> ShortcutsRowView(row, ctx)
        else -> Unit
    }
}

private fun tagColors() = listOf(Palette.Accent, Palette.Green, Palette.Pink)

// ---- the shell every row sits in: spacing, optional card, optional header -----------------------

@Composable
private fun RowShell(
    row: HomeRow,
    defaultTitle: String,
    action: String?,
    onAction: (() -> Unit)?,
    content: @Composable (edge: Dp) -> Unit
) {
    val card = row.boolOpt("card")
    val edge = row.intOpt("edge").dp
    val inner = if (card) 12.dp else edge
    val shell = if (card) {
        Modifier
            .padding(horizontal = edge)
            .fillMaxWidth()
            .clip(cornerShape(24.dp))
            .background(Palette.Card)
            .then(if (row.boolOpt("outline")) Modifier.border(1.5.dp, Palette.Accent, cornerShape(24.dp)) else Modifier)
            .padding(bottom = 12.dp)
    } else Modifier.fillMaxWidth()
    val showHeader = row.boolOpt("header")
    Column(Modifier.padding(top = row.intOpt("spaceBefore").dp, bottom = row.intOpt("spaceAfter").dp)) {
        Column(shell) {
            if (showHeader) {
                RowHeader(row, row.strOpt("headerText").ifBlank { defaultTitle }, action, onAction, inner, if (card) 14.dp else 20.dp)
            } else if (card) {
                Spacer(Modifier.height(12.dp))
            }
            content(inner)
        }
    }
}

@Composable
private fun RowHeader(row: HomeRow, title: String, action: String?, onAction: (() -> Unit)?, edge: Dp, top: Dp) {
    val center = row.boolOpt("headerCenter")
    val weight = if (row.boolOpt("headerBold")) FontWeight.SemiBold else FontWeight.Medium
    val showAction = action != null && onAction != null && row.boolOpt("more") && !center
    Row(
        Modifier.fillMaxWidth().padding(start = edge, end = edge, top = top, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(
            title, color = Palette.Text, fontSize = row.intOpt("headerSize").sp, fontWeight = weight,
            textAlign = if (center) TextAlign.Center else TextAlign.Start,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
        )
        if (showAction && action != null && onAction != null) {
            if (app.needle.music.data.Skins.blackGreen) {
                Row(Modifier.clickable(onClick = onAction), verticalAlignment = Alignment.CenterVertically) {
                    Text(action, color = Palette.Muted, fontSize = 13.sp)
                    NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 16.dp)
                }
            } else {
                Text(action, color = Color(0xFFDDDDDD), fontSize = 12.sp, modifier = Modifier.clickable(onClick = onAction))
            }
        }
    }
}

@Composable
internal fun EmptyRowHint(text: String) {
    Text(
        text, color = Palette.Muted, fontSize = 13.sp, textAlign = TextAlign.Center,
        modifier = Modifier
            .padding(horizontal = 18.dp, vertical = 6.dp)
            .fillMaxWidth()
            .clip(cornerShape(18.dp))
            .background(Palette.Card)
            .padding(horizontal = 16.dp, vertical = 18.dp)
    )
}

// ---- items that look like a cover with a title: shared by albums, rediscover, roulette, mixes, radio -----

private class Item(
    val title: String,
    val subtitle: String?,
    val cover: Song?,
    val station: RadioStation? = null,
    val progress: Float? = null,
    val onClick: () -> Unit,
    val onPlay: (() -> Unit)? = null
)

private fun albumItem(a: HomeAlbum, ctx: HomeRowContext, subtitle: String?, withProgress: Boolean) = Item(
    title = a.title,
    subtitle = subtitle,
    cover = a.cover,
    progress = if (withProgress && a.songs.isNotEmpty()) (a.heardTracks.toFloat() / a.songs.size).coerceIn(0f, 1f) else null,
    onClick = { ctx.onOpenAlbum(a.songs) },
    onPlay = { ctx.onPlay(a.songs) }
)

@Composable
private fun PlayDot(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier.size(38.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.62f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { NeedleIconView(NeedleIcon.PLAY, Palette.Accent, size = 20.dp) }
}

@Composable
private fun ItemArt(item: Item, size: Dp, corner: Dp, modifier: Modifier) {
    val station = item.station
    val cover = item.cover
    when {
        station != null -> StationLogo(station, size, modifier, corner)
        cover != null -> Cover(cover, modifier.clip(coverClip(corner)))
        else -> Box(modifier.clip(cornerShape(corner)).background(Palette.Card))
    }
}

@Composable
private fun CoverCard(
    item: Item,
    size: Dp,
    corner: Dp,
    subtitles: Boolean,
    play: Boolean,
    progress: Boolean,
    modifier: Modifier = Modifier,
    fill: Boolean = false
) {
    val small = size < 120.dp
    Column(modifier.clip(cornerShape(12.dp)).clickable(onClick = item.onClick)) {
        val fillCover = fill && item.station == null
        Box(if (fillCover) Modifier.fillMaxWidth().aspectRatio(1f) else Modifier.size(size)) {
            ItemArt(item, size, corner, Modifier.fillMaxSize())
            val onPlay = item.onPlay
            if (play && onPlay != null) PlayDot(onPlay, Modifier.align(Alignment.BottomStart).padding(8.dp))
        }
        Text(
            item.title, color = Palette.Text, fontSize = if (small) 12.5.sp else 14.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp, start = 2.dp, end = 2.dp)
        )
        if (subtitles && !item.subtitle.isNullOrBlank()) {
            Text(
                item.subtitle, color = Palette.Muted, fontSize = if (small) 11.sp else 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 2.dp)
            )
        }
        val fraction = item.progress
        if (progress && fraction != null) {
            Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(3.dp).clip(CircleShape).background(Color(0xFF555555))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(fraction).background(Palette.Accent))
            }
        }
    }
}

@Composable
private fun ListItemRow(item: Item, subtitles: Boolean, play: Boolean, progress: Boolean) {
    Row(
        Modifier.fillMaxWidth().clip(cornerShape(14.dp)).clickable(onClick = item.onClick).padding(vertical = 5.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        ItemArt(item, 52.dp, 12.dp, Modifier.size(52.dp))
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(item.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (subtitles && !item.subtitle.isNullOrBlank()) {
                Text(item.subtitle, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            val fraction = item.progress
            if (progress && fraction != null) {
                Box(Modifier.padding(top = 6.dp).fillMaxWidth().height(3.dp).clip(CircleShape).background(Color(0xFF555555))) {
                    Box(Modifier.fillMaxHeight().fillMaxWidth(fraction).background(Palette.Accent))
                }
            }
        }
        val onPlay = item.onPlay
        if (play && onPlay != null) PlayDot(onPlay)
    }
}

/** Lays the items out as the row's chosen layout: a carousel, big covers, a grid or a list. */
@Composable
private fun ItemsLayout(items: List<Item>, row: HomeRow, edge: Dp, fallback: RowLayout) {
    val layout = row.layout ?: fallback
    val size = row.intOpt("size").coerceAtLeast(60).dp
    val shown = items.take(row.intOpt("max").coerceAtLeast(1))
    val subtitles = row.boolOpt("subtitles")
    val play = row.boolOpt("playButton")
    val progress = row.boolOpt("progress")
    when (layout) {
        RowLayout.GRID -> {
            val columns = if (size >= 130.dp) 2 else 3
            Column(Modifier.padding(horizontal = edge), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                shown.chunked(columns).forEach { chunk ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        chunk.forEach { CoverCard(it, size, 18.dp, subtitles, play, progress, Modifier.weight(1f), fill = true) }
                        repeat(columns - chunk.size) { Spacer(Modifier.weight(1f)) }
                    }
                }
            }
        }
        RowLayout.LIST -> Column(Modifier.padding(horizontal = edge)) {
            shown.forEach { ListItemRow(it, subtitles, play, progress) }
        }
        else -> {
            val corner = if (layout == RowLayout.BIG) 26.dp else 20.dp
            LazyRow(contentPadding = PaddingValues(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown) { CoverCard(it, size, corner, subtitles, play, progress, Modifier.width(size)) }
            }
        }
    }
}

// ---- Latest Moments ------------------------------------------------------------------------------

@Composable
private fun MomentsRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    if (ctx.moments.isEmpty()) {
        if (preview) EmptyRowHint("Moments you add to songs show up here.")
        return
    }
    Column(Modifier.padding(top = row.intOpt("spaceBefore").dp, bottom = row.intOpt("spaceAfter").dp)) {
        MomentsSection(ctx.moments, ctx.momentsPlayer, ctx.onPlayMoment, ctx.onMomentToPlaylist)
    }
}

// ---- Play now cards ------------------------------------------------------------------------------

@Composable
private fun HeroesRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val heroes = ctx.home?.heroes.orEmpty()
    if (heroes.isEmpty()) {
        if (preview) EmptyRowHint("Cards appear once Needle has some of your listening to go on.")
        else Text(
            "Your library is empty. Open Songs and scan for music.",
            color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
        )
        return
    }
    RowShell(row, "Made for you", null, null) { edge ->
        val width = row.intOpt("size").dp
        LazyRow(contentPadding = PaddingValues(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            items(heroes.take(row.intOpt("max").coerceAtLeast(1))) { hero ->
                HeroCardView(
                    title = hero.title, subtitle = hero.subtitle, cover = hero.songs.first(), width = width,
                    showPlay = row.boolOpt("playButton"),
                    onPlay = { ctx.onPlay(hero.songs) }, onOpen = { ctx.onOpenAlbum(hero.songs) }
                )
            }
        }
    }
}

@Composable
private fun HeroCardView(title: String, subtitle: String, cover: Song, width: Dp, showPlay: Boolean, onPlay: () -> Unit, onOpen: () -> Unit) {
    // 196 wide has always been 262 tall; other widths keep that shape.
    Box(Modifier.width(width).height(width * (262f / 196f)).clip(cornerShape(26.dp)).background(Palette.Card).clickable(onClick = onOpen)) {
        Cover(cover, Modifier.fillMaxSize())
        // Darkens the top and bottom so the white text and button stay readable on any cover.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = 0.55f),
                    0.4f to Color.Transparent,
                    0.75f to Color.Transparent,
                    1f to Color.Black.copy(alpha = 0.45f)
                )
            )
        )
        Column(Modifier.align(Alignment.TopStart).padding(14.dp)) {
            Text(title, color = Color.White, fontSize = 21.sp, lineHeight = 23.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 11.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        }
        if (showPlay) {
            Box(
                Modifier.align(Alignment.BottomStart).padding(10.dp).height(40.dp).clip(CircleShape).background(Color.White)
                    .clickable(onClick = onPlay).padding(horizontal = 20.dp),
                contentAlignment = Alignment.Center
            ) { Text("Play now", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

// ---- Your albums ---------------------------------------------------------------------------------

@Composable
private fun AlbumsRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val albums = ctx.home?.yourAlbums.orEmpty()
    if (albums.isEmpty()) {
        if (preview) EmptyRowHint("Albums you play show up here.")
        return
    }
    RowShell(row, "Your albums", "View all", ctx.onViewAllAlbums) { edge ->
        if (row.layout == RowLayout.TILES || row.layout == null) {
            val shown = albums.take(row.intOpt("max").coerceAtLeast(1))
            val colors = tagColors()
            LazyRow(contentPadding = PaddingValues(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(shown.size) { i ->
                    val album = shown[i]
                    AlbumTile(album, colors[i % colors.size], row.intOpt("size").dp, row.boolOpt("progress")) { ctx.onOpenAlbum(album.songs) }
                }
            }
        } else {
            ItemsLayout(albums.map { albumItem(it, ctx, if (row.boolOpt("subtitles")) it.artist else null, true) }, row, edge, RowLayout.COVERS)
        }
    }
}

@Composable
private fun AlbumTile(album: HomeAlbum, tagColor: Color, width: Dp, showProgress: Boolean, onClick: () -> Unit) {
    val total = album.songs.size
    Column(
        Modifier.width(width).clip(cornerShape(22.dp)).background(Palette.Card).clickable(onClick = onClick).padding(14.dp)
    ) {
        Text(album.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(
            album.genre ?: album.artist, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.padding(top = 6.dp, bottom = 16.dp).clip(CircleShape).background(tagColor).padding(horizontal = 10.dp, vertical = 4.dp)
        )
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${album.heardTracks}", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text("/ $total tracks", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 3.dp), maxLines = 1)
        }
        if (showProgress) {
            Box(Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(Color(0xFF555555))) {
                val fraction = (album.heardTracks.toFloat() / total.coerceAtLeast(1)).coerceIn(0f, 1f)
                Box(Modifier.fillMaxHeight().fillMaxWidth(fraction).background(Color.White))
            }
        }
    }
}

// ---- This week -----------------------------------------------------------------------------------

@Composable
private fun WeekRowView(row: HomeRow, ctx: HomeRowContext) {
    val week = ctx.home?.week ?: return
    RowShell(row, "This week", "Stats", ctx.onOpenStats) { edge ->
        if (row.layout == RowLayout.CARD) WeekCard(week, edge) else WeekCards(week, edge)
    }
}

@Composable
private fun WeekCards(week: WeekStats, edge: Dp) {
    Row(
        Modifier.height(IntrinsicSize.Max).horizontalScroll(rememberScrollState()).padding(horizontal = edge),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard(formatListened(week.listenedMs), "Listened", width = 104.dp)
        StatCard("${week.plays}", "Plays", width = 104.dp)
        StatCard(week.topArtist ?: "–", "Top artist", width = 150.dp, valueSize = 17.sp)
    }
}

@Composable
private fun StatCard(value: String, label: String, width: Dp, valueSize: androidx.compose.ui.unit.TextUnit = 24.sp) {
    Column(
        Modifier.width(width).fillMaxHeight().clip(cornerShape(22.dp)).background(Palette.Card).padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Text(value, color = Palette.Text, fontSize = valueSize, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = Palette.Muted, fontSize = 11.5.sp)
    }
}

@Composable
private fun WeekCard(week: WeekStats, edge: Dp) {
    Row(
        Modifier.padding(horizontal = edge).fillMaxWidth().clip(cornerShape(24.dp)).background(Palette.Card).padding(horizontal = 16.dp, vertical = 16.dp)
    ) {
        WeekCell(formatListened(week.listenedMs), "Listened", Modifier.weight(1f))
        WeekCell("${week.plays}", "Plays", Modifier.weight(1f))
        WeekCell(week.topArtist ?: "–", "Top artist", Modifier.weight(1.3f))
    }
}

@Composable
private fun WeekCell(value: String, label: String, modifier: Modifier) {
    Column(modifier) {
        Text(value, color = Palette.Text, fontSize = 19.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, color = Palette.Muted, fontSize = 12.sp)
    }
}

// ---- Rediscover ----------------------------------------------------------------------------------

@Composable
private fun RediscoverRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val now = System.currentTimeMillis()
    val cutoff = (row.strOpt("since").toLongOrNull() ?: 30L) * 24L * 3_600_000L
    val albums = ctx.home?.rediscover.orEmpty().filter { val last = it.lastPlayedAt; last == null || now - last >= cutoff }
    if (albums.isEmpty()) {
        if (preview) EmptyRowHint("Albums you have not played for a while show up here.")
        return
    }
    RowShell(row, "Rediscover", "View all", ctx.onViewAllAlbums) { edge ->
        val items = albums.map { albumItem(it, ctx, notPlayedLabel(it.lastPlayedAt, now), false) }
        ItemsLayout(items, row, edge, RowLayout.COVERS)
    }
}

// ---- Artists -------------------------------------------------------------------------------------

@Composable
private fun ArtistsRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val home = ctx.home
    // Pinned artists (Library > Artists) come first.
    val pinnedKeys by PinnedArtists.keys.collectAsState()
    val artists = remember(home, pinnedKeys) {
        if (home == null) emptyList<Pair<String, Song>>() else (home.yourAlbums + home.rediscover)
            .filter { isKnownArtist(it.artist) && it.songs.isNotEmpty() }
            .distinctBy { artistKey(it.artist) }
            .sortedBy { if (artistKey(it.artist) in pinnedKeys) 0 else 1 }
            .map { it.artist to it.songs.first() }
    }
    if (artists.isEmpty()) {
        if (preview) EmptyRowHint("Artists you play show up here.")
        return
    }
    RowShell(row, "Artists", "See all", ctx.onOpenArtists) { edge ->
        val shown = artists.take(row.intOpt("max").coerceAtLeast(1))
        val size = row.intOpt("size").dp
        val names = row.boolOpt("names")
        val open: (String) -> Unit = { name -> ctx.onOpenArtist?.invoke(name) }
        when (row.layout) {
            RowLayout.CHIPS -> LazyRow(contentPadding = PaddingValues(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(shown) { (name, song) ->
                    Row(
                        Modifier.clip(CircleShape).background(Palette.Card2).clickable { open(name) }.padding(end = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(38.dp).clip(CircleShape)) { Cover(song, Modifier.fillMaxSize()) }
                        Text(name, color = Palette.Text, fontSize = 13.5.sp, maxLines = 1, modifier = Modifier.padding(start = 10.dp))
                    }
                }
            }
            RowLayout.LIST -> Column(Modifier.padding(horizontal = edge)) {
                shown.forEach { (name, song) ->
                    Row(
                        Modifier.fillMaxWidth().clip(cornerShape(14.dp)).clickable { open(name) }.padding(vertical = 5.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(Modifier.size(48.dp).clip(CircleShape)) { Cover(song, Modifier.fillMaxSize()) }
                        Text(name, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 12.dp))
                    }
                }
            }
            else -> LazyRow(contentPadding = PaddingValues(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                items(shown) { (name, song) ->
                    Column(
                        Modifier.width(size + 8.dp).clip(cornerShape(12.dp)).clickable { open(name) },
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(Modifier.size(size).clip(CircleShape)) { Cover(song, Modifier.fillMaxSize()) }
                        if (names) {
                            Text(
                                name, color = Palette.Text, fontSize = 12.sp, textAlign = TextAlign.Center,
                                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}

// ---- Roulette, Mixes, Radio ----------------------------------------------------------------------

@Composable
private fun RouletteRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val all = ctx.albums.orEmpty().filter { it.songs.isNotEmpty() }
    val order = row.strOpt("order")
    val day = System.currentTimeMillis() / 86_400_000L
    val ordered = remember(all, order, day) {
        when (order) {
            "newest" -> all.sortedByDescending { a -> a.songs.maxOf { it.dateAdded } }
            "az" -> all.sortedBy { it.title.lowercase() }
            else -> all.shuffled(java.util.Random(day))
        }
    }
    if (ordered.isEmpty()) {
        if (preview) EmptyRowHint("Albums from your library show up here.")
        return
    }
    RowShell(row, "Roulette", "View all", ctx.onViewAllAlbums) { edge ->
        ItemsLayout(ordered.take(row.intOpt("max").coerceAtLeast(1)).map { albumItem(it, ctx, it.artist, false) }, row, edge, RowLayout.BIG)
    }
}

@Composable
private fun MixesRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val mixes = ctx.mixes.filter { it.songs.isNotEmpty() }
    if (mixes.isEmpty()) {
        if (preview) EmptyRowHint("Your mixes show up here once Needle has made them.")
        return
    }
    RowShell(row, "Mixes", null, null) { edge ->
        val items = mixes.map { m ->
            Item(
                title = m.name, subtitle = "${m.songs.size} songs", cover = m.songs.first(),
                onClick = { ctx.onOpenMix(m.id) }, onPlay = { ctx.onPlay(m.songs) }
            )
        }
        ItemsLayout(items, row, edge, RowLayout.COVERS)
    }
}

@Composable
private fun RadiosRowView(row: HomeRow, ctx: HomeRowContext, preview: Boolean) {
    val favoritesOnly = row.boolOpt("favoritesOnly")
    val stations = ctx.stations.filter { !favoritesOnly || it.favorite }
    if (stations.isEmpty()) {
        if (preview) EmptyRowHint(if (favoritesOnly) "Stations you mark as favorite show up here." else "Your radio stations show up here.")
        return
    }
    RowShell(row, "Radio", "View all", { ctx.onShortcut("radio") }) { edge ->
        val items = stations.map { s ->
            Item(title = s.name, subtitle = s.tagLine.ifBlank { null }, cover = null, station = s, onClick = { ctx.onPlayStation(s) })
        }
        ItemsLayout(items, row, edge, RowLayout.COVERS)
    }
}

// ---- Shortcuts -----------------------------------------------------------------------------------

private fun shortcutIcon(key: String): NeedleIcon = when (key) {
    "songs" -> NeedleIcon.SONGS
    "albums" -> NeedleIcon.ALBUMS
    "artists" -> NeedleIcon.ARTIST
    "playlists" -> NeedleIcon.ADD_PLAYLIST
    "library" -> NeedleIcon.SHELF
    "radio" -> NeedleIcon.RADIO
    "singles" -> NeedleIcon.MIC
    "most" -> NeedleIcon.FLAME
    "stats" -> NeedleIcon.CHART
    "foryou" -> NeedleIcon.SPARK
    "folders" -> NeedleIcon.FOLDER
    else -> NeedleIcon.LINK
}

@Composable
private fun ShortcutsRowView(row: HomeRow, ctx: HomeRowContext) {
    val labels = app.needle.music.data.ShortcutChoices.toMap()
    val keys = row.listOpt("items").filter { it in labels }
    if (keys.isEmpty()) return
    RowShell(row, "Shortcuts", null, null) { edge ->
        when (row.layout) {
            RowLayout.GRID -> Column(Modifier.padding(horizontal = edge), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                keys.chunked(2).forEach { pair ->
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        pair.forEach { key -> ShortcutTile(key, labels.getValue(key), Modifier.weight(1f)) { ctx.onShortcut(key) } }
                        if (pair.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
            RowLayout.LIST -> Column(Modifier.padding(horizontal = edge)) {
                keys.forEach { key ->
                    Row(
                        Modifier.fillMaxWidth().clip(cornerShape(14.dp)).clickable { ctx.onShortcut(key) }.padding(horizontal = 6.dp, vertical = 13.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NeedleIconView(shortcutIcon(key), Palette.Muted, size = 22.dp)
                        Text(labels.getValue(key), color = Palette.Text, fontSize = 16.sp, modifier = Modifier.weight(1f).padding(start = 16.dp))
                        NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
                    }
                }
            }
            else -> Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = edge), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                keys.forEach { key ->
                    Row(
                        Modifier.clip(CircleShape).background(Palette.Card2).clickable { ctx.onShortcut(key) }.padding(horizontal = 16.dp, vertical = 11.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NeedleIconView(shortcutIcon(key), Palette.Text, size = 18.dp)
                        Text(labels.getValue(key), color = Palette.Text, fontSize = 14.sp, maxLines = 1, modifier = Modifier.padding(start = 8.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ShortcutTile(key: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Row(
        modifier.height(56.dp).clip(cornerShape(18.dp)).background(Palette.Card).clickable(onClick = onClick).padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(shortcutIcon(key), Palette.Accent, size = 22.dp)
        Text(label, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.padding(start = 12.dp))
    }
}
