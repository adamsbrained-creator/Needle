package app.needle.music.ui

import android.widget.Toast
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeLayout
import app.needle.music.data.HomeRow
import app.needle.music.data.OptionKind
import app.needle.music.data.OptionTab
import app.needle.music.data.RowLayout
import app.needle.music.data.RowOption
import app.needle.music.data.RowType
import kotlin.math.roundToInt

/**
 * The settings of one row: its live preview stays on top while you change things below.
 * Nothing here is specific to a kind of row. The tabs and controls come from the row's entry in RowRegistry.
 */
@Composable
internal fun RowSettingsPage(rowId: String, ctx: HomeRowContext, onClose: () -> Unit) {
    val row = HomeLayout.row(rowId)
    val type = row?.spec
    if (row == null || type == null) {
        // The row was deleted (or undone away) while this page was open.
        LaunchedEffect(Unit) { onClose() }
        return
    }
    val tabs = type.tabs
    var tabName by rememberSaveable(rowId) {
        mutableStateOf((tabs.firstOrNull { it == OptionTab.LAYOUT } ?: tabs.firstOrNull())?.name ?: OptionTab.LAYOUT.name)
    }
    val tab = tabs.firstOrNull { it.name == tabName } ?: tabs.firstOrNull()
    var copyFrom by remember { mutableStateOf(false) }
    val context = LocalContext.current

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 6.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(type.title, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 22.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(type.about, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            RoundIconButton(NeedleIcon.CLOSE, onClose, size = 42.dp, iconSize = 20.dp)
        }

        // Live preview: the real row, drawn from the options as they are right now.
        Column(Modifier.fillMaxWidth().padding(top = 8.dp).heightIn(max = 250.dp).clipToBounds()) {
            Text(
                "LIVE PREVIEW", color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                modifier = Modifier.padding(start = 18.dp, bottom = 2.dp)
            )
            HomeRowView(row, ctx, preview = true)
        }

        Column(
            Modifier.weight(1f).fillMaxWidth().padding(top = 10.dp)
                .clip(cornerShapeOf(topStart = 28.dp, topEnd = 28.dp)).background(Palette.Card)
        ) {
            if (tabs.size > 1) {
                Segmented(
                    tabs.map { it.label }, tabs.indexOf(tab).coerceAtLeast(0),
                    Modifier.padding(start = 18.dp, end = 18.dp, top = 14.dp)
                ) { tabName = tabs[it].name }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp, vertical = 8.dp)) {
                if (tab == OptionTab.LAYOUT && type.hasLayoutPicker) LayoutPicker(row, type)
                type.options.filter { it.tab == tab }.forEach { OptionControl(row, it) }
                if (tab == OptionTab.STYLE && row.boolOpt("card").not() && type.options.any { it.key == "outline" }) {
                    Text("Outline and side padding apply when the row is shown as a card.", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))
                }
            }
            Column(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    FooterLink("Copy from\u2026") { copyFrom = true }
                    FooterLink("Apply style to all") {
                        HomeLayout.applyStyleToAll(rowId)
                        Toast.makeText(context, "Header and style copied to the other rows", Toast.LENGTH_SHORT).show()
                    }
                    FooterLink("Reset row") { HomeLayout.resetRow(rowId) }
                }
                Spacer(Modifier.height(8.dp))
                PillButton("Done", onClose, Modifier.fillMaxWidth(), filled = true)
            }
        }
    }

    if (copyFrom) {
        val page = HomeLayout.pageOf(rowId)
        val others = if (page == null) emptyList() else HomeLayout.rows(page).filter { it.id != rowId && it.spec?.external != true }
        AlertDialog(
            shape = cornerShape(28.dp),
            onDismissRequest = { copyFrom = false },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            title = { Text("Copy settings from") },
            text = {
                Column(Modifier.verticalScroll(rememberScrollState())) {
                    if (others.isEmpty()) Text("There are no other rows on this page.", color = Palette.Muted, fontSize = 14.sp)
                    others.forEach { other ->
                        Text(
                            other.title, color = Palette.Text, fontSize = 16.sp,
                            modifier = Modifier.fillMaxWidth().clickable {
                                HomeLayout.copyOptions(rowId, other.id)
                                copyFrom = false
                            }.padding(vertical = 12.dp)
                        )
                    }
                }
            },
            confirmButton = { TextButton(onClick = { copyFrom = false }) { Text("Cancel", color = Palette.Muted) } }
        )
    }
}

@Composable
private fun FooterLink(text: String, onClick: () -> Unit) {
    Text(
        text, color = Palette.Accent, fontSize = 13.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier.clip(cornerShape(12.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 10.dp)
    )
}

// ---- layout picker ------------------------------------------------------------------------------

@Composable
private fun LayoutPicker(row: HomeRow, type: RowType) {
    val current = row.layout
    Text("Layout", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        type.layouts.forEach { layout ->
            val on = layout == current
            val shape = cornerShape(16.dp)
            Column(
                Modifier.width(80.dp).clip(shape)
                    .background(if (on) Palette.Accent.copy(alpha = 0.18f) else Palette.Card2)
                    .then(if (on) Modifier.border(1.5.dp, Palette.Accent, shape) else Modifier)
                    .clickable { HomeLayout.setOption(row.id, "layout", layout.id) }
                    .padding(vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                LayoutGlyph(layout, Modifier.size(width = 48.dp, height = 30.dp), if (on) Palette.Accent else Palette.Text.copy(alpha = 0.75f))
                Text(layout.label, color = if (on) Palette.Text else Palette.Muted, fontSize = 11.5.sp, maxLines = 1, modifier = Modifier.padding(top = 6.dp))
            }
        }
    }
    Spacer(Modifier.height(6.dp))
}

/** A tiny drawing of each layout, for the picker. */
@Composable
internal fun LayoutGlyph(layout: RowLayout, modifier: Modifier, tint: Color) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        fun box(x: Float, y: Float, bw: Float, bh: Float, r: Float = 0.15f) {
            drawRoundRect(color = tint, topLeft = Offset(x * w, y * h), size = Size(bw * w, bh * h), cornerRadius = CornerRadius(r * minOf(w, h)))
        }
        when (layout) {
            RowLayout.TILES -> {
                box(0.02f, 0.05f, 0.44f, 0.9f, 0.2f)
                box(0.54f, 0.05f, 0.44f, 0.9f, 0.2f)
            }
            RowLayout.COVERS -> for (i in 0..2) box(0.02f + i * 0.34f, 0.1f, 0.3f, 0.8f)
            RowLayout.BIG -> {
                box(0.02f, 0.02f, 0.62f, 0.96f, 0.2f)
                box(0.72f, 0.02f, 0.26f, 0.96f, 0.2f)
            }
            RowLayout.GRID -> for (i in 0..1) for (j in 0..1) box(0.1f + i * 0.46f, 0.04f + j * 0.5f, 0.38f, 0.42f)
            RowLayout.LIST -> for (i in 0..2) box(0.05f, 0.04f + i * 0.34f, 0.9f, 0.24f, 0.3f)
            RowLayout.CIRCLES -> for (i in 0..2) drawCircle(tint, minOf(w, h) * 0.34f, Offset(w * (0.2f + i * 0.3f), h * 0.5f))
            RowLayout.CHIPS -> for (i in 0..2) box(0.02f + i * 0.34f, 0.3f, 0.3f, 0.4f, 0.5f)
            RowLayout.CARDS -> for (i in 0..2) box(0.02f + i * 0.34f, 0.08f, 0.3f, 0.84f, 0.2f)
            RowLayout.CARD -> box(0.04f, 0.1f, 0.92f, 0.8f, 0.2f)
        }
    }
}

// ---- one control per kind of option -------------------------------------------------------------

@Composable
private fun OptionControl(row: HomeRow, opt: RowOption) {
    val set: (Any?) -> Unit = { HomeLayout.setOption(row.id, opt.key, it) }
    when (opt.kind) {
        OptionKind.TOGGLE -> ToggleLine(opt.label, opt.note, row.boolOpt(opt.key)) { set(it) }
        OptionKind.SLIDER -> SliderLine(opt, row.intOpt(opt.key)) { set(it) }
        OptionKind.STEPPER -> StepperLine(opt, row.intOpt(opt.key)) { set(it) }
        OptionKind.CHOICE -> ChoiceLine(opt, row.strOpt(opt.key)) { set(it) }
        OptionKind.TEXT -> TextLine(row.id, opt, row.options[opt.key] as? String ?: "") { set(it) }
        OptionKind.MULTI -> MultiLine(opt, row.listOpt(opt.key)) { set(it.joinToString(",")) }
    }
}

@Composable
private fun ToggleLine(label: String, note: String?, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f).padding(end = 12.dp)) {
            Text(label, color = Palette.Text, fontSize = 15.sp)
            if (note != null) Text(note, color = Palette.Muted, fontSize = 12.sp)
        }
        NeedleSwitch(checked, onChange)
    }
}

@Composable
private fun SliderLine(opt: RowOption, value: Int, onChange: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(opt.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
            Text("$value${if (opt.unit.isEmpty()) "" else " " + opt.unit}", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
        Slider(
            value = value.toFloat(),
            onValueChange = { onChange(it.roundToInt()) },
            valueRange = opt.min.toFloat()..opt.max.toFloat(),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Palette.Accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f)
            )
        )
    }
}

@Composable
private fun StepperLine(opt: RowOption, value: Int, onChange: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(opt.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
        RoundIconButton(NeedleIcon.MINUS, { if (value > opt.min) onChange(value - 1) }, size = 38.dp, iconSize = 18.dp)
        Text("$value", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.width(44.dp), textAlign = androidx.compose.ui.text.style.TextAlign.Center)
        RoundIconButton(NeedleIcon.PLUS, { if (value < opt.max) onChange(value + 1) }, size = 38.dp, iconSize = 18.dp)
    }
}

@Composable
private fun ChoiceLine(opt: RowOption, value: String, onChange: (String) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(opt.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            opt.choices.forEach { (key, label) -> Chip(label, key == value, { onChange(key) }) }
        }
        if (opt.note != null) Text(opt.note, color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}

@Composable
private fun MultiLine(opt: RowOption, selected: List<String>, onChange: (List<String>) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(opt.label, color = Palette.Text, fontSize = 15.sp)
        Text("They show in the order you pick them.", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp, bottom = 10.dp))
        opt.choices.chunked(3).forEach { chunk ->
            Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                chunk.forEach { (key, label) ->
                    Chip(
                        label, key in selected,
                        {
                            val next = if (key in selected) selected - key else selected + key
                            if (next.isNotEmpty()) onChange(next)
                        },
                        Modifier.weight(1f)
                    )
                }
                repeat(3 - chunk.size) { Spacer(Modifier.weight(1f)) }
            }
        }
    }
}

@Composable
private fun TextLine(rowId: String, opt: RowOption, stored: String, onChange: (String) -> Unit) {
    var text by remember(rowId, opt.key) { mutableStateOf(stored) }
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        Text(opt.label, color = Palette.Text, fontSize = 15.sp, modifier = Modifier.padding(bottom = 8.dp))
        Box(Modifier.fillMaxWidth().clip(cornerShape(16.dp)).background(Palette.Card2).padding(horizontal = 16.dp, vertical = 14.dp)) {
            BasicTextField(
                value = text,
                onValueChange = { text = it.take(40); onChange(text) },
                singleLine = true,
                textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                cursorBrush = SolidColor(Palette.Accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    Box {
                        if (text.isEmpty()) Text("Row name", color = Palette.Muted, fontSize = 15.sp)
                        inner()
                    }
                }
            )
        }
        if (opt.note != null) Text(opt.note, color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
    }
}
