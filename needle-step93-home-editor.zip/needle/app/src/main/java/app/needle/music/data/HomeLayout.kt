package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject

/**
 * Which rows Home shows, in what order and how each one looks, plus the pills under the title.
 *
 * The whole thing is one small document (see [toJson]) kept in SharedPreferences, exported and imported as a
 * `.json` layout file, and included in backups. Row kinds and their options are declared in [RowRegistry].
 * It is Compose state, so Home and the editor update the moment something changes.
 *
 * Old installs saved a plain order/hidden list; [init] and [fromJson] still read that and convert it.
 */
object HomeLayout {
    const val FORMAT = "needle-home-layout"
    const val VERSION = 2

    private class Snapshot(
        val pages: Map<String, List<HomeRow>>,
        val tabOrder: List<String>,
        val hiddenTabs: Set<String>,
        val start: String
    )

    private class Parsed(
        val pages: Map<String, List<HomeRow>>,
        val tabOrder: List<String>,
        val hiddenTabs: Set<String>,
        val start: String
    )

    private var prefs: SharedPreferences? = null
    private var appContext: Context? = null

    private val pages = mutableStateOf<Map<String, List<HomeRow>>>(emptyMap())
    private val tabOrder = mutableStateOf(HomeDefaults.tabs)
    private val hiddenTabs = mutableStateOf<Set<String>>(emptySet())

    /** NEW or POPULAR: the page Home opens on. */
    val startTab = mutableStateOf("POPULAR")

    private val history = ArrayList<Snapshot>()
    /** Changes whenever the undo stack does, so the editor can enable or disable Undo. */
    val undoCount = mutableStateOf(0)

    // ---- start-up and saving ----

    fun init(context: Context) {
        if (prefs != null) return
        val app = context.applicationContext
        appContext = app
        val p = app.getSharedPreferences("needle_home", Context.MODE_PRIVATE)
        prefs = p
        val saved = p.getString("layout_v2", null)
        val parsed = saved?.let { runCatching { parse(JSONObject(it)) }.getOrNull() }
            ?: legacyFromPrefs(p)
            ?: defaults()
        applyParsed(parsed)
        save()
    }

    internal fun context(): Context? = appContext

    private fun defaults() = Parsed(HomeDefaults.pages(), HomeDefaults.tabs, emptySet(), "POPULAR")

    private fun applyParsed(p: Parsed) {
        pages.value = p.pages
        tabOrder.value = p.tabOrder
        hiddenTabs.value = p.hiddenTabs
        startTab.value = p.start
    }

    private fun save() {
        prefs?.edit()?.putString("layout_v2", toJson().toString())?.apply()
    }

    private fun snapshot() = Snapshot(pages.value, tabOrder.value, hiddenTabs.value, startTab.value)

    private fun push() {
        history.add(snapshot())
        if (history.size > 60) history.removeAt(0)
        undoCount.value = history.size
    }

    fun undo(): Boolean {
        if (history.isEmpty()) return false
        val s = history.removeAt(history.lastIndex)
        pages.value = s.pages
        tabOrder.value = s.tabOrder
        hiddenTabs.value = s.hiddenTabs
        startTab.value = s.start
        undoCount.value = history.size
        save()
        return true
    }

    private fun commit(newPages: Map<String, List<HomeRow>>, undoable: Boolean = true) {
        if (undoable) push()
        pages.value = newPages
        save()
    }

    // ---- reading ----

    /** A page's rows in order, hidden ones included (this is what the editor lists). */
    fun rows(page: String): List<HomeRow> = pages.value[page].orEmpty()

    fun visibleRows(page: String): List<HomeRow> = rows(page).filter { it.visible }

    fun row(id: String): HomeRow? = pages.value.values.firstNotNullOfOrNull { list -> list.firstOrNull { it.id == id } }

    fun pageOf(id: String): String? = pages.value.entries.firstOrNull { e -> e.value.any { it.id == id } }?.key

    /** NewScreen asks for the ids of its visible sections. Rows of the New page always use their type id. */
    fun visibleSectionIds(tab: String): List<String> = visibleRows(tab).map { it.id }

    fun isVisible(id: String): Boolean = row(id)?.visible ?: false

    // ---- rows ----

    private fun mutatePage(page: String, undoable: Boolean = true, change: (List<HomeRow>) -> List<HomeRow>) {
        val before = rows(page)
        val after = change(before)
        if (after == before) return
        commit(pages.value + (page to after), undoable)
    }

    private fun mutateRow(id: String, undoable: Boolean = true, change: (HomeRow) -> HomeRow) {
        val page = pageOf(id) ?: return
        mutatePage(page, undoable) { list -> list.map { if (it.id == id) change(it) else it } }
    }

    private fun freshId(typeId: String): String {
        val used = pages.value.values.flatten().map { it.id }.toSet()
        if (typeId !in used) return typeId
        var n = 2
        while ("$typeId#$n" in used) n++
        return "$typeId#$n"
    }

    /** Adds a row of this type after [afterId] (or at the end of its page). Returns its id, or null if not allowed. */
    fun add(typeId: String, afterId: String? = null): String? {
        val type = RowRegistry.byId(typeId) ?: return null
        val list = rows(type.page)
        if (type.unique && list.any { it.type == typeId }) return null
        val row = HomeRow(freshId(typeId), typeId)
        val at = afterId?.let { a -> list.indexOfFirst { it.id == a }.takeIf { it >= 0 }?.plus(1) } ?: list.size
        commit(pages.value + (type.page to list.toMutableList().apply { add(at, row) }))
        return row.id
    }

    fun duplicate(id: String): String? {
        val src = row(id) ?: return null
        val type = src.spec ?: return null
        if (type.unique) return null
        val page = pageOf(id) ?: return null
        val copy = src.copy(id = freshId(src.type))
        val list = rows(page)
        val at = list.indexOfFirst { it.id == id } + 1
        commit(pages.value + (page to list.toMutableList().apply { add(at, copy) }))
        return copy.id
    }

    fun remove(id: String) {
        val page = pageOf(id) ?: return
        mutatePage(page) { list -> list.filter { it.id != id } }
    }

    fun setVisible(id: String, visible: Boolean) = mutateRow(id) { it.copy(visible = visible) }

    /** Puts a page's rows in the order of [ids]. Rows missing from [ids] keep their relative order at the end. */
    fun setOrder(page: String, ids: List<String>) {
        mutatePage(page) { list ->
            val byId = list.associateBy { it.id }
            val ordered = ids.mapNotNull { byId[it] }.distinctBy { it.id }
            ordered + list.filter { r -> ordered.none { it.id == r.id } }
        }
    }

    /** Reorders only the shown rows; hidden rows stay in their slots. */
    fun setVisibleOrder(page: String, ids: List<String>) {
        mutatePage(page) { list ->
            val byId = list.associateBy { it.id }
            val newVisible = ids.mapNotNull { byId[it] }.filter { it.visible }.distinctBy { it.id }.toMutableList()
            val missing = list.filter { it.visible && newVisible.none { n -> n.id == it.id } }
            newVisible += missing
            var next = 0
            list.map { r -> if (r.visible && next < newVisible.size) newVisible[next++] else r }
        }
    }

    // ---- options ----

    private var lastEditTag: String? = null
    private var lastEditAt = 0L

    /** Sets one option (null clears it back to the default). Quick repeated edits of one option are one undo step. */
    fun setOption(id: String, key: String, value: Any?) {
        val row = row(id) ?: return
        val type = row.spec ?: return
        var clean: Any? = if (value == null) null else (sanitizeOption(type, key, value) ?: return)
        if (clean is String && key == "headerText" && clean.isEmpty()) clean = null
        val now = System.currentTimeMillis()
        val tag = "$id/$key"
        val undoable = !(tag == lastEditTag && now - lastEditAt < 1500)
        lastEditTag = tag
        lastEditAt = now
        mutateRow(id, undoable) { it.with(key, clean) }
    }

    fun resetRow(id: String) = mutateRow(id) { it.copy(options = emptyMap()) }

    /** Makes [targetId] look like [sourceId] wherever the target has the same options. */
    fun copyOptions(targetId: String, sourceId: String) {
        val src = row(sourceId) ?: return
        val target = row(targetId) ?: return
        val type = target.spec ?: return
        val copied = HashMap<String, Any>()
        for ((k, v) in src.options) sanitizeOption(type, k, v)?.let { copied[k] = it }
        mutateRow(targetId) { it.copy(options = copied) }
    }

    private val styleKeys: Set<String> =
        (HeaderOptions + SpaceOptions + CardOptions).map { it.key }.toSet() - "headerText" - "header"

    /** Gives every other row on the page the same header and style options as [sourceId]. */
    fun applyStyleToAll(sourceId: String) {
        val src = row(sourceId) ?: return
        val page = pageOf(sourceId) ?: return
        mutatePage(page) { list ->
            list.map { r ->
                val type = r.spec
                if (r.id == sourceId || type == null || type.external) r
                else {
                    val kept = r.options.filterKeys { it !in styleKeys }.toMutableMap()
                    for ((k, v) in src.options) {
                        if (k in styleKeys) sanitizeOption(type, k, v)?.let { kept[k] = it }
                    }
                    r.copy(options = kept)
                }
            }
        }
    }

    // ---- pills ----

    fun tabs(): List<String> = tabOrder.value
    fun visibleTabs(): List<String> = tabOrder.value.filter { it !in hiddenTabs.value }
    fun isTabVisible(name: String): Boolean = name !in hiddenTabs.value

    fun toggleTab(name: String) {
        if (isTabVisible(name)) {
            if (visibleTabs().size <= 1) return // keep at least one pill
            push()
            hiddenTabs.value = hiddenTabs.value + name
        } else {
            push()
            hiddenTabs.value = hiddenTabs.value - name
        }
        save()
    }

    fun moveTab(name: String, delta: Int) {
        val list = tabOrder.value.toMutableList()
        val at = list.indexOf(name)
        val to = at + delta
        if (at < 0 || to !in list.indices) return
        push()
        java.util.Collections.swap(list, at, to)
        tabOrder.value = list
        save()
    }

    fun setStartTab(name: String) {
        if (name != "NEW" && name != "POPULAR") return
        push()
        startTab.value = name
        save()
    }

    fun reset() {
        push()
        applyParsed(defaults())
        save()
    }

    // ---- the layout file ----

    fun toJson(name: String = ""): JSONObject {
        val pagesJson = JSONObject()
        for ((page, list) in pages.value) {
            val arr = JSONArray()
            for (r in list) {
                val o = JSONObject().put("id", r.id).put("type", r.type).put("visible", r.visible)
                if (r.options.isNotEmpty()) {
                    val oo = JSONObject()
                    for ((k, v) in r.options) oo.put(k, v)
                    o.put("options", oo)
                }
                arr.put(o)
            }
            pagesJson.put(page, arr)
        }
        val tabsJson = JSONArray()
        for (t in tabOrder.value) tabsJson.put(JSONObject().put("id", t).put("visible", t !in hiddenTabs.value))
        val root = JSONObject().put("format", FORMAT).put("version", VERSION)
        if (name.isNotBlank()) root.put("name", name)
        return root.put("start", startTab.value).put("tabs", tabsJson).put("pages", pagesJson)
    }

    fun exportText(name: String = ""): String = toJson(name).toString(2)

    /** Applies a layout file (new or old format). The change can be undone. Returns false if it is not a layout. */
    fun fromJson(o: JSONObject): Boolean {
        val parsed = runCatching { parse(o) }.getOrNull() ?: return false
        push()
        applyParsed(parsed)
        save()
        return true
    }

    fun importText(text: String): Boolean = runCatching { fromJson(JSONObject(text)) }.getOrDefault(false)

    /** The rows of a layout file without applying it, for thumbnails. */
    fun previewPages(o: JSONObject): Map<String, List<HomeRow>>? = runCatching { parse(o)?.pages }.getOrNull()

    private fun jsonValue(v: Any?): Any? = when (v) {
        is Boolean, is String, is Int, is Double -> v
        is Long -> v.toInt()
        else -> null
    }

    private fun parse(o: JSONObject): Parsed? {
        if (!o.has("pages")) return legacy(o)
        if (o.optString("format", FORMAT) != FORMAT) return null
        val pagesObj = o.optJSONObject("pages") ?: return null
        val used = HashSet<String>()
        val out = LinkedHashMap<String, List<HomeRow>>()
        for (page in listOf("POPULAR", "NEW")) {
            val list = parseRows(pagesObj.optJSONArray(page), page, used).toMutableList()
            // Rows of the New page are drawn by NewScreen: if a file leaves one out, it comes back instead of vanishing.
            if (page == "NEW") {
                for (t in RowRegistry.forPage("NEW")) if (list.none { it.type == t.id }) list += HomeRow(t.id, t.id)
            }
            out[page] = list
        }
        val tabs = ArrayList<String>()
        val hidden = HashSet<String>()
        val tabsArr = o.optJSONArray("tabs")
        if (tabsArr != null) {
            for (i in 0 until tabsArr.length()) {
                val t = tabsArr.optJSONObject(i) ?: continue
                val id = t.optString("id")
                if (id in HomeDefaults.tabs && id !in tabs) {
                    tabs += id
                    if (!t.optBoolean("visible", true)) hidden += id
                }
            }
        }
        for (t in HomeDefaults.tabs) if (t !in tabs) tabs += t
        if (tabs.all { it in hidden }) hidden.clear()
        val start = o.optString("start", "POPULAR").let { if (it == "NEW" || it == "POPULAR") it else "POPULAR" }
        return Parsed(out, tabs, hidden, start)
    }

    private fun parseRows(arr: JSONArray?, page: String, used: MutableSet<String>): List<HomeRow> {
        val out = ArrayList<HomeRow>()
        if (arr == null) return out
        for (i in 0 until arr.length()) {
            val r = arr.optJSONObject(i) ?: continue
            val type = RowRegistry.byId(r.optString("type")) ?: continue
            if (type.page != page) continue
            if (type.unique && out.any { it.type == type.id }) continue
            var id = if (type.external) type.id else r.optString("id").ifBlank { type.id }
            if (id in used) {
                var n = 2
                while ("${type.id}#$n" in used) n++
                id = "${type.id}#$n"
            }
            used += id
            val options = HashMap<String, Any>()
            val oo = r.optJSONObject("options")
            if (oo != null) {
                val keys = oo.keys()
                while (keys.hasNext()) {
                    val k = keys.next()
                    sanitizeOption(type, k, jsonValue(oo.opt(k)))?.let { options[k] = it }
                }
            }
            out += HomeRow(id, type.id, r.optBoolean("visible", true), options)
        }
        return out
    }

    // ---- old layouts (a saved order and hidden list) ----

    private fun JSONObject.strings(key: String): List<String> {
        val a = optJSONArray(key) ?: return emptyList()
        return List(a.length()) { a.optString(it) }
    }

    private fun csv(p: SharedPreferences, key: String): List<String> =
        (p.getString(key, "") ?: "").split(',').filter { it.isNotBlank() }

    private fun legacyFromPrefs(p: SharedPreferences): Parsed? {
        if (!p.contains("order") && !p.contains("hidden") && !p.contains("tabs") && !p.contains("start")) return null
        return legacyParsed(csv(p, "order"), csv(p, "hidden"), csv(p, "tabs"), csv(p, "hiddenTabs"), p.getString("start", "POPULAR") ?: "POPULAR")
    }

    private fun legacy(o: JSONObject): Parsed? {
        if (!o.has("order") && !o.has("hidden") && !o.has("tabs")) return null
        return legacyParsed(o.strings("order"), o.strings("hidden"), o.strings("tabs"), o.strings("hiddenTabs"), o.optString("start", "POPULAR"))
    }

    private fun legacyParsed(order: List<String>, hidden: List<String>, tabs: List<String>, hidTabs: List<String>, start: String): Parsed {
        val oldIds = listOf("moments", "new_hero", "new_recent", "new_singles", "new_needtags", "pop_heroes", "pop_albums", "pop_week", "pop_rediscover")
        val ordered = order.filter { it in oldIds }.distinct().let { kept -> kept + oldIds.filter { it !in kept } }
            // Latest Moments was added later: a saved layout without it gets it at the top.
            .let { all -> if ("moments" in order) all else listOf("moments") + all.filter { it != "moments" } }
        val result = LinkedHashMap<String, MutableList<HomeRow>>()
        result["POPULAR"] = ArrayList()
        result["NEW"] = ArrayList()
        // Black & Green always had its artists row on top, so keep it.
        if (Skins.blackGreen) result["POPULAR"]!!.add(HomeRow("artists", "artists"))
        for (id in ordered) {
            val type = RowRegistry.byId(id) ?: continue
            result[type.page]?.add(HomeRow(id, id, id !in hidden))
        }
        val tabList = tabs.filter { it in HomeDefaults.tabs }.distinct().let { kept -> kept + HomeDefaults.tabs.filter { it !in kept } }
        var hiddenTabSet = hidTabs.filter { it in HomeDefaults.tabs }.toSet()
        if (tabList.all { it in hiddenTabSet }) hiddenTabSet = emptySet()
        return Parsed(result, tabList, hiddenTabSet, if (start == "NEW" || start == "POPULAR") start else "POPULAR")
    }
}
