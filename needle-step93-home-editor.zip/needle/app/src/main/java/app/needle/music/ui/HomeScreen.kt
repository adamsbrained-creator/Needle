package app.needle.music.ui

import app.needle.music.data.Skins
import app.needle.music.data.PinnedArtists
import app.needle.music.data.artistKey
import app.needle.music.data.isKnownArtist
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.HomeAlbum
import app.needle.music.data.HomeLayout
import app.needle.music.data.HeroCard
import app.needle.music.data.HomeState
import app.needle.music.data.Song
import app.needle.music.data.WeekStats
import app.needle.music.data.formatListened
import app.needle.music.data.notPlayedLabel
import app.needle.music.playback.PlayerViewModel
import androidx.compose.foundation.layout.navigationBarsPadding
import app.needle.music.data.MixData
import app.needle.music.data.RadioStation

/** The pills under the Home title. [ready] is false until that page exists. */
enum class HomeTab(val label: String, val ready: Boolean) {
    NEW("New", true),
    POPULAR("Popular", true),
    MOST_PLAYED("Most played", true),
    SINGLES("Singles", true)
}

/**
 * Home / Popular page. What sits between the pills and the end of the page is the list of rows from
 * [HomeLayout] (edited in the Home editor); each row draws itself in HomeRows.kt.
 * [onViewAllAlbums] and [onOpenStats] are null until those pages exist; the links stay hidden until then.
 */
@Composable
fun HomeScreen(
    home: HomeState?,
    bottomPadding: Dp,
    onPlay: (List<Song>) -> Unit,
    onTabSelected: (HomeTab) -> Unit,
    /** Tapping an album card opens its page; only the "Play now" buttons play. */
    onOpenAlbum: (List<Song>) -> Unit = {},
    modifier: Modifier = Modifier,
    profileInitial: String = "E",
    onSearch: () -> Unit = {},
    onProfile: () -> Unit = {},
    onViewAllAlbums: (() -> Unit)? = null,
    onOpenStats: (() -> Unit)? = null,
    genrePrompt: Boolean = false,
    onChooseGenres: () -> Unit = {},
    onDismissGenrePrompt: () -> Unit = {},
    onOpenArtist: ((String) -> Unit)? = null,
    onOpenArtists: (() -> Unit)? = null,
    moments: List<Song> = emptyList(),
    momentsPlayer: PlayerViewModel? = null,
    onPlayMoment: (Song) -> Unit = {},
    onMomentToPlaylist: (Song) -> Unit = {},
    /** Every album in the library, for rows such as Roulette. */
    albums: List<HomeAlbum>? = null,
    mixes: List<MixData> = emptyList(),
    stations: List<RadioStation> = emptyList(),
    /** A Shortcuts row was tapped; the key says which ("songs", "albums", "artists" ...). */
    onShortcut: (String) -> Unit = {},
    onOpenMix: (String) -> Unit = {},
    onPlayStation: (RadioStation) -> Unit = {},
    /** Opens the Home editor. Null hides the button. */
    onEditHome: (() -> Unit)? = null
) {
    val ctx = HomeRowContext(
        home = home, albums = albums, moments = moments, momentsPlayer = momentsPlayer, mixes = mixes, stations = stations,
        onPlay = onPlay, onOpenAlbum = onOpenAlbum, onViewAllAlbums = onViewAllAlbums, onOpenStats = onOpenStats,
        onOpenArtist = onOpenArtist, onOpenArtists = onOpenArtists, onShortcut = onShortcut, onOpenMix = onOpenMix,
        onPlayStation = onPlayStation, onPlayMoment = onPlayMoment, onMomentToPlaylist = onMomentToPlaylist
    )
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item { HomeHeader(profileInitial, onSearch, onProfile) }
        item { HomeTabs(selected = HomeTab.POPULAR, onSelect = onTabSelected) }
        if (genrePrompt) item { GenrePromptCard(onChooseGenres, onDismissGenrePrompt) }

        if (home == null) return@LazyColumn

        val rows = HomeLayout.visibleRows("POPULAR")
        items(rows, key = { it.id }) { row -> HomeRowView(row, ctx) }
        if (rows.isEmpty()) {
            item {
                Text(
                    "Every row is hidden. Bring them back with Edit Home below.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
                )
            }
        }
        if (onEditHome != null) item { EditHomeButton(onEditHome) }
    }
}

/** A quiet pill at the end of the page that opens the Home editor. */
@Composable
private fun EditHomeButton(onClick: () -> Unit) {
    Box(Modifier.fillMaxWidth().padding(top = 26.dp), contentAlignment = Alignment.Center) {
        Row(
            Modifier.clip(CircleShape).background(Palette.Card2).clickable(onClick = onClick)
                .padding(horizontal = 20.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleIconView(NeedleIcon.PENCIL, Palette.Muted, size = 18.dp)
            Text("Edit Home", color = Palette.Muted, fontSize = 14.sp, modifier = Modifier.padding(start = 8.dp))
        }
    }
}

// ---- header and tabs -------------------------------------------------------------------

@Composable
internal fun HomeHeader(initial: String, onSearch: () -> Unit, onProfile: () -> Unit = {}) {
    if (Skins.blackGreen) {
        // Black & Green: a big greeting on the left, search and the profile on the right.
        val hour = remember { java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY) }
        val greeting = when {
            hour < 5 -> "Good night"
            hour < 12 -> "Good morning"
            hour < 18 -> "Good afternoon"
            else -> "Good evening"
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                greeting, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 28.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
            RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)
            Spacer(Modifier.width(10.dp))
            Box(
                Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(Palette.Accent)
                    .clickable(onClick = onProfile),
                contentAlignment = Alignment.Center
            ) { Text(initial, color = Color.Black, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
        }
        return
    }
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)

        Text(
            "Needle", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 21.sp,
            textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
        )

        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFD9A38B), Color(0xFF6B4A5E))))
                .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                .clickable(onClick = onProfile),
            contentAlignment = Alignment.Center
        ) { Text(initial, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
internal fun HomeTabs(selected: HomeTab, onSelect: (HomeTab) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(start = 18.dp, end = 18.dp, top = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HomeLayout.visibleTabs().mapNotNull { name -> HomeTab.entries.firstOrNull { it.name == name } }.forEach { tab ->
            val on = tab == selected
            Text(
                tab.label,
                color = if (on) Color(0xFF111111) else Palette.Text,
                fontSize = 14.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (on) (if (Skins.blackGreen) Palette.Accent else Color.White) else Palette.Card2)
                    .then(if (tab.ready && !on) Modifier.clickable { onSelect(tab) } else Modifier)
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            )
        }
    }
}

@Composable
internal fun SectionHeader(title: String, action: String, onAction: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(title, color = Palette.Text, fontSize = if (Skins.blackGreen) 19.sp else 18.sp, fontWeight = if (Skins.blackGreen) FontWeight.SemiBold else FontWeight.Medium, modifier = Modifier.weight(1f))
        if (onAction != null) {
            if (Skins.blackGreen) {
                Row(Modifier.clickable(onClick = onAction), verticalAlignment = Alignment.CenterVertically) {
                    Text(action, color = Palette.Muted, fontSize = 13.sp)
                    NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 16.dp)
                }
            } else {
                Text(action, color = Color(0xFFDDDDDD), fontSize = 12.sp, modifier = Modifier.clickable(onClick = onAction))
            }
        }
    }
}

/** The card that asks for the favourite genres once. "Not now" hides it for good; Settings keeps the picker. */
@Composable
private fun GenrePromptCard(onChoose: () -> Unit, onDismiss: () -> Unit) {
    val shape = cornerShape(24.dp)
    Column(
        Modifier
            .padding(start = 18.dp, end = 18.dp, top = 14.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Accent.copy(alpha = 0.40f), Color.White.copy(alpha = 0.06f))))
            .padding(18.dp)
    ) {
        Text("Choose your genres", color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
        Text(
            "Pick the genres you like. They come first on Home, in the picks and in Rediscover.",
            color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                "Choose", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).background(Color.White).clickable(onClick = onChoose)
                    .padding(horizontal = 22.dp, vertical = 11.dp)
            )
            Text(
                "Not now", color = Palette.Muted, fontSize = 14.sp,
                modifier = Modifier.padding(start = 6.dp).clip(CircleShape).clickable(onClick = onDismiss)
                    .padding(horizontal = 16.dp, vertical = 11.dp)
            )
        }
    }
}

// ---- artwork -----------------------------------------------------------------------------

/** Large cover that fills [modifier]. Shows the pink placeholder while loading or when the file has no cover. */
@Composable
internal fun Cover(song: Song, modifier: Modifier) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peekLarge(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peekLarge(song) ?: ArtworkLoader.loadLarge(context, song)
    }
    val bitmap = art
    if (bitmap != null) {
        Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
    } else {
        ArtworkPlaceholder(modifier)
    }
}

/** The page Home opens on: the one picked in the layout editor, or the first pill that is still shown. */
internal fun startHomeTab(): HomeTab {
    val shown = HomeLayout.visibleTabs()
    val want = HomeLayout.startTab.value
    val name = if (want in shown) want else (shown.firstOrNull() ?: "POPULAR")
    return HomeTab.entries.firstOrNull { it.name == name } ?: HomeTab.POPULAR
}
