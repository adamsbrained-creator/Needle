package app.needle.music.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Whole-Home layouts you can switch to. Built-in ones are layout files in assets/home_presets/ (add a file there
 * and it shows up in the editor); the ones you save yourself are kept next to the layout in SharedPreferences.
 */
object HomePresets {
    class Preset(val id: String, val name: String, val about: String, val json: JSONObject, val builtIn: Boolean)

    fun builtIn(): List<Preset> {
        val ctx = HomeLayout.context() ?: return emptyList()
        val files = runCatching { ctx.assets.list("home_presets")?.filter { it.endsWith(".json") }?.sorted() }
            .getOrNull().orEmpty()
        return files.mapNotNull { file ->
            runCatching {
                val text = ctx.assets.open("home_presets/$file").bufferedReader().use { it.readText() }
                val o = JSONObject(text)
                val id = file.removeSuffix(".json")
                Preset(id, o.optString("name", id), o.optString("about", ""), o, true)
            }.getOrNull()
        }
    }

    private fun prefs(): android.content.SharedPreferences? =
        HomeLayout.context()?.getSharedPreferences("needle_home", Context.MODE_PRIVATE)

    fun user(): List<Preset> {
        val text = prefs()?.getString("user_presets", null) ?: return emptyList()
        val arr = runCatching { JSONArray(text) }.getOrNull() ?: return emptyList()
        val out = ArrayList<Preset>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val layout = o.optJSONObject("layout") ?: continue
            val name = o.optString("name", "My layout")
            out += Preset("user$i", name, "Saved by you", layout, false)
        }
        return out
    }

    private fun writeUser(list: List<Preset>) {
        val arr = JSONArray()
        for (p in list) arr.put(JSONObject().put("name", p.name).put("layout", p.json))
        prefs()?.edit()?.putString("user_presets", arr.toString())?.apply()
    }

    /** Saves the layout as it is now under this name (same name replaces the older one). */
    fun saveCurrent(name: String) {
        val clean = name.trim().ifEmpty { "My layout" }.take(30)
        val others = user().filter { it.name != clean }
        writeUser(others + Preset("new", clean, "Saved by you", HomeLayout.toJson(clean), false))
    }

    fun deleteUser(preset: Preset) {
        if (preset.builtIn) return
        writeUser(user().filter { it.id != preset.id })
    }
}
