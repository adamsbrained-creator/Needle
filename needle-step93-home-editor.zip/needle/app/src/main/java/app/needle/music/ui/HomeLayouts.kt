package app.needle.music.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeLayout
import app.needle.music.data.HomePresets
import app.needle.music.data.HomeRow
import app.needle.music.data.PreviewKind
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Whole-Home layouts: switch to a preset, save the current Home as your own, and move a layout in or out as a
 * .json file (or by clipboard / share) to back it up or send it to someone.
 */
@Composable
internal fun LayoutsPage(onClose: () -> Unit) {
    val context = LocalContext.current
    var tick by remember { mutableStateOf(0) }
    val builtIn = remember { HomePresets.builtIn() }
    val mine = remember(tick) { HomePresets.user() }
    var confirm by remember { mutableStateOf<HomePresets.Preset?>(null) }
    var saving by remember { mutableStateOf(false) }
    var restoring by remember { mutableStateOf(false) }

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            val ok = runCatching {
                context.contentResolver.openOutputStream(uri)?.use { it.write(HomeLayout.exportText().toByteArray()) } != null
            }.getOrDefault(false)
            Toast.makeText(context, if (ok) "Layout saved" else "Could not save the file", Toast.LENGTH_SHORT).show()
        }
    }
    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching { context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } }.getOrNull()
            val ok = text != null && HomeLayout.importText(text)
            Toast.makeText(context, if (ok) "Layout loaded. Undo is in the editor." else "That file is not a Home layout", Toast.LENGTH_SHORT).show()
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(NeedleIcon.BACK, onClose, size = 42.dp, iconSize = 22.dp)
            Text("Home layouts", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            // The layout in use now.
            Column(Modifier.padding(top = 12.dp).fillMaxWidth().clip(cornerShape(24.dp)).background(Palette.Card).padding(16.dp)) {
                Text("Your Home now", color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    "${HomeLayout.visibleRows("POPULAR").size} rows showing, ${HomeLayout.rows("POPULAR").size} on the page.",
                    color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp, bottom = 12.dp)
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    PillButton("Save as preset", { saving = true })
                    PillButton("Export file", { exportLauncher.launch("needle-home-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json") })
                    PillButton("Copy", {
                        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                        cm?.setPrimaryClip(ClipData.newPlainText("Needle Home layout", HomeLayout.exportText()))
                        Toast.makeText(context, "Layout copied", Toast.LENGTH_SHORT).show()
                    })
                    PillButton("Share", {
                        try {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, HomeLayout.exportText())
                            }
                            context.startActivity(Intent.createChooser(send, null))
                        } catch (e: Exception) {
                            Toast.makeText(context, "Could not share the layout", Toast.LENGTH_SHORT).show()
                        }
                    })
                }
            }

            Text("Presets", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
            PresetGrid(builtIn, onPick = { confirm = it }, onDelete = null)
            if (mine.isNotEmpty()) {
                Text("Yours", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
                PresetGrid(mine, onPick = { confirm = it }, onDelete = { HomePresets.deleteUser(it); tick++ })
            }

            Text("Bring a layout in", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PillButton("Import file", { importLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) })
                PillButton("Paste from clipboard", {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
                    val text = cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
                    val ok = text.isNotBlank() && HomeLayout.importText(text)
                    Toast.makeText(context, if (ok) "Layout loaded. Undo is in the editor." else "Copy a Home layout first", Toast.LENGTH_SHORT).show()
                })
            }
            Text(
                "A layout is a small .json file. Presets are just layout files too: put one in assets/home_presets and it appears above.",
                color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 10.dp)
            )

            Text("Start over", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
            PillButton("Restore the default Home", { restoring = true })
            Spacer(Modifier.height(48.dp))
        }
    }

    confirm?.let { preset ->
        AlertDialog(
            shape = cornerShape(28.dp), onDismissRequest = { confirm = null },
            containerColor = Palette.Surface, titleContentColor = Palette.Text, textContentColor = Palette.Muted,
            title = { Text("Use \u201c${preset.name}\u201d?") },
            text = { Text("Your Home is replaced by this layout. You can undo it from the editor.") },
            confirmButton = {
                TextButton(onClick = {
                    confirm = null
                    val ok = HomeLayout.fromJson(preset.json)
                    Toast.makeText(context, if (ok) "Layout applied" else "That layout could not be read", Toast.LENGTH_SHORT).show()
                    if (ok) onClose()
                }) { Text("Use it", color = Palette.Accent) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Palette.Muted) } }
        )
    }
    if (restoring) {
        AlertDialog(
            shape = cornerShape(28.dp), onDismissRequest = { restoring = false },
            containerColor = Palette.Surface, titleContentColor = Palette.Text, textContentColor = Palette.Muted,
            title = { Text("Restore the default Home?") },
            text = { Text("Every row and its settings go back to how Needle comes. You can undo it from the editor.") },
            confirmButton = { TextButton(onClick = { restoring = false; HomeLayout.reset(); onClose() }) { Text("Restore", color = Palette.Accent) } },
            dismissButton = { TextButton(onClick = { restoring = false }) { Text("Cancel", color = Palette.Muted) } }
        )
    }
    if (saving) {
        var name by remember { mutableStateOf("") }
        AlertDialog(
            shape = cornerShape(28.dp), onDismissRequest = { saving = false },
            containerColor = Palette.Surface, titleContentColor = Palette.Text,
            title = { Text("Save as preset") },
            text = {
                Box(Modifier.fillMaxWidth().clip(cornerShape(16.dp)).background(Palette.Card2).padding(horizontal = 16.dp, vertical = 14.dp)) {
                    BasicTextField(
                        value = name, onValueChange = { name = it.take(30) }, singleLine = true,
                        textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp), cursorBrush = SolidColor(Palette.Accent),
                        modifier = Modifier.fillMaxWidth(),
                        decorationBox = { inner ->
                            Box {
                                if (name.isEmpty()) Text("Preset name", color = Palette.Muted, fontSize = 15.sp)
                                inner()
                            }
                        }
                    )
                }
            },
            confirmButton = { TextButton(onClick = { HomePresets.saveCurrent(name); saving = false; tick++ }) { Text("Save", color = Palette.Accent) } },
            dismissButton = { TextButton(onClick = { saving = false }) { Text("Cancel", color = Palette.Muted) } }
        )
    }
}

@Composable
private fun PresetGrid(presets: List<HomePresets.Preset>, onPick: (HomePresets.Preset) -> Unit, onDelete: ((HomePresets.Preset) -> Unit)?) {
    presets.chunked(2).forEach { pair ->
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            pair.forEach { preset ->
                val rows = HomeLayout.previewPages(preset.json)?.get("POPULAR").orEmpty()
                Column(Modifier.weight(1f).clip(cornerShape(20.dp)).background(Palette.Card).clickable { onPick(preset) }.padding(8.dp)) {
                    Box {
                        LayoutThumb(rows, Modifier.fillMaxWidth().height(120.dp))
                        if (onDelete != null) {
                            Box(
                                Modifier.align(Alignment.TopEnd).padding(4.dp).size(36.dp).clip(androidx.compose.foundation.shape.CircleShape)
                                    .background(Color(0x99000000)).clickable { onDelete(preset) },
                                contentAlignment = Alignment.Center
                            ) { NeedleIconView(NeedleIcon.TRASH, Color.White, size = 16.dp) }
                        }
                    }
                    Text(preset.name, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(start = 4.dp, top = 8.dp))
                    Text(preset.about, color = Palette.Muted, fontSize = 11.5.sp, lineHeight = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(horizontal = 4.dp))
                }
            }
            if (pair.size == 1) Spacer(Modifier.weight(1f))
        }
    }
}

/** A layout drawn as the stack of its rows, from the layout file itself. */
@Composable
private fun LayoutThumb(rows: List<HomeRow>, modifier: Modifier) {
    Column(modifier.clip(cornerShape(14.dp)).background(Color(0xFF14121A)).padding(8.dp).clipToBounds(), verticalArrangement = Arrangement.spacedBy(5.dp)) {
        rows.filter { it.visible }.take(7).forEach { r ->
            val kind = r.spec?.preview ?: PreviewKind.COVERS
            val height = when (kind) {
                PreviewKind.HERO -> 30
                PreviewKind.BIG -> 24
                PreviewKind.COVERS -> 18
                PreviewKind.CIRCLES -> 14
                PreviewKind.CHIPS -> 9
                PreviewKind.BARS -> 14
                PreviewKind.LIST -> 16
                PreviewKind.CARD -> 18
            }
            val accent = kind == PreviewKind.HERO || kind == PreviewKind.BIG || kind == PreviewKind.COVERS
            Box(
                Modifier.fillMaxWidth().height(height.dp).clip(cornerShape(6.dp))
                    .background(if (accent) Palette.Accent.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.18f))
            )
        }
    }
}
