package app.needle.music.data

/**
 * The Home row registry.
 *
 * Everything the Home editor knows about a kind of row lives here, as plain data: its name, which layouts it
 * can use, which options it has (with limits and defaults). The editor's settings sheet and the "Add row"
 * gallery are generated from this file, so a new row type or a new option is a few lines here plus one
 * `when` branch in ui/HomeRows.kt that draws it. Nothing in the editor itself has to change.
 *
 * A row on the page is a [HomeRow]: a type id plus only the options the person changed. Anything not set
 * falls back to the default declared here, so improving a default improves every untouched row.
 */

enum class RowCategory(val label: String) {
    QUICK("Quick access"),
    MUSIC("Your music"),
    DISCOVER("Made for you"),
    RADIO("Radio"),
    STATS("Stats"),
    NEW("New page")
}

/** How a row lays out its items. Each type lists the ones it supports. */
enum class RowLayout(val id: String, val label: String) {
    TILES("tiles", "Tiles"),
    COVERS("covers", "Carousel"),
    BIG("big", "Big cover"),
    GRID("grid", "Grid"),
    LIST("list", "List"),
    CIRCLES("circles", "Circles"),
    CHIPS("chips", "Chips"),
    CARDS("cards", "Stat cards"),
    CARD("card", "Single card");

    companion object {
        fun of(id: String?): RowLayout? = entries.firstOrNull { it.id == id }
    }
}

/** What the little picture in the gallery and in layout thumbnails looks like. */
enum class PreviewKind { COVERS, BIG, CIRCLES, LIST, CHIPS, BARS, CARD, HERO }

enum class OptionKind { TOGGLE, SLIDER, STEPPER, CHOICE, TEXT, MULTI }

/** The tabs of the row settings sheet. A tab with no options for a row is not shown. */
enum class OptionTab(val label: String) {
    CONTENT("Content"),
    LAYOUT("Layout"),
    HEADER("Header"),
    STYLE("Style")
}

class RowOption(
    val key: String,
    val label: String,
    val kind: OptionKind,
    val tab: OptionTab,
    val default: Any? = null,
    val min: Int = 0,
    val max: Int = 0,
    val step: Int = 1,
    val unit: String = "",
    /** CHOICE and MULTI: (stored value, shown label). */
    val choices: List<Pair<String, String>> = emptyList(),
    val note: String? = null
)

class RowType(
    val id: String,
    val title: String,
    val about: String,
    val category: RowCategory,
    /** POPULAR (the Home page) or NEW. */
    val page: String,
    val layouts: List<RowLayout> = emptyList(),
    val own: List<RowOption> = emptyList(),
    /** Overrides for the shared defaults and for this type's own option defaults. */
    val defaults: Map<String, Any> = emptyMap(),
    /** Only one row of this type per layout. */
    val unique: Boolean = false,
    /** Drawn by its own page (the New page): it can only be shown, hidden and reordered. */
    val external: Boolean = false,
    /** Draws its own title, so it has no header options. */
    val selfHeader: Boolean = false,
    val preview: PreviewKind = PreviewKind.COVERS
) {
    /** All options of this type in sheet order: its own, then header, then style. */
    val options: List<RowOption> by lazy {
        when {
            external -> emptyList()
            selfHeader -> own + SpaceOptions
            else -> own + HeaderOptions + SpaceOptions + CardOptions
        }
    }

    fun option(key: String): RowOption? = if (key == "layout") null else options.firstOrNull { it.key == key }

    fun default(key: String): Any? {
        defaults[key]?.let { return it }
        return when (key) {
            "layout" -> layouts.firstOrNull()?.id
            "headerBold" -> Skins.blackGreen
            "headerSize" -> if (Skins.blackGreen) 19 else 18
            else -> option(key)?.default
        }
    }

    val hasLayoutPicker: Boolean get() = layouts.size > 1
    val tabs: List<OptionTab>
        get() = OptionTab.entries.filter { tab ->
            (tab == OptionTab.LAYOUT && hasLayoutPicker) || options.any { it.tab == tab }
        }
}

private fun toggle(key: String, label: String, tab: OptionTab, default: Boolean, note: String? = null) =
    RowOption(key, label, OptionKind.TOGGLE, tab, default, note = note)

private fun slider(key: String, label: String, tab: OptionTab, default: Int, min: Int, max: Int, unit: String = "dp", step: Int = 1) =
    RowOption(key, label, OptionKind.SLIDER, tab, default, min, max, step, unit)

private fun stepper(key: String, label: String, tab: OptionTab, default: Int, min: Int, max: Int) =
    RowOption(key, label, OptionKind.STEPPER, tab, default, min, max)

val HeaderOptions: List<RowOption> = listOf(
    toggle("header", "Show header", OptionTab.HEADER, true),
    RowOption("headerText", "Header text", OptionKind.TEXT, OptionTab.HEADER, "", note = "Leave empty to use the row's own name."),
    toggle("more", "Show the \u201cView all\u201d link", OptionTab.HEADER, true),
    toggle("headerCenter", "Center the header", OptionTab.HEADER, false),
    toggle("headerBold", "Bold header", OptionTab.HEADER, false),
    slider("headerSize", "Header size", OptionTab.HEADER, 18, 14, 30, "sp")
)

val SpaceOptions: List<RowOption> = listOf(
    slider("spaceBefore", "Space before", OptionTab.STYLE, 0, 0, 48),
    slider("spaceAfter", "Space after", OptionTab.STYLE, 0, 0, 48)
)

val CardOptions: List<RowOption> = listOf(
    toggle("card", "Show as card", OptionTab.STYLE, false),
    toggle("outline", "Outlined card", OptionTab.STYLE, false),
    slider("edge", "Side padding", OptionTab.STYLE, 18, 0, 32)
)

/** The shortcuts a Shortcuts row can hold. The screen that opens for each is wired in NeedleApp. */
val ShortcutChoices: List<Pair<String, String>> = listOf(
    "songs" to "Songs", "albums" to "Albums", "artists" to "Artists", "playlists" to "Playlists",
    "library" to "Library", "radio" to "Radio", "singles" to "Singles", "most" to "Most played",
    "stats" to "Stats", "foryou" to "For you", "folders" to "Folders"
)

object RowRegistry {
    val types: List<RowType> = listOf(
        RowType(
            "moments", "Latest Moments", "Your notes and photos on songs, with the newest one to play.",
            RowCategory.DISCOVER, "POPULAR", unique = true, selfHeader = true, preview = PreviewKind.CARD
        ),
        RowType(
            "pop_heroes", "Play now cards", "Big album cards picked from what you play.",
            RowCategory.DISCOVER, "POPULAR", preview = PreviewKind.HERO,
            own = listOf(
                slider("size", "Card width", OptionTab.LAYOUT, 196, 150, 300),
                stepper("max", "Cards", OptionTab.LAYOUT, 4, 1, 4),
                toggle("playButton", "Show the Play now button", OptionTab.LAYOUT, true)
            ),
            defaults = mapOf("header" to false, "spaceBefore" to 14)
        ),
        RowType(
            "pop_albums", "Your albums", "Albums you played lately, and how much of each you heard.",
            RowCategory.MUSIC, "POPULAR", preview = PreviewKind.COVERS,
            layouts = listOf(RowLayout.TILES, RowLayout.COVERS, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                slider("size", "Size", OptionTab.LAYOUT, 152, 90, 240),
                stepper("max", "Items shown", OptionTab.LAYOUT, 10, 1, 10),
                toggle("progress", "Show how much you heard", OptionTab.LAYOUT, true),
                toggle("subtitles", "Show the artist", OptionTab.LAYOUT, true),
                toggle("playButton", "Play button on covers", OptionTab.LAYOUT, false)
            )
        ),
        RowType(
            "pop_week", "This week", "Listening time, plays and your top artist.",
            RowCategory.STATS, "POPULAR", preview = PreviewKind.BARS, unique = true,
            layouts = listOf(RowLayout.CARDS, RowLayout.CARD)
        ),
        RowType(
            "pop_rediscover", "Rediscover", "Albums you have not played for a while.",
            RowCategory.MUSIC, "POPULAR", preview = PreviewKind.COVERS,
            layouts = listOf(RowLayout.COVERS, RowLayout.BIG, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                RowOption(
                    "since", "Not played for", OptionKind.CHOICE, OptionTab.CONTENT, "30",
                    choices = listOf("30" to "30 days", "60" to "60 days", "90" to "90 days", "180" to "6 months", "365" to "1 year")
                ),
                slider("size", "Size", OptionTab.LAYOUT, 96, 80, 240),
                stepper("max", "Items shown", OptionTab.LAYOUT, 10, 1, 20),
                toggle("subtitles", "Show how long ago", OptionTab.LAYOUT, true),
                toggle("playButton", "Play button on covers", OptionTab.LAYOUT, false)
            )
        ),
        RowType(
            "artists", "Artists", "Round pictures of the artists you play.",
            RowCategory.MUSIC, "POPULAR", preview = PreviewKind.CIRCLES,
            layouts = listOf(RowLayout.CIRCLES, RowLayout.CHIPS, RowLayout.LIST),
            own = listOf(
                slider("size", "Picture size", OptionTab.LAYOUT, 64, 44, 120),
                stepper("max", "Artists shown", OptionTab.LAYOUT, 10, 3, 20),
                toggle("names", "Show names", OptionTab.LAYOUT, true)
            )
        ),
        RowType(
            "roulette", "Roulette", "Albums from your library to spin: a random pick, new ones, or A to Z.",
            RowCategory.DISCOVER, "POPULAR", preview = PreviewKind.BIG,
            layouts = listOf(RowLayout.BIG, RowLayout.COVERS, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                RowOption(
                    "order", "Order", OptionKind.CHOICE, OptionTab.CONTENT, "random",
                    choices = listOf("random" to "Random", "newest" to "Newest", "az" to "A to Z"),
                    note = "Random stays the same all day, then changes."
                ),
                slider("size", "Size", OptionTab.LAYOUT, 165, 100, 260),
                stepper("max", "Items shown", OptionTab.LAYOUT, 10, 1, 20),
                toggle("subtitles", "Show the artist", OptionTab.LAYOUT, true),
                toggle("playButton", "Play button on covers", OptionTab.LAYOUT, true)
            )
        ),
        RowType(
            "mixes", "Mixes", "Your daily mixes and smart playlists.",
            RowCategory.DISCOVER, "POPULAR", preview = PreviewKind.COVERS,
            layouts = listOf(RowLayout.COVERS, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                slider("size", "Size", OptionTab.LAYOUT, 140, 100, 220),
                stepper("max", "Items shown", OptionTab.LAYOUT, 6, 1, 10),
                toggle("subtitles", "Show the song count", OptionTab.LAYOUT, true),
                toggle("playButton", "Play button on covers", OptionTab.LAYOUT, false)
            )
        ),
        RowType(
            "radios", "Radio", "Your internet radio stations.",
            RowCategory.RADIO, "POPULAR", preview = PreviewKind.COVERS,
            layouts = listOf(RowLayout.COVERS, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                toggle("favoritesOnly", "Favorites only", OptionTab.CONTENT, true),
                slider("size", "Size", OptionTab.LAYOUT, 96, 64, 160),
                stepper("max", "Stations shown", OptionTab.LAYOUT, 10, 1, 20),
                toggle("subtitles", "Show the station's tags", OptionTab.LAYOUT, true)
            )
        ),
        RowType(
            "shortcuts", "Shortcuts", "Quick links to the places in Needle you use most.",
            RowCategory.QUICK, "POPULAR", preview = PreviewKind.CHIPS,
            layouts = listOf(RowLayout.CHIPS, RowLayout.GRID, RowLayout.LIST),
            own = listOf(
                RowOption(
                    "items", "Shortcuts", OptionKind.MULTI, OptionTab.CONTENT, "songs,albums,artists,playlists",
                    choices = ShortcutChoices
                )
            ),
            defaults = mapOf("header" to false, "spaceBefore" to 14)
        ),
        // The New page draws these itself (NewScreen). The editor can show, hide and reorder them.
        RowType("new_hero", "Newest album", "The latest album added to your library.", RowCategory.NEW, "NEW", unique = true, external = true, preview = PreviewKind.HERO),
        RowType("new_recent", "Recently added", "Songs and albums added lately.", RowCategory.NEW, "NEW", unique = true, external = true),
        RowType("new_singles", "New singles", "Singles added lately.", RowCategory.NEW, "NEW", unique = true, external = true),
        RowType("new_needtags", "Songs that need tags", "Songs with missing tags, to fix.", RowCategory.NEW, "NEW", unique = true, external = true, preview = PreviewKind.LIST)
    )

    private val index: Map<String, RowType> = types.associateBy { it.id }
    fun byId(id: String): RowType? = index[id]
    fun forPage(page: String): List<RowType> = types.filter { it.page == page }
}

/** One row on a page. [options] holds only what was changed; the rest comes from [RowRegistry]. */
data class HomeRow(
    val id: String,
    val type: String,
    val visible: Boolean = true,
    val options: Map<String, Any> = emptyMap()
) {
    val spec: RowType? get() = RowRegistry.byId(type)

    fun intOpt(key: String): Int =
        (options[key] as? Number)?.toInt() ?: (spec?.default(key) as? Number)?.toInt() ?: 0

    fun boolOpt(key: String): Boolean =
        options[key] as? Boolean ?: (spec?.default(key) as? Boolean) ?: false

    fun strOpt(key: String): String =
        options[key] as? String ?: (spec?.default(key) as? String).orEmpty()

    fun listOpt(key: String): List<String> = strOpt(key).split(',').map { it.trim() }.filter { it.isNotEmpty() }

    val layout: RowLayout? get() = RowLayout.of(strOpt("layout"))

    fun with(key: String, value: Any?): HomeRow =
        copy(options = if (value == null) options - key else options + (key to value))

    /** Name shown in the editor: the person's own header text if they set one, else the type's name. */
    val title: String
        get() {
            val custom = (options["headerText"] as? String).orEmpty().trim()
            return custom.ifEmpty { spec?.title ?: type }
        }
}

/** Turns whatever a layout file holds for an option into something safe, or null to drop it. */
internal fun sanitizeOption(type: RowType, key: String, raw: Any?): Any? {
    if (key == "layout") {
        val id = raw as? String ?: return null
        return if (type.layouts.any { it.id == id }) id else null
    }
    val opt = type.option(key) ?: return null
    return when (opt.kind) {
        OptionKind.TOGGLE -> raw as? Boolean
        OptionKind.SLIDER, OptionKind.STEPPER -> (raw as? Number)?.toInt()?.coerceIn(opt.min, opt.max)
        OptionKind.CHOICE -> (raw as? String)?.takeIf { v -> opt.choices.any { it.first == v } }
        OptionKind.TEXT -> (raw as? String)?.trim()?.take(40)
        OptionKind.MULTI -> (raw as? String)?.split(',')?.map { it.trim() }
            ?.filter { v -> opt.choices.any { it.first == v } }?.distinct()?.joinToString(",")
    }
}

/** What a fresh install, and "Reset", give: the Home that Needle always had. */
object HomeDefaults {
    fun pages(): Map<String, List<HomeRow>> {
        val popular = mutableListOf<HomeRow>()
        // Black & Green always had a row of artists above everything else; keep it for those who use that skin.
        if (Skins.blackGreen) popular += HomeRow("artists", "artists")
        popular += listOf("moments", "pop_heroes", "pop_albums", "pop_week", "pop_rediscover").map { HomeRow(it, it) }
        val new = listOf("new_hero", "new_recent", "new_singles", "new_needtags").map { HomeRow(it, it) }
        return mapOf("POPULAR" to popular, "NEW" to new)
    }

    val tabs = listOf("NEW", "POPULAR", "MOST_PLAYED", "SINGLES")
}
