package app.needle.music.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import app.needle.music.data.HomeDefaults
import app.needle.music.data.HomeLayout
import app.needle.music.data.HomeRow
import app.needle.music.data.PreviewKind

/**
 * The Home editor. "Visual" shows the real rows in frames you can drag, hide, duplicate and open; "List" is the
 * same rows as a plain list for quick reordering. Every change is saved at once and can be undone.
 * The rows themselves, their options and their defaults all come from data/HomeRows.kt.
 */
@Composable
fun HomeEditorScreen(ctx: HomeRowContext, onBack: () -> Unit, modifier: Modifier = Modifier) {
    var visual by rememberSaveable { mutableStateOf(true) }
    var page by rememberSaveable { mutableStateOf("POPULAR") }
    var selected by rememberSaveable { mutableStateOf<String?>(null) }
    var settingsId by rememberSaveable { mutableStateOf<String?>(null) }
    var showAdd by rememberSaveable { mutableStateOf(false) }
    var showLayouts by rememberSaveable { mutableStateOf(false) }
    var showPills by rememberSaveable { mutableStateOf(false) }
    val canUndo = HomeLayout.undoCount.value > 0

    BackHandler(enabled = settingsId != null) { settingsId = null }
    BackHandler(enabled = showAdd) { showAdd = false }
    BackHandler(enabled = showLayouts) { showLayouts = false }
    BackHandler(enabled = showPills) { showPills = false }

    Box(modifier.fillMaxSize().background(Palette.Bg)) {
        Column(Modifier.fillMaxSize()) {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Edit Home", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 24.sp, modifier = Modifier.weight(1f))
                Text(
                    "Undo", color = if (canUndo) Palette.Text else Palette.Muted.copy(alpha = 0.5f), fontSize = 15.sp,
                    modifier = Modifier.clip(CircleShape).clickable(enabled = canUndo) { HomeLayout.undo() }.padding(horizontal = 14.dp, vertical = 12.dp)
                )
                PillButton("Done", onClick = onBack, filled = true)
            }
            Segmented(listOf("Visual", "List"), if (visual) 0 else 1, Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) { visual = it == 0 }
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Popular", page == "POPULAR", { page = "POPULAR"; selected = null })
                Chip("New", page == "NEW", { page = "NEW"; selected = null })
                Spacer(Modifier.width(8.dp))
                Chip("Pills", false, { showPills = true })
                Chip("Layouts", false, { showLayouts = true })
            }
            EditorList(
                page = page, visual = visual, ctx = ctx, selected = selected,
                onSelect = { selected = it }, onSettings = { settingsId = it }, onAdd = { showAdd = true },
                modifier = Modifier.weight(1f)
            )
        }

        if (settingsId != null) {
            Overlay { RowSettingsPage(settingsId.orEmpty(), ctx, onClose = { settingsId = null }) }
        }
        if (showAdd) {
            Overlay {
                AddRowPage(page, onClose = { showAdd = false }, onAdd = { typeId ->
                    val id = HomeLayout.add(typeId, afterId = selected)
                    if (id != null) selected = id
                    showAdd = false
                })
            }
        }
        if (showLayouts) Overlay { LayoutsPage(onClose = { showLayouts = false }) }
        if (showPills) Overlay { PillsPage(onClose = { showPills = false }) }
    }
}

/** A full-screen layer over the editor that also stops touches reaching what is under it. */
@Composable
private fun Overlay(content: @Composable () -> Unit) {
    Box(
        Modifier.fillMaxSize().background(Palette.Bg)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) {}
    ) { content() }
}

// ---- the list of rows, with drag to reorder ------------------------------------------------------

@Composable
private fun EditorList(
    page: String,
    visual: Boolean,
    ctx: HomeRowContext,
    selected: String?,
    onSelect: (String?) -> Unit,
    onSettings: (String) -> Unit,
    onAdd: () -> Unit,
    modifier: Modifier
) {
    val rows = HomeLayout.rows(page)
    val listState = rememberLazyListState()
    val haptic = LocalHapticFeedback.current
    var working by remember(page, visual) { mutableStateOf<List<HomeRow>?>(null) }
    var dragKey by remember { mutableStateOf<String?>(null) }
    var dragOffset by remember { mutableStateOf(0f) }

    val shown = working ?: rows
    val listed = if (visual) shown else shown.filter { it.visible }
    val hidden = if (visual) emptyList() else shown.filter { !it.visible }

    fun beginDrag(id: String) {
        working = rows
        dragKey = id
        dragOffset = 0f
    }

    fun dragBy(dy: Float) {
        val key = dragKey ?: return
        val list = working ?: return
        dragOffset += dy
        val info = listState.layoutInfo.visibleItemsInfo
        val cur = info.firstOrNull { it.key == key } ?: return
        val center = cur.offset + cur.size / 2f + dragOffset
        val ids = list.map { it.id }.toSet()
        val target = info.firstOrNull {
            val k = it.key
            k != key && k is String && k in ids && center >= it.offset && center <= it.offset + it.size
        } ?: return
        val from = list.indexOfFirst { it.id == key }
        val to = list.indexOfFirst { it.id == target.key }
        if (from < 0 || to < 0 || from == to) return
        working = list.toMutableList().apply { add(to, removeAt(from)) }
        // The dragged row now sits where the other one was: keep it under the finger.
        val newOffset = if (to > from) target.offset + target.size - cur.size else target.offset
        dragOffset += (cur.offset - newOffset).toFloat()
    }

    fun endDrag() {
        val w = working
        if (w != null) {
            val ids = w.map { it.id }
            if (visual) HomeLayout.setOrder(page, ids) else HomeLayout.setVisibleOrder(page, ids)
        }
        working = null
        dragKey = null
        dragOffset = 0f
    }

    // Scroll the list while a row is held near the top or bottom edge.
    LaunchedEffect(dragKey) {
        if (dragKey == null) return@LaunchedEffect
        while (true) {
            withFrameNanos { }
            val key = dragKey ?: break
            val info = listState.layoutInfo
            val item = info.visibleItemsInfo.firstOrNull { it.key == key } ?: continue
            val top = item.offset + dragOffset
            val bottom = top + item.size
            val delta = when {
                bottom > info.viewportEndOffset - 90f -> 18f
                top < info.viewportStartOffset + 90f -> -18f
                else -> 0f
            }
            if (delta != 0f) dragOffset += listState.scrollBy(delta)
        }
    }

    LazyColumn(state = listState, modifier = modifier, contentPadding = PaddingValues(top = 6.dp, bottom = 40.dp)) {
        if (!visual) item(key = "label_shown") { SectionLabel("Showing · ${listed.size}") }
        items(listed, key = { it.id }) { row ->
            val dragging = dragKey == row.id
            val itemModifier = if (dragging) Modifier.zIndex(1f).graphicsLayer { translationY = dragOffset } else Modifier.animateItem()
            val grip: @Composable () -> Unit = {
                DragGrip(
                    onStart = { haptic.performHapticFeedback(HapticFeedbackType.LongPress); beginDrag(row.id) },
                    onDrag = { dragBy(it) },
                    onEnd = { endDrag() }
                )
            }
            if (visual) {
                VisualFrame(row, ctx, selected == row.id, grip, { onSelect(if (selected == row.id) null else row.id) }, { onSettings(row.id) }, itemModifier)
            } else {
                ListFrame(row, grip, { onSettings(row.id) }, itemModifier)
            }
        }
        if (!visual && hidden.isNotEmpty()) {
            item(key = "label_hidden") { SectionLabel("Hidden · ${hidden.size}") }
            items(hidden, key = { "hidden:" + it.id }) { row -> ListFrame(row, null, { onSettings(row.id) }, Modifier.animateItem()) }
        }
        item(key = "add") { AddRowButton(onAdd) }
    }
}

@Composable
private fun SectionLabel(text: String) {
    Text(text, color = Palette.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 20.dp, top = 12.dp, bottom = 6.dp))
}

@Composable
private fun AddRowButton(onClick: () -> Unit) {
    Box(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp).height(52.dp).clip(CircleShape)
            .dashedBorder(Palette.Accent, 26.dp).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            NeedleIconView(NeedleIcon.PLUS, Palette.Accent, size = 20.dp)
            Text("Add row", color = Palette.Accent, fontSize = 15.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 8.dp))
        }
    }
}

// ---- frames --------------------------------------------------------------------------------------

/** One row as it really looks (cut short), in a frame with its controls. */
@Composable
private fun VisualFrame(
    row: HomeRow,
    ctx: HomeRowContext,
    selected: Boolean,
    grip: @Composable () -> Unit,
    onSelect: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier
) {
    val type = row.spec
    val external = type?.external == true
    val shape = cornerShape(22.dp)
    val frame = if (selected) {
        Modifier.background(Palette.Accent.copy(alpha = 0.10f), shape).border(2.dp, Palette.Accent, shape)
    } else {
        Modifier.background(Color.White.copy(alpha = 0.04f), shape).dashedBorder(Color.White.copy(alpha = 0.22f), 22.dp)
    }
    Column(modifier.padding(horizontal = 14.dp, vertical = 5.dp).then(frame).clip(shape).alpha(if (row.visible) 1f else 0.6f)) {
        Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
            grip()
            Column(Modifier.weight(1f).clickable(onClick = onSelect).padding(vertical = 6.dp)) {
                Text(row.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(rowSummary(row), color = Palette.Muted, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            EditorIconButton({ HomeLayout.setVisible(row.id, !row.visible) }) {
                NeedleIconView(if (row.visible) NeedleIcon.EYE else NeedleIcon.EYE_OFF, Palette.Muted, size = 20.dp)
            }
            if (!external) EditorIconButton(onSettings) { TuneIcon(Palette.Muted) }
        }
        if (row.visible) {
            if (external) {
                Text(type?.about.orEmpty(), color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(start = 14.dp, end = 14.dp, bottom = 14.dp))
            } else {
                Box(Modifier.padding(start = 6.dp, end = 6.dp, bottom = 8.dp).fillMaxWidth().heightIn(max = 168.dp).clip(cornerShape(16.dp))) {
                    Column(Modifier.fillMaxWidth()) { HomeRowView(row, ctx, preview = true) }
                    // Rows are only for looking at here: a tap anywhere on one selects it.
                    Box(
                        Modifier.matchParentSize()
                            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onSelect)
                    )
                }
            }
        }
        if (selected) {
            Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.10f)))
            Row(Modifier.fillMaxWidth()) {
                if (!external) FrameAction("Settings", Palette.Text, onSettings, Modifier.weight(1f)) { TuneIcon(Palette.Text) }
                if (type != null && !type.unique && !external) {
                    FrameAction("Duplicate", Palette.Text, { HomeLayout.duplicate(row.id) }, Modifier.weight(1f)) {
                        NeedleIconView(NeedleIcon.PLUS, Palette.Text, size = 18.dp)
                    }
                }
                FrameAction(if (row.visible) "Hide" else "Show", Palette.Text, { HomeLayout.setVisible(row.id, !row.visible) }, Modifier.weight(1f)) {
                    NeedleIconView(if (row.visible) NeedleIcon.EYE_OFF else NeedleIcon.EYE, Palette.Text, size = 18.dp)
                }
                FrameAction("Delete", Color(0xFFFF8A80), { HomeLayout.remove(row.id) }, Modifier.weight(1f)) {
                    NeedleIconView(NeedleIcon.TRASH, Color(0xFFFF8A80), size = 18.dp)
                }
            }
        }
    }
}

@Composable
private fun FrameAction(label: String, color: Color, onClick: () -> Unit, modifier: Modifier, icon: @Composable () -> Unit) {
    Row(
        modifier.height(48.dp).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        icon()
        Text(label, color = color, fontSize = 12.sp, maxLines = 1, modifier = Modifier.padding(start = 5.dp))
    }
}

/** The compact version for the List mode. [grip] is null for hidden rows, which are not reordered. */
@Composable
private fun ListFrame(row: HomeRow, grip: (@Composable () -> Unit)?, onSettings: () -> Unit, modifier: Modifier) {
    val type = row.spec
    Row(
        modifier.padding(horizontal = 14.dp, vertical = 4.dp).clip(cornerShape(20.dp)).background(Palette.Card)
            .alpha(if (row.visible) 1f else 0.65f).height(68.dp).padding(end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (grip != null) grip() else Spacer(Modifier.width(44.dp))
        Box(Modifier.size(44.dp).clip(cornerShape(12.dp)).background(Palette.Accent.copy(alpha = 0.18f))) {
            Sketch(type?.preview ?: PreviewKind.COVERS, Modifier.fillMaxSize())
        }
        Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
            Text(row.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(rowSummary(row), color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        NeedleSwitch(row.visible) { HomeLayout.setVisible(row.id, it) }
        if (type?.external != true) EditorIconButton(onSettings) { TuneIcon(Palette.Muted) } else Spacer(Modifier.width(8.dp))
    }
}

/** "Carousel · 10 items" under a row's name. */
internal fun rowSummary(row: HomeRow): String {
    val type = row.spec ?: return ""
    val parts = ArrayList<String>()
    if (type.external) {
        parts += "Drawn by the New page"
    } else {
        row.layout?.let { parts += it.label }
        if (type.option("max") != null) parts += "${row.intOpt("max")} items"
        if (type.id == "shortcuts") parts += "${row.listOpt("items").size} links"
    }
    if (!row.visible) parts += "Hidden"
    return parts.joinToString(" · ")
}

// ---- small shared pieces -------------------------------------------------------------------------

@Composable
internal fun EditorIconButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick), contentAlignment = Alignment.Center) { content() }
}

/** The handle you drag a row by. Reports vertical movement; the list works out where the row goes. */
@Composable
private fun DragGrip(onStart: () -> Unit, onDrag: (Float) -> Unit, onEnd: () -> Unit) {
    val start = rememberUpdatedState(onStart)
    val drag = rememberUpdatedState(onDrag)
    val end = rememberUpdatedState(onEnd)
    Box(
        Modifier.size(44.dp).pointerInput(Unit) {
            detectDragGestures(
                onDragStart = { start.value() },
                onDrag = { change, amount ->
                    change.consume()
                    drag.value(amount.y)
                },
                onDragEnd = { end.value() },
                onDragCancel = { end.value() }
            )
        },
        contentAlignment = Alignment.Center
    ) { GripIcon(Palette.Muted) }
}

@Composable
internal fun GripIcon(color: Color) {
    Canvas(Modifier.size(22.dp)) {
        val r = 1.9.dp.toPx()
        for (x in listOf(0.38f, 0.62f)) for (y in listOf(0.25f, 0.5f, 0.75f)) drawCircle(color, r, Offset(size.width * x, size.height * y))
    }
}

/** Three sliders: the "settings of this row" icon. */
@Composable
internal fun TuneIcon(color: Color, size: Dp = 20.dp) {
    Canvas(Modifier.size(size)) {
        val w = this.size.width
        val h = this.size.height
        val stroke = 1.8.dp.toPx()
        val ys = listOf(0.25f, 0.5f, 0.75f)
        val knobs = listOf(0.68f, 0.32f, 0.6f)
        for (i in ys.indices) {
            drawLine(color, Offset(w * 0.1f, h * ys[i]), Offset(w * 0.9f, h * ys[i]), stroke, StrokeCap.Round)
            drawCircle(color, 2.6.dp.toPx(), Offset(w * knobs[i], h * ys[i]))
        }
    }
}

/** A dashed rounded outline, for things you can still add to. */
internal fun Modifier.dashedBorder(color: Color, radius: Dp): Modifier = drawBehind {
    drawRoundRect(
        color = color,
        cornerRadius = CornerRadius(radius.toPx()),
        style = Stroke(width = 1.5.dp.toPx(), pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f)))
    )
}

/** Two or more choices in one rounded bar. */
@Composable
internal fun Segmented(options: List<String>, selected: Int, modifier: Modifier = Modifier, onSelect: (Int) -> Unit) {
    Row(modifier.fillMaxWidth().clip(CircleShape).background(Palette.Card2).padding(4.dp)) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Box(
                Modifier.weight(1f).height(40.dp).clip(CircleShape)
                    .background(if (on) (if (app.needle.music.data.Skins.blackGreen) Palette.Accent else Color.White) else Color.Transparent)
                    .clickable { onSelect(i) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    label, color = if (on) Color(0xFF111111) else Palette.Text, fontSize = 13.sp,
                    fontWeight = if (on) FontWeight.SemiBold else FontWeight.Medium, maxLines = 1
                )
            }
        }
    }
}

/** A small picture of what a row looks like: used in the list, the gallery and layout thumbnails. */
@Composable
internal fun Sketch(kind: PreviewKind, modifier: Modifier = Modifier, tint: Color = Palette.Accent) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        val c = tint.copy(alpha = 0.85f)
        fun box(x: Float, y: Float, bw: Float, bh: Float, r: Float) {
            drawRoundRect(color = c, topLeft = Offset(x * w, y * h), size = Size(bw * w, bh * h), cornerRadius = CornerRadius(r * minOf(w, h)))
        }
        when (kind) {
            PreviewKind.COVERS -> {
                for (i in 0..2) box(0.05f + i * 0.32f, 0.2f, 0.27f, 0.42f, 0.1f)
                for (i in 0..2) box(0.05f + i * 0.32f, 0.7f, 0.2f, 0.07f, 0.03f)
            }
            PreviewKind.BIG -> {
                box(0.06f, 0.15f, 0.42f, 0.62f, 0.1f)
                box(0.54f, 0.15f, 0.42f, 0.62f, 0.1f)
                box(0.06f, 0.84f, 0.3f, 0.07f, 0.03f)
            }
            PreviewKind.CIRCLES -> {
                for (i in 0..3) drawCircle(c, minOf(w, h) * 0.17f, Offset(w * (0.16f + i * 0.226f), h * 0.42f))
                for (i in 0..3) box(0.07f + i * 0.226f, 0.76f, 0.18f, 0.07f, 0.03f)
            }
            PreviewKind.LIST -> {
                for (i in 0..2) {
                    box(0.07f, 0.12f + i * 0.28f, 0.2f, 0.2f, 0.06f)
                    box(0.34f, 0.17f + i * 0.28f, 0.58f, 0.07f, 0.03f)
                }
            }
            PreviewKind.CHIPS -> {
                for (i in 0..2) box(0.05f + i * 0.32f, 0.36f, 0.27f, 0.28f, 0.14f)
            }
            PreviewKind.BARS -> {
                val hs = listOf(0.3f, 0.5f, 0.38f, 0.66f, 0.5f)
                for (i in hs.indices) box(0.1f + i * 0.17f, 0.82f - hs[i], 0.11f, hs[i], 0.03f)
            }
            PreviewKind.CARD -> {
                box(0.07f, 0.22f, 0.86f, 0.56f, 0.1f)
            }
            PreviewKind.HERO -> {
                box(0.1f, 0.1f, 0.38f, 0.8f, 0.1f)
                box(0.52f, 0.1f, 0.38f, 0.8f, 0.1f)
            }
        }
    }
}

// ---- pills and start page ------------------------------------------------------------------------

@Composable
internal fun PillsPage(onClose: () -> Unit) {
    val names = mapOf("NEW" to "New", "POPULAR" to "Popular", "MOST_PLAYED" to "Most played", "SINGLES" to "Singles")
    val tabs = HomeLayout.tabs()
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(NeedleIcon.BACK, onClose, size = 42.dp, iconSize = 22.dp)
            Text("Pills", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
        }
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 18.dp)) {
            Text(
                "The pills under the Home title. Hide the ones you do not use and put the rest in your order.",
                color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 10.dp)
            )
            tabs.forEachIndexed { i, name ->
                Row(
                    Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(cornerShape(20.dp)).background(Palette.Card).height(60.dp).padding(start = 18.dp, end = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(names[name] ?: name, color = Palette.Text, fontSize = 16.sp, modifier = Modifier.weight(1f))
                    EditorIconButton({ if (i > 0) HomeLayout.moveTab(name, -1) }) {
                        NeedleIconView(NeedleIcon.CHEVRON_DOWN, if (i > 0) Palette.Text else Palette.Muted.copy(alpha = 0.4f), Modifier.rotate(180f), 20.dp)
                    }
                    EditorIconButton({ if (i < tabs.size - 1) HomeLayout.moveTab(name, 1) }) {
                        NeedleIconView(NeedleIcon.CHEVRON_DOWN, if (i < tabs.size - 1) Palette.Text else Palette.Muted.copy(alpha = 0.4f), size = 20.dp)
                    }
                    Spacer(Modifier.width(6.dp))
                    NeedleSwitch(HomeLayout.isTabVisible(name)) { HomeLayout.toggleTab(name) }
                    Spacer(Modifier.width(8.dp))
                }
            }
            Text("Home opens on", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 10.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("Popular", HomeLayout.startTab.value == "POPULAR", { HomeLayout.setStartTab("POPULAR") })
                Chip("New", HomeLayout.startTab.value == "NEW", { HomeLayout.setStartTab("NEW") })
            }
            Text(
                "If that pill is hidden, Home opens on the first pill that is shown.",
                color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}
