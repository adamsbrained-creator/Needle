package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeLayout
import app.needle.music.data.RowCategory
import app.needle.music.data.RowRegistry
import app.needle.music.data.RowType

/** The gallery of row types for a page. Tapping one adds it; what it can do is declared in RowRegistry. */
@Composable
internal fun AddRowPage(page: String, onClose: () -> Unit, onAdd: (String) -> Unit) {
    var query by remember { mutableStateOf("") }
    var category by remember { mutableStateOf<RowCategory?>(null) }
    val all = RowRegistry.forPage(page)
    val present = HomeLayout.rows(page).map { it.type }.toSet()
    val categories = all.map { it.category }.distinct()
    val shown = all.filter { type ->
        (category == null || type.category == category) &&
            (query.isBlank() || type.title.contains(query, ignoreCase = true) || type.about.contains(query, ignoreCase = true))
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(start = 6.dp, end = 12.dp, top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(NeedleIcon.CLOSE, onClose, size = 42.dp, iconSize = 20.dp)
            Text("Add a row", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 22.sp, modifier = Modifier.weight(1f).padding(start = 8.dp))
        }
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 10.dp).clip(cornerShape(24.dp)).background(Palette.Card2).padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleIconView(NeedleIcon.SEARCH, Palette.Muted, size = 20.dp)
            Box(Modifier.weight(1f).padding(start = 10.dp)) {
                BasicTextField(
                    value = query, onValueChange = { query = it }, singleLine = true,
                    textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                    cursorBrush = SolidColor(Palette.Accent), modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) Text("Search row types", color = Palette.Muted, fontSize = 15.sp)
                            inner()
                        }
                    }
                )
            }
        }
        if (categories.size > 1) {
            Row(Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Chip("All", category == null, { category = null })
                categories.forEach { c -> Chip(c.label, category == c, { category = c }) }
            }
        }
        if (shown.isEmpty()) {
            Text("Nothing matches.", color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.fillMaxWidth().padding(48.dp))
        }
        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(top = 14.dp, bottom = 40.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown.chunked(2)) { pair ->
                Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    pair.forEach { type -> TypeCard(type, type.id in present, Modifier.weight(1f)) { onAdd(type.id) } }
                    if (pair.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun TypeCard(type: RowType, added: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val enabled = !(added && type.unique)
    Column(
        modifier.clip(cornerShape(20.dp)).background(Palette.Card).alpha(if (enabled) 1f else 0.55f)
            .clickable(enabled = enabled, onClick = onClick).padding(10.dp)
    ) {
        Box(Modifier.fillMaxWidth().height(64.dp).clip(cornerShape(12.dp)).background(Palette.Accent.copy(alpha = 0.12f))) {
            Sketch(type.preview, Modifier.fillMaxSize())
            if (added) {
                Text(
                    if (type.unique) "Added" else "On Home", color = Palette.Text, fontSize = 10.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.align(Alignment.TopEnd).padding(6.dp).clip(cornerShape(8.dp)).background(Color(0x66000000)).padding(horizontal = 7.dp, vertical = 2.dp)
                )
            }
        }
        Text(type.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(type.about, color = Palette.Muted, fontSize = 11.5.sp, lineHeight = 15.sp, maxLines = 3, overflow = TextOverflow.Ellipsis)
    }
}
