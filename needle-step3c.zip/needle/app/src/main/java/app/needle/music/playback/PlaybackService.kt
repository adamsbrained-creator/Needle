package app.needle.music.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import androidx.core.app.TaskStackBuilder
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.needle.music.MainActivity
import app.needle.music.data.NeedleDatabase
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The audio engine AND the owner of the queue.
 * The UI only asks for things ("play these songs", shuffle, repeat, jump, remove);
 * the queue itself lives here, so it survives the UI closing, and it is saved to disk
 * so it survives the whole app being killed.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private val songDao by lazy { NeedleDatabase.get(this).songDao() }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    // ---- saving ----------------------------------------------------------------------

    private val saveQueueRunnable = Runnable { saveQueue() }

    private val positionTicker = object : Runnable {
        override fun run() {
            saveState()
            if (player.isPlaying) handler.postDelayed(this, 15_000)
        }
    }

    private val persistListener = object : Player.Listener {
        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            // The queue changed: save it a moment later (batches bursts of changes).
            handler.removeCallbacks(saveQueueRunnable)
            handler.postDelayed(saveQueueRunnable, 1_000)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) = saveState()

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            handler.removeCallbacks(positionTicker)
            saveState()
            if (isPlaying) handler.postDelayed(positionTicker, 15_000)
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            if (shuffleModeEnabled) reshuffleCurrentFirst()
            saveState()
        }

        override fun onRepeatModeChanged(repeatMode: Int) = saveState()
    }

    private fun saveState() {
        val item = player.currentMediaItem ?: return
        val id = item.mediaId.toLongOrNull() ?: return
        QueueStore.saveState(this, id, player.currentPosition, player.shuffleModeEnabled, player.repeatMode)
    }

    private fun saveQueue() {
        val count = player.mediaItemCount
        if (count == 0) return
        val ids = List(count) { player.getMediaItemAt(it).mediaId }
        scope.launch(Dispatchers.IO) { QueueStore.saveIds(this@PlaybackService, ids) }
    }

    // ---- shuffle ---------------------------------------------------------------------

    /** New random order, but the song that is playing right now stays first. */
    private fun reshuffleCurrentFirst() {
        val n = player.mediaItemCount
        if (n < 2) return
        val current = player.currentMediaItemIndex
        val order = IntArray(n)
        order[0] = current
        var k = 1
        for (i in (0 until n).shuffled()) if (i != current) order[k++] = i
        player.setShuffleOrder(DefaultShuffleOrder(order, System.nanoTime()))
    }

    // ---- commands from the UI --------------------------------------------------------

    private val callback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                .buildUpon()
                .add(QueueCommands.playQueue)
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> =
            if (customCommand.customAction == QueueCommands.PLAY_QUEUE) {
                handlePlayQueue(args)
            } else {
                super.onCustomCommand(session, controller, customCommand, args)
            }
    }

    private fun handlePlayQueue(args: Bundle): ListenableFuture<SessionResult> {
        val ids = args.getLongArray(QueueCommands.KEY_IDS) ?: LongArray(0)
        val start = args.getInt(QueueCommands.KEY_START, 0)
        val shuffle: Boolean? =
            if (args.containsKey(QueueCommands.KEY_SHUFFLE)) args.getBoolean(QueueCommands.KEY_SHUFFLE) else null

        val result = SettableFuture.create<SessionResult>()
        scope.launch {
            try {
                val byId = withContext(Dispatchers.IO) { songDao.getAllOnce().associateBy { it.id } }
                val items = ids.asList().mapNotNull { byId[it]?.toMediaItem() }
                if (items.isNotEmpty()) {
                    val startId = ids.getOrNull(start)?.toString()
                    val startIndex = items.indexOfFirst { it.mediaId == startId }.coerceAtLeast(0)
                    player.setMediaItems(items, startIndex, C.TIME_UNSET)
                    if (shuffle != null) player.shuffleModeEnabled = shuffle
                    if (player.shuffleModeEnabled) reshuffleCurrentFirst()
                    player.prepare()
                    player.play()
                }
                result.set(SessionResult(SessionResult.RESULT_SUCCESS))
            } catch (e: Exception) {
                result.set(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            }
        }
        return result
    }

    // ---- restoring after the app was killed -------------------------------------------

    private fun restoreQueue() {
        scope.launch {
            val saved = withContext(Dispatchers.IO) { QueueStore.load(this@PlaybackService) } ?: return@launch
            val byId = withContext(Dispatchers.IO) { songDao.getAllOnce().associateBy { it.id } }
            // If the person already started something while we were loading, leave it alone.
            if (player.mediaItemCount > 0) return@launch

            val items = saved.ids.mapNotNull { byId[it]?.toMediaItem() }
            if (items.isEmpty()) return@launch

            val index = items.indexOfFirst { it.mediaId == saved.currentId.toString() }
            val found = index >= 0
            player.setMediaItems(items, if (found) index else 0, if (found) saved.positionMs else 0L)
            player.repeatMode = saved.repeatMode
            player.shuffleModeEnabled = saved.shuffle
            if (saved.shuffle) reshuffleCurrentFirst()
            player.prepare() // ready to resume, but stays paused
        }
    }

    // ---- lifecycle -------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones unplug
            .setWakeMode(C.WAKE_MODE_LOCAL)    // keep CPU awake for local files
            .build()
        player.addListener(persistListener)
        session = MediaSession.Builder(this, player)
            .setCallback(callback)
            .setSessionActivity(openAppIntent())
            .build()
        restoreQueue()
    }

    /** What opens when the notification or the system media widget is tapped. */
    private fun openAppIntent(): PendingIntent =
        TaskStackBuilder.create(this)
            .addNextIntent(Intent(this, MainActivity::class.java))
            .getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)!!

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveState()
        // Swiped away from recents: stop the service only if nothing is playing.
        if (!player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        saveState()
        if (player.mediaItemCount > 0) {
            QueueStore.saveIds(this, List(player.mediaItemCount) { player.getMediaItemAt(it).mediaId })
        }
        scope.cancel()
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
