package app.needle.music.data

import android.app.Application
import android.graphics.Bitmap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * Saves what the tag editor collected into Needle's database, and, when the person wants it, into the
 * audio files too (see [TagWriter]).
 */
class TagsViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)
    private val tags = db.tagDao()
    private val extraTags = db.extraTagDao()

    /** While Needle writes into files: (songs done, songs in total). Otherwise null. */
    var writeProgress by mutableStateOf<Pair<Int, Int>?>(null)
        private set

    init {
        // If the app stopped in the middle of replacing a file, the backup is put back first thing.
        viewModelScope.launch(Dispatchers.IO) { runCatching { TagWriter.recover(app) } }
    }

    /**
     * Applies [changes] (and the new [cover], if any) to every song in [ids]. [onSaved] runs when Needle's own
     * copy is saved. With [writeToFiles], the files are written next and [onWritten] gets a short report.
     */
    fun save(
        ids: List<Long>,
        changes: TagChanges,
        cover: Bitmap?,
        writeToFiles: Boolean,
        onSaved: () -> Unit,
        onWritten: (String) -> Unit
    ) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val existing = tags.getAll().associateBy { it.songId }
                val updated = ids.map { id -> existing[id].withChanges(id, changes) }
                val (keep, drop) = updated.partition { !it.isEmpty() }
                if (keep.isNotEmpty()) tags.upsertAll(keep)
                if (drop.isNotEmpty()) tags.delete(drop.map { it.songId })
                saveExtras(ids, changes.extras)
                if (cover != null) CoverStore.save(app, ids, cover)
            }
            if (cover != null) ArtworkLoader.invalidate(ids)
            onSaved()
            if (writeToFiles) onWritten(writeFiles(ids))
        }
    }

    /** Writes every edit Needle holds (tags and covers) into the files. For the Settings button. */
    fun writeAll(onWritten: (String) -> Unit) {
        if (writeProgress != null) return
        viewModelScope.launch {
            val ids = withContext(Dispatchers.IO) {
                (tags.getAll().map { it.songId } + extraTags.getAll().map { it.songId } + CoverStore.songIds(app)).distinct()
            }
            onWritten(writeFiles(ids))
        }
    }

    private suspend fun writeFiles(ids: List<Long>): String {
        FileAccess.refresh()
        if (!FileAccess.granted.value) return "Saved in Needle. To write into the files, allow \"All files access\" in Settings."
        writeProgress = 0 to ids.size
        return try {
            val results = TagWriter.writeSongs(app, ids) { done, total -> writeProgress = done to total }
            val failed = results.filter { !it.ok }
            val ok = results.size - failed.size
            when {
                results.isEmpty() -> "Nothing to write"
                failed.isEmpty() -> if (ok == 1) "Saved into the file" else "Saved into $ok files"
                else -> "Saved into $ok of ${results.size} files. ${failed.first().name}: ${failed.first().error}"
            }
        } catch (e: Exception) {
            "Could not write into the files: ${e.message}"
        } finally {
            writeProgress = null
        }
    }

    private suspend fun saveExtras(ids: List<Long>, extras: Map<String, String>) {
        if (extras.isEmpty()) return
        val set = extras.filterValues { it.isNotBlank() }
        val clear = extras.filterValues { it.isBlank() }.keys.toList()
        if (clear.isNotEmpty()) extraTags.delete(ids, clear)
        if (set.isNotEmpty()) {
            extraTags.upsertAll(ids.flatMap { id -> set.map { (field, value) -> ExtraTag(id, field, value.trim()) } })
        }
    }
}
