package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/** Your own note about an artist ("found them on a radio show"). One row per artist; [artistKey] is the lower-case name. */
@Entity(tableName = "artist_notes")
data class ArtistNote(
    @PrimaryKey val artistKey: String,
    val note: String
)

fun artistKey(artist: String): String = artist.trim().lowercase()

@Dao
interface ArtistNoteDao {
    @Query("SELECT * FROM artist_notes")
    fun observeAll(): Flow<List<ArtistNote>>

    @Upsert
    suspend fun save(row: ArtistNote)

    @Query("DELETE FROM artist_notes WHERE artistKey = :key")
    suspend fun delete(key: String)
}
