package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.FileAccess
import app.needle.music.data.LyricsPrefs
import kotlin.math.roundToInt

/** Settings -> Lyrics: where lyrics come from, how they look. The mockup's "Sources, size, sync". */
@Composable
fun LyricsSettingsScreen(
    savedCount: Int,
    onRefreshSaved: () -> Unit,
    onClearSaved: () -> Unit,
    bottomPadding: Dp,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val fileAccess = FileAccess.granted.value
    LaunchedEffect(Unit) { onRefreshSaved() }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Lyrics", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp)
        Text("Sources, size and sync.", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))

        Group("Sources")
        SettingRow(
            ".lrc files next to songs",
            note = if (LyricsPrefs.useLrcFiles.value && !fileAccess)
                "Song.mp3 and Song.lrc in the same folder. Needs access to all files, tap to allow."
            else "Song.mp3 and Song.lrc in the same folder. Needs access to all files.",
            onClick = if (LyricsPrefs.useLrcFiles.value && !fileAccess) ({ FileAccess.openSettings(context) }) else null
        ) { NeedleSwitch(LyricsPrefs.useLrcFiles.value) { LyricsPrefs.setUseLrcFiles(it) } }
        SettingRow("Lyrics inside audio files", note = "The lyrics tag Needle has read from MP3, FLAC, Ogg and M4A files.") {
            NeedleSwitch(LyricsPrefs.useEmbedded.value) { LyricsPrefs.setUseEmbedded(it) }
        }
        SettingRow("Online search", note = "Adds the Search online button (LRCLIB, free). Found lyrics are saved on the phone.") {
            NeedleSwitch(LyricsPrefs.onlineSearch.value) { LyricsPrefs.setOnlineSearch(it) }
        }
        if (LyricsPrefs.onlineSearch.value) {
            SettingRow("Search online automatically", note = "When a song has no lyrics, look them up as soon as it shows on Now Playing or the lyrics page.") {
                NeedleSwitch(LyricsPrefs.autoOnline.value) { LyricsPrefs.setAutoOnline(it) }
            }
        }
        Text(
            "Lyrics you write or save in Needle always come first.",
            color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, bottom = 4.dp)
        )

        Spacer(Modifier.height(14.dp))
        Group("Display")
        SettingRow("Text size", note = "The slider on the lyrics page changes this too.") {
            Row(verticalAlignment = Alignment.CenterVertically) {
                RoundIconButton(NeedleIcon.MINUS, { LyricsPrefs.setScale(LyricsPrefs.scale.floatValue - 0.1f) })
                Text(
                    "${(LyricsPrefs.scale.floatValue * 100).roundToInt()}%",
                    color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    textAlign = TextAlign.Center, modifier = Modifier.width(52.dp)
                )
                RoundIconButton(NeedleIcon.PLUS, { LyricsPrefs.setScale(LyricsPrefs.scale.floatValue + 0.1f) })
            }
        }
        SettingRow("Font", note = "Used on the lyrics page and the preview card on Now Playing.") {
            Text(LyricsFont.byId(LyricsPrefs.font.value).label, color = Palette.Muted, fontSize = 14.sp)
        }
        FontPicker()
        SettingRow("Keep the screen on", note = "Start the lyrics page with the lock on, so the screen does not turn off while you read.") {
            NeedleSwitch(LyricsPrefs.keepScreenOn.value) { LyricsPrefs.setKeepScreenOn(it) }
        }

        Spacer(Modifier.height(14.dp))
        Group("Sync")
        SettingRow(
            "Sync offset",
            note = "Set per song: open the lyrics page, tap the info button and use −0.1 and +0.1."
        ) { Text("Per song", color = Palette.Muted, fontSize = 14.sp) }

        Spacer(Modifier.height(14.dp))
        Group("Saved lyrics")
        SettingRow(
            "Lyrics saved from LRCLIB",
            note = if (savedCount == 0) "None yet." else "$savedCount songs. Tap to forget them all.",
            onClick = if (savedCount > 0) onClearSaved else null
        ) {
            Text(if (savedCount > 0) "Clear" else "", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun Group(text: String) {
    Text(
        text, color = Palette.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}

/** The four fonts as chips, each written in its own font, and a sample of the chosen one at the lyrics sizes. */
@Composable
private fun FontPicker() {
    val current = LyricsFont.byId(LyricsPrefs.font.value)
    val scale = LyricsPrefs.scale.floatValue
    Row(Modifier.fillMaxWidth().padding(bottom = 8.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        LyricsFont.entries.forEach { f ->
            val on = f == current
            Box(
                Modifier
                    .weight(1f)
                    .height(44.dp)
                    .then(if (on) Modifier.clip(RoundedCornerShape(16.dp)).background(Palette.Accent) else Modifier.glass(RoundedCornerShape(16.dp)))
                    .clickable { LyricsPrefs.setFont(f.id) },
                contentAlignment = Alignment.Center
            ) {
                Text(f.label, color = Color.White, fontFamily = f.family, fontWeight = f.weight, fontSize = 15.sp, maxLines = 1)
            }
        }
    }
    Column(Modifier.fillMaxWidth().padding(bottom = 8.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 18.dp, vertical = 16.dp)) {
        Text(
            "She was a day tripper",
            color = Palette.Muted, fontFamily = current.family, fontWeight = current.weight, fontSize = (20f * scale).sp
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Sunday driver, yeah",
            color = Color.White, fontFamily = current.family, fontWeight = current.weight, fontSize = (29f * scale).sp, lineHeight = (33f * scale).sp
        )
    }
}
