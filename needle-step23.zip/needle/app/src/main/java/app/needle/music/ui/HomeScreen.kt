package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.IntrinsicSize
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.HomeAlbum
import app.needle.music.data.HeroCard
import app.needle.music.data.HomeState
import app.needle.music.data.Song
import app.needle.music.data.WeekStats
import app.needle.music.data.formatListened
import app.needle.music.data.notPlayedLabel

/** The pills under the Home title. [ready] is false until that page exists. */
enum class HomeTab(val label: String, val ready: Boolean) {
    NEW("New", true),
    POPULAR("Popular", true),
    MOST_PLAYED("Most played", false),
    SINGLES("Singles", true)
}

/**
 * Home / Popular page from the mockup.
 * [onViewAllAlbums] and [onOpenStats] are null until those pages exist; the links stay hidden until then.
 */
@Composable
fun HomeScreen(
    home: HomeState?,
    bottomPadding: Dp,
    onPlay: (List<Song>) -> Unit,
    onTabSelected: (HomeTab) -> Unit,
    modifier: Modifier = Modifier,
    profileInitial: String = "E",
    onSearch: () -> Unit = {},
    onProfile: () -> Unit = {},
    onViewAllAlbums: (() -> Unit)? = null,
    onOpenStats: (() -> Unit)? = null
) {
    val now = System.currentTimeMillis()
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item { HomeHeader(profileInitial, onSearch, onProfile) }
        item { HomeTabs(selected = HomeTab.POPULAR, onSelect = onTabSelected) }

        if (home == null) return@LazyColumn

        if (home.heroes.isNotEmpty()) {
            item {
                LazyRow(
                    Modifier.padding(top = 14.dp),
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(home.heroes) { hero -> HeroCardView(hero, onPlay = { onPlay(hero.songs) }) }
                }
            }
        } else {
            item {
                Text(
                    "Your library is empty. Open Songs and scan for music.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
                )
            }
        }

        if (home.yourAlbums.isNotEmpty()) {
            item { SectionHeader("Your albums", "View all", onViewAllAlbums) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(home.yourAlbums.size) { i ->
                        val album = home.yourAlbums[i]
                        AlbumTile(album, tagColor = tagColors[i % tagColors.size], onClick = { onPlay(album.songs) })
                    }
                }
            }
        }

        item { SectionHeader("This week", "Stats", onOpenStats) }
        item { WeekRow(home.week) }

        if (home.rediscover.isNotEmpty()) {
            item { SectionHeader("Rediscover", "View all", onViewAllAlbums) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    items(home.rediscover) { album ->
                        RediscoverTile(album, label = notPlayedLabel(album.lastPlayedAt, now), onClick = { onPlay(album.songs) })
                    }
                }
            }
        }
    }
}

private val tagColors = listOf(Palette.Accent, Palette.Green, Palette.Pink)

// ---- header and tabs -------------------------------------------------------------------

@Composable
internal fun HomeHeader(initial: String, onSearch: () -> Unit, onProfile: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)

        Text(
            "Needle", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 21.sp,
            textAlign = TextAlign.Center, modifier = Modifier.weight(1f)
        )

        Box(
            Modifier
                .size(42.dp)
                .clip(CircleShape)
                .background(Brush.linearGradient(listOf(Color(0xFFD9A38B), Color(0xFF6B4A5E))))
                .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                .clickable(onClick = onProfile),
            contentAlignment = Alignment.Center
        ) { Text(initial, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

@Composable
internal fun HomeTabs(selected: HomeTab, onSelect: (HomeTab) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(start = 18.dp, end = 18.dp, top = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        HomeTab.entries.forEach { tab ->
            val on = tab == selected
            Text(
                tab.label,
                color = if (on) Color(0xFF111111) else Palette.Text,
                fontSize = 14.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                maxLines = 1,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (on) Color.White else Palette.Card2)
                    .then(if (tab.ready && !on) Modifier.clickable { onSelect(tab) } else Modifier)
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            )
        }
    }
}

@Composable
internal fun SectionHeader(title: String, action: String, onAction: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 10.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        Text(title, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
        if (onAction != null) {
            Text(action, color = Color(0xFFDDDDDD), fontSize = 12.sp, modifier = Modifier.clickable(onClick = onAction))
        }
    }
}

// ---- hero cards --------------------------------------------------------------------------

@Composable
private fun HeroCardView(hero: HeroCard, onPlay: () -> Unit) {
    Box(Modifier.width(196.dp).height(262.dp).clip(RoundedCornerShape(26.dp)).background(Palette.Card)) {
        Cover(hero.cover, Modifier.fillMaxSize())
        // Darkens the top and bottom so the white text and button stay readable on any cover.
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = 0.55f),
                    0.4f to Color.Transparent,
                    0.75f to Color.Transparent,
                    1f to Color.Black.copy(alpha = 0.45f)
                )
            )
        )
        Column(Modifier.align(Alignment.TopStart).padding(14.dp)) {
            Text(
                hero.title, color = Color.White, fontSize = 21.sp, lineHeight = 23.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(
                hero.subtitle, color = Color.White.copy(alpha = 0.8f), fontSize = 11.5.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
            )
        }
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(10.dp)
                .height(40.dp)
                .clip(CircleShape)
                .background(Color.White)
                .clickable(onClick = onPlay)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) { Text("Play now", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    }
}

// ---- your albums -------------------------------------------------------------------------

@Composable
private fun AlbumTile(album: HomeAlbum, tagColor: Color, onClick: () -> Unit) {
    val total = album.songs.size
    Column(
        Modifier
            .width(152.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(Palette.Card)
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Text(
            album.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Text(
            album.artist, color = Color.White, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
            modifier = Modifier
                .padding(top = 6.dp, bottom = 16.dp)
                .clip(CircleShape)
                .background(tagColor)
                .padding(horizontal = 10.dp, vertical = 4.dp)
        )
        Row(verticalAlignment = Alignment.Bottom) {
            Text("${album.heardTracks}", color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.SemiBold)
            Text(
                "/ $total tracks", color = Palette.Muted, fontSize = 12.sp,
                modifier = Modifier.padding(start = 4.dp, bottom = 3.dp), maxLines = 1
            )
        }
        Box(
            Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(Color(0xFF555555))
        ) {
            val fraction = (album.heardTracks.toFloat() / total).coerceIn(0f, 1f)
            Box(Modifier.fillMaxHeight().fillMaxWidth(fraction).background(Color.White))
        }
    }
}

// ---- this week ---------------------------------------------------------------------------

@Composable
private fun WeekRow(week: WeekStats) {
    Row(
        Modifier.height(IntrinsicSize.Max).horizontalScroll(rememberScrollState()).padding(horizontal = 18.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        StatCard(formatListened(week.listenedMs), "Listened", width = 104.dp)
        StatCard("${week.plays}", "Plays", width = 104.dp)
        StatCard(week.topArtist ?: "–", "Top artist", width = 150.dp, valueSize = 17.sp)
    }
}

@Composable
private fun StatCard(value: String, label: String, width: Dp, valueSize: androidx.compose.ui.unit.TextUnit = 24.sp) {
    Column(
        Modifier
            .width(width)
            .fillMaxHeight()
            .clip(RoundedCornerShape(22.dp))
            .background(Palette.Card)
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Text(
            value, color = Palette.Text, fontSize = valueSize, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        Text(label, color = Palette.Muted, fontSize = 11.5.sp)
    }
}

// ---- rediscover --------------------------------------------------------------------------

@Composable
private fun RediscoverTile(album: HomeAlbum, label: String, onClick: () -> Unit) {
    Column(Modifier.width(96.dp).clickable(onClick = onClick)) {
        Cover(album.cover, Modifier.size(96.dp).clip(RoundedCornerShape(20.dp)))
        Text(
            album.title, color = Palette.Text, fontSize = 12.5.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp)
        )
        Text(label, color = Palette.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---- artwork -----------------------------------------------------------------------------

/** Large cover that fills [modifier]. Shows the pink placeholder while loading or when the file has no cover. */
@Composable
internal fun Cover(song: Song, modifier: Modifier) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peekLarge(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peekLarge(song) ?: ArtworkLoader.loadLarge(context, song)
    }
    val bitmap = art
    if (bitmap != null) {
        Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
    } else {
        ArtworkPlaceholder(modifier)
    }
}
