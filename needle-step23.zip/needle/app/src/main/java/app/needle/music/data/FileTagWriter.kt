package app.needle.music.data

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel

/**
 * What to change inside an audio file. Only what is listed is touched; every other tag stays as it is.
 * [core] keys: TITLE, ARTIST, ALBUM, GENRE, YEAR, TRACK. [extras] keys are the field names of [TagFields].
 * [cover] is a JPEG.
 */
class TagWrite(
    val core: Map<String, String>,
    val extras: Map<String, String>,
    val cover: ByteArray?
) {
    fun isEmpty() = core.isEmpty() && extras.isEmpty() && cover == null
}

/** A piece of the new file: bytes made here, or a stretch of the original file copied as it is. */
sealed class Segment {
    class Bytes(val data: ByteArray) : Segment()
    class Range(val start: Long, val end: Long) : Segment()
}

/** How to build the new file: its pieces in order, and which part of it is the audio (for checking). */
class WritePlan(val segments: List<Segment>, val format: String)

class UnsupportedFormat(message: String) : Exception(message)

/**
 * Works out the new file for MP3 (ID3v2.3 / 2.4), FLAC and M4A / MP4. It never changes the audio: the new file
 * is the new tag area plus the old audio, copied untouched. The result is checked before it replaces anything
 * (see TagWriter). Tested against files written by ffmpeg, with ffmpeg confirming the audio is byte for byte
 * the same and the new file still decodes.
 */
object FileTagWriter {

    private const val MAX_BLOCK = 16 * 1024 * 1024
    private const val ID3_PADDING = 1024
    private const val FLAC_PADDING = 4096

    fun plan(ch: FileChannel, write: TagWrite): WritePlan {
        val head = readUpTo(ch, 0, 12)
        return when {
            head.size >= 3 && String(head, 0, 3, Charsets.ISO_8859_1) == "ID3" ||
                (head.size >= 2 && u(head[0]) == 0xFF && (u(head[1]) and 0xE0) == 0xE0 && (u(head[1]) and 0x06) != 0) -> planId3(ch, write)
            head.size >= 4 && String(head, 0, 4, Charsets.ISO_8859_1) == "fLaC" -> planFlac(ch, write)
            head.size >= 8 && String(head, 4, 4, Charsets.ISO_8859_1) == "ftyp" -> planMp4(ch, write)
            else -> throw UnsupportedFormat("This file type cannot be written yet (MP3, FLAC and M4A can)")
        }
    }

    // ---- small helpers -----------------------------------------------------------------------

    private fun u(b: Byte): Int = b.toInt() and 0xFF

    private fun readUpTo(ch: FileChannel, pos: Long, n: Int): ByteArray {
        val buf = ByteBuffer.allocate(n)
        var at = pos
        while (buf.hasRemaining()) {
            val r = ch.read(buf, at)
            if (r <= 0) break
            at += r
        }
        return buf.array().copyOfRange(0, buf.position())
    }

    private fun readExact(ch: FileChannel, pos: Long, n: Int): ByteArray {
        if (n < 0 || n > MAX_BLOCK * 4) throw UnsupportedFormat("The tag area is too big")
        val got = readUpTo(ch, pos, n)
        if (got.size != n) throw UnsupportedFormat("The file ends too early")
        return got
    }

    private fun synchsafe(b: ByteArray, at: Int): Int =
        (u(b[at]) shl 21) or (u(b[at + 1]) shl 14) or (u(b[at + 2]) shl 7) or u(b[at + 3])

    private fun toSynchsafe(n: Int): ByteArray =
        byteArrayOf(((n shr 21) and 0x7F).toByte(), ((n shr 14) and 0x7F).toByte(), ((n shr 7) and 0x7F).toByte(), (n and 0x7F).toByte())

    private fun be32(n: Int): ByteArray =
        byteArrayOf((n ushr 24).toByte(), (n ushr 16).toByte(), (n ushr 8).toByte(), n.toByte())

    private fun be16(n: Int): ByteArray = byteArrayOf((n ushr 8).toByte(), n.toByte())

    private fun readBe(b: ByteArray, at: Int, n: Int): Long {
        var v = 0L
        for (i in 0 until n) v = (v shl 8) or u(b[at + i]).toLong()
        return v
    }

    private fun cat(vararg parts: ByteArray): ByteArray {
        val out = ByteArrayOutputStream()
        for (p in parts) out.write(p)
        return out.toByteArray()
    }

    private fun norm(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    private val byNorm: Map<String, String> = TagFields.all.associate { norm(it.key) to it.key }

    /** The names Picard and Mp3tag use for these in TXXX frames and iTunes freeform atoms. */
    private val pretty: Map<String, String> = mapOf(
        "MUSICBRAINZ_ALBUMARTISTID" to "MusicBrainz Album Artist Id", "MUSICBRAINZ_ALBUMID" to "MusicBrainz Album Id",
        "MUSICBRAINZ_ALBUMRELEASECOUNTRY" to "MusicBrainz Album Release Country",
        "MUSICBRAINZ_ALBUMSTATUS" to "MusicBrainz Album Status", "MUSICBRAINZ_ALBUMTYPE" to "MusicBrainz Album Type",
        "MUSICBRAINZ_ARTISTID" to "MusicBrainz Artist Id", "MUSICBRAINZ_DISCID" to "MusicBrainz Disc Id",
        "MUSICBRAINZ_ORIGINALALBUMID" to "MusicBrainz Original Album Id",
        "MUSICBRAINZ_ORIGINALARTISTID" to "MusicBrainz Original Artist Id",
        "MUSICBRAINZ_RELEASEGROUPID" to "MusicBrainz Release Group Id",
        "MUSICBRAINZ_RELEASETRACKID" to "MusicBrainz Release Track Id", "MUSICBRAINZ_TRMID" to "MusicBrainz TRM Id",
        "MUSICBRAINZ_WORKID" to "MusicBrainz Work Id", "ACOUSTID_ID" to "Acoustid Id",
        "ACOUSTID_FINGERPRINT" to "Acoustid Fingerprint"
    )

    private fun isLatin1(s: String) = s.all { it.code <= 0xFF }

    // =========================================================================== ID3v2 (MP3)

    private val id3Text: Map<String, String> = mapOf(
        "ALBUMARTIST" to "TPE2", "COMPOSER" to "TCOM", "CONDUCTOR" to "TPE3", "LYRICIST" to "TEXT", "MIXARTIST" to "TPE4",
        "ORIGARTIST" to "TOPE", "ORIGLYRICIST" to "TOLY", "TITLESORT" to "TSOT", "ARTISTSORT" to "TSOP",
        "ALBUMSORT" to "TSOA", "ALBUMARTISTSORT" to "TSO2", "COMPOSERSORT" to "TSOC", "DISCNUMBER" to "TPOS",
        "SUBTITLE" to "TIT3", "SETSUBTITLE" to "TSST", "GROUPING" to "GRP1", "CONTENTGROUP" to "TIT1",
        "COMPILATION" to "TCMP", "MOVEMENTNAME" to "MVNM", "ORIGALBUM" to "TOAL", "MOOD" to "TMOO", "BPM" to "TBPM",
        "INITIALKEY" to "TKEY", "LANGUAGE" to "TLAN", "PUBLISHER" to "TPUB", "COPYRIGHT" to "TCOP", "ISRC" to "TSRC",
        "MEDIATYPE" to "TMED"
    )

    private val id3Url: Map<String, String> = mapOf(
        "WWWARTIST" to "WOAR", "WWWAUDIOFILE" to "WOAF", "WWWAUDIOSOURCE" to "WOAS", "WWWCOMMERCIALINFO" to "WCOM",
        "WWWCOPYRIGHT" to "WCOP", "WWWPAYMENT" to "WPAY", "WWWPUBLISHER" to "WPUB", "WWWRADIOPAGE" to "WORS"
    )

    private class Frame(val id: String, val flags: ByteArray, var data: ByteArray)

    private fun unsync(b: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(b.size)
        var i = 0
        while (i < b.size) {
            out.write(u(b[i]))
            if (b[i] == 0xFF.toByte() && i + 1 < b.size && b[i + 1] == 0.toByte()) i++
            i++
        }
        return out.toByteArray()
    }

    private fun planId3(ch: FileChannel, write: TagWrite): WritePlan {
        val fileSize = ch.size()
        val head = readUpTo(ch, 0, 10)
        var ver = 4
        var audioStart = 0L
        val frames = ArrayList<Frame>()

        if (head.size == 10 && String(head, 0, 3, Charsets.ISO_8859_1) == "ID3") {
            ver = u(head[3])
            val flags = u(head[5])
            val size = synchsafe(head, 6)
            if (ver != 3 && ver != 4) throw UnsupportedFormat("This MP3 has an old ID3v2.$ver tag, which cannot be written")
            if (size > MAX_BLOCK) throw UnsupportedFormat("The tag area is too big")
            audioStart = 10L + size + (if (ver == 4 && (flags and 0x10) != 0) 10 else 0)
            var body = readExact(ch, 10, size)
            if (ver == 3 && (flags and 0x80) != 0) body = unsync(body)
            var pos = 0
            if ((flags and 0x40) != 0) { // extended header: skipped, we write none
                if (body.size < 4) throw UnsupportedFormat("The tag is damaged")
                pos = if (ver == 4) synchsafe(body, 0) else (readBe(body, 0, 4) + 4).toInt()
            }
            while (pos + 10 <= body.size && body[pos] != 0.toByte()) {
                val id = String(body, pos, 4, Charsets.ISO_8859_1)
                val fsz = if (ver == 4) synchsafe(body, pos + 4) else readBe(body, pos + 4, 4).toInt()
                val fl = body.copyOfRange(pos + 8, pos + 10)
                pos += 10
                if (fsz <= 0 || pos + fsz > body.size) break
                var d = body.copyOfRange(pos, pos + fsz)
                pos += fsz
                if (ver == 4 && (u(fl[1]) and 0x0C) == 0) { // normalise: no unsync, no length indicator
                    if ((u(fl[1]) and 0x01) != 0) d = d.copyOfRange(minOf(4, d.size), d.size)
                    if ((u(fl[1]) and 0x02) != 0 || (flags and 0x80) != 0) d = unsync(d)
                    fl[1] = (u(fl[1]) and 0x03.inv()).toByte()
                }
                frames += Frame(id, fl, d)
            }
        }

        fun drop(vararg ids: String) { frames.removeAll { it.id in ids } }
        fun put(id: String, data: ByteArray) { frames += Frame(id, byteArrayOf(0, 0), data) }

        fun encText(s: String): Pair<Int, ByteArray> = when {
            ver == 4 -> 3 to s.toByteArray(Charsets.UTF_8)
            isLatin1(s) -> 0 to s.toByteArray(Charsets.ISO_8859_1)
            else -> 1 to cat(byteArrayOf(0xFF.toByte(), 0xFE.toByte()), s.toByteArray(Charsets.UTF_16LE))
        }
        fun textFrame(s: String): ByteArray { val (e, b) = encText(s); return cat(byteArrayOf(e.toByte()), b) }
        fun terminator(e: Int) = if (e == 1) byteArrayOf(0, 0) else byteArrayOf(0)

        // description + text in one encoding (COMM, USLT, TXXX)
        fun twoStrings(desc: String, text: String): Triple<Int, ByteArray, ByteArray> {
            val e = if (ver == 4) 3 else if (isLatin1(desc) && isLatin1(text)) 0 else 1
            fun enc(s: String) = when (e) {
                0 -> s.toByteArray(Charsets.ISO_8859_1)
                3 -> s.toByteArray(Charsets.UTF_8)
                else -> cat(byteArrayOf(0xFF.toByte(), 0xFE.toByte()), s.toByteArray(Charsets.UTF_16LE))
            }
            return Triple(e, enc(desc), enc(text))
        }
        fun commLike(desc: String, text: String): ByteArray {
            val (e, d, t) = twoStrings(desc, text)
            return cat(byteArrayOf(e.toByte()), "eng".toByteArray(), d, terminator(e), t)
        }
        fun txxx(desc: String, text: String): ByteArray {
            val (e, d, t) = twoStrings(desc, text)
            return cat(byteArrayOf(e.toByte()), d, terminator(e), t)
        }
        fun listFrame(items: List<String>): ByteArray {
            if (ver == 4) return cat(byteArrayOf(3), items.joinToString("\u0000").toByteArray(Charsets.UTF_8))
            if (items.all { isLatin1(it) }) return cat(byteArrayOf(0), items.joinToString("\u0000").toByteArray(Charsets.ISO_8859_1))
            val out = ByteArrayOutputStream()
            out.write(1)
            items.forEachIndexed { i, s ->
                if (i > 0) { out.write(0); out.write(0) }
                out.write(0xFF); out.write(0xFE)
                out.write(s.toByteArray(Charsets.UTF_16LE))
            }
            return out.toByteArray()
        }

        fun firstString(e: Int, b: ByteArray): String {
            if (e == 1 || e == 2) {
                var i = 0
                var end = b.size
                while (i + 1 < b.size) {
                    if (b[i] == 0.toByte() && b[i + 1] == 0.toByte()) { end = i; break }
                    i += 2
                }
                val s = b.copyOfRange(0, end)
                return when {
                    s.size >= 2 && u(s[0]) == 0xFF && u(s[1]) == 0xFE -> String(s, 2, s.size - 2, Charsets.UTF_16LE)
                    s.size >= 2 && u(s[0]) == 0xFE && u(s[1]) == 0xFF -> String(s, 2, s.size - 2, Charsets.UTF_16BE)
                    e == 1 -> String(s, Charsets.UTF_16LE)
                    else -> String(s, Charsets.UTF_16BE)
                }
            }
            val z = b.indexOf(0.toByte())
            val s = if (z >= 0) b.copyOfRange(0, z) else b
            return String(s, if (e == 0) Charsets.ISO_8859_1 else Charsets.UTF_8)
        }
        /** The description of a COMM / USLT payload (3 language bytes first) or of a TXXX payload. */
        fun descOf(data: ByteArray, withLanguage: Boolean): String {
            if (data.isEmpty()) return ""
            val skip = if (withLanguage) 4 else 1
            return firstString(u(data[0]), if (data.size > skip) data.copyOfRange(skip, data.size) else ByteArray(0))
        }
        fun oldText(id: String): String {
            val f = frames.firstOrNull { it.id == id && it.data.isNotEmpty() } ?: return ""
            val e = u(f.data[0])
            val b = f.data.copyOfRange(1, f.data.size)
            return try {
                when (e) {
                    0 -> String(b, Charsets.ISO_8859_1)
                    3 -> String(b, Charsets.UTF_8)
                    1 -> if (b.size >= 2 && u(b[0]) == 0xFF && u(b[1]) == 0xFE) String(b, 2, b.size - 2, Charsets.UTF_16LE)
                         else if (b.size >= 2) String(b, 2, b.size - 2, Charsets.UTF_16BE) else ""
                    else -> String(b, Charsets.UTF_16BE)
                }
            } catch (ex: Exception) { "" }
        }
        fun apicType(data: ByteArray): Int {
            if (data.size < 2) return -1
            val i = data.indexOf(0.toByte(), 1)
            return if (i >= 0 && i + 1 < data.size) u(data[i + 1]) else -1
        }
        fun putTxxx(desc: String, value: String) {
            frames.removeAll { it.id == "TXXX" && norm(descOf(it.data, false)) == norm(desc) }
            put("TXXX", txxx(desc, value))
        }

        // ---- core
        val core = write.core
        for ((k, id) in listOf("TITLE" to "TIT2", "ARTIST" to "TPE1", "ALBUM" to "TALB", "GENRE" to "TCON")) {
            core[k]?.let { drop(id); put(id, textFrame(it)) }
        }
        core["YEAR"]?.let {
            drop("TDRC", "TYER", "TDAT", "TIME", "TRDA")
            put(if (ver == 4) "TDRC" else "TYER", textFrame(it))
        }
        core["TRACK"]?.let {
            val total = oldText("TRCK").substringAfter('/', "")
            drop("TRCK")
            put("TRCK", textFrame(it + if (total.isNotEmpty()) "/$total" else ""))
        }

        // ---- extras
        val movement = LinkedHashMap<String, String>()
        for ((key, value) in write.extras) {
            // A leftover TXXX that means the same thing would win over the new frame when reading.
            if (key != "MUSICBRAINZ_TRACKID" && key !in pretty) {
                frames.removeAll { it.id == "TXXX" && byNorm[norm(descOf(it.data, false))] == key }
            }
            when {
                key in id3Text -> { val id = id3Text.getValue(key); drop(id); put(id, textFrame(value)) }
                key == "ORIGYEAR" -> { drop("TORY", "TDOR"); put(if (ver == 4) "TDOR" else "TORY", textFrame(value)) }
                key == "RELEASETIME" && ver == 4 -> { drop("TDRL"); put("TDRL", textFrame(value)) }
                key == "COMMENT" -> {
                    frames.removeAll { it.id == "COMM" && descOf(it.data, true).isEmpty() }
                    put("COMM", commLike("", value))
                }
                key == "UNSYNCEDLYRICS" -> {
                    frames.removeAll { it.id == "USLT" && descOf(it.data, true).isEmpty() }
                    put("USLT", commLike("", value))
                }
                key == "RATING" -> {
                    val stars = value.toIntOrNull()?.coerceIn(1, 5)
                    if (stars != null) {
                        val b = intArrayOf(0, 1, 64, 128, 196, 255)[stars]
                        drop("POPM")
                        put("POPM", cat("Windows Media Player 9 Series".toByteArray(Charsets.ISO_8859_1),
                            byteArrayOf(0, b.toByte(), 0, 0, 0, 0)))
                    }
                }
                key in id3Url -> { val id = id3Url.getValue(key); drop(id); put(id, value.toByteArray(Charsets.ISO_8859_1)) }
                key == "WWW" -> {
                    frames.removeAll { it.id == "WXXX" && descOf(it.data, false).isEmpty() }
                    put("WXXX", cat(byteArrayOf(0, 0), value.toByteArray(Charsets.ISO_8859_1)))
                }
                key == "MOVEMENT" || key == "MOVEMENTTOTAL" -> movement[key] = value
                key == "INVOLVEDPEOPLE" || key == "MUSICIANCREDITS" -> {
                    val items = ArrayList<String>()
                    for (pair in value.split(';')) {
                        if (':' in pair) { items += pair.substringBefore(':').trim(); items += pair.substringAfter(':').trim() }
                    }
                    if (key == "INVOLVEDPEOPLE") {
                        drop("TIPL", "IPLS"); put(if (ver == 4) "TIPL" else "IPLS", listFrame(items))
                    } else if (ver == 4) {
                        drop("TMCL"); put("TMCL", listFrame(items))
                    } else {
                        putTxxx(key, value)
                    }
                }
                key == "MUSICBRAINZ_TRACKID" -> {
                    val owner = "http://musicbrainz.org".toByteArray(Charsets.ISO_8859_1)
                    frames.removeAll { it.id == "UFID" && it.data.size > owner.size && it.data.copyOfRange(0, owner.size).contentEquals(owner) && it.data[owner.size] == 0.toByte() }
                    put("UFID", cat(owner, byteArrayOf(0), value.toByteArray(Charsets.ISO_8859_1)))
                }
                else -> putTxxx(pretty[key] ?: key, value)
            }
        }
        if (movement.isNotEmpty()) {
            val old = oldText("MVIN")
            val n = movement["MOVEMENT"] ?: old.substringBefore('/')
            val t = movement["MOVEMENTTOTAL"] ?: old.substringAfter('/', "")
            drop("MVIN")
            put("MVIN", textFrame(n + if (t.isNotEmpty()) "/$t" else ""))
        }
        write.cover?.let { jpeg ->
            frames.removeAll { it.id == "APIC" && apicType(it.data) in listOf(0, 3) } // the front cover, or an untyped picture
            put("APIC", cat(byteArrayOf(0), "image/jpeg".toByteArray(), byteArrayOf(0, 3, 0), jpeg))
        }

        // ---- the new tag area
        val body = ByteArrayOutputStream()
        for (f in frames) {
            body.write(f.id.toByteArray(Charsets.ISO_8859_1))
            body.write(if (ver == 4) toSynchsafe(f.data.size) else be32(f.data.size))
            body.write(f.flags)
            body.write(f.data)
        }
        body.write(ByteArray(ID3_PADDING))
        val bodyBytes = body.toByteArray()
        val tag = cat("ID3".toByteArray(), byteArrayOf(ver.toByte(), 0, 0), toSynchsafe(bodyBytes.size), bodyBytes)
        return WritePlan(listOf(Segment.Bytes(tag), Segment.Range(audioStart, fileSize)), "MP3")
    }

    private fun ByteArray.indexOf(element: Byte, from: Int): Int {
        for (i in from until size) if (this[i] == element) return i
        return -1
    }

    // =========================================================================== FLAC

    private val flacName: Map<String, String> = mapOf(
        "MIXARTIST" to "REMIXER", "ORIGARTIST" to "ORIGINALARTIST", "ORIGLYRICIST" to "ORIGINALLYRICIST",
        "SETSUBTITLE" to "DISCSUBTITLE", "UNSYNCEDLYRICS" to "LYRICS", "PUBLISHER" to "LABEL",
        "RELEASETIME" to "RELEASEDATE", "ORIGYEAR" to "ORIGINALDATE", "ORIGALBUM" to "ORIGINALALBUM",
        "MEDIATYPE" to "MEDIA"
    )

    /** Other names the same thing may already have in the file; all of them are replaced. */
    private val flacAliases: Map<String, List<String>> = mapOf(
        "UNSYNCEDLYRICS" to listOf("LYRICS", "UNSYNCEDLYRICS"), "PUBLISHER" to listOf("LABEL", "ORGANIZATION", "PUBLISHER"),
        "MIXARTIST" to listOf("REMIXER", "MIXARTIST"), "ORIGYEAR" to listOf("ORIGINALDATE", "ORIGINALYEAR", "ORIGYEAR"),
        "RELEASETIME" to listOf("RELEASEDATE", "RELEASETIME"), "INITIALKEY" to listOf("INITIALKEY", "KEY"),
        "BPM" to listOf("BPM", "TEMPO")
    )

    private fun le32(b: ByteArray, at: Int): Long =
        u(b[at]).toLong() or (u(b[at + 1]).toLong() shl 8) or (u(b[at + 2]).toLong() shl 16) or (u(b[at + 3]).toLong() shl 24)

    private fun leBytes(n: Int): ByteArray =
        byteArrayOf(n.toByte(), (n ushr 8).toByte(), (n ushr 16).toByte(), (n ushr 24).toByte())

    private class FlacBlock(val type: Int, val start: Long, val length: Int)

    private fun jpegSize(b: ByteArray): Pair<Int, Int> {
        var i = 2
        while (i + 9 < b.size) {
            if (u(b[i]) != 0xFF) { i++; continue }
            val m = u(b[i + 1])
            if (m == 0xC0 || m == 0xC1 || m == 0xC2) {
                return ((u(b[i + 7]) shl 8) or u(b[i + 8])) to ((u(b[i + 5]) shl 8) or u(b[i + 6])) // width to height
            }
            i += 2 + ((u(b[i + 2]) shl 8) or u(b[i + 3]))
        }
        return 0 to 0
    }

    private fun planFlac(ch: FileChannel, write: TagWrite): WritePlan {
        val fileSize = ch.size()
        var pos = 4L
        val blocks = ArrayList<FlacBlock>()
        while (true) {
            val h = readExact(ch, pos, 4)
            val last = (u(h[0]) and 0x80) != 0
            val type = u(h[0]) and 0x7F
            val len = (u(h[1]) shl 16) or (u(h[2]) shl 8) or u(h[3])
            if (pos + 4 + len > fileSize) throw UnsupportedFormat("The FLAC file is damaged")
            blocks += FlacBlock(type, pos + 4, len)
            pos += 4 + len
            if (last) break
        }
        val audioStart = pos

        var vendor = "Needle".toByteArray()
        val items = ArrayList<String>()
        blocks.firstOrNull { it.type == 4 }?.let { b ->
            if (b.length > MAX_BLOCK) throw UnsupportedFormat("The tag area is too big")
            val d = readExact(ch, b.start, b.length)
            var p = 0
            val vl = le32(d, p).toInt(); p += 4
            vendor = d.copyOfRange(p, p + vl); p += vl
            val n = le32(d, p).toInt(); p += 4
            repeat(n) {
                val l = le32(d, p).toInt(); p += 4
                items += String(d, p, l, Charsets.UTF_8); p += l
            }
        }
        fun setKey(names: List<String>, value: String) {
            items.removeAll { it.substringBefore('=').uppercase() in names }
            if (value.isNotEmpty()) items += names.last() + "=" + value
        }
        for ((k, name) in listOf("TITLE" to "TITLE", "ARTIST" to "ARTIST", "ALBUM" to "ALBUM", "GENRE" to "GENRE", "YEAR" to "DATE", "TRACK" to "TRACKNUMBER")) {
            write.core[k]?.let { setKey(listOf(name), it) }
        }
        for ((key, value) in write.extras) {
            val primary = flacName[key] ?: key
            if (primary.isEmpty() || !primary.all { it.code in 0x20..0x7D && it != '=' }) continue
            setKey((flacAliases[key] ?: listOf(primary)).map { it.uppercase() } + primary, value)
        }

        // The blocks to keep (by reference, nothing big is loaded), then the new comments, cover and padding.
        class Out(val type: Int, val bytes: ByteArray?, val range: Segment.Range?)
        val out = ArrayList<Out>()
        for (b in blocks) {
            if (b.type == 4 || b.type == 1) continue // old comments, old padding
            if (b.type == 6 && write.cover != null) {
                val pictureType = readLe4Be(readExact(ch, b.start, 4))
                if (pictureType == 0 || pictureType == 3) continue // old front cover
            }
            out += Out(b.type, null, Segment.Range(b.start, b.start + b.length))
        }
        val comments = ByteArrayOutputStream()
        comments.write(leBytes(vendor.size)); comments.write(vendor); comments.write(leBytes(items.size))
        for (entry in items) { val e = entry.toByteArray(Charsets.UTF_8); comments.write(leBytes(e.size)); comments.write(e) }
        out += Out(4, comments.toByteArray(), null)
        write.cover?.let { jpeg ->
            val (w, h) = jpegSize(jpeg)
            val mime = "image/jpeg".toByteArray()
            val pic = cat(
                be32(3), be32(mime.size), mime, be32(0), be32(w), be32(h), be32(24), be32(0), be32(jpeg.size), jpeg
            )
            out += Out(6, pic, null)
        }
        out += Out(1, ByteArray(FLAC_PADDING), null)

        val segments = ArrayList<Segment>()
        segments += Segment.Bytes("fLaC".toByteArray())
        out.forEachIndexed { i, o ->
            val length = o.bytes?.size ?: (o.range!!.end - o.range.start).toInt()
            val first = (if (i == out.size - 1) 0x80 else 0) or o.type
            segments += Segment.Bytes(byteArrayOf(first.toByte(), (length shr 16).toByte(), (length shr 8).toByte(), length.toByte()))
            segments += if (o.bytes != null) Segment.Bytes(o.bytes) else o.range!!
        }
        segments += Segment.Range(audioStart, fileSize)
        return WritePlan(segments, "FLAC")
    }

    private fun readLe4Be(b: ByteArray): Int = ((u(b[0]) shl 24) or (u(b[1]) shl 16) or (u(b[2]) shl 8) or u(b[3]))

    // =========================================================================== MP4 / M4A

    private val mp4Text: Map<String, String> = mapOf(
        "ALBUMARTIST" to "aART", "COMPOSER" to "\u00A9wrt", "GROUPING" to "\u00A9grp", "COMMENT" to "\u00A9cmt",
        "DESCRIPTION" to "desc", "UNSYNCEDLYRICS" to "\u00A9lyr", "COPYRIGHT" to "cprt", "ALBUMSORT" to "soal",
        "ALBUMARTISTSORT" to "soaa", "ARTISTSORT" to "soar", "TITLESORT" to "sonm", "COMPOSERSORT" to "soco",
        "MOVEMENTNAME" to "\u00A9mvn", "WORK" to "\u00A9wrk"
    )

    private val mp4Core: Map<String, String> = mapOf(
        "TITLE" to "\u00A9nam", "ARTIST" to "\u00A9ART", "ALBUM" to "\u00A9alb", "GENRE" to "\u00A9gen", "YEAR" to "\u00A9day"
    )

    private class MBox(val type: String, val off: Int, val size: Int)

    private fun box(type: String, payload: ByteArray): ByteArray =
        cat(be32(payload.size + 8), type.toByteArray(Charsets.ISO_8859_1), payload)

    private fun dataBox(flags: Int, value: ByteArray): ByteArray = box("data", cat(be32(flags), be32(0), value))

    private fun itemText(type: String, s: String) = box(type, dataBox(1, s.toByteArray(Charsets.UTF_8)))

    private fun itemFreeform(name: String, s: String): ByteArray = box(
        "----",
        cat(
            box("mean", cat(be32(0), "com.apple.iTunes".toByteArray())),
            box("name", cat(be32(0), name.toByteArray(Charsets.UTF_8))),
            dataBox(1, s.toByteArray(Charsets.UTF_8))
        )
    )

    private fun boxesIn(b: ByteArray, start: Int, end: Int): List<MBox> {
        val out = ArrayList<MBox>()
        var p = start
        while (p + 8 <= end) {
            var size = readBe(b, p, 4)
            val type = String(b, p + 4, 4, Charsets.ISO_8859_1)
            val headerLen = if (size == 1L) 16 else 8
            if (size == 1L) { if (p + 16 > end) break; size = readBe(b, p + 8, 8) }
            else if (size == 0L) size = (end - p).toLong()
            if (size < headerLen || p + size > end) break
            out += MBox(type, p, size.toInt())
            p += size.toInt()
        }
        return out
    }

    /** Adds [delta] to every chunk offset (stco / co64) that points behind the old position of moov. */
    private fun patchOffsets(moov: ByteArray, oldMoovPos: Long, delta: Long): ByteArray {
        val m = moov.copyOf()
        fun walk(start: Int, end: Int) {
            for (bx in boxesIn(m, start, end)) {
                when (bx.type) {
                    "trak", "mdia", "minf", "stbl" -> walk(bx.off + 8, bx.off + bx.size)
                    "stco" -> {
                        val n = readBe(m, bx.off + 12, 4).toInt()
                        for (i in 0 until n) {
                            val q = bx.off + 16 + 4 * i
                            val v = readBe(m, q, 4)
                            if (v >= oldMoovPos) {
                                val nv = (v + delta).toInt()
                                for (k in 0 until 4) m[q + k] = (nv ushr (24 - 8 * k)).toByte()
                            }
                        }
                    }
                    "co64" -> {
                        val n = readBe(m, bx.off + 12, 4).toInt()
                        for (i in 0 until n) {
                            val q = bx.off + 16 + 8 * i
                            val v = readBe(m, q, 8)
                            if (v >= oldMoovPos) {
                                val nv = v + delta
                                for (k in 0 until 8) m[q + k] = (nv ushr (56 - 8 * k)).toByte()
                            }
                        }
                    }
                }
            }
        }
        walk(8, m.size)
        return m
    }

    private fun planMp4(ch: FileChannel, write: TagWrite): WritePlan {
        val fileSize = ch.size()
        // find moov among the top-level boxes by reading only their headers
        var pos = 0L
        var moovPos = -1L
        var moovSize = 0L
        while (pos + 8 <= fileSize) {
            val h = readExact(ch, pos, 8)
            var size = readBe(h, 0, 4)
            val type = String(h, 4, 4, Charsets.ISO_8859_1)
            var headerLen = 8
            if (size == 1L) { size = readBe(readExact(ch, pos + 8, 8), 0, 8); headerLen = 16 }
            else if (size == 0L) size = fileSize - pos
            if (size < headerLen || pos + size > fileSize) throw UnsupportedFormat("The file is damaged")
            if (type == "moov") {
                if (headerLen != 8 || size > MAX_BLOCK * 4L) throw UnsupportedFormat("The metadata box is too big")
                moovPos = pos; moovSize = size
                break
            }
            pos += size
        }
        if (moovPos < 0) throw UnsupportedFormat("No metadata box found in this file")

        val mb = readExact(ch, moovPos, moovSize.toInt())
        val kids = boxesIn(mb, 8, mb.size)
        val udta = kids.firstOrNull { it.type == "udta" }
        val items = ArrayList<Pair<String, ByteArray>>()
        val metaChildren = ArrayList<ByteArray>()
        var hdlr: ByteArray? = null
        var udtaOther = ByteArray(0)
        if (udta != null) {
            val ub = mb.copyOfRange(udta.off, udta.off + udta.size)
            for (b1 in boxesIn(ub, 8, ub.size)) {
                if (b1.type == "meta") {
                    val mm = ub.copyOfRange(b1.off, b1.off + b1.size)
                    for (b2 in boxesIn(mm, 12, mm.size)) {
                        when (b2.type) {
                            "keys" -> throw UnsupportedFormat("This M4A uses QuickTime-style metadata, which cannot be written")
                            "ilst" -> {
                                val il = mm.copyOfRange(b2.off, b2.off + b2.size)
                                for (b3 in boxesIn(il, 8, il.size)) items += b3.type to il.copyOfRange(b3.off, b3.off + b3.size)
                            }
                            "hdlr" -> hdlr = mm.copyOfRange(b2.off, b2.off + b2.size)
                            else -> metaChildren += mm.copyOfRange(b2.off, b2.off + b2.size)
                        }
                    }
                } else {
                    udtaOther = cat(udtaOther, ub.copyOfRange(b1.off, b1.off + b1.size))
                }
            }
        }
        val handler = hdlr ?: box("hdlr", cat(be32(0), be32(0), "mdir".toByteArray(), "appl".toByteArray(), ByteArray(8), byteArrayOf(0)))

        fun freeformName(raw: ByteArray): String {
            for (b in boxesIn(raw, 8, raw.size)) {
                if (b.type == "name" && b.size >= 12) return String(raw, b.off + 12, b.size - 12, Charsets.UTF_8)
            }
            return ""
        }
        fun remove(type: String? = null, name: String? = null) {
            items.removeAll { (t, raw) ->
                (type != null && t == type) || (name != null && t == "----" && norm(freeformName(raw)) == norm(name))
            }
        }
        fun oldValue(type: String): ByteArray {
            val raw = items.firstOrNull { it.first == type }?.second ?: return ByteArray(0)
            for (b in boxesIn(raw, 8, raw.size)) if (b.type == "data" && b.size >= 16) return raw.copyOfRange(b.off + 16, b.off + b.size)
            return ByteArray(0)
        }

        for ((k, type) in mp4Core) {
            write.core[k]?.let {
                remove(type); items += type to itemText(type, it)
                if (k == "GENRE") remove("gnre")
            }
        }
        write.core["TRACK"]?.toIntOrNull()?.let { track ->
            val old = oldValue("trkn")
            val total = if (old.size >= 6) readBe(old, 4, 2).toInt() else 0
            remove("trkn")
            items += "trkn" to box("trkn", dataBox(0, cat(be16(0), be16(track), be16(total), be16(0))))
        }
        for ((key, value) in write.extras) {
            when {
                key in mp4Text -> { val t = mp4Text.getValue(key); remove(t); items += t to itemText(t, value) }
                key == "DISCNUMBER" -> {
                    val d = value.substringBefore('/').trim().toIntOrNull() ?: 0
                    val t = value.substringAfter('/', "").trim().toIntOrNull() ?: 0
                    remove("disk"); items += "disk" to box("disk", dataBox(0, cat(be16(0), be16(d), be16(t), be16(0))))
                }
                key == "COMPILATION" -> {
                    remove("cpil")
                    items += "cpil" to box("cpil", dataBox(21, byteArrayOf(if (value != "0" && value.isNotEmpty()) 1 else 0)))
                }
                key == "BPM" -> value.toIntOrNull()?.let {
                    remove("tmpo"); items += "tmpo" to box("tmpo", dataBox(21, be16(it.coerceIn(0, 65535))))
                }
                key == "MOVEMENT" || key == "MOVEMENTTOTAL" -> value.toIntOrNull()?.let {
                    val t = if (key == "MOVEMENT") "\u00A9mvi" else "\u00A9mvc"
                    remove(t); items += t to box(t, dataBox(21, byteArrayOf(it.coerceIn(0, 255).toByte())))
                }
                else -> { val name = pretty[key] ?: key; remove(name = name); items += "----" to itemFreeform(name, value) }
            }
        }
        write.cover?.let { jpeg -> remove("covr"); items += "covr" to box("covr", dataBox(13, jpeg)) }

        val ilst = box("ilst", cat(*items.map { it.second }.toTypedArray()))
        val meta = box("meta", cat(be32(0), handler, ilst, *metaChildren.toTypedArray()))
        val newUdta = box("udta", cat(udtaOther, meta))
        val others = kids.filter { it.type != "udta" }.map { mb.copyOfRange(it.off, it.off + it.size) }
        var newMoov = box("moov", cat(*others.toTypedArray(), newUdta))
        newMoov = patchOffsets(newMoov, moovPos, (newMoov.size - moovSize))

        return WritePlan(
            listOf(Segment.Range(0, moovPos), Segment.Bytes(newMoov), Segment.Range(moovPos + moovSize, fileSize)),
            "M4A"
        )
    }
}
