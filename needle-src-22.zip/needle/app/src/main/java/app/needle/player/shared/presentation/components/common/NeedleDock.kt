package app.needle.player.shared.presentation.components.common

import android.provider.Settings
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.EnterTransition
import androidx.compose.animation.ExitTransition
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.Stable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.saveable.listSaver
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.PointerEventType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.player.R
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import kotlinx.coroutines.delay
import kotlin.math.abs
import kotlin.math.roundToInt

/*
 * Needle dock
 *
 * One dock for the phone, built from the two mockups:
 *  - "Needle nav dock spec" gives the look and the sizes: one glass card holding the mini player row
 *    and four round tab buttons, the expanded player panel, and the small pill.
 *  - "Needle dock in motion" gives the behaviour: at rest only a thin handle shows, the dock rises on
 *    scroll up / handle tap / track change and tucks itself away again, with the same rise and sink
 *    motion, 44 dp touch targets and a fade-only path for reduced motion.
 */

/** One destination in the Needle dock's tab bar. */
data class NeedleNavItem(
    val route: String,
    val label: String,
    val selectedIcon: MaterialSymbolIcon,
    val icon: MaterialSymbolIcon,
    val selected: Boolean
)

/**
 * What the dock is showing right now.
 *  - HIDDEN: not on this screen at all (player, search, tablets, nothing to show)
 *  - REST: only the thin handle
 *  - PEEK: the player row alone, briefly, after a track or play/pause change
 *  - FULL: player row + tabs (tabs alone when nothing is playing)
 *  - LOW: player row alone, on pages that have no tabs
 *  - OPEN: the expanded player panel, tabs stay
 *  - SMALL: the pill with the tabs and a round art button
 */
enum class NeedleDockVisual { HIDDEN, REST, PEEK, FULL, LOW, OPEN, SMALL }

fun resolveNeedleDockVisual(
    applies: Boolean,
    topLevel: Boolean,
    hasSong: Boolean,
    expanded: Boolean,
    small: Boolean,
    shown: Boolean,
    peek: Boolean
): NeedleDockVisual = when {
    !applies -> NeedleDockVisual.HIDDEN
    expanded && hasSong -> NeedleDockVisual.OPEN
    !topLevel -> when {
        !hasSong -> NeedleDockVisual.HIDDEN
        shown -> NeedleDockVisual.LOW
        else -> NeedleDockVisual.REST
    }
    shown -> if (small && hasSong) NeedleDockVisual.SMALL else NeedleDockVisual.FULL
    peek && hasSong -> NeedleDockVisual.PEEK
    else -> NeedleDockVisual.REST
}

/**
 * Space the dock needs at the bottom of a page, from the spec: Mini 122, Idle 66, Small 62,
 * player row alone 58. It does not change while the dock auto-hides, so lists never jump. The
 * expanded player overlays the page, so it counts as Mini.
 */
fun needleDockClearance(topLevel: Boolean, hasSong: Boolean, small: Boolean): Dp = when {
    topLevel && hasSong -> if (small) 62.dp else 122.dp
    topLevel -> 66.dp
    hasSong -> 58.dp
    else -> 0.dp
}

/** Holds what the user did to the dock (expanded, small) and what is waking or hiding it. */
@Stable
class NeedleDockState(expanded: Boolean = false, small: Boolean = false) {
    var expanded by mutableStateOf(expanded)
    var small by mutableStateOf(small)

    /** Tabs and player are out (scroll up, handle tap, route change). */
    var shown by mutableStateOf(true)

    /** The player row alone is out for a moment. */
    var peek by mutableStateOf(false)

    /** Bumped on every touch of the dock so the auto-hide timer restarts. */
    var touches by mutableIntStateOf(0)

    fun touched() {
        touches++
    }

    fun reveal() {
        shown = true
        peek = false
        touches++
    }

    fun peekNow() {
        if (!shown) {
            peek = true
            touches++
        }
    }

    fun scrolledDown() {
        if (!expanded) {
            shown = false
            peek = false
        }
    }

    fun scrolledUp() {
        if (!expanded) {
            shown = true
            peek = false
        }
    }

    fun expand() {
        expanded = true
        shown = true
        peek = false
    }

    fun collapse() {
        expanded = false
        shown = true
        peek = false
        touches++
    }

    fun shrink() {
        expanded = false
        small = true
        shown = true
        peek = false
        touches++
    }

    fun restore() {
        small = false
        shown = true
        peek = false
        touches++
    }
}

val NeedleDockStateSaver = listSaver<NeedleDockState, Boolean>(
    save = { listOf(it.expanded, it.small) },
    restore = { NeedleDockState(expanded = it[0], small = it[1]) }
)

/**
 * Watches the scrolling of everything inside the page and tells the dock: scroll up brings it out,
 * scroll down tucks it away. It only listens, it never consumes scroll.
 */
@Composable
fun rememberNeedleDockScrollConnection(
    state: NeedleDockState,
    enabled: Boolean
): NestedScrollConnection {
    val thresholdPx = with(LocalDensity.current) { 12.dp.toPx() }
    val currentEnabled by rememberUpdatedState(enabled)
    return remember(state, thresholdPx) {
        object : NestedScrollConnection {
            private var travelled = 0f

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                if (!currentEnabled || dy == 0f) return Offset.Zero
                if (travelled != 0f && (travelled > 0f) != (dy > 0f)) travelled = 0f
                travelled += dy
                when {
                    // Finger moves up: the list scrolls forward
                    travelled <= -thresholdPx -> {
                        travelled = 0f
                        state.scrolledDown()
                    }
                    // Finger moves down: the list scrolls back toward the top
                    travelled >= thresholdPx -> {
                        travelled = 0f
                        state.scrolledUp()
                    }
                }
                return Offset.Zero
            }
        }
    }
}

/**
 * Tucks the dock away again: 4 s (or the chosen time, 0 = never) for the tabs, 3 s for a peek.
 * Touching the dock restarts the clock.
 */
@Composable
fun NeedleDockAutoHide(
    state: NeedleDockState,
    visual: NeedleDockVisual,
    autoHideMs: Int
) {
    LaunchedEffect(visual, state.touches, autoHideMs) {
        val wait = when (visual) {
            NeedleDockVisual.FULL, NeedleDockVisual.LOW, NeedleDockVisual.SMALL -> autoHideMs.toLong()
            NeedleDockVisual.PEEK -> 3_000L
            else -> 0L
        }
        if (wait <= 0L) return@LaunchedEffect
        delay(wait)
        if (visual == NeedleDockVisual.PEEK) state.peek = false else state.shown = false
    }
}

// Motion from the mockup: appear = rise 26, scale .94 to 1, fade, 320 ms soft spring;
// disappear = sink 26, shrink, fade, 220 ms ease-in with no bounce. Reduced motion = fade only, 120 ms.
private val NeedleRiseEase = CubicBezierEasing(0.2f, 0.9f, 0.25f, 1.15f)
private val NeedleSinkEase = CubicBezierEasing(0.4f, 0f, 1f, 1f)
private val NeedleBottomCenter = TransformOrigin(0.5f, 1f)

private fun needleEnter(reduceMotion: Boolean, risePx: Int): EnterTransition =
    if (reduceMotion) {
        fadeIn(tween(120))
    } else {
        fadeIn(tween(200)) +
            slideInVertically(tween(320, easing = NeedleRiseEase)) { risePx } +
            scaleIn(
                animationSpec = tween(320, easing = NeedleRiseEase),
                initialScale = 0.94f,
                transformOrigin = NeedleBottomCenter
            )
    }

private fun needleExit(reduceMotion: Boolean, risePx: Int): ExitTransition =
    if (reduceMotion) {
        fadeOut(tween(120))
    } else {
        fadeOut(tween(220, easing = NeedleSinkEase)) +
            slideOutVertically(tween(220, easing = NeedleSinkEase)) { risePx } +
            scaleOut(
                animationSpec = tween(220, easing = NeedleSinkEase),
                targetScale = 0.94f,
                transformOrigin = NeedleBottomCenter
            )
    }

@Composable
private fun rememberReduceMotion(): Boolean {
    val context = LocalContext.current
    return remember(context) {
        runCatching {
            Settings.Global.getFloat(
                context.contentResolver,
                Settings.Global.ANIMATOR_DURATION_SCALE,
                1f
            ) == 0f
        }.getOrDefault(false)
    }
}

private fun safeFraction(value: Float): Float = if (value.isNaN()) 0f else value.coerceIn(0f, 1f)

private fun formatClock(ms: Long): String {
    val totalSeconds = (ms / 1000L).coerceAtLeast(0L)
    return "%d:%02d".format(totalSeconds / 60L, totalSeconds % 60L)
}

/**
 * Glass look shared by the card and the pill: a translucent two-tone fill, a soft sheen from the
 * top, a light rim and a tinted glow. Compose can't blur what is behind a view, so the fill is kept
 * slightly see-through instead. Colors come from the caller so this stays a plain modifier.
 */
private fun Modifier.needleGlass(
    shape: Shape,
    startColor: Color,
    endColor: Color,
    glowColor: Color,
    glow: Dp = 16.dp
): Modifier = this
    .shadow(
        elevation = glow,
        shape = shape,
        ambientColor = glowColor,
        spotColor = glowColor
    )
    .clip(shape)
    .background(Brush.linearGradient(listOf(startColor, endColor)))
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
            endY = 140f
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.05f))
        ),
        shape
    )

/**
 * The Needle dock. The caller decides which [visual] state to show (see [resolveNeedleDockVisual]);
 * the dock draws it and reports taps. Every state is drawn by one of three layers that rise and
 * sink independently: the rest handle, the card (player row, expanded panel, tabs) and the small pill.
 *
 * @param tabsAvailable true on pages that have the tab bar (Home, Library)
 * @param artwork draws the current cover; it fills whatever box it is placed in
 */
@Composable
fun NeedleDock(
    visual: NeedleDockVisual,
    state: NeedleDockState,
    tabsAvailable: Boolean,
    items: List<NeedleNavItem>,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    artwork: @Composable () -> Unit,
    onItemClick: (NeedleNavItem) -> Unit,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onOpenPlayer: () -> Unit,
    onDismiss: () -> Unit,
    onHaptic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val reduceMotion = rememberReduceMotion()
    val risePx = with(LocalDensity.current) { 26.dp.roundToPx() }
    val enter = remember(reduceMotion, risePx) { needleEnter(reduceMotion, risePx) }
    val exit = remember(reduceMotion, risePx) { needleExit(reduceMotion, risePx) }

    val cardVisible = visual == NeedleDockVisual.FULL ||
        visual == NeedleDockVisual.LOW ||
        visual == NeedleDockVisual.PEEK ||
        visual == NeedleDockVisual.OPEN
    val showRow = song != null &&
        (visual == NeedleDockVisual.FULL || visual == NeedleDockVisual.LOW || visual == NeedleDockVisual.PEEK)
    val showPanel = song != null && visual == NeedleDockVisual.OPEN
    val showTabs = tabsAvailable && (visual == NeedleDockVisual.FULL || visual == NeedleDockVisual.OPEN)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .navigationBarsPadding()
            .pointerInput(state) {
                // Any touch on the dock restarts the auto-hide clock. Never consumes.
                awaitPointerEventScope {
                    while (true) {
                        val event = awaitPointerEvent(PointerEventPass.Initial)
                        if (event.type == PointerEventType.Press) state.touched()
                    }
                }
            },
        contentAlignment = Alignment.BottomCenter
    ) {
        AnimatedVisibility(
            visible = visual == NeedleDockVisual.REST,
            enter = fadeIn(tween(180)),
            exit = fadeOut(tween(180))
        ) {
            NeedleHandle(progress = progress, onReveal = { onHaptic(); state.reveal() })
        }

        AnimatedVisibility(visible = cardVisible, enter = enter, exit = exit) {
            NeedleDockCard(
                showRow = showRow,
                showPanel = showPanel,
                showTabs = showTabs,
                items = items,
                song = song,
                isPlaying = isPlaying,
                progress = progress,
                artwork = artwork,
                onItemClick = onItemClick,
                onExpand = { state.expand() },
                onCollapse = { state.collapse() },
                onShrink = { state.shrink() },
                onPlayPause = onPlayPause,
                onSkipNext = onSkipNext,
                onSkipPrevious = onSkipPrevious,
                onSeek = onSeek,
                onOpenPlayer = onOpenPlayer,
                onDismiss = onDismiss,
                onHaptic = onHaptic
            )
        }

        AnimatedVisibility(
            visible = visual == NeedleDockVisual.SMALL && song != null,
            enter = enter,
            exit = exit
        ) {
            NeedleSmallPill(
                items = items,
                artwork = artwork,
                onItemClick = onItemClick,
                onRestore = { state.restore() },
                onHaptic = onHaptic
            )
        }
    }
}

/** Rest state: a 44 x 4 line at the bottom edge whose fill follows playback. Tap or swipe up. */
@Composable
private fun NeedleHandle(
    progress: () -> Float,
    onReveal: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val label = stringResource(R.string.needle_dock_show_navigation)
    val thresholdPx = with(LocalDensity.current) { 24.dp.toPx() }
    var dragged by remember { mutableFloatStateOf(0f) }
    val currentReveal by rememberUpdatedState(onReveal)

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(46.dp)
            .draggable(
                orientation = Orientation.Vertical,
                state = rememberDraggableState { delta -> dragged += delta },
                onDragStarted = { dragged = 0f },
                onDragStopped = {
                    if (dragged <= -thresholdPx) currentReveal()
                    dragged = 0f
                }
            )
            .clickable(role = Role.Button, onClick = onReveal)
            .semantics { contentDescription = label },
        contentAlignment = Alignment.BottomCenter
    ) {
        Box(
            modifier = Modifier
                .padding(bottom = 10.dp)
                .width(44.dp)
                .height(4.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(scheme.onSurface.copy(alpha = 0.30f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(safeFraction(progress()))
                    .background(scheme.onSurface)
            )
        }
    }
}

/**
 * The wide glass card: 12 dp side inset, 14 dp above the bottom, radius 32. It holds the player
 * row, the expanded panel and the tab bar, each sliding open and shut inside the card.
 */
@Composable
private fun NeedleDockCard(
    showRow: Boolean,
    showPanel: Boolean,
    showTabs: Boolean,
    items: List<NeedleNavItem>,
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    artwork: @Composable () -> Unit,
    onItemClick: (NeedleNavItem) -> Unit,
    onExpand: () -> Unit,
    onCollapse: () -> Unit,
    onShrink: () -> Unit,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onSkipPrevious: () -> Unit,
    onSeek: (Float) -> Unit,
    onOpenPlayer: () -> Unit,
    onDismiss: () -> Unit,
    onHaptic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(32.dp)

    Column(
        modifier = modifier
            .padding(horizontal = 12.dp)
            .padding(bottom = 14.dp)
            .widthIn(max = 420.dp)
            .fillMaxWidth()
            .needleGlass(
                shape = shape,
                startColor = scheme.primaryContainer.copy(alpha = 0.92f),
                endColor = scheme.surfaceContainerHigh.copy(alpha = 0.95f),
                glowColor = scheme.primary,
                glow = 16.dp
            )
    ) {
        // Mini player row: the row steps out (350 ms) when the panel opens
        AnimatedVisibility(
            visible = showRow,
            enter = expandVertically(tween(350)) + fadeIn(tween(250)),
            exit = shrinkVertically(tween(350)) + fadeOut(tween(250))
        ) {
            if (song != null) {
                NeedleMiniRow(
                    song = song,
                    isPlaying = isPlaying,
                    canShrink = showTabs,
                    compact = !showTabs,
                    artwork = artwork,
                    onExpand = onExpand,
                    onShrink = onShrink,
                    onPlayPause = onPlayPause,
                    onDismiss = onDismiss,
                    onHaptic = onHaptic
                )
            }
        }

        // Expanded player panel: grows 0 to 430 dp (400 ms)
        AnimatedVisibility(
            visible = showPanel,
            enter = expandVertically(tween(400)) + fadeIn(tween(300)),
            exit = shrinkVertically(tween(400)) + fadeOut(tween(300))
        ) {
            if (song != null) {
                NeedleOpenPanel(
                    song = song,
                    isPlaying = isPlaying,
                    progress = progress,
                    artwork = artwork,
                    onCollapse = onCollapse,
                    onOpenPlayer = onOpenPlayer,
                    onSeek = onSeek,
                    onSkipPrevious = onSkipPrevious,
                    onPlayPause = onPlayPause,
                    onSkipNext = onSkipNext,
                    onHaptic = onHaptic
                )
            }
        }

        AnimatedVisibility(
            visible = showTabs,
            enter = expandVertically(tween(350)) + fadeIn(tween(250)),
            exit = shrinkVertically(tween(350)) + fadeOut(tween(250))
        ) {
            NeedleTabBar(
                items = items,
                gap = null,
                onItemClick = { item ->
                    onHaptic()
                    onItemClick(item)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 10.dp)
            )
        }
    }
}

/** Art 44 (r12), title 14/600 over artist 12, a 44 dp shrink button and a 44 dp play/pause. */
@Composable
private fun NeedleMiniRow(
    song: Song,
    isPlaying: Boolean,
    canShrink: Boolean,
    compact: Boolean,
    artwork: @Composable () -> Unit,
    onExpand: () -> Unit,
    onShrink: () -> Unit,
    onPlayPause: () -> Unit,
    onDismiss: () -> Unit,
    onHaptic: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val topPad by animateDpAsState(if (compact) 7.dp else 10.dp, tween(250), label = "needle_row_top")
    val bottomPad by animateDpAsState(if (compact) 7.dp else 2.dp, tween(250), label = "needle_row_bottom")
    val swipePx = with(LocalDensity.current) { 48.dp.toPx() }
    val currentExpand by rememberUpdatedState(onExpand)
    val currentDismiss by rememberUpdatedState(onDismiss)
    var dragged by remember { mutableFloatStateOf(0f) }
    val expandLabel = stringResource(R.string.needle_dock_expand_player)

    Row(
        modifier = Modifier
            .fillMaxWidth()
            .pointerInput(swipePx) {
                // Swipe up opens the player, swipe down dismisses it (same as the old mini player)
                detectVerticalDragGestures(
                    onDragStart = { dragged = 0f },
                    onDragEnd = {
                        if (dragged <= -swipePx) currentExpand()
                        else if (dragged >= swipePx) currentDismiss()
                        dragged = 0f
                    },
                    onDragCancel = { dragged = 0f },
                    onVerticalDrag = { _, amount -> dragged += amount }
                )
            }
            .clickable(onClickLabel = expandLabel) {
                onHaptic()
                onExpand()
            }
            .padding(start = 12.dp, end = 12.dp, top = topPad, bottom = bottomPad),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(44.dp)
                .clip(RoundedCornerShape(12.dp))
        ) {
            artwork()
        }
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = song.title,
                color = scheme.onSurface,
                fontSize = 14.sp,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = song.artist,
                color = scheme.onSurfaceVariant,
                fontSize = 12.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
        if (canShrink) {
            NeedleRoundButton(
                onClick = {
                    onHaptic()
                    onShrink()
                },
                contentDescription = stringResource(R.string.needle_dock_make_smaller),
                size = 44.dp,
                container = scheme.onSurface.copy(alpha = 0.14f)
            ) {
                Icon(
                    icon = RhythmIcons.KeyboardArrowDown,
                    contentDescription = null,
                    tint = scheme.onSurface,
                    size = 20.dp
                )
            }
        }
        NeedleRoundButton(
            onClick = {
                onHaptic()
                onPlayPause()
            },
            contentDescription = stringResource(R.string.play_pause),
            size = 44.dp,
            container = scheme.onSurface
        ) {
            Icon(
                icon = if (isPlaying) RhythmIcons.Pause else RhythmIcons.Play,
                contentDescription = null,
                tint = scheme.surface,
                size = 22.dp
            )
        }
    }
}

/**
 * The expanded player: handle 32, art 150 (r20) with a glow, serif title 27, artist line 13, times
 * 11.5, a 4 dp time bar you can tap or drag, and prev / play / next at 48 / 60 / 48 with a 14 gap.
 */
@Composable
private fun NeedleOpenPanel(
    song: Song,
    isPlaying: Boolean,
    progress: () -> Float,
    artwork: @Composable () -> Unit,
    onCollapse: () -> Unit,
    onOpenPlayer: () -> Unit,
    onSeek: (Float) -> Unit,
    onSkipPrevious: () -> Unit,
    onPlayPause: () -> Unit,
    onSkipNext: () -> Unit,
    onHaptic: () -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    val collapseLabel = stringResource(R.string.needle_dock_collapse_player)
    val openLabel = stringResource(R.string.needle_dock_open_player)
    val artShape = RoundedCornerShape(20.dp)

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, bottom = 6.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Handle: full width, 32 dp tall
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(32.dp)
                .clickable(role = Role.Button) {
                    onHaptic()
                    onCollapse()
                }
                .semantics { contentDescription = collapseLabel },
            contentAlignment = Alignment.Center
        ) {
            Icon(
                icon = RhythmIcons.KeyboardArrowDown,
                contentDescription = null,
                tint = scheme.onSurfaceVariant,
                size = 24.dp
            )
        }

        // Tapping the art opens the full player (lyrics, queue, outputs)
        Box(
            modifier = Modifier
                .size(150.dp)
                .shadow(
                    elevation = 24.dp,
                    shape = artShape,
                    ambientColor = scheme.primary,
                    spotColor = scheme.tertiary
                )
                .clip(artShape)
                .clickable(onClickLabel = openLabel) {
                    onHaptic()
                    onOpenPlayer()
                }
        ) {
            artwork()
        }

        Text(
            text = song.title,
            modifier = Modifier.padding(top = 16.dp),
            color = scheme.onSurface,
            fontFamily = FontFamily.Serif,
            fontSize = 27.sp,
            lineHeight = 29.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Text(
            text = if (song.album.isNotBlank()) "${song.artist} \u00B7 ${song.album}" else song.artist,
            modifier = Modifier.padding(top = 5.dp, bottom = 12.dp),
            color = scheme.onSurface.copy(alpha = 0.85f),
            fontSize = 13.sp,
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        NeedleTimes(progress = progress, durationMs = song.duration)
        NeedleSeekBar(
            progress = progress,
            onSeek = onSeek,
            modifier = Modifier.padding(top = 2.dp, bottom = 6.dp)
        )

        Row(
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleRoundButton(
                onClick = {
                    onHaptic()
                    onSkipPrevious()
                },
                contentDescription = stringResource(R.string.cd_previous_track),
                size = 48.dp,
                container = scheme.onSurface.copy(alpha = 0.20f)
            ) {
                Icon(
                    icon = RhythmIcons.SkipPrevious,
                    contentDescription = null,
                    tint = scheme.onSurface,
                    size = 26.dp
                )
            }
            NeedleRoundButton(
                onClick = {
                    onHaptic()
                    onPlayPause()
                },
                contentDescription = stringResource(R.string.play_pause),
                size = 60.dp,
                container = scheme.onSurface
            ) {
                Icon(
                    icon = if (isPlaying) RhythmIcons.Pause else RhythmIcons.Play,
                    contentDescription = null,
                    tint = scheme.surface,
                    size = 30.dp
                )
            }
            NeedleRoundButton(
                onClick = {
                    onHaptic()
                    onSkipNext()
                },
                contentDescription = stringResource(R.string.cd_next_track),
                size = 48.dp,
                container = scheme.onSurface.copy(alpha = 0.20f)
            ) {
                Icon(
                    icon = RhythmIcons.SkipNext,
                    contentDescription = null,
                    tint = scheme.onSurface,
                    size = 26.dp
                )
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
private fun NeedleTimes(progress: () -> Float, durationMs: Long) {
    val scheme = MaterialTheme.colorScheme
    val total = durationMs.coerceAtLeast(0L)
    val position = (safeFraction(progress()) * total).toLong()
    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(text = formatClock(position), color = scheme.onSurface.copy(alpha = 0.85f), fontSize = 11.5.sp)
        Text(text = formatClock(total), color = scheme.onSurface.copy(alpha = 0.85f), fontSize = 11.5.sp)
    }
}

/** A 4 dp bar inside a 24 dp touch area. Tap to jump, drag to scrub; the seek happens on release. */
@Composable
private fun NeedleSeekBar(
    progress: () -> Float,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val currentSeek by rememberUpdatedState(onSeek)
    var widthPx by remember { mutableFloatStateOf(1f) }
    var scrub by remember { mutableStateOf<Float?>(null) }

    Box(
        modifier = modifier
            .fillMaxWidth()
            .height(24.dp)
            .onSizeChanged { widthPx = it.width.toFloat().coerceAtLeast(1f) }
            .pointerInput(Unit) {
                detectTapGestures { offset -> currentSeek((offset.x / widthPx).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures(
                    onDragStart = { offset -> scrub = (offset.x / widthPx).coerceIn(0f, 1f) },
                    onDragEnd = {
                        scrub?.let { currentSeek(it) }
                        scrub = null
                    },
                    onDragCancel = { scrub = null },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        scrub = (change.position.x / widthPx).coerceIn(0f, 1f)
                    }
                )
            },
        contentAlignment = Alignment.CenterStart
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(4.dp)
                .clip(RoundedCornerShape(9.dp))
                .background(scheme.onSurface.copy(alpha = 0.28f))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(safeFraction(scrub ?: progress()))
                    .background(scheme.onSurface)
            )
        }
    }
}

/**
 * The small pill: radius 99, the four 48 dp tab buttons 2 dp apart and a 44 dp round art button with
 * a white ring and glow at the end. Tapping the art button brings the full dock back. Centered.
 */
@Composable
private fun NeedleSmallPill(
    items: List<NeedleNavItem>,
    artwork: @Composable () -> Unit,
    onItemClick: (NeedleNavItem) -> Unit,
    onRestore: () -> Unit,
    onHaptic: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val showFullLabel = stringResource(R.string.needle_dock_show_full)

    Row(
        modifier = modifier
            .padding(bottom = 14.dp)
            .needleGlass(
                shape = CircleShape,
                startColor = scheme.primaryContainer.copy(alpha = 0.92f),
                endColor = scheme.surfaceContainerHigh.copy(alpha = 0.95f),
                glowColor = scheme.primary,
                glow = 16.dp
            )
            .padding(6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        NeedleTabBar(
            items = items,
            gap = 2.dp,
            onItemClick = { item ->
                onHaptic()
                onItemClick(item)
            }
        )
        Box(
            modifier = Modifier
                .padding(start = 2.dp, end = 4.dp)
                .size(44.dp)
                .shadow(
                    elevation = 10.dp,
                    shape = CircleShape,
                    ambientColor = scheme.primary,
                    spotColor = scheme.primary
                )
                .clip(CircleShape)
                .border(2.dp, Color.White.copy(alpha = 0.75f), CircleShape)
                .clickable(role = Role.Button) {
                    onHaptic()
                    onRestore()
                }
                .semantics { contentDescription = showFullLabel }
        ) {
            artwork()
        }
    }
}

/**
 * Round 48 dp tab buttons. The selected one is a bright circle that slides to the new button and
 * stretches a little on the way. [gap] null spreads the buttons evenly across the width (the wide
 * card); a value packs them together (the small pill).
 */
@Composable
private fun NeedleTabBar(
    items: List<NeedleNavItem>,
    gap: Dp?,
    onItemClick: (NeedleNavItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val density = LocalDensity.current
    val itemSize = 48.dp
    val itemPx = with(density) { itemSize.toPx() }
    val gapPx = with(density) { (gap ?: 0.dp).toPx() }

    val selectedIndex = items.indexOfFirst { it.selected }
    var lastIndex by remember { mutableIntStateOf(if (selectedIndex >= 0) selectedIndex else 0) }
    LaunchedEffect(selectedIndex) {
        if (selectedIndex >= 0) lastIndex = selectedIndex
    }
    val shownIndex = if (selectedIndex >= 0) selectedIndex else lastIndex
    val indicatorAlpha by animateFloatAsState(
        targetValue = if (selectedIndex >= 0) 1f else 0f,
        animationSpec = tween(200),
        label = "needle_tab_indicator_alpha"
    )

    BoxWithConstraints(modifier = modifier.height(itemSize)) {
        val count = items.size.coerceAtLeast(1)

        // Where button i starts: even spacing across the width, or packed with a fixed gap
        fun startOf(index: Int): Float =
            if (gap == null) {
                val free = (constraints.maxWidth - itemPx * count).coerceAtLeast(0f)
                free / count * (index + 0.5f) + itemPx * index
            } else {
                index * (itemPx + gapPx)
            }

        val targetX = startOf(shownIndex)
        val indicatorX by animateFloatAsState(
            targetValue = targetX,
            animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium),
            label = "needle_tab_indicator_x"
        )

        Box(
            modifier = Modifier
                .offset { IntOffset(indicatorX.roundToInt(), 0) }
                .size(itemSize)
                .graphicsLayer {
                    alpha = indicatorAlpha
                    scaleX = 1f + (abs(indicatorX - targetX) / (itemPx * 2f)).coerceIn(0f, 0.22f)
                }
                .shadow(
                    elevation = 8.dp,
                    shape = CircleShape,
                    ambientColor = Color.White.copy(alpha = 0.25f),
                    spotColor = Color.White.copy(alpha = 0.25f)
                )
                .clip(CircleShape)
                .background(scheme.onSurface)
        )

        Row(
            modifier = if (gap == null) Modifier.fillMaxWidth() else Modifier,
            horizontalArrangement = if (gap == null) Arrangement.SpaceAround else Arrangement.spacedBy(gap),
            verticalAlignment = Alignment.CenterVertically
        ) {
            items.forEach { item ->
                val tint by animateColorAsState(
                    targetValue = if (item.selected) scheme.surface else scheme.onSurfaceVariant,
                    animationSpec = tween(220),
                    label = "needle_tab_tint"
                )
                Box(
                    modifier = Modifier
                        .size(itemSize)
                        .clip(CircleShape)
                        .selectable(
                            selected = item.selected,
                            role = Role.Tab,
                            onClick = { onItemClick(item) }
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        icon = if (item.selected) item.selectedIcon else item.icon,
                        contentDescription = item.label,
                        tint = tint,
                        size = 22.dp
                    )
                }
            }
        }
    }
}

@Composable
private fun NeedleRoundButton(
    onClick: () -> Unit,
    contentDescription: String,
    size: Dp,
    container: Color,
    modifier: Modifier = Modifier,
    content: @Composable () -> Unit
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(container)
            .clickable(role = Role.Button, onClick = onClick)
            .semantics { this.contentDescription = contentDescription },
        contentAlignment = Alignment.Center
    ) {
        content()
    }
}
