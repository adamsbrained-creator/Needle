package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.DirectoryStation
import app.needle.music.data.RadioArt
import app.needle.music.data.RadioDirectory
import app.needle.music.data.RadioSong
import app.needle.music.data.RadioStation
import app.needle.music.data.RadioStations
import app.needle.music.data.radioInitials
import app.needle.music.data.radioTileIndex
import app.needle.music.playback.PlayerViewModel
import java.text.DateFormat
import java.util.Date

private val Danger = Color(0xFFFF6B6B)

private val tileColors = listOf(
    listOf(Color(0xFFFF7A59), Color(0xFFC2306F)),
    listOf(Color(0xFF2DD4BF), Color(0xFF2455A4)),
    listOf(Color(0xFFF2C14E), Color(0xFFD9622B)),
    listOf(Color(0xFF8B7BFF), Color(0xFF3A2C8F)),
    listOf(Color(0xFF6FCF97), Color(0xFF1E6B52)),
    listOf(Color(0xFFEF42B8), Color(0xFF5A1D6E))
)

/**
 * A station's logo: its Thumbnail URL picture, or a colored tile with its initials while there is none (or the link
 * does not work). The same name always gets the same color.
 */
@Composable
fun RadioLogo(name: String, thumbUrl: String, size: Dp, modifier: Modifier = Modifier, corner: Dp = 14.dp) {
    val context = LocalContext.current
    val image by produceState<ImageBitmap?>(RadioArt.peek(thumbUrl), thumbUrl) {
        value = RadioArt.peek(thumbUrl) ?: RadioArt.load(context, thumbUrl)
    }
    val colors = tileColors[radioTileIndex(name)]
    Box(
        modifier
            .size(size)
            .clip(if (corner * 2 >= size) CircleShape else cornerShape(corner))
            .background(Brush.linearGradient(colors)),
        contentAlignment = Alignment.Center
    ) {
        val bitmap = image
        if (bitmap != null) {
            Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Text(
                radioInitials(name), color = Color.White.copy(alpha = 0.92f), fontWeight = FontWeight.Bold,
                fontSize = (size.value * 0.3f).sp
            )
        }
    }
}

/** The logo of the station that is playing, filling whatever box the dock gives its cover. */
@Composable
fun RadioCover(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val st = app.needle.music.data.RadioStations.get(vm.radioId.orEmpty())
    androidx.compose.foundation.layout.BoxWithConstraints(modifier, contentAlignment = Alignment.Center) {
        RadioLogo(st?.name ?: vm.artist.orEmpty(), st?.thumbUrl.orEmpty(), minOf(maxWidth, maxHeight), corner = 0.dp)
    }
}

@Composable
fun StationLogo(station: RadioStation, size: Dp, modifier: Modifier = Modifier, corner: Dp = 14.dp) =
    RadioLogo(station.name, station.thumbUrl, size, modifier, corner)

/** The pill buttons of the radio pages (Add URL, Find stations, Play ...). */
@Composable
private fun RadioPill(text: String, icon: NeedleIcon, onClick: () -> Unit, modifier: Modifier = Modifier, filled: Boolean = false) {
    Row(
        modifier
            .clip(CircleShape)
            .background(if (filled) Palette.Accent else Palette.Card)
            .clickable(onClick = onClick)
            .padding(start = 14.dp, end = 18.dp)
            .height(44.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        NeedleIconView(icon, if (filled) Color(0xFF15101A) else Palette.Text, size = 20.dp)
        Spacer(Modifier.width(8.dp))
        Text(text, color = if (filled) Color(0xFF15101A) else Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
    }
}

@Composable
private fun RadioChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text, color = if (selected) Color(0xFF15101A) else Palette.Text, fontSize = 13.5.sp, fontWeight = FontWeight.Medium, maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Palette.Accent else Palette.Card)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}

// ---- the list ---------------------------------------------------------------------------------

/**
 * Radio: every station, with the playing one marked. Tap the logo or the play button to listen, the name to open
 * the station's page. Add URL types a station in, Find stations searches a public directory.
 */
@Composable
fun RadioListScreen(
    stations: List<RadioStation>,
    playingId: String?,
    isPlaying: Boolean,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onAdd: () -> Unit,
    onFind: () -> Unit,
    onOpen: (RadioStation) -> Unit,
    onPlay: (RadioStation) -> Unit,
    onTogglePause: () -> Unit,
    modifier: Modifier = Modifier
) {
    var ascending by rememberSaveable { mutableStateOf(true) }
    var searching by rememberSaveable { mutableStateOf(false) }
    var query by rememberSaveable { mutableStateOf("") }
    var tag by rememberSaveable { mutableStateOf("") }
    val tags = remember(stations) {
        stations.flatMap { it.tags }.groupingBy { it.lowercase() }.eachCount().entries
            .sortedByDescending { it.value }.take(12).map { it.key }
    }
    val shown = remember(stations, ascending, query, tag) {
        val q = query.trim().lowercase()
        stations
            .filter { s -> tag.isEmpty() || (tag == "★" && s.favorite) || s.tags.any { it.equals(tag, ignoreCase = true) } }
            .filter { s -> q.isEmpty() || s.name.lowercase().contains(q) || s.tags.any { it.lowercase().contains(q) } }
            .sortedBy { it.name.lowercase() }
            .let { if (ascending) it else it.reversed() }
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                    Spacer(Modifier.width(12.dp))
                    Text("Radio", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                }
                Row(Modifier.padding(top = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RadioPill("Add URL", NeedleIcon.RADIO, onAdd)
                    RadioPill("Find stations", NeedleIcon.GLOBE, onFind)
                }
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Row(
                        Modifier.clip(cornerShape(10.dp)).clickable { ascending = !ascending }.padding(vertical = 8.dp, horizontal = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Title", color = Palette.Muted, fontSize = 15.sp)
                        Spacer(Modifier.width(6.dp))
                        Text(if (ascending) "A–Z" else "Z–A", color = Palette.Muted, fontSize = 13.sp)
                    }
                    Spacer(Modifier.weight(1f))
                    RoundIconButton(NeedleIcon.SEARCH, { searching = !searching; if (!searching) query = "" }, active = searching)
                }
                if (searching) {
                    Box(Modifier.fillMaxWidth().padding(top = 6.dp).glass(cornerShape(16.dp)).padding(14.dp)) {
                        BasicTextField(
                            value = query, onValueChange = { query = it }, singleLine = true,
                            textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                            cursorBrush = SolidColor(Palette.Accent),
                            modifier = Modifier.fillMaxWidth(),
                            decorationBox = { inner ->
                                if (query.isEmpty()) Text("Search stations", color = Palette.Muted, fontSize = 16.sp)
                                inner()
                            }
                        )
                    }
                }
                if (tags.isNotEmpty() || stations.any { it.favorite }) {
                    Row(
                        Modifier.horizontalScroll(rememberScrollState()).padding(top = 10.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        RadioChip("All", tag.isEmpty()) { tag = "" }
                        if (stations.any { it.favorite }) RadioChip("★ Favorites", tag == "★") { tag = if (tag == "★") "" else "★" }
                        tags.forEach { t -> RadioChip(t.replaceFirstChar { it.uppercase() }, tag == t) { tag = if (tag == t) "" else t } }
                    }
                }
                Spacer(Modifier.height(6.dp))
            }
        }

        if (stations.isEmpty()) {
            item {
                Text(
                    "No stations yet. Add one with its stream address, or find one in the directory.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 64.dp)
                )
            }
        } else if (shown.isEmpty()) {
            item {
                Text(
                    "Nothing matches.", color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp)
                )
            }
        }

        items(shown, key = { it.id }) { s ->
            val current = s.id == playingId
            StationRow(
                station = s, current = current, playing = current && isPlaying,
                onOpen = { onOpen(s) },
                onToggle = { if (current) onTogglePause() else onPlay(s) }
            )
        }
    }
}

@Composable
private fun StationRow(station: RadioStation, current: Boolean, playing: Boolean, onOpen: () -> Unit, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        StationLogo(station, 54.dp, Modifier.clickable(onClick = onToggle))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f).clip(cornerShape(8.dp)).clickable(onClick = onOpen).padding(vertical = 4.dp)) {
            Text(
                station.name, color = if (current) Palette.Accent else Palette.Text, fontSize = 16.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (current) {
                    Text("LIVE", color = Palette.Accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.6.sp)
                    Spacer(Modifier.width(7.dp))
                }
                Text(
                    station.tagLine.ifEmpty { station.description.ifEmpty { "Internet radio" } },
                    color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Box(Modifier.size(44.dp).clip(CircleShape).clickable(onClick = onToggle), contentAlignment = Alignment.Center) {
            if (playing) MiniPauseGlyph(Palette.Accent) else NeedleIconView(NeedleIcon.PLAY, if (current) Palette.Accent else Palette.Muted, size = 22.dp)
        }
    }
}

/** Two small bars: the pause symbol, for rows that are too small for a whole PlayPauseButton. */
@Composable
private fun MiniPauseGlyph(color: Color) {
    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Box(Modifier.size(width = 5.dp, height = 18.dp).clip(cornerShape(2.dp)).background(color))
        Box(Modifier.size(width = 5.dp, height = 18.dp).clip(cornerShape(2.dp)).background(color))
    }
}

// ---- the station's page -----------------------------------------------------------------------

/**
 * One station: its logo and name, Play and Favorite, its details, the songs the person saved from its stream and
 * what played there lately.
 */
@Composable
fun RadioStationScreen(
    station: RadioStation,
    saved: List<RadioSong>,
    recent: List<RadioSong>,
    current: Boolean,
    playing: Boolean,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onTogglePause: () -> Unit,
    onFavorite: () -> Unit,
    onEdit: () -> Unit,
    onRemoveSaved: (RadioSong) -> Unit,
    modifier: Modifier = Modifier
) {
    val dateFormat = remember { DateFormat.getDateInstance(DateFormat.MEDIUM) }
    val host = remember(station.url) { runCatching { java.net.URI(station.url).host }.getOrNull().orEmpty() }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)) {
        item {
            Column(Modifier.fillMaxWidth(), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                    Spacer(Modifier.weight(1f))
                    RoundIconButton(NeedleIcon.PENCIL, onEdit, size = 40.dp, iconSize = 20.dp)
                }
                Spacer(Modifier.height(8.dp))
                StationLogo(station, 132.dp, corner = 26.dp)
                Text(
                    station.name, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 26.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.padding(top = 16.dp)
                )
                if (station.tagLine.isNotEmpty()) {
                    Text(station.tagLine, color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 2.dp))
                }
                if (station.description.isNotEmpty()) {
                    Text(
                        station.description, color = Palette.Muted, fontSize = 13.5.sp, textAlign = TextAlign.Center,
                        modifier = Modifier.padding(top = 8.dp, start = 12.dp, end = 12.dp)
                    )
                }
                Row(Modifier.padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    RadioPill(if (current && playing) "Pause" else "Play", NeedleIcon.PLAY, { if (current) onTogglePause() else onPlay() }, filled = true)
                    RadioPill(if (station.favorite) "Favorite" else "Add to favorites", if (station.favorite) NeedleIcon.HEART_FILLED else NeedleIcon.HEART, onFavorite)
                }
                Spacer(Modifier.height(10.dp))
            }
            Column(Modifier.fillMaxWidth().padding(top = 8.dp)) {
                DetailLine("Stream", host.ifEmpty { station.url })
                DetailLine("Mobile URL", if (station.mobileUrl.isBlank()) "Not set" else "Set, used on mobile data")
                DetailLine("Added", dateFormat.format(Date(station.addedAt)))
                DetailLine("Songs saved", saved.size.toString())
            }
        }

        item { RadioHeader("Songs you saved") }
        if (saved.isEmpty()) {
            item {
                Text(
                    "Tap the heart on the player while a song plays, and it is kept here.",
                    color = Palette.Muted, fontSize = 13.5.sp, modifier = Modifier.padding(vertical = 4.dp, horizontal = 2.dp)
                )
            }
        }
        items(saved, key = { "s${it.at}${it.title}${it.artist}" }) { song ->
            Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    if (song.artist.isNotEmpty()) Text(song.artist, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(dateFormat.format(Date(song.at)), color = Palette.Muted, fontSize = 12.sp)
                Box(Modifier.size(40.dp).clip(CircleShape).clickable { onRemoveSaved(song) }, contentAlignment = Alignment.Center) {
                    NeedleIconView(NeedleIcon.CLOSE, Palette.Muted, size = 16.dp)
                }
            }
        }

        val played = recent.filter { it.stationId == station.id }.take(8)
        if (played.isNotEmpty()) {
            item { RadioHeader("Played recently") }
            items(played, key = { "r${it.at}${it.title}" }) { song ->
                Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(song.title, color = Palette.Text, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        if (song.artist.isNotEmpty()) Text(song.artist, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(minutesAgo(song.at), color = Palette.Muted, fontSize = 12.sp)
                }
            }
        }
    }
}

@Composable
private fun RadioHeader(text: String) {
    Text(text, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 22.dp, bottom = 6.dp))
}

@Composable
private fun DetailLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().height(40.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Palette.Muted, fontSize = 14.5.sp)
        Spacer(Modifier.width(16.dp))
        Text(value, color = Palette.Text, fontSize = 14.5.sp, textAlign = TextAlign.End, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
    }
}

private fun minutesAgo(at: Long): String {
    val min = ((System.currentTimeMillis() - at) / 60_000L).toInt().coerceAtLeast(0)
    return when {
        min < 1 -> "Just now"
        min < 60 -> "$min min ago"
        else -> "${min / 60} h ago"
    }
}

// ---- add / edit form --------------------------------------------------------------------------

/**
 * The form of Add URL (and Edit): Name, Default URL, Mobile URL, Thumbnail URL, Description and comma-separated tags,
 * like in Symfonium. Only the Default URL is required. [initial] is set when a station is being edited, or filled
 * from a directory result. [onDelete] is only given when editing; it asks twice.
 */
@Composable
fun RadioFormDialog(
    initial: RadioStation?,
    onSave: (name: String, url: String, mobileUrl: String, thumbUrl: String, description: String, tags: String) -> Unit,
    onDismiss: () -> Unit,
    onFind: (() -> Unit)?,
    onDelete: (() -> Unit)?
) {
    var name by remember { mutableStateOf(initial?.name.orEmpty()) }
    var url by remember { mutableStateOf(initial?.url.orEmpty()) }
    var mobile by remember { mutableStateOf(initial?.mobileUrl.orEmpty()) }
    var thumb by remember { mutableStateOf(initial?.thumbUrl.orEmpty()) }
    var description by remember { mutableStateOf(initial?.description.orEmpty()) }
    var tags by remember { mutableStateOf(initial?.tagLine.orEmpty()) }
    var tried by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    val urlOk = url.trim().startsWith("http://", ignoreCase = true) || url.trim().startsWith("https://", ignoreCase = true)

    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text(if (initial == null) "Internet radio" else "Edit radio") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                FormField("Name", name, { name = it })
                FormField(
                    "Default URL", url, { url = it }, keyboard = KeyboardType.Uri,
                    error = if (tried && !urlOk) "Enter the stream address (http or https)." else null
                )
                FormField("Mobile URL (Optional)", mobile, { mobile = it }, keyboard = KeyboardType.Uri)
                FormField("Thumbnail URL (Optional)", thumb, { thumb = it }, keyboard = KeyboardType.Uri)
                FormField("Description", description, { description = it })
                FormField("Comma-separated tags", tags, { tags = it })
                if (onFind != null) {
                    Row(
                        Modifier.clip(cornerShape(10.dp)).clickable(onClick = onFind).padding(vertical = 10.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NeedleIconView(NeedleIcon.GLOBE, Palette.Accent, size = 20.dp)
                        Spacer(Modifier.width(8.dp))
                        Text("Find in directory", color = Palette.Accent, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
                if (onDelete != null) {
                    Text(
                        if (confirmDelete) "Tap again to delete this station" else "Delete station",
                        color = Danger, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(cornerShape(10.dp)).clickable { if (confirmDelete) onDelete() else confirmDelete = true }.padding(vertical = 10.dp, horizontal = 4.dp)
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                tried = true
                if (urlOk) onSave(name, url, mobile, thumb, description, tags)
            }) { Text(if (initial == null) "Add" else "Save", color = Palette.Accent) }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}

@Composable
private fun FormField(
    label: String, value: String, onChange: (String) -> Unit,
    keyboard: KeyboardType = KeyboardType.Text, error: String? = null
) {
    Column(Modifier.fillMaxWidth().padding(bottom = 10.dp)) {
        Column(Modifier.fillMaxWidth().clip(cornerShape(12.dp)).background(Palette.Card).padding(horizontal = 14.dp, vertical = 9.dp)) {
            Text(label, color = if (error != null) Danger else Palette.Muted, fontSize = 12.sp)
            BasicTextField(
                value = value, onValueChange = onChange, singleLine = true,
                textStyle = TextStyle(color = Color.White, fontSize = 15.5.sp),
                cursorBrush = SolidColor(Palette.Accent),
                keyboardOptions = KeyboardOptions(keyboardType = keyboard),
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp)
            )
        }
        if (error != null) Text(error, color = Danger, fontSize = 12.sp, modifier = Modifier.padding(start = 14.dp, top = 4.dp))
    }
}

// ---- find stations (public directory) ---------------------------------------------------------

/**
 * Searches the public Radio Browser directory. Tap + to put a station in the list; the copy keeps working without
 * the directory. Nothing is sent anywhere except the words that are typed here.
 */
@Composable
fun RadioFindScreen(
    stations: List<RadioStation>,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onAdd: (DirectoryStation) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    var minBitrate by rememberSaveable { mutableIntStateOf(0) }
    var submitted by rememberSaveable { mutableIntStateOf(0) }
    var results by remember { mutableStateOf<List<DirectoryStation>?>(null) }
    var loading by remember { mutableStateOf(false) }
    var failed by remember { mutableStateOf(false) }

    LaunchedEffect(submitted, minBitrate) {
        if (submitted == 0 || query.isBlank()) return@LaunchedEffect
        loading = true
        failed = false
        val found = RadioDirectory.search(query, minBitrate)
        loading = false
        if (found == null) failed = true else results = found
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)) {
        item {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                    Spacer(Modifier.width(12.dp))
                    Text("Find stations", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp)
                }
                Row(
                    Modifier.fillMaxWidth().padding(top = 14.dp).glass(CircleShape).padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeedleIconView(NeedleIcon.SEARCH, Palette.Muted, size = 20.dp)
                    Spacer(Modifier.width(10.dp))
                    BasicTextField(
                        value = query, onValueChange = { query = it }, singleLine = true,
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                        cursorBrush = SolidColor(Palette.Accent),
                        keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                        keyboardActions = KeyboardActions(onSearch = { if (query.isNotBlank()) submitted++ }),
                        modifier = Modifier.weight(1f),
                        decorationBox = { inner ->
                            if (query.isEmpty()) Text("Name, genre or place", color = Palette.Muted, fontSize = 16.sp)
                            inner()
                        }
                    )
                }
                Row(Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RadioChip("Any quality", minBitrate == 0) { minBitrate = 0 }
                    RadioChip("128k and up", minBitrate == 128) { minBitrate = 128 }
                }
                Spacer(Modifier.height(8.dp))
            }
        }

        val list = results
        when {
            loading -> item { InfoLine("Searching…") }
            failed -> item { InfoLine("Could not reach the directory. Check the connection and try again.") }
            list == null -> item { InfoLine("Type what you look for and press search. The list comes from a free public station directory.") }
            list.isEmpty() -> item { InfoLine("No stations found.") }
        }

        if (!loading && !failed && list != null) {
            items(list, key = { it.url }) { d ->
                val added = stations.any { it.url.equals(d.url, ignoreCase = true) }
                Row(Modifier.fillMaxWidth().padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                    RadioLogo(d.name, d.thumbUrl, 48.dp, corner = 12.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(d.name, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(d.line, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Box(
                        Modifier.size(40.dp).clip(CircleShape).background(if (added) Palette.Accent else Palette.Card)
                            .then(if (added) Modifier else Modifier.clickable { onAdd(d) }),
                        contentAlignment = Alignment.Center
                    ) {
                        NeedleIconView(if (added) NeedleIcon.CHECK else NeedleIcon.PLUS, if (added) Color(0xFF15101A) else Palette.Accent, size = 20.dp)
                    }
                }
            }
        }
    }
}

@Composable
private fun InfoLine(text: String) {
    Text(
        text, color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
        modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp)
    )
}

// ---- the live player --------------------------------------------------------------------------

/**
 * The player while a station plays. It is live, so there is no seek bar: the big picture, the song the stream says
 * is on now (with a heart to keep it), previous and next station, and what played just before.
 */
@Composable
fun RadioPlayerScreen(
    vm: PlayerViewModel,
    stations: List<RadioStation>,
    onClose: () -> Unit,
    onOpenStation: (RadioStation) -> Unit,
    onSleepTimer: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val station = stations.firstOrNull { it.id == vm.radioId }
    val name = station?.name ?: vm.artist.orEmpty()
    val saved by RadioStations.saved.collectAsState()
    val recent by RadioStations.recent.collectAsState()
    val song = vm.radioSong
    val songArtist = vm.radioSongArtist
    val stationId = station?.id.orEmpty()
    val isSaved = song.isNotEmpty() && saved.any { it.stationId == stationId && it.title == song && it.artist == songArtist }
    val sorted = remember(stations) { stations.sortedBy { it.name.lowercase() } }
    val sortedIndex = sorted.indexOfFirst { it.id == stationId }
    val context = LocalContext.current

    Column(
        modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().padding(horizontal = 22.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(NeedleIcon.CHEVRON_DOWN, onClose, size = 40.dp, iconSize = 20.dp)
            Column(
                Modifier.weight(1f).padding(horizontal = 8.dp).then(if (station != null) Modifier.clickable { onOpenStation(station) } else Modifier),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("Radio", color = Palette.Muted, fontSize = 12.sp)
                Text(name, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Spacer(Modifier.size(40.dp))
        }
        Spacer(Modifier.height(18.dp))
        Box {
            RadioLogo(name, station?.thumbUrl.orEmpty(), 300.dp, corner = 26.dp)
            Text(
                "● LIVE", color = Color.White, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 0.8.sp,
                modifier = Modifier.padding(14.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.55f)).padding(horizontal = 10.dp, vertical = 5.dp)
            )
        }
        Spacer(Modifier.height(20.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(
                    song.ifEmpty { name }, color = Palette.Accent, fontFamily = Palette.TitleFont, fontSize = 24.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    songArtist.ifEmpty { if (song.isEmpty()) "Waiting for the stream…" else name },
                    color = Palette.Muted, fontSize = 15.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (song.isNotEmpty()) Text("From the stream", color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 2.dp))
            }
            RoundIconButton(
                if (isSaved) NeedleIcon.HEART_FILLED else NeedleIcon.HEART,
                onClick = {
                    if (song.isNotEmpty() && stationId.isNotEmpty()) {
                        val now = RadioStations.toggleSaved(stationId, song, songArtist)
                        android.widget.Toast.makeText(context, if (now) "Saved to $name" else "Removed", android.widget.Toast.LENGTH_SHORT).show()
                    }
                },
                size = 44.dp, iconSize = 22.dp, active = isSaved
            )
        }
        Box(Modifier.fillMaxWidth().padding(top = 16.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f))) {
            Box(Modifier.fillMaxSize().background(Palette.Accent.copy(alpha = 0.9f)))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp)) {
            Text(if (vm.isPlaying) "Playing live" else "Paused", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.weight(1f))
            Text("LIVE", color = Palette.Muted, fontSize = 12.sp)
        }
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            SkipButton(next = false, enabled = sorted.size > 1, onClick = {
                if (sorted.size > 1) vm.playRadio(sorted[(sortedIndex - 1 + sorted.size) % sorted.size])
            })
            PlayPauseButton(vm.isPlaying, enabled = true, onClick = { vm.togglePlay() })
            SkipButton(next = true, enabled = sorted.size > 1, onClick = {
                if (sorted.size > 1) vm.playRadio(sorted[(sortedIndex + 1) % sorted.size])
            })
        }
        Row(
            Modifier.padding(top = 14.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.10f)).clickable(onClick = onSleepTimer)
                .padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleIconView(NeedleIcon.TIMER, Palette.Accent, size = 18.dp)
            Spacer(Modifier.width(8.dp))
            Text("Sleep timer · " + app.needle.music.playback.SleepTimer.summary, color = Palette.Text, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
        }
        val earlier = recent.filter { it.stationId == stationId && !(it.title == song && it.artist == songArtist) }.take(3)
        if (earlier.isNotEmpty()) {
            Column(Modifier.fillMaxWidth().padding(top = 14.dp)) {
                Text("Earlier on this station", color = Palette.Muted, fontSize = 13.sp)
                earlier.forEach { e ->
                    Row(Modifier.fillMaxWidth().height(32.dp), verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            if (e.artist.isEmpty()) e.title else "${e.title} · ${e.artist}",
                            color = Palette.Text, fontSize = 14.sp, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Text(minutesAgo(e.at), color = Palette.Muted, fontSize = 12.5.sp)
                    }
                }
            }
        }
    }
}
