package app.needle.music.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.music.cast.CastHub
import app.needle.music.cast.CastPhase
import app.needle.music.cast.CastSettings
import app.needle.music.data.ExcludedFolders
import app.needle.music.data.HiddenSongs
import app.needle.music.data.MixPrefs
import app.needle.music.data.Onboarding
import app.needle.music.data.PinnedArtists
import app.needle.music.data.SmartPlaylist
import app.needle.music.data.SmartPlaylists
import app.needle.music.data.exportM3u
import app.needle.music.data.importM3u
import app.needle.music.data.Ringtone
import app.needle.music.data.buildArtistList
import app.needle.music.data.isKnownArtist
import app.needle.music.data.genresOf
import app.needle.music.data.SimilarSongs
import androidx.activity.result.IntentSenderRequest
import app.needle.music.data.buildArtistPage
import app.needle.music.data.RatingStyle
import app.needle.music.data.RatingScale
import app.needle.music.data.artistKey
import app.needle.music.data.buildPlaylists
import app.needle.music.playback.EqState
import app.needle.music.playback.SleepTimer
import app.needle.music.data.FileAccess
import app.needle.music.data.NeedleSettings
import app.needle.music.data.SettingsViewModel
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import app.needle.music.data.HomeAlbum
import app.needle.music.data.RadioStation
import app.needle.music.data.RadioStations
import app.needle.music.data.Recommendations
import app.needle.music.data.GenrePrefs
import app.needle.music.data.HomeViewModel
import app.needle.music.data.LyricsViewModel
import app.needle.music.data.LibraryViewModel
import app.needle.music.data.Song
import app.needle.music.data.TagsViewModel
import app.needle.music.data.WritePrefs
import app.needle.music.playback.PlayerViewModel

@Composable
fun NeedleApp() {
    val library: LibraryViewModel = viewModel()
    val homeVm: HomeViewModel = viewModel()
    val tagsVm: TagsViewModel = viewModel()
    val settingsVm: SettingsViewModel = viewModel()
    val player: PlayerViewModel = viewModel()
    val lyricsVm: LyricsViewModel = viewModel()
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    var homeTab by rememberSaveable { mutableStateOf(startHomeTab()) }
    var showSingles by rememberSaveable { mutableStateOf(false) }
    var showMostPlayed by rememberSaveable { mutableStateOf(false) }
    var showStats by rememberSaveable { mutableStateOf(false) }
    // Radio: the list, a station's page, the directory search, and the add / edit form (a station with an empty id is a new one)
    var showRadio by rememberSaveable { mutableStateOf(false) }
    var openRadioId by rememberSaveable { mutableStateOf<String?>(null) }
    var showRadioFind by rememberSaveable { mutableStateOf(false) }
    var showForYou by rememberSaveable { mutableStateOf(false) }
    var radioFormOpen by remember { mutableStateOf(false) }
    var radioFormStation by remember { mutableStateOf<RadioStation?>(null) }
    // True when the Hidden songs page was opened from the Library page (Back then returns there, not to Settings)
    var hiddenFromLibrary by rememberSaveable { mutableStateOf(false) }
    // The Folders page and the folder it is in ("" = the top)
    var showFolders by rememberSaveable { mutableStateOf(false) }
    var showArtists by rememberSaveable { mutableStateOf(false) }
    var folderPath by rememberSaveable { mutableStateOf("") }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showLyricsEditor by rememberSaveable { mutableStateOf(false) }
    var lyricsEditSongId by rememberSaveable { mutableStateOf(0L) }
    var showLyricsSettings by rememberSaveable { mutableStateOf(false) }
    var showHidden by rememberSaveable { mutableStateOf(false) }
    var openMixId by rememberSaveable { mutableStateOf<String?>(null) }
    var showNewChoice by remember { mutableStateOf(false) }
    var smartEditing by remember { mutableStateOf(false) }
    var smartEdit by remember { mutableStateOf<SmartPlaylist?>(null) }
    // The song menu and the Song info page. The ids stay put while they slide away.
    var showMenu by rememberSaveable { mutableStateOf(false) }
    var menuSongId by rememberSaveable { mutableStateOf(0L) }
    var showInfo by rememberSaveable { mutableStateOf(false) }
    var infoSongId by rememberSaveable { mutableStateOf(0L) }
    // The menu of a whole album (press and hold on the Albums page)
    var showAlbumMenu by rememberSaveable { mutableStateOf(false) }
    var showArtistMenu by remember { mutableStateOf(false) }
    var artistMenuSongs by remember { mutableStateOf<List<Song>>(emptyList()) }
    var artistMenuName by remember { mutableStateOf("") }
    // The Player controls sheet on Now Playing, and its Speed & pitch dialog
    var showControls by rememberSaveable { mutableStateOf(false) }
    var showSpeed by rememberSaveable { mutableStateOf(false) }
    var albumMenuId by rememberSaveable { mutableStateOf(0L) }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var openAlbumId by rememberSaveable { mutableStateOf<Long?>(null) }
    // A song that is not on an album gets a page of its own, built like an album page with one track.
    var openSingleId by rememberSaveable { mutableStateOf<Long?>(null) }
    // The Sides editor for an album. The id stays put while it slides away.
    var showSides by rememberSaveable { mutableStateOf(false) }
    // "Choose your genres"
    var showGenres by rememberSaveable { mutableStateOf(false) }
    var sidesAlbumId by rememberSaveable { mutableStateOf(0L) }
    // The artist page that is open (the artist's name), and the color it paints behind the whole screen
    var openArtist by rememberSaveable { mutableStateOf<String?>(null) }
    // "Go to genre": the genre page that is open, and (when a song has several genres) the question which one
    var openGenre by rememberSaveable { mutableStateOf<String?>(null) }
    var genreChoices by remember { mutableStateOf<List<String>>(emptyList()) }
    // "Delete file": the song we ask about (older Android only), and the song whose Android delete box is open
    var deleteAskId by remember { mutableStateOf<Long?>(null) }
    var deletingSong by remember { mutableStateOf<Song?>(null) }
    // The Equalizer page, and where Back should go ("player", "settings" or "")
    var showEq by rememberSaveable { mutableStateOf(false) }
    var eqFrom by rememberSaveable { mutableStateOf("") }
    // The Sleep timer page, and where Back should go ("player" or "settings")
    var showSleep by rememberSaveable { mutableStateOf(false) }
    var sleepFrom by rememberSaveable { mutableStateOf("") }
    // Playlists: the open playlist page, its menu, the Add to playlist sheet and the dialogs
    var openPlaylistId by rememberSaveable { mutableStateOf<Long?>(null) }
    var playlistMenuId by rememberSaveable { mutableStateOf<Long?>(null) }
    var showPlaylistMenu by rememberSaveable { mutableStateOf(false) }
    var addSongIds by remember { mutableStateOf<List<Long>>(emptyList()) }       // the songs the sheet is about
    var showAddSheet by remember { mutableStateOf(false) }
    // The Rate song sheet
    var showRatingSheet by remember { mutableStateOf(false) }
    var ratingSongId by remember { mutableStateOf<Long?>(null) }
    var nameRequest by remember { mutableStateOf<NameRequest?>(null) }
    var deletePlaylistId by remember { mutableStateOf<Long?>(null) }
    val artistChrome = remember { mutableStateOf<Color?>(null) }
    // The tag editor. The ids stay put while it slides away, so it does not go blank mid-animation.
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var editorIds by rememberSaveable { mutableStateOf(longArrayOf()) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        library.refreshPermission()
        if (library.hasPermission) Onboarding.setPermissionDeferred(false)
    }
    // First launch: the playback notification is asked for first (Android 13+), then the music; the answer to the
    // notification question does not matter, the music permission follows either way.
    val notificationLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        permissionLauncher.launch(library.audioPermission)
    }
    var wantNotifications by rememberSaveable { mutableStateOf(true) }

    // ---- casting (DLNA / UPnP) ----
    val context = LocalContext.current
    var showPlayOn by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var settingsPage by rememberSaveable { mutableStateOf(SettingsPage.HOME) }
    var castSettingsUdn by rememberSaveable { mutableStateOf<String?>(null) }
    var lanDenied by rememberSaveable { mutableStateOf(false) }
    val castDevices by CastHub.devices.collectAsState()
    val castHidden by CastHub.hidden.collectAsState()
    val castScanning by CastHub.scanning.collectAsState()
    val castState by CastHub.state.collectAsState()
    val castSettingsMap by CastHub.settings.collectAsState()
    val lanGranted by CastHub.localNetworkGranted.collectAsState()
    val lanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        CastHub.refreshPermission()
        lanDenied = !granted
        if (granted) CastHub.startScan()
    }
    // The box Android shows to delete an audio file (Android 11 and newer). When it says yes, the song leaves the queue and the list.
    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { result ->
        val gone = deletingSong
        deletingSong = null
        if (gone != null && deleteConfirmed(result.resultCode)) {
            player.removeSongFromQueue(gone.id)
            library.scan()
            Toast.makeText(context, "File deleted", Toast.LENGTH_SHORT).show()
        }
    }
    val allowAccess = {
        val askNotifications = wantNotifications && Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(context, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        if (askNotifications) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
        else permissionLauncher.launch(library.audioPermission)
    }
    val openAppSettings = {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        )
    }
    // Opening "Play on" asks for local network access (Android 17+) and starts looking for devices.
    LaunchedEffect(showPlayOn, lanGranted) {
        if (showPlayOn) {
            if (lanGranted) CastHub.startScan()
            else if (!lanDenied) lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
        }
    }
    // Short messages from the casting engine ("Lost connection to ...", volume).
    LaunchedEffect(Unit) {
        var toast: Toast? = null
        CastHub.messages.collect { message ->
            toast?.cancel()
            toast = Toast.makeText(context, message, Toast.LENGTH_SHORT).also { it.show() }
        }
    }

    // Ask once on launch; scan whenever access becomes available.
    LaunchedEffect(Unit) {
        // The first-launch screens ask on their own; "Not now" is respected.
        if (!library.hasPermission && Onboarding.welcomeDone.value && !Onboarding.permissionDeferred.value) {
            permissionLauncher.launch(library.audioPermission)
        }
    }
    LaunchedEffect(library.hasPermission) {
        if (library.hasPermission) {
            val loaded = library.songs.first { it != null }
            if (NeedleSettings.scanOnLaunch.value || loaded.isNullOrEmpty()) library.scan()
        }
    }

    val closeEq = {
        showEq = false
        when (eqFrom) {
            "player" -> showPlayer = true
            "settings" -> showSettings = true
        }
        eqFrom = ""
    }
    val closeSleep = {
        showSleep = false
        when (sleepFrom) {
            "player" -> showPlayer = true
            "settings" -> showSettings = true
            "queue" -> {
                showPlayer = true
                showQueue = true
            }
        }
        sleepFrom = ""
    }
    BackHandler(enabled = destination != Destination.HOME) { destination = Destination.HOME }
    BackHandler(enabled = showSingles) { showSingles = false }
    BackHandler(enabled = showMostPlayed) { showMostPlayed = false }
    BackHandler(enabled = showStats) { showStats = false }
    // Radio: the directory search closes first, then a station's page, then the list
    BackHandler(enabled = showForYou) { showForYou = false }
    BackHandler(enabled = showRadio) { showRadio = false }
    BackHandler(enabled = openRadioId != null) { openRadioId = null }
    BackHandler(enabled = showRadioFind) { showRadioFind = false }
    BackHandler(enabled = openMixId != null) { openMixId = null }
    // Back goes up one folder first, then leaves the page
    BackHandler(enabled = showFolders) {
        if (folderPath.isEmpty()) showFolders = false else folderPath = folderPath.substringBeforeLast('/', "")
    }
    BackHandler(enabled = showArtists) { showArtists = false }
    BackHandler(enabled = openArtist != null) { openArtist = null }
    BackHandler(enabled = openGenre != null) { openGenre = null }
    BackHandler(enabled = openPlaylistId != null) { openPlaylistId = null }
    BackHandler(enabled = openAlbumId != null || openSingleId != null) {
        openAlbumId = null
        openSingleId = null
    }
    BackHandler(enabled = showSearch) { showSearch = false }
    BackHandler(enabled = showSettings) {
        when (settingsPage) {
            SettingsPage.HOME -> showSettings = false
            SettingsPage.HOME_LAYOUT, SettingsPage.COLORS_THEMES, SettingsPage.MEDIA_LISTS, SettingsPage.SKINS -> settingsPage = SettingsPage.APPEARANCE
            else -> settingsPage = SettingsPage.HOME
        }
    }
    BackHandler(enabled = showLyricsSettings) { showLyricsSettings = false; showSettings = true }
    BackHandler(enabled = showHidden) {
        showHidden = false
        if (hiddenFromLibrary) hiddenFromLibrary = false else showSettings = true
    }
    BackHandler(enabled = showEq) { closeEq() }
    BackHandler(enabled = showSleep) { closeSleep() }
    BackHandler(enabled = showPlayOn) { showPlayOn = false }
    BackHandler(enabled = castSettingsUdn != null) { castSettingsUdn = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = showInfo) { showInfo = false }
    BackHandler(enabled = showSides) { showSides = false }
    BackHandler(enabled = showGenres) { showGenres = false }
    BackHandler(enabled = showEditor) { showEditor = false }
    BackHandler(enabled = showQueue) { showQueue = false }
    BackHandler(enabled = showLyrics) { showLyrics = false }
    BackHandler(enabled = showAlbumMenu) { showAlbumMenu = false }
    BackHandler(enabled = showArtistMenu) { showArtistMenu = false }
    BackHandler(enabled = showMenu) { showMenu = false }
    BackHandler(enabled = showControls) { showControls = false }
    BackHandler(enabled = showPlaylistMenu) { showPlaylistMenu = false }
    BackHandler(enabled = showAddSheet) { showAddSheet = false }
    BackHandler(enabled = showRatingSheet) { showRatingSheet = false } // registered last, so it wins

    // The moving glow sits behind every page; pages that slide over it share the same clock.
    Box(Modifier.fillMaxSize()) {
        GlowLayer(Modifier.matchParentSize())
        // The artist page paints its color behind the status bar and the whole screen (cleared when it goes away).
        Box(Modifier.matchParentSize().drawBehind { artistChrome.value?.let { drawRect(it) } })
        if (!Onboarding.welcomeDone.value) {
            WelcomeScreen(onStart = { Onboarding.finishWelcome() }, modifier = Modifier.safeDrawingPadding())
        } else if (!library.hasPermission && !Onboarding.permissionDeferred.value) {
            PermissionScreen(
                notifications = wantNotifications,
                onNotificationsChange = { wantNotifications = it },
                onAllow = allowAccess,
                onNotNow = { Onboarding.setPermissionDeferred(true) },
                modifier = Modifier.safeDrawingPadding()
            )
        } else if (library.hasPermission && !Onboarding.scanIntroDone.value) {
            ScanIntro(library, homeVm, Modifier.safeDrawingPadding())
        } else {
            val songs by library.songs.collectAsState()
            val extras by library.extras.collectAsState()
            val playedIds by library.playedIds.collectAsState()
            val artistNotes by library.artistNotes.collectAsState()
            val playCounts by library.playCounts.collectAsState()
            val playlistRows by library.playlistRows.collectAsState()
            val playlistEntries by library.playlistEntries.collectAsState()
            val playlists = remember(songs, playlistRows, playlistEntries) {
                buildPlaylists(playlistRows, playlistEntries, songs.orEmpty())
            }
            val playingSongId = player.currentMediaId?.toLongOrNull()
            val ratings by library.ratings.collectAsState()
            // Smart flow: when the queue runs low, add songs like the one that is playing, so the music never stops.
            val smartFlow = NeedleSettings.smartFlow.value
            LaunchedEffect(smartFlow, player.currentMediaId, player.queueVersion, songs) {
                val all = songs
                if (!smartFlow || all == null || !player.hasMedia) return@LaunchedEffect
                if (player.songsLeft() >= 3) return@LaunchedEffect
                val seed = all.firstOrNull { it.id.toString() == player.currentMediaId } ?: return@LaunchedEffect
                val more = SimilarSongs.pick(seed, all, ratings, exclude = player.queueSongIds().toSet(), limit = 10)
                if (more.isNotEmpty()) player.addToQueue(more)
            }
            val tagsRead by library.tagsReadCount.collectAsState()
            val hiddenSongs by library.hiddenSongs.collectAsState()
            val folderGroups by library.folderGroups.collectAsState()
            val excludedFolders by ExcludedFolders.names.collectAsState()
            val sort by library.sort.collectAsState()
            val home by homeVm.home.collectAsState()
            val newState by homeVm.newState.collectAsState()
            val libraryGenres by homeVm.genres.collectAsState()
            val favoriteGenres by GenrePrefs.selected.collectAsState()
            val genresAsked by GenrePrefs.asked.collectAsState()
            val singlesState by homeVm.singles.collectAsState()
            val mostPlayedState by homeVm.mostPlayed.collectAsState()
            val statsState by homeVm.stats.collectAsState()
            val mixes by homeVm.mixes.collectAsState()
            val smartMixes by homeVm.smartMixes.collectAsState()
            val moments by homeVm.moments.collectAsState()
            val radioStations by RadioStations.stations.collectAsState()
            val radioSaved by RadioStations.saved.collectAsState()
            val radioRecent by RadioStations.recent.collectAsState()
            val recOn by Recommendations.enabled.collectAsState()
            val recWifiOnly by Recommendations.wifiOnly.collectAsState()
            val recSuggestions by Recommendations.suggestions.collectAsState()
            val recWishlist by Recommendations.wishlist.collectAsState()
            val recUpdated by Recommendations.updatedAt.collectAsState()
            val recLoading by Recommendations.loading.collectAsState()
            val recFailed by Recommendations.failed.collectAsState()
            val openMix = (mixes + smartMixes).firstOrNull { it.id == openMixId }
            // Library > New playlist > Import from a file: an .m3u / .m3u8 whose songs are matched to the library.
            val importScope = rememberCoroutineScope()
            val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
                if (uri != null) importScope.launch {
                    val result = runCatching { importM3u(context, uri, songs.orEmpty()) }.getOrNull()
                    when {
                        result == null || result.total == 0 ->
                            Toast.makeText(context, "That file has no songs in it.", Toast.LENGTH_LONG).show()
                        result.songIds.isEmpty() ->
                            Toast.makeText(context, "None of its ${result.total} songs were found in your library.", Toast.LENGTH_LONG).show()
                        else -> library.createPlaylist(result.name, result.songIds) { id ->
                            openPlaylistId = id
                            Toast.makeText(context, "Imported ${result.songIds.size} of ${result.total} songs into ${result.name}", Toast.LENGTH_LONG).show()
                        }
                    }
                }
            }
            // Playlist menu > Export as .m3u: ask where to save it, then write it.
            var pendingExport by remember { mutableStateOf<List<Song>>(emptyList()) }
            val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("audio/x-mpegurl")) { uri ->
                if (uri != null) {
                    val songsToWrite = pendingExport
                    importScope.launch {
                        val n = runCatching { exportM3u(context, uri, songsToWrite) }.getOrDefault(0)
                        Toast.makeText(
                            context,
                            if (n == 0) "Could not write the playlist." else "Exported $n of ${songsToWrite.size} songs",
                            Toast.LENGTH_LONG
                        ).show()
                    }
                }
            }
            val pinnedKeys by PinnedArtists.keys.collectAsState()
            val albums by homeVm.albums.collectAsState()
            // Every artist of the library for the Artists page (null while the library is still loading).
            val artistRows = remember(songs, albums) {
                val all = songs
                val real = albums
                if (all == null || real == null) null else buildArtistList(all, real.map { it.id }.toSet())
            }
            // Look the open album up again each time, so it shows the latest tags. If an edit renamed it
            // into another album (it gets a new id), go back to the Albums grid.
            val albumToShow = openAlbumId?.let { id -> albums?.firstOrNull { it.id == id } }
            val singleAlbum = openSingleId?.let { id -> songs?.firstOrNull { it.id == id } }?.let { s ->
                HomeAlbum(
                    id = -s.id,
                    title = if (s.album != "Unknown album") s.album else s.title,
                    artist = s.artist,
                    songs = listOf(s),
                    heardTracks = 0,
                    lastPlayedAt = null
                )
            }
            val shownAlbum = singleAlbum ?: albumToShow
            LaunchedEffect(albums, openAlbumId) {
                if (albums != null && openAlbumId != null && albumToShow == null) openAlbumId = null
            }

            val openEditor: (List<Song>) -> Unit = { list ->
                editorIds = list.map { it.id }.toLongArray()
                showEditor = true
            }

            // Pressing and holding a song opens its menu (edit tags, song info, share, go to album).
            val openMenu: (Song) -> Unit = { song ->
                menuSongId = song.id
                showMenu = true
            }

            // Opens the page of a genre over whatever is open (closes the player and the other pages that sit under it).
            val openGenrePage: (String) -> Unit = { name ->
                showPlayer = false; showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                openAlbumId = null; openSingleId = null; openArtist = null; openPlaylistId = null
                openGenre = name
            }
            // Delete the audio file: Android asks by itself on version 11 and newer; older ones ask in our own box first.
            val startDelete: (Song) -> Unit = { song ->
                when (deleteSongFile(context, song) { sender ->
                    deletingSong = song
                    deleteLauncher.launch(IntentSenderRequest.Builder(sender).build())
                }) {
                    true -> {
                        player.removeSongFromQueue(song.id)
                        library.scan()
                        Toast.makeText(context, "File deleted", Toast.LENGTH_SHORT).show()
                    }
                    null -> Toast.makeText(context, "Could not delete this file", Toast.LENGTH_SHORT).show()
                    false -> {}
                }
            }

            // Media lists: what song rows show (heart, plays) and what swipes and the selection bar do
            val likedIds = remember(playlists) { playlists.firstOrNull { it.liked }?.songIds?.toSet().orEmpty() }
            SideEffect {
                ListDecor.liked.value = likedIds
                ListDecor.playCounts.value = playCounts
                val said: (List<Song>, String) -> String = { list, what ->
                    if (list.size == 1) "$what: ${list[0].title}" else "$what: ${list.size} songs"
                }
                // The toast text is only for the other navigations; the Island dock answers with its Queue card and an Undo.
                RowActions.playNext = { list -> announceQueue(context, player, list, true, said(list, "Plays next")) }
                RowActions.addToQueue = { list -> announceQueue(context, player, list, false, said(list, "Added to queue")) }
                RowActions.addToPlaylist = { list ->
                    if (list.isNotEmpty()) {
                        addSongIds = list.map { it.id }
                        showAddSheet = true
                    }
                }
                RowActions.editTags = { list -> if (list.isNotEmpty()) openEditor(list) }
                RowActions.toggleLike = { song ->
                    val was = song.id in likedIds
                    library.toggleLiked(song.id)
                    Toast.makeText(context, if (was) "Removed from Liked songs" else "Added to Liked songs", Toast.LENGTH_SHORT).show()
                }
            }

            // Singles and Most played open as their own pages; the other pills switch the Home page itself.
            val selectTab: (HomeTab) -> Unit = { tab ->
                when (tab) {
                    HomeTab.SINGLES -> showSingles = true
                    HomeTab.MOST_PLAYED -> showMostPlayed = true
                    else -> homeTab = tab
                }
            }

            // The dock floats over every screen: room to scroll past it (with / without the player row).
            // (Navigation "Pill only" and "Island dock" are one slim capsule even while a song plays.)
            val dockPadding = if (player.hasMedia && effectiveNavStyle().let { it != 1 && it != 4 }) 160.dp else 100.dp

            val settingsUdn = castSettingsUdn

            Box(Modifier.fillMaxSize().safeDrawingPadding().dockScrollAware()) {
                when {
                    settingsUdn != null -> CastDeviceSettingsScreen(
                        device = castDevices.firstOrNull { it.udn == settingsUdn },
                        settings = castSettingsMap[settingsUdn] ?: CastSettings(),
                        connected = castState.phase == CastPhase.CONNECTED && castState.device?.udn == settingsUdn,
                        bottomPadding = dockPadding,
                        onBack = { castSettingsUdn = null },
                        onChange = { change -> CastHub.updateSettings(settingsUdn, change) },
                        onRestore = { CastHub.restoreDefaults(settingsUdn) },
                        modifier = Modifier.fillMaxSize()
                    )
                    showPlayOn -> PlayOnScreen(
                        devices = castDevices,
                        hidden = castHidden,
                        scanning = castScanning,
                        cast = castState,
                        isPlaying = player.isPlaying,
                        volumeStep = castState.device?.let { (castSettingsMap[it.udn] ?: CastSettings()).volumeStep } ?: 10,
                        permissionGranted = lanGranted,
                        permissionDenied = lanDenied,
                        bottomPadding = dockPadding,
                        onBack = { showPlayOn = false },
                        onRefresh = { CastHub.startScan(clear = true) },
                        onUsePhone = { CastHub.disconnect() },
                        onUseDevice = { CastHub.connect(it) },
                        onHide = { CastHub.hide(it.udn) },
                        onUnhide = { CastHub.unhide(it.udn) },
                        onSettings = { castSettingsUdn = it.udn },
                        onVolume = { CastHub.stepVolume(it) },
                        onRequestPermission = {
                            if (lanDenied) openAppSettings() else lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSleep -> SleepTimerScreen(
                        bottomPadding = dockPadding,
                        onBack = closeSleep,
                        onUnavailable = { Toast.makeText(context, "Play a song first", Toast.LENGTH_SHORT).show() },
                        modifier = Modifier.fillMaxSize()
                    )
                    showEq -> EqualizerScreen(
                        casting = castState.phase == CastPhase.CONNECTED,
                        bottomPadding = dockPadding,
                        onBack = closeEq,
                        onSoon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() },
                        modifier = Modifier.fillMaxSize()
                    )
                    showHidden -> HiddenSongsScreen(
                        songs = hiddenSongs,
                        bottomPadding = dockPadding,
                        onBack = {
                            showHidden = false
                            if (hiddenFromLibrary) hiddenFromLibrary = false else showSettings = true
                        },
                        onUnhide = { HiddenSongs.unhide(listOf(it.id)) },
                        onUnhideAll = {
                            HiddenSongs.unhideAll()
                            Toast.makeText(context, "All songs are back in your library", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showLyricsSettings -> LyricsSettingsScreen(
                        savedCount = lyricsVm.savedCount,
                        onRefreshSaved = { lyricsVm.refreshSavedCount() },
                        onClearSaved = { lyricsVm.clearAllSaved() },
                        bottomPadding = dockPadding,
                        onBack = {
                            showLyricsSettings = false
                            showSettings = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSettings -> SettingsScreen(
                        page = settingsPage,
                        onPage = { settingsPage = it },
                        isScanning = library.isScanning,
                        onRescan = { library.scan() },
                        onChooseGenres = { showGenres = true },
                        vm = settingsVm,
                        glowOn = GlowSettings.enabled.value,
                        onGlowChange = { GlowSettings.set(it) },
                        onOpenLyricsSettings = {
                            showSettings = false
                            showLyricsSettings = true
                        },
                        folderGroups = folderGroups,
                        excludedFolders = excludedFolders,
                        onToggleFolder = { ExcludedFolders.toggle(it) },
                        hiddenCount = hiddenSongs.size,
                        onOpenHidden = {
                            showSettings = false
                            showHidden = true
                        },
                        onOpenEq = {
                            showSettings = false
                            eqFrom = "settings"
                            showEq = true
                        },
                        onOpenSleep = {
                            showSettings = false
                            sleepFrom = "settings"
                            showSleep = true
                        },
                        bottomPadding = dockPadding,
                        onBack = { showSettings = false },
                        onOpenCast = {
                            showSettings = false
                            showPlayOn = true
                        },
                        tagsRead = tagsRead,
                        songCount = songs?.size ?: 0,
                        tagProgress = library.tagProgress,
                        onRereadTags = { library.readTags(all = true) },
                        writeToFiles = WritePrefs.enabled.value,
                        onWriteToFilesChange = { on ->
                            WritePrefs.set(on)
                            if (on) {
                                FileAccess.refresh()
                                if (!FileAccess.granted.value) FileAccess.openSettings(context)
                            }
                        },
                        writeProgress = tagsVm.writeProgress,
                        onWriteAll = {
                            tagsVm.writeAll { message -> Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSearch -> SearchScreen(
                        songs = songs.orEmpty(),
                        albums = albums.orEmpty(),
                        extras = extras,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { showSearch = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onOpenAlbum = { album ->
                            showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                            destination = Destination.ALBUMS
                            openSingleId = null
                            openAlbumId = album.id
                        },
                        onOpenArtist = { name ->
                            showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                            openAlbumId = null; openSingleId = null
                            openArtist = name
                        },
                        onEditTags = openMenu
                    )
                    shownAlbum != null -> AlbumScreen(
                        album = shownAlbum,
                        extras = extras,
                        ratings = ratings,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = {
                            openAlbumId = null
                            openSingleId = null
                        },
                        onTrack = { index -> player.playSongs(shownAlbum.songs, index) },
                        onPlay = { player.playSongs(shownAlbum.songs, 0, shuffle = false) },
                        onShuffle = { player.shuffleAll(shownAlbum.songs) },
                        onPlayNext = {
                            announceQueue(context, player, shownAlbum.songs, true, "Playing next")
                        },
                        onAddToQueue = {
                            announceQueue(context, player, shownAlbum.songs, false, "Added to queue")
                        },
                        onEditTags = openEditor,
                        onEditSides = {
                            sidesAlbumId = shownAlbum.id
                            showSides = true
                        },
                        onEditTrack = openMenu,
                        onOpenArtist = { name ->
                            openAlbumId = null; openSingleId = null
                            openArtist = name
                        },
                        onChrome = { artistChrome.value = it }
                    )
                    openArtist != null -> {
                        val name = openArtist.orEmpty()
                        val page = remember(name, songs, albums, playCounts, ratings) {
                            buildArtistPage(name, songs.orEmpty(), albums.orEmpty(), playCounts, ratings)
                        }
                        // If an edit renamed the artist away, there is nothing left to show.
                        LaunchedEffect(page.songs.isEmpty(), songs != null, albums != null) {
                            if (songs != null && albums != null && page.songs.isEmpty()) openArtist = null
                        }
                        ArtistScreen(
                            data = page,
                            currentMediaId = player.currentMediaId,
                            bottomPadding = dockPadding,
                            onBack = { openArtist = null },
                            onPlay = { player.playSongs(page.songs, 0, shuffle = false) },
                            onShuffle = { player.shuffleAll(page.songs) },
                            onPlayList = { list, index -> player.playSongs(list, index) },
                            onOpenAlbum = { openAlbumId = it.id },
                            onQueueLatest = {
                                page.latest?.let {
                                    announceQueue(context, player, it.songs, false, "Added to queue")
                                }
                            },
                            onSongMenu = openMenu,
                            onMenu = {
                                artistMenuName = page.name
                                artistMenuSongs = page.songs
                                showArtistMenu = true
                            },
                            onChrome = { artistChrome.value = it },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    openGenre != null -> GenreScreen(
                        genre = openGenre.orEmpty(),
                        songs = songs.orEmpty(),
                        currentMediaId = player.currentMediaId,
                        ratings = ratings,
                        bottomPadding = dockPadding,
                        onBack = { openGenre = null },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onShuffle = { list -> player.shuffleAll(list) },
                        onMenu = openMenu,
                        modifier = Modifier.fillMaxSize()
                    )
                    openPlaylistId != null -> {
                        val page = playlists.firstOrNull { it.id == openPlaylistId }
                        // Deleted, or not loaded yet: if the list is loaded and it is gone, close the page.
                        LaunchedEffect(page == null, playlistRows.isNotEmpty()) {
                            if (page == null && playlistRows.isNotEmpty()) openPlaylistId = null
                        }
                        if (page != null) {
                            PlaylistScreen(
                                playlist = page,
                                playCounts = playCounts,
                                ratings = ratings,
                                currentMediaId = player.currentMediaId,
                                bottomPadding = dockPadding,
                                onBack = { openPlaylistId = null },
                                onMenu = { playlistMenuId = page.id; showPlaylistMenu = true },
                                onPlay = { list, index -> player.playSongs(list, index) },
                                onShuffle = { list -> player.shuffleAll(list) },
                                onRemove = { song ->
                                    library.removeFromPlaylist(page.id, listOf(song.id))
                                    Toast.makeText(context, if (page.liked) "Removed from Liked songs" else "Removed from ${page.name}", Toast.LENGTH_SHORT).show()
                                },
                                onSongMenu = openMenu,
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    showArtists -> ArtistsScreen(
                        artists = artistRows,
                        pinnedKeys = pinnedKeys,
                        bottomPadding = dockPadding,
                        onBack = { showArtists = false },
                        onSearch = { showSearch = true },
                        onOpenArtist = { openArtist = it },
                        onTogglePin = { row ->
                            val now = PinnedArtists.toggle(row.name)
                            Toast.makeText(context, if (now) "Pinned ${row.name}" else "Unpinned ${row.name}", Toast.LENGTH_SHORT).show()
                        }
                    )
                    showFolders -> FoldersScreen(
                        songs = songs,
                        path = folderPath,
                        bottomPadding = dockPadding,
                        onPath = { folderPath = it },
                        onBack = { showFolders = false },
                        onPlayAll = { list -> player.playSongs(list, 0, shuffle = false) },
                        onShuffleAll = { list -> player.shuffleAll(list) },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onMenu = openMenu,
                        onSearch = { showSearch = true }
                    )
                    openMix != null -> MixScreen(
                        mix = openMix,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { openMixId = null },
                        onRefresh = {
                            MixPrefs.refresh(openMix.id)
                            Toast.makeText(context, "Made a new ${openMix.name}", Toast.LENGTH_SHORT).show()
                        },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onShuffle = { list -> player.shuffleAll(list) },
                        onSavePlaylist = {
                            nameRequest = NameRequest(NameKind.NEW, songIds = openMix.songs.map { it.id }, initial = openMix.name)
                        },
                        onEdit = {
                            smartEdit = SmartPlaylists.get(openMix.id.removePrefix("smart:"))
                            smartEditing = true
                        },
                        onSongMenu = openMenu,
                        modifier = Modifier.fillMaxSize()
                    )
                    showForYou -> {
                        // Your most played artists (else the ones with the most songs) are the starting point.
                        val seeds = remember(statsState, artistRows) {
                            val played = statsState?.get(app.needle.music.data.MostRange.ALL)?.topArtists.orEmpty().map { it.name }
                            if (played.size >= 3) played else (played + artistRows.orEmpty().sortedByDescending { it.songs }.map { it.name }).distinct()
                        }
                        val ownKeys = remember(artistRows) { artistRows.orEmpty().map { it.key }.toSet() }
                        val askAgain: (Boolean) -> Unit = { force ->
                            if (seeds.isNotEmpty()) importScope.launch { Recommendations.refresh(context, seeds, ownKeys, force) }
                        }
                        LaunchedEffect(recOn, seeds) { if (recOn) askAgain(false) }
                        ForYouScreen(
                            suggestions = recSuggestions,
                            wishlist = recWishlist,
                            enabled = recOn,
                            wifiOnly = recWifiOnly,
                            loading = recLoading,
                            failed = recFailed,
                            updatedAt = recUpdated,
                            libraryAlbums = albums.orEmpty(),
                            bottomPadding = dockPadding,
                            onBack = { showForYou = false },
                            onEnable = { Recommendations.setEnabled(it) },
                            onWifiOnly = { Recommendations.setWifiOnly(it) },
                            onRefresh = { askAgain(true) },
                            onToggleWish = { Recommendations.toggleWish(it) },
                            onRemoveWish = { Recommendations.removeWish(it) },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    showRadioFind -> RadioFindScreen(
                        stations = radioStations,
                        bottomPadding = dockPadding,
                        onBack = { showRadioFind = false },
                        onAdd = { found ->
                            radioFormStation = RadioStation(id = "", name = found.name, url = found.url, thumbUrl = found.thumbUrl, tags = found.tags)
                            radioFormOpen = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    openRadioId != null -> {
                        val station = radioStations.firstOrNull { it.id == openRadioId }
                        // Deleted from its own form: nothing left to show.
                        LaunchedEffect(station == null) { if (station == null) openRadioId = null }
                        if (station != null) {
                            val here = player.radioId == station.id
                            RadioStationScreen(
                                station = station,
                                saved = radioSaved.filter { it.stationId == station.id },
                                recent = radioRecent.filter { it.stationId == station.id },
                                current = here,
                                playing = here && player.isPlaying,
                                bottomPadding = dockPadding,
                                onBack = { openRadioId = null },
                                onPlay = { player.playRadio(station) },
                                onTogglePause = { player.togglePlay() },
                                onFavorite = { RadioStations.toggleFavorite(station.id) },
                                onEdit = {
                                    radioFormStation = station
                                    radioFormOpen = true
                                },
                                onRemoveSaved = { RadioStations.toggleSaved(it.stationId, it.title, it.artist) },
                                modifier = Modifier.fillMaxSize()
                            )
                        }
                    }
                    showRadio -> RadioListScreen(
                        stations = radioStations,
                        playingId = player.radioId,
                        isPlaying = player.isPlaying,
                        bottomPadding = dockPadding,
                        onBack = { showRadio = false },
                        onAdd = {
                            radioFormStation = null
                            radioFormOpen = true
                        },
                        onFind = { showRadioFind = true },
                        onOpen = { openRadioId = it.id },
                        onPlay = { player.playRadio(it) },
                        onTogglePause = { player.togglePlay() },
                        modifier = Modifier.fillMaxSize()
                    )
                    showStats -> StatsScreen(
                        state = statsState,
                        bottomPadding = dockPadding,
                        onBack = { showStats = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onMenu = openMenu,
                        onOpenArtist = { openArtist = it }
                    )
                    showMostPlayed -> MostPlayedScreen(
                        state = mostPlayedState,
                        bottomPadding = dockPadding,
                        onBack = { showMostPlayed = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onMenu = openMenu
                    )
                    showSingles -> SinglesScreen(
                        state = singlesState,
                        bottomPadding = dockPadding,
                        onBack = { showSingles = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onEditTags = openMenu
                    )
                    destination == Destination.SONGS -> SongsScreen(
                        songs = songs,
                        isScanning = library.isScanning,
                        currentMediaId = player.currentMediaId,
                        sort = sort,
                        bottomPadding = dockPadding,
                        onSongClick = { index -> songs?.let { player.playSongs(it, index) } },
                        onSongLongClick = openMenu,
                        onShuffleAll = { songs?.let { player.shuffleAll(it) } },
                        onSortSelected = library::setSort,
                        onRescan = library::scan,
                        ratings = ratings,
                        hasPermission = library.hasPermission,
                        onAllow = allowAccess,
                        onChooseFolders = {
                            settingsPage = SettingsPage.LIBRARY
                            showSettings = true
                        }
                    )
                    destination == Destination.PLAYLISTS -> {
                        val artistCount = remember(songs) { songs.orEmpty().map { artistKey(it.artist) }.toSet().size }
                        LibraryScreen(
                            playlists = playlists,
                            songCount = songs?.size ?: 0,
                            albumCount = albums?.size ?: 0,
                            artistCount = artistCount,
                            bottomPadding = dockPadding,
                            onOpenPlaylist = { openPlaylistId = it.id },
                            onPlaylistMenu = { playlistMenuId = it.id; showPlaylistMenu = true },
                            onNewPlaylist = { showNewChoice = true },
                            mixes = mixes,
                            smartMixes = smartMixes,
                            onOpenMix = { openMixId = it.id },
                            onSearch = { showSearch = true },
                            onSongs = { destination = Destination.SONGS },
                            onAlbums = { destination = Destination.ALBUMS },
                            onFolders = {
                                folderPath = ""
                                showFolders = true
                            },
                            onArtists = { showArtists = true },
                            onSoon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() },
                            title = "Playlists",
                            showLinks = false,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    destination == Destination.BROWSE -> BrowseScreen(
                        home = home,
                        artistRows = artistRows,
                        stats = statsState,
                        mostPlayed = mostPlayedState,
                        stations = radioStations,
                        playingStationId = player.radioId,
                        bottomPadding = dockPadding,
                        onSearch = { showSearch = true },
                        onOpenAlbum = { a ->
                            if (albums?.any { it.id == a.id } == true) { openSingleId = null; openAlbumId = a.id }
                            else { openAlbumId = null; openSingleId = a.cover.id }
                        },
                        onOpenArtist = { openArtist = it },
                        onOpenArtists = { showArtists = true },
                        onPlaySongs = { list, index -> player.playSongs(list, index) },
                        onSongMenu = openMenu,
                        onStats = { showStats = true },
                        onMostPlayed = { showMostPlayed = true },
                        onSingles = { showSingles = true },
                        onRadio = { showRadio = true },
                        onForYou = { showForYou = true },
                        onPlayStation = { player.playRadio(it) },
                        modifier = Modifier.fillMaxSize()
                    )
                    destination == Destination.LIBRARY -> LibraryHubScreen(
                        songCount = songs?.size ?: 0,
                        albumCount = albums?.size ?: 0,
                        artistCount = artistRows?.size ?: 0,
                        playlistCount = playlists.count { !it.liked },
                        likedCount = playlists.firstOrNull { it.liked }?.songs?.size ?: 0,
                        stationCount = radioStations.size,
                        hiddenCount = hiddenSongs.size,
                        bottomPadding = dockPadding,
                        onSearch = { showSearch = true },
                        onSongs = { destination = Destination.SONGS },
                        onAlbums = { destination = Destination.ALBUMS },
                        onArtists = { showArtists = true },
                        onPlaylists = { destination = Destination.PLAYLISTS },
                        onLiked = { playlists.firstOrNull { it.liked }?.let { openPlaylistId = it.id } },
                        onFolders = {
                            folderPath = ""
                            showFolders = true
                        },
                        onSingles = { showSingles = true },
                        onMostPlayed = { showMostPlayed = true },
                        onStats = { showStats = true },
                        onRadio = { showRadio = true },
                        onForYou = { showForYou = true },
                        onHidden = {
                            hiddenFromLibrary = true
                            showHidden = true
                        },
                        onSettings = {
                            settingsPage = SettingsPage.HOME
                            showSettings = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    destination == Destination.ALBUMS -> AlbumsScreen(
                        albums = albums,
                        bottomPadding = dockPadding,
                        onOpenAlbum = { openAlbumId = it.id },
                        onSearch = { showSearch = true },
                        onEditTags = { album ->
                            albumMenuId = album.id
                            showAlbumMenu = true
                        }
                    )
                    else -> when (homeTab) {
                        HomeTab.NEW -> NewScreen(
                            state = newState,
                            bottomPadding = dockPadding,
                            onPlay = { list, index -> player.playSongs(list, index) },
                            onShuffle = { list -> player.shuffleAll(list) },
                            onEditTags = openEditor,
                            onSearch = { showSearch = true },
                            onProfile = { settingsPage = SettingsPage.HOME; showSettings = true },
                            onTabSelected = selectTab
                        )
                        else -> HomeScreen(
                            home = home,
                            bottomPadding = dockPadding,
                            genrePrompt = !genresAsked && libraryGenres.isNotEmpty(),
                            onChooseGenres = { showGenres = true },
                            onDismissGenrePrompt = { GenrePrefs.skip() },
                            onPlay = { list -> player.playSongs(list, 0) },
                            onOpenAlbum = { list ->
                                val s = list.firstOrNull()
                                if (s != null) {
                                    if (albums?.any { it.id == s.albumId } == true) { openSingleId = null; openAlbumId = s.albumId }
                                    else { openAlbumId = null; openSingleId = s.id }
                                }
                            },
                            onSearch = { showSearch = true },
                            onProfile = { settingsPage = SettingsPage.HOME; showSettings = true },
                            onTabSelected = selectTab,
                            onOpenArtist = { openArtist = it },
                            onOpenArtists = { showArtists = true },
                            onOpenStats = { showStats = true },
                            moments = moments,
                            momentsPlayer = player,
                            onPlayMoment = { player.playSongs(listOf(it), 0) },
                            onMomentToPlaylist = {
                                addSongIds = listOf(it.id)
                                showAddSheet = true
                            }
                        )
                    }
                }
                NeedleDock(
                    selected = destination,
                    onSelect = {
                        run {
                            destination = it
                            openPlaylistId = null
                            showSingles = false
                            showMostPlayed = false; showStats = false; openMixId = null
                            showRadio = false; openRadioId = null; showRadioFind = false; showForYou = false
                            hiddenFromLibrary = false
                            showFolders = false
                            showArtists = false
                            openAlbumId = null
                            openSingleId = null
                            openArtist = null
                            openGenre = null
                            showEq = false
                            eqFrom = ""
                            showSleep = false
                            sleepFrom = ""
                            showSearch = false
                            showPlayOn = false
                            showSettings = false
                            settingsPage = SettingsPage.HOME
                            showLyricsSettings = false
                            showHidden = false
                            castSettingsUdn = null
                        }
                    },
                    player = player,
                    onOpenPlayer = { showPlayer = true },
                    castName = castState.device?.name?.takeIf { castState.phase == CastPhase.CONNECTED },
                    onOpenCast = { showPlayOn = true },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            AnimatedVisibility(
                visible = showPlayer,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val npGlow = rememberArtworkGlow(player.artwork)
                // Where the player's links go: close the player and open the page.
                val openAlbumOf: (Song) -> Unit = { s ->
                    showPlayer = false; showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                    openArtist = null; openPlaylistId = null
                    if (albums?.any { it.id == s.albumId } == true) { openSingleId = null; openAlbumId = s.albumId }
                    else { openAlbumId = null; openSingleId = s.id }
                }
                val openArtistOf: (String) -> Unit = { name ->
                    showPlayer = false; showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                    openAlbumId = null; openSingleId = null
                    openArtist = name
                }
                val queueSource = remember(player.queueVersion, player.sourceIds, songs, albums, playlists) {
                    // Prefer the list the queue was started from; fall back to reading the queue itself (after a restart).
                    val live = player.queueSongIds()
                    val liveSet = live.toHashSet()
                    val started = player.sourceIds
                    inferQueueSource(
                        ids = if (started.isNotEmpty() && started.any { it in liveSet }) started else live, songs = songs.orEmpty(), albums = albums.orEmpty(), playlists = playlists,
                        openPlaylist = { id ->
                            showPlayer = false; showSearch = false; showSingles = false; showMostPlayed = false; showStats = false; openMixId = null; showArtists = false; showFolders = false
                            openAlbumId = null; openSingleId = null; openArtist = null
                            openPlaylistId = id
                        },
                        openAlbum = openAlbumOf,
                        openArtist = openArtistOf
                    )
                }
                GlowSurface(Modifier.fillMaxSize(), npGlow) {
                if (player.isRadio) RadioPlayerScreen(
                    vm = player,
                    stations = radioStations,
                    onClose = { showPlayer = false },
                    onOpenStation = { st ->
                        showPlayer = false
                        showRadioFind = false
                        showRadio = true
                        openRadioId = st.id
                    },
                    onSleepTimer = {
                        showPlayer = false
                        sleepFrom = "player"
                        showSleep = true
                    },
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                ) else NowPlayingScreen(
                    vm = player,
                    onClose = { showPlayer = false },
                    onOpenQueue = { showQueue = true },
                    onOpenLyrics = { showLyrics = true },
                    onOpenControls = { showControls = true },
                    onRate = {
                        if (playingSongId != null) {
                            ratingSongId = playingSongId
                            showRatingSheet = true
                        }
                    },
                    liked = playingSongId != null && playlists.firstOrNull { it.liked }?.songIds?.contains(playingSongId) == true,
                    onToggleLike = {
                        val id = playingSongId
                        if (id != null) {
                            val isLiked = playlists.firstOrNull { it.liked }?.songIds?.contains(id) == true
                            library.toggleLiked(id)
                            Toast.makeText(
                                context, if (isLiked) "Removed from Liked songs" else "Added to Liked songs", Toast.LENGTH_SHORT
                            ).show()
                        }
                    },
                    lyricsVm = lyricsVm,
                    queueSource = queueSource,
                    library = NowPlayingLibrary(
                        songs = songs.orEmpty(),
                        extras = extras,
                        playedIds = playedIds,
                        artistNotes = artistNotes,
                        onSaveArtistNote = { artist, note -> library.saveArtistNote(artist, note) },
                        onOpenArtist = { name ->
                            showPlayer = false
                            showSearch = false
                            showSingles = false
                            showMostPlayed = false; showStats = false; openMixId = null; showArtists = false
                            showFolders = false
                            openAlbumId = null
                            openSingleId = null
                            openArtist = name
                        },
                        onEditTags = { song -> openEditor(listOf(song)) },
                        onOpenInfo = { song ->
                            infoSongId = song.id
                            showInfo = true
                        },
                        onOpenAlbum = openAlbumOf,
                        onPlayTile = { tile ->
                            player.shuffleAll(tile.songs)
                            Toast.makeText(context, "Shuffling ${tile.label}", Toast.LENGTH_SHORT).show()
                        }
                    ),
                    castActive = castState.phase == CastPhase.CONNECTED,
                    onOpenPlayOn = {
                        showPlayer = false
                        showPlayOn = true
                    },
                    // swallow taps so they don't reach the list underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showInfo,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val infoSong = songs?.firstOrNull { it.id == infoSongId }
                if (infoSong != null) {
                    val trackCount = remember(songs, infoSong.albumId) { songs?.count { it.albumId == infoSong.albumId } ?: 0 }
                    GlowSurface(Modifier.fillMaxSize()) {
                        SongInfoScreen(
                            song = infoSong,
                            albumTrackCount = trackCount,
                            extras = extras[infoSong.id].orEmpty(),
                            onBack = { showInfo = false },
                            onEditTags = { openEditor(listOf(infoSong)) },
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showGenres,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                    GenrePickerScreen(
                        genres = libraryGenres,
                        initial = favoriteGenres,
                        onSave = { chosen ->
                            GenrePrefs.save(chosen)
                            showGenres = false
                        },
                        onSkip = {
                            GenrePrefs.skip()
                            showGenres = false
                        },
                        modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                    )
                }
            }

            AnimatedVisibility(
                visible = showSides,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val sidesAlbum = albums?.firstOrNull { it.id == sidesAlbumId }
                if (sidesAlbum != null) {
                    GlowSurface(Modifier.fillMaxSize()) {
                        SidesScreen(
                            album = sidesAlbum,
                            extras = extras,
                            onClose = { showSides = false },
                            onSave = { sideOf, totalSides, newTrack ->
                                tagsVm.saveSides(
                                    sideOf, totalSides, newTrack, WritePrefs.enabled.value,
                                    onSaved = { showSides = false },
                                    onWritten = { message -> Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
                                )
                            },
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showEditor,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val all = songs
                val ids = editorIds.toList()
                val editing = remember(all, editorIds) { all?.filter { it.id in ids }.orEmpty() }
                val trackTotal = remember(all, editing) {
                    editing.firstOrNull()?.let { first -> all?.count { it.albumId == first.albumId } } ?: 0
                }
                GlowSurface(Modifier.fillMaxSize()) {
                TagEditorScreen(
                    songs = editing,
                    extras = extras,
                    trackTotal = trackTotal,
                    onClose = { showEditor = false },
                    writeToFiles = WritePrefs.enabled.value,
                    onSave = { changes, cover ->
                        tagsVm.save(
                            ids, changes, cover, WritePrefs.enabled.value,
                            onSaved = { showEditor = false },
                            onWritten = { message -> Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
                        )
                    },
                    // swallow taps so they don't reach the screen underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showQueue,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                // Same name as the "Playing from" header on Now playing
                val playingFrom = remember(player.queueVersion, player.sourceIds, songs, albums, playlists) {
                    val live = player.queueSongIds()
                    val liveSet = live.toHashSet()
                    val started = player.sourceIds
                    inferQueueSource(
                        ids = if (started.isNotEmpty() && started.any { it in liveSet }) started else live,
                        songs = songs.orEmpty(), albums = albums.orEmpty(), playlists = playlists,
                        openPlaylist = {}, openAlbum = {}, openArtist = {}
                    )?.title
                }
                QueueScreen(
                    vm = player,
                    songs = songs.orEmpty(),
                    playingFrom = playingFrom,
                    onClose = { showQueue = false },
                    onSleepTimer = {
                        showQueue = false
                        showPlayer = false
                        sleepFrom = "queue"
                        showSleep = true
                    },
                    onSaveQueue = {
                        val ids = player.queueSongIds()
                        if (ids.isNotEmpty()) nameRequest = NameRequest(NameKind.NEW, songIds = ids, initial = "Saved queue")
                    },
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showLyrics,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                    LyricsScreen(
                        player = player,
                        lyricsVm = lyricsVm,
                        onClose = { showLyrics = false },
                        onEdit = {
                            val id = player.currentMediaId?.toLongOrNull()
                            if (id != null) {
                                lyricsEditSongId = id
                                showLyricsEditor = true
                            }
                        },
                        modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                    )
                }
            }

            AnimatedVisibility(
                visible = showLyricsEditor,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val editSong = songs?.firstOrNull { it.id == lyricsEditSongId }
                if (editSong != null) {
                    GlowSurface(Modifier.fillMaxSize()) {
                        LyricsEditorScreen(
                            song = editSong,
                            player = player,
                            lyricsVm = lyricsVm,
                            onClose = { showLyricsEditor = false },
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showMenu || showAlbumMenu || showArtistMenu || showControls || showPlaylistMenu || showAddSheet || showRatingSheet,
                enter = fadeIn(), exit = fadeOut()
            ) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))
                        .pointerInput(Unit) {
                            detectTapGestures {
                                showMenu = false
                                showAlbumMenu = false
                                showArtistMenu = false
                                showControls = false
                                showPlaylistMenu = false
                                showAddSheet = false
                                showRatingSheet = false
                            }
                        }
                )
            }
            if (radioFormOpen) {
                val editing = radioFormStation?.takeIf { it.id.isNotBlank() }
                RadioFormDialog(
                    initial = radioFormStation,
                    onSave = { name, url, mobileUrl, thumbUrl, description, tags ->
                        if (editing != null) {
                            RadioStations.update(
                                editing.copy(
                                    name = name.trim().ifEmpty { url.trim() }, url = url.trim(), mobileUrl = mobileUrl.trim(),
                                    thumbUrl = thumbUrl.trim(), description = description.trim(), tags = RadioStations.splitTags(tags)
                                )
                            )
                        } else {
                            RadioStations.add(name, url, mobileUrl, thumbUrl, description, tags)
                            Toast.makeText(context, "Added ${name.trim().ifEmpty { url.trim() }}", Toast.LENGTH_SHORT).show()
                        }
                        radioFormOpen = false
                    },
                    onDismiss = { radioFormOpen = false },
                    onFind = if (editing == null && !showRadioFind) {
                        {
                            radioFormOpen = false
                            showRadio = true
                            showRadioFind = true
                        }
                    } else null,
                    onDelete = editing?.let { e ->
                        {
                            RadioStations.delete(e.id)
                            radioFormOpen = false
                            openRadioId = null
                        }
                    }
                )
            }
            // ---- playlists: the name and delete questions (dialogs open their own window) ----
            if (showNewChoice) {
                NewPlaylistChoiceDialog(
                    onCreate = {
                        showNewChoice = false
                        nameRequest = NameRequest(NameKind.NEW, openAfter = true)
                    },
                    onImport = {
                        showNewChoice = false
                        importLauncher.launch(arrayOf("audio/x-mpegurl", "audio/mpegurl", "application/vnd.apple.mpegurl", "application/x-mpegurl", "text/plain", "*/*"))
                    },
                    onSmart = {
                        showNewChoice = false
                        smartEdit = null
                        smartEditing = true
                    },
                    onDismiss = { showNewChoice = false }
                )
            }
            if (smartEditing) {
                SmartPlaylistEditor(
                    initial = smartEdit,
                    onSave = { sp ->
                        val id = SmartPlaylists.save(sp)
                        smartEditing = false
                        openMixId = "smart:$id"
                    },
                    onDelete = smartEdit?.let { e ->
                        {
                            SmartPlaylists.delete(e.id)
                            smartEditing = false
                            openMixId = null
                        }
                    },
                    onDismiss = { smartEditing = false }
                )
            }
            nameRequest?.let { req ->
                PlaylistNameDialog(
                    title = if (req.kind == NameKind.NEW) "New playlist" else "Rename playlist",
                    initial = req.initial,
                    confirm = if (req.kind == NameKind.NEW) "Create" else "Rename",
                    onConfirm = { typed ->
                        nameRequest = null
                        val name = typed.trim().ifEmpty { "New playlist" }
                        if (req.kind == NameKind.NEW) {
                            library.createPlaylist(name, req.songIds) { id ->
                                showAddSheet = false
                                if (req.openAfter) openPlaylistId = id
                                val text = if (req.songIds.isEmpty()) "Created $name" else "Saved ${req.songIds.size} songs to $name"
                                Toast.makeText(context, text, Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            library.renamePlaylist(req.playlistId, name)
                        }
                    },
                    onDismiss = { nameRequest = null }
                )
            }
            deletePlaylistId?.let { id ->
                val doomed = playlists.firstOrNull { it.id == id }
                if (doomed == null) {
                    deletePlaylistId = null
                } else {
                    DeletePlaylistDialog(
                        name = doomed.name,
                        onConfirm = {
                            library.deletePlaylist(id)
                            deletePlaylistId = null
                            if (openPlaylistId == id) openPlaylistId = null
                            Toast.makeText(context, "Deleted ${doomed.name}", Toast.LENGTH_SHORT).show()
                        },
                        onDismiss = { deletePlaylistId = null }
                    )
                }
            }
            // ---- ratings: the Rate song sheet ----
            AnimatedVisibility(
                visible = showRatingSheet,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val rateSong = songs?.firstOrNull { it.id == ratingSongId }
                if (rateSong != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        RatingSheet(
                            song = rateSong,
                            value = ratings[rateSong.id] ?: 0,
                            style = NeedleSettings.ratingStyle.value,
                            onRate = { value -> library.setRating(rateSong.id, value) },
                            onCycleStyle = {
                                val all = RatingStyle.entries
                                NeedleSettings.setRatingStyle(all[(NeedleSettings.ratingStyle.value.ordinal + 1) % all.size])
                            },
                            onDone = { showRatingSheet = false },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
            // ---- playlists: the Add to playlist sheet and the playlist menu ----
            AnimatedVisibility(
                visible = showAddSheet,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val sheetSongs = remember(songs, addSongIds) { songs.orEmpty().filter { it.id in addSongIds } }
                if (sheetSongs.isNotEmpty()) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        AddToPlaylistSheet(
                            songs = sheetSongs,
                            playlists = playlists,
                            onToggle = { p, allIn ->
                                val ids = sheetSongs.map { it.id }
                                if (allIn) {
                                    library.removeFromPlaylist(p.id, ids)
                                    Toast.makeText(context, "Removed from ${p.name}", Toast.LENGTH_SHORT).show()
                                } else {
                                    library.addToPlaylist(p.id, ids)
                                    Toast.makeText(context, "Added to ${p.name}", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onNew = { nameRequest = NameRequest(NameKind.NEW, songIds = addSongIds) },
                            onDone = { showAddSheet = false },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = showPlaylistMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val menuPlaylist = playlists.firstOrNull { it.id == playlistMenuId }
                if (menuPlaylist != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        PlaylistMenuSheet(
                            playlist = menuPlaylist,
                            onPlay = { showPlaylistMenu = false; player.playSongs(menuPlaylist.songs, 0) },
                            onShuffle = { showPlaylistMenu = false; player.shuffleAll(menuPlaylist.songs) },
                            onPlayNext = {
                                showPlaylistMenu = false
                                announceQueue(context, player, menuPlaylist.songs, true, "Playlist playing next")
                            },
                            onAddToQueue = {
                                showPlaylistMenu = false
                                announceQueue(context, player, menuPlaylist.songs, false, "Playlist added to queue")
                            },
                            onRename = {
                                showPlaylistMenu = false
                                nameRequest = NameRequest(NameKind.RENAME, playlistId = menuPlaylist.id, initial = menuPlaylist.name)
                            },
                            onDelete = {
                                showPlaylistMenu = false
                                deletePlaylistId = menuPlaylist.id
                            },
                            onExport = {
                                showPlaylistMenu = false
                                pendingExport = menuPlaylist.songs
                                exportLauncher.launch(menuPlaylist.name.replace(Regex("[\\\\/:*?\"<>|]"), "_") + ".m3u8")
                            },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = showArtistMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val pinnedNow by PinnedArtists.keys.collectAsState()
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                    ArtistMenuSheet(
                        name = artistMenuName,
                        cover = artistMenuSongs.firstOrNull(),
                        songCount = artistMenuSongs.size,
                        pinned = artistKey(artistMenuName) in pinnedNow,
                        onPlayNext = {
                            showArtistMenu = false
                            announceQueue(context, player, artistMenuSongs, true, "Playing next")
                        },
                        onAddToQueue = {
                            showArtistMenu = false
                            announceQueue(context, player, artistMenuSongs, false, "Added to queue")
                        },
                        onShuffle = {
                            showArtistMenu = false
                            player.shuffleAll(artistMenuSongs)
                        },
                        onTogglePin = {
                            showArtistMenu = false
                            val now = PinnedArtists.toggle(artistMenuName)
                            Toast.makeText(context, if (now) "Pinned $artistMenuName" else "Unpinned $artistMenuName", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                    )
                }
            }
            AnimatedVisibility(
                visible = showAlbumMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val menuAlbum = albums?.firstOrNull { it.id == albumMenuId }
                if (menuAlbum != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        AlbumMenuSheet(
                            album = menuAlbum,
                            onPlayNext = {
                                showAlbumMenu = false
                                announceQueue(context, player, menuAlbum.songs, true, "Album playing next")
                            },
                            onAddToQueue = {
                                showAlbumMenu = false
                                announceQueue(context, player, menuAlbum.songs, false, "Album added to queue")
                            },
                            onShuffle = {
                                showAlbumMenu = false
                                player.shuffleAll(menuAlbum.songs)
                            },
                            onAddToPlaylist = {
                                showAlbumMenu = false
                                addSongIds = menuAlbum.songs.map { it.id }
                                showAddSheet = true
                            },
                            onEditTags = {
                                showAlbumMenu = false
                                openEditor(menuAlbum.songs)
                            },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = showControls,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                // The song that is playing. It is looked up here so the sheet always matches the player.
                val current = songs?.firstOrNull { it.id.toString() == player.currentMediaId }
                if (current != null) {
                    val casting = castState.phase == CastPhase.CONNECTED
                    val lyricsReady = lyricsVm.state.songId == current.id && lyricsVm.state.lyrics != null
                    val soon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() }
                    val onAlbum = albums?.any { it.id == current.albumId } == true
                    val liked = playlists.firstOrNull { it.liked }?.songIds?.contains(current.id) == true
                    val genres = genresOf(current).distinctBy { it.lowercase() }
                    // Close the sheet and the pages that sit under a "Go to ..." page
                    val leaveForPage = {
                        showControls = false
                        showPlayer = false
                        showSearch = false
                        showSingles = false
                        showMostPlayed = false; showStats = false; openMixId = null; showArtists = false
                        showFolders = false
                    }
                    val playback = listOf(
                        ControlTile(
                            NeedleIcon.SPEED, "Speed & pitch",
                            if (casting) "Not while casting" else speedSummary(player.speed, player.speedSemitones)
                        ) {
                            if (casting) {
                                Toast.makeText(context, "Speed and pitch work on this phone only", Toast.LENGTH_SHORT).show()
                            } else {
                                showControls = false
                                showSpeed = true
                            }
                        },
                        ControlTile(NeedleIcon.EQUALIZER, "Equalizer \u00B7 DSP", EqState.summary) {
                            showControls = false
                            showPlayer = false
                            eqFrom = "player"
                            showEq = true
                        },
                        ControlTile(NeedleIcon.TIMER, "Sleep timer", SleepTimer.summary) {
                            showControls = false
                            showPlayer = false
                            sleepFrom = "player"
                            showSleep = true
                        },
                        ControlTile(NeedleIcon.CAST, "Play on", castState.device?.name?.takeIf { casting } ?: "This phone") {
                            showControls = false
                            showPlayer = false
                            showPlayOn = true
                        },
                        // Smart flow: the queue refills itself with songs like the playing one (see the effect near the top)
                        ControlTile(
                            NeedleIcon.SMART_FLOW, "Smart flow",
                            if (smartFlow) "On \u00B7 queue keeps going" else "Off",
                            active = smartFlow
                        ) {
                            NeedleSettings.setSmartFlow(!smartFlow)
                            Toast.makeText(
                                context, if (smartFlow) "Smart flow off" else "Smart flow on: similar songs are added when the queue runs low",
                                Toast.LENGTH_SHORT
                            ).show()
                        },
                        // Instant mix: a new queue of songs like this one, this song first
                        ControlTile(NeedleIcon.MIX, "Instant mix", "Songs like this one") {
                            val mix = SimilarSongs.pick(current, songs.orEmpty(), ratings, limit = 50)
                            if (mix.isEmpty()) {
                                Toast.makeText(context, "Not enough songs to make a mix", Toast.LENGTH_SHORT).show()
                            } else {
                                showControls = false
                                player.playSongs(listOf(current) + mix, 0, shuffle = false)
                                Toast.makeText(context, "Instant mix: ${mix.size + 1} songs", Toast.LENGTH_SHORT).show()
                            }
                        }
                    )
                    val song = listOf(
                        ControlTile(
                            if (liked) NeedleIcon.HEART_FILLED else NeedleIcon.HEART, "Favorite",
                            if (liked) "In Liked songs" else "Add to Liked songs", active = liked
                        ) {
                            library.toggleLiked(current.id)
                        },
                        ControlTile(
                            NeedleIcon.STAR, "Rate song",
                            ratings[current.id]?.let { RatingScale.label(NeedleSettings.ratingStyle.value, it) } ?: "Not rated"
                        ) {
                            showControls = false
                            ratingSongId = current.id
                            showRatingSheet = true
                        },
                        ControlTile(
                            NeedleIcon.ADD_PLAYLIST, "Add to playlist",
                            playlists.filter { current.id in it.songIds }.let { inLists ->
                                when {
                                    inLists.isEmpty() -> null
                                    inLists.size == 1 -> inLists[0].name
                                    else -> "In ${inLists.size} playlists"
                                }
                            }
                        ) {
                            showControls = false
                            addSongIds = listOf(current.id)
                            showAddSheet = true
                        },
                        ControlTile(NeedleIcon.INFO, "Song info", "Tags, file, format") {
                            showControls = false
                            infoSongId = current.id
                            showInfo = true
                        }
                    )
                    val goTo = listOf(
                        ControlTile(NeedleIcon.ALBUMS, "Go to album", current.album.takeIf { onAlbum }) {
                            leaveForPage()
                            if (onAlbum) {
                                destination = Destination.ALBUMS
                                openSingleId = null
                                openAlbumId = current.albumId
                            } else {
                                // not on an album: its own page, with the description and tags
                                openAlbumId = null
                                openSingleId = current.id
                            }
                        },
                        ControlTile(
                            NeedleIcon.ARTIST, "Go to artist", current.artist.takeIf { isKnownArtist(it) },
                            enabled = isKnownArtist(current.artist)
                        ) {
                            if (isKnownArtist(current.artist)) {
                                leaveForPage()
                                openAlbumId = null
                                openSingleId = null
                                openArtist = current.artist
                            } else {
                                Toast.makeText(context, "This song has no artist", Toast.LENGTH_SHORT).show()
                            }
                        },
                        ControlTile(
                            NeedleIcon.GENRE, "Go to genre",
                            when {
                                genres.isEmpty() -> "No genre"
                                genres.size == 1 -> genres[0]
                                else -> "${genres.size} genres"
                            },
                            enabled = genres.isNotEmpty()
                        ) {
                            when {
                                genres.isEmpty() -> Toast.makeText(context, "This song has no genre", Toast.LENGTH_SHORT).show()
                                genres.size == 1 -> { showControls = false; openGenrePage(genres[0]) }
                                else -> { showControls = false; genreChoices = genres }
                            }
                        }
                    )
                    val edit = listOf(
                        ControlTile(NeedleIcon.TAG, "Edit tags") {
                            showControls = false
                            openEditor(listOf(current))
                        },
                        ControlTile(NeedleIcon.PENCIL, "Edit lyrics", if (lyricsReady) "Has lyrics" else "No lyrics yet") {
                            showControls = false
                            lyricsEditSongId = current.id
                            showLyricsEditor = true
                        }
                    )
                    val find = listOf(
                        ControlTile(NeedleIcon.GLOBE, "Web search", "Look it up online") {
                            searchSongOnWeb(context, current)
                        },
                        ControlTile(NeedleIcon.LYRICS, "Genius search", "Lyrics and meaning") {
                            searchSongOnGenius(context, current)
                        },
                        ControlTile(NeedleIcon.SHARE, "Share", "Title and artist") {
                            showControls = false
                            shareSongText(context, current)
                        },
                        ControlTile(NeedleIcon.BACKUP, "Share file", "Send the audio") {
                            showControls = false
                            shareSong(context, current)
                        }
                    )
                    val danger = listOf(
                        ControlTile(NeedleIcon.TRASH, "Delete file", "Removes it from this phone", danger = true) {
                            showControls = false
                            if (android.os.Build.VERSION.SDK_INT >= 30) startDelete(current) else deleteAskId = current.id
                        },
                        ControlTile(NeedleIcon.GEAR, "Edit controls", onClick = soon)
                    )
                    val sections = listOf(
                        ControlSection("Playback", playback),
                        ControlSection("Song", song),
                        ControlSection("Go to", goTo),
                        ControlSection("Edit", edit),
                        ControlSection("Find and share", find),
                        ControlSection("More", danger)
                    )
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        PlayerControlsSheet(sections, Modifier.pointerInput(Unit) { detectTapGestures { } })
                    }
                }
            }
            if (genreChoices.isNotEmpty()) {
                GenreChoiceDialog(
                    genres = genreChoices,
                    onPick = { g -> genreChoices = emptyList(); openGenrePage(g) },
                    onDismiss = { genreChoices = emptyList() }
                )
            }
            deleteAskId?.let { id ->
                val askSong = songs?.firstOrNull { it.id == id }
                if (askSong != null) {
                    DeleteFileDialog(
                        title = askSong.title,
                        onDelete = { deleteAskId = null; startDelete(askSong) },
                        onDismiss = { deleteAskId = null }
                    )
                }
            }
            if (showSpeed) {
                SpeedPitchDialog(
                    speed = player.speed,
                    semitones = player.speedSemitones,
                    keepPitch = player.keepPitch,
                    remembered = player.speedRemembered,
                    onChange = { sp, st, keep, own -> player.setSpeedSettings(sp, st, keep, own) },
                    onDismiss = { showSpeed = false }
                )
            }
            AnimatedVisibility(
                visible = showMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val menuSong = songs?.firstOrNull { it.id == menuSongId }
                if (menuSong != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        SongMenuSheet(
                            song = menuSong,
                            canGoToAlbum = albums?.any { it.id == menuSong.albumId } == true,
                            onOpenSingle = {
                                showMenu = false
                                showSearch = false
                                showSingles = false
                                showMostPlayed = false; showStats = false; openMixId = null; showArtists = false
                                showFolders = false
                                openAlbumId = null
                                openSingleId = null
                                openSingleId = menuSong.id
                            },
                            canGoToArtist = isKnownArtist(menuSong.artist),
                            onGoToArtist = {
                                showMenu = false
                                showSearch = false
                                showSingles = false
                                showMostPlayed = false; showStats = false; openMixId = null; showArtists = false
                                showFolders = false
                                openAlbumId = null
                                openSingleId = null
                                openArtist = menuSong.artist
                            },
                            onPlayNext = {
                                showMenu = false
                                announceQueue(context, player, listOf(menuSong), true, "Playing next")
                            },
                            onAddToQueue = {
                                showMenu = false
                                announceQueue(context, player, listOf(menuSong), false, "Added to queue")
                            },
                            onAddToPlaylist = {
                                showMenu = false
                                addSongIds = listOf(menuSong.id)
                                showAddSheet = true
                            },
                            onRate = {
                                showMenu = false
                                ratingSongId = menuSong.id
                                showRatingSheet = true
                            },
                            onGoToAlbum = {
                                showMenu = false
                                showSearch = false
                                showSingles = false
                                showMostPlayed = false; showStats = false; openMixId = null; showArtists = false
                                showFolders = false
                                destination = Destination.ALBUMS
                                openAlbumId = menuSong.albumId
                            },
                            onEditTags = {
                                showMenu = false
                                openEditor(listOf(menuSong))
                            },
                            onEditLyrics = {
                                showMenu = false
                                lyricsEditSongId = menuSong.id
                                showLyricsEditor = true
                            },
                            onInfo = {
                                showMenu = false
                                infoSongId = menuSong.id
                                showInfo = true
                            },
                            onShare = {
                                showMenu = false
                                shareSong(context, menuSong)
                            },
                            onSetRingtone = {
                                showMenu = false
                                val msg = when (Ringtone.set(context, menuSong)) {
                                    Ringtone.Result.SET -> "\"${menuSong.title}\" is now your ringtone"
                                    Ringtone.Result.NEEDS_PERMISSION -> "Allow Needle to change settings, then try again"
                                    Ringtone.Result.FAILED -> "Could not set the ringtone"
                                }
                                Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                            },
                            onHide = {
                                showMenu = false
                                HiddenSongs.hide(listOf(menuSong.id))
                                Toast.makeText(context, "Hidden. Unhide it in Settings > Library > Hidden songs.", Toast.LENGTH_LONG).show()
                            },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
        }
    }
}

/**
 * The first scan, as the mockup's "Scanning your library": it stays while Needle lists the files and reads their
 * tags, and closes by itself when that is done, or at once with "Continue in background".
 */
@Composable
private fun ScanIntro(library: LibraryViewModel, homeVm: HomeViewModel, modifier: Modifier = Modifier) {
    val songs by library.songs.collectAsState()
    val albums by homeVm.albums.collectAsState()
    val groups by library.folderGroups.collectAsState()
    val excluded by ExcludedFolders.names.collectAsState()
    val artistCount = remember(songs) { songs.orEmpty().map { artistKey(it.artist) }.toSet().size }

    val working = library.isScanning || library.tagProgress != null
    var sawWork by remember { mutableStateOf(false) }
    LaunchedEffect(working) {
        if (working) {
            sawWork = true
        } else if (sawWork) {
            delay(900)   // the tag reading starts a moment after the listing ends; wait to be sure nothing follows
            Onboarding.finishScanIntro()
        }
    }
    // Nothing started at all (for example no music): do not leave the person looking at an empty ring.
    LaunchedEffect(Unit) {
        delay(5_000)
        if (!sawWork) Onboarding.finishScanIntro()
    }

    val progress = library.tagProgress
    ScanScreen(
        songs = songs.orEmpty().size,
        albums = albums?.size ?: 0,
        artists = artistCount,
        done = progress?.first,
        total = progress?.second,
        groups = groups,
        excluded = excluded,
        onToggleFolder = { ExcludedFolders.toggle(it) },
        onContinue = { Onboarding.finishScanIntro() },
        modifier = modifier
    )
}
