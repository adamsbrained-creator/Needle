# Build fix (Step 73, on Step 72)

The first real build (GitHub Actions log) compiled everything up to the Kotlin step and reported three errors, all mine:
- data/HomeViewModel.kt (2 places): `HomeViewModel(app: Application)` has a parameter called `app`, which hides the package name
  `app` inside the class, so `app.needle.music.widget.WidgetState` could not be found. Now imported and used by its short name.
- ui/Appearance.kt: `Skins` was used without its import (needed by the Navigation setting).
Also tidied data/Backup.kt to import SpeedPrefs instead of spelling out its package.

Good news in the same log: resources (all the new widget layouts and XML), the manifest and the annotation step (KSP) all passed, and no
other source file had an error. If the next build shows more errors, they are usually in a later compiler phase; send the new log.
