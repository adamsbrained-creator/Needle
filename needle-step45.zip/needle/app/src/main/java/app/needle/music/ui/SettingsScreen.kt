package app.needle.music.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import app.needle.music.data.GenrePrefs
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AccentChoices
import app.needle.music.data.AlbumPrefs
import app.needle.music.data.discLabel
import app.needle.music.data.CountAfter
import app.needle.music.data.NeedleSettings
import app.needle.music.data.RatingStyle
import app.needle.music.data.RatingScale
import app.needle.music.data.SettingsViewModel
import app.needle.music.playback.EqState
import app.needle.music.playback.SleepTimer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class SettingsPage { HOME, APPEARANCE, NOW_PLAYING, PLAYBACK, RATINGS, LIBRARY, TAGS, BACKUP, ABOUT }

private val Danger = Color(0xFFEB5757)

/**
 * Settings, opened from the avatar on Home. The list follows the mockup. Pages that exist open;
 * Equalizer is marked "Soon". Lyrics and Cast devices open the pages that were built for them.
 */
@Composable
fun SettingsScreen(
    page: SettingsPage,
    onPage: (SettingsPage) -> Unit,
    glowOn: Boolean,
    onGlowChange: (Boolean) -> Unit,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onOpenCast: () -> Unit,
    onOpenLyricsSettings: () -> Unit,
    onOpenEq: () -> Unit,
    onOpenSleep: () -> Unit,
    tagsRead: Int,
    songCount: Int,
    tagProgress: Pair<Int, Int>?,
    onRereadTags: () -> Unit,
    onChooseGenres: () -> Unit,
    writeToFiles: Boolean,
    onWriteToFilesChange: (Boolean) -> Unit,
    writeProgress: Pair<Int, Int>?,
    onWriteAll: () -> Unit,
    isScanning: Boolean,
    onRescan: () -> Unit,
    vm: SettingsViewModel,
    modifier: Modifier = Modifier
) {
    val back: () -> Unit = { if (page == SettingsPage.HOME) onBack() else onPage(SettingsPage.HOME) }
    when (page) {
        SettingsPage.HOME -> SettingsHome(
            songCount = songCount,
            bottomPadding = bottomPadding,
            onBack = back,
            onPage = onPage,
            onOpenCast = onOpenCast,
            onOpenLyricsSettings = onOpenLyricsSettings,
            onOpenEq = onOpenEq,
            onOpenSleep = onOpenSleep,
            modifier = modifier
        )
        SettingsPage.APPEARANCE -> PageFrame("Appearance", "Make Needle yours. Changes show up right away.", back, bottomPadding, modifier) {
            AppearanceContent(glowOn, onGlowChange)
        }
        SettingsPage.NOW_PLAYING -> PageFrame("Now playing", "The player page and the cards under it.", back, bottomPadding, modifier) {
            NowPlayingContent()
        }
        SettingsPage.PLAYBACK -> PageFrame("Playback", "How songs play and when they count.", back, bottomPadding, modifier) {
            PlaybackContent()
        }
        SettingsPage.RATINGS -> PageFrame("Ratings", "Rate songs your way. Needle sorts by it.", back, bottomPadding, modifier) {
            RatingsContent()
        }
        SettingsPage.LIBRARY -> PageFrame("Library", "Finding and reading your music.", back, bottomPadding, modifier) {
            LibraryContent(songCount, isScanning, onRescan, tagsRead, tagProgress, onRereadTags, onChooseGenres)
        }
        SettingsPage.TAGS -> PageFrame("Tags and covers", "Your edits, and writing them into files.", back, bottomPadding, modifier) {
            TagsContent(vm, writeToFiles, onWriteToFilesChange, writeProgress, onWriteAll)
        }
        SettingsPage.BACKUP -> PageFrame("Backup and restore", "Keep what Needle can't rebuild.", back, bottomPadding, modifier) {
            BackupContent(vm, glowOn, onGlowChange)
        }
        SettingsPage.ABOUT -> PageFrame("About Needle", "A music player that stays on your phone.", back, bottomPadding, modifier) {
            AboutContent(vm, songCount)
        }
    }
}

// ---- frame and shared pieces -------------------------------------------------------------

@Composable
private fun PageFrame(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    bottomPadding: Dp,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text(title, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
        Text(subtitle, color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        content()
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text, color = Palette.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun Note(text: String) {
    Text(text, color = Palette.Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
}

@Composable
private fun OptionPills(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Text(
                label,
                color = if (on) Color(0xFF111111) else Palette.Text,
                fontSize = 14.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (on) Color.White else Palette.Card2)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            )
        }
    }
}

@Composable
private fun CountTile(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.glass(RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(value, color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Palette.Muted, fontSize = 12.sp)
    }
}

// ---- home --------------------------------------------------------------------------------

private class Entry(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val icon: NeedleIcon,
    val onClick: (() -> Unit)?   // null = not built yet
)

@Composable
private fun appVersion(): String {
    val context = LocalContext.current
    return remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }
}

@Composable
private fun SettingsHome(
    songCount: Int,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPage: (SettingsPage) -> Unit,
    onOpenCast: () -> Unit,
    onOpenLyricsSettings: () -> Unit,
    onOpenEq: () -> Unit,
    onOpenSleep: () -> Unit,
    modifier: Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    val accentName = AccentChoices[NeedleSettings.accentIndex.intValue].name
    val version = appVersion()
    val entries = listOf(
        Entry("Appearance", "$accentName · ${if (NeedleSettings.amoled.value) "AMOLED" else "Dark"}",
            "theme accent color titles font serif sans glow moving background amoled black", NeedleIcon.PALETTE
        ) { onPage(SettingsPage.APPEARANCE) },
        Entry("Now playing", "Info cards color",
            "now playing cards color artist credits file details library info rgb", NeedleIcon.CONTROLS
        ) { onPage(SettingsPage.NOW_PLAYING) },
        Entry("Playback", "Gapless, skip silence, play counts",
            "skip silence headphones unplug play count history gapless popular", NeedleIcon.PLAY
        ) { onPage(SettingsPage.PLAYBACK) },
        Entry(
            "Ratings", "Rate songs · ${NeedleSettings.ratingStyle.value.label}",
            "rating rate stars score favourite best top 5 stars decimal 10", NeedleIcon.STAR
        ) { onPage(SettingsPage.RATINGS) },
        Entry("Equalizer and audio", "10 bands · ${EqState.summary}", "equalizer eq bass audio", NeedleIcon.EQUALIZER, onOpenEq),
        Entry(
            "Sleep timer", if (SleepTimer.mode.value == SleepTimer.Mode.OFF) "Stop the music after a while" else SleepTimer.summary,
            "sleep timer stop night bed fade end of song album minutes", NeedleIcon.TIMER, onOpenSleep
        ),
        Entry("Library", "$songCount songs · scanning, short songs, tags",
            "scan folders hidden songs rescan short length tags read", NeedleIcon.FOLDER
        ) { onPage(SettingsPage.LIBRARY) },
        Entry("Cast devices", "Xbox, Kodi · UPnP", "cast dlna upnp xbox tv play on", NeedleIcon.CAST, onOpenCast),
        Entry("Lyrics", "Sources, size, sync", "lyrics lrc online font size sync", NeedleIcon.LYRICS, onOpenLyricsSettings),
        Entry("Tags and covers", "Editing, artwork, writing to files",
            "tags covers artwork edit reset write files mp3tag", NeedleIcon.TAG
        ) { onPage(SettingsPage.TAGS) },
        Entry("Backup and restore", "Play history, tag edits, settings",
            "backup restore export import history stats notes", NeedleIcon.BACKUP
        ) { onPage(SettingsPage.BACKUP) },
        Entry("About Needle", "Version $version", "about version licenses", NeedleIcon.INFO) { onPage(SettingsPage.ABOUT) }
    )
    val q = query.trim()
    val shown = entries.filter {
        q.isEmpty() || it.title.contains(q, ignoreCase = true) ||
            it.subtitle.contains(q, ignoreCase = true) || it.keywords.contains(q, ignoreCase = true)
    }

    PageFrame("Settings", "Make Needle yours.", onBack, bottomPadding, modifier) {
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleIconView(NeedleIcon.SEARCH, Palette.Muted, size = 18.dp)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                    cursorBrush = SolidColor(Palette.Accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) Text("Search settings", color = Palette.Muted, fontSize = 15.sp)
                            inner()
                        }
                    }
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        if (q.isEmpty()) {
            val shape = RoundedCornerShape(22.dp)
            Row(
                Modifier.fillMaxWidth().glass(shape).border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape).padding(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.LOCK, Palette.Text, size = 20.dp) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Stays on this phone", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "No account, no uploads. Your library, stats and notes are local. The only thing that can leave " +
                            "the phone is a lyrics lookup (song title and artist, sent to LRCLIB), and you can turn that off under Lyrics.",
                        color = Palette.Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        if (shown.isEmpty()) Note("No setting matches \"$q\".")
        shown.forEach { NavRow(it) }
    }
}

@Composable
private fun NavRow(entry: Entry) {
    val active = entry.onClick != null
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .glass(RoundedCornerShape(20.dp))
            .then(if (entry.onClick != null) Modifier.clickable(onClick = entry.onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = if (active) 0.12f else 0.06f)),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(entry.icon, if (active) Palette.Text else Palette.Muted, size = 20.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.title, color = if (active) Palette.Text else Palette.Muted,
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold
            )
            Text(entry.subtitle, color = Palette.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        if (active) {
            NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
        } else {
            Text(
                "Soon", color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

// ---- appearance --------------------------------------------------------------------------

@Composable
private fun AppearanceContent(glowOn: Boolean, onGlowChange: (Boolean) -> Unit) {
    Label("Theme")
    OptionPills(listOf("Dark", "AMOLED"), if (NeedleSettings.amoled.value) 1 else 0) { NeedleSettings.setAmoled(it == 1) }
    Note("AMOLED makes the background pure black, which also saves battery on OLED screens.")

    Spacer(Modifier.height(10.dp))
    Label("Accent color")
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AccentChoices.forEachIndexed { i, choice ->
            val selected = i == NeedleSettings.accentIndex.intValue
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(choice.color)
                    .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                    .clickable { NeedleSettings.setAccent(i) },
                contentAlignment = Alignment.Center
            ) { if (selected) NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 22.dp) }
        }
    }
    Note(AccentChoices[NeedleSettings.accentIndex.intValue].name)

    Spacer(Modifier.height(10.dp))
    Label("Cards")
    OptionPills(listOf("Auto", "Custom"), if (NeedleSettings.cardCustom.value) 1 else 0) { NeedleSettings.setCardCustom(it == 1) }
    if (NeedleSettings.cardCustom.value) {
        Note("Pick any color for the cards on Home and the other pages. Light colors can make the white text hard to read.")
        CardColorPicker(NeedleSettings.cardArgb.intValue) { NeedleSettings.setCardArgb(it) }
    } else {
        Note("Auto keeps the dark gray cards on a plain background, and tints them to match the accent color when the moving background is on.")
    }

    Spacer(Modifier.height(10.dp))
    Label("Animated covers")
    SettingRow(
        "Animated covers",
        note = "Plays the looping Apple Music cover video on the Now playing page, when one exists for the album. Looked up online, so it needs internet. Many albums have none and keep the normal cover."
    ) { NeedleSwitch(NeedleSettings.animatedCovers.value) { NeedleSettings.setAnimatedCovers(it) } }
    if (NeedleSettings.animatedCovers.value) {
        SettingRow(
            "Full page",
            note = "Plays the animated cover behind the whole Now playing page, like Spotify's Canvas, instead of only on the cover. The cover shows until the video is ready."
        ) { NeedleSwitch(NeedleSettings.animatedFullPage.value) { NeedleSettings.setAnimatedFullPage(it) } }
        SettingRow(
            "Artists too",
            note = "Also plays the artist's looping video in the artist header, on the artist page and in About the artist, for artists Apple Music has one for."
        ) { NeedleSwitch(NeedleSettings.animatedArtistCovers.value) { NeedleSettings.setAnimatedArtistCovers(it) } }
        OptionPills(listOf("Wi-Fi only", "Wi-Fi and mobile data"), if (NeedleSettings.animatedCoversWifiOnly.value) 0 else 1) {
            NeedleSettings.setAnimatedCoversWifiOnly(it == 0)
        }
        Note("The videos are streamed each time, so on mobile data they can use a fair amount.")
    }

    Spacer(Modifier.height(10.dp))
    Label("Online artwork")
    SettingRow(
        "Find missing covers",
        note = "For songs that have no cover, looks one up on iTunes and Deezer and keeps it on the phone. Each album is looked up once."
    ) { NeedleSwitch(NeedleSettings.fetchMissingCovers.value) { NeedleSettings.setFetchMissingCovers(it) } }
    SettingRow(
        "Artist backgrounds",
        note = "Shows a wide picture of the artist from Fanart.tv at the top of the artist page and in About the artist. Needs your own free Fanart.tv API key."
    ) { NeedleSwitch(NeedleSettings.artistBackgrounds.value) { NeedleSettings.setArtistBackgrounds(it) } }
    if (NeedleSettings.artistBackgrounds.value) {
        FanartKeyField()
        Note("Get a free personal key: make an account on fanart.tv, then copy the API key from your profile. The key stays on this phone and is not saved in backups.")
    }

    Spacer(Modifier.height(10.dp))
    Label("Titles")
    OptionPills(listOf("Serif", "Sans"), if (NeedleSettings.serifTitles.value) 0 else 1) { NeedleSettings.setSerifTitles(it == 0) }
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
        Text("Albums", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 32.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Just added", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(CircleShape).background(Palette.Accent).padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }

    Spacer(Modifier.height(10.dp))
    Label("Background")
    SettingRow(
        "Moving background",
        note = "The slowly drifting glow behind every page. Off gives a plain dark background and saves a little battery."
    ) { NeedleSwitch(glowOn, onGlowChange) }
    Note("A light theme, corner shapes and cover shapes are not built yet.")
}

@Composable
private fun FanartKeyField() {
    var text by remember { mutableStateOf(NeedleSettings.fanartKey.value) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it.trim(); NeedleSettings.setFanartKey(text) },
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Palette.Accent),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (text.isEmpty()) Text("Fanart.tv API key", color = Palette.Muted, fontSize = 15.sp)
                    inner()
                }
            }
        )
    }
}

// ---- now playing ------------------------------------------------------------------------

@Composable
private fun NowPlayingContent() {
    Label("Background")
    SettingRow(
        "Glow follows the song",
        note = "The moving glow on Now playing takes its colors from the cover of the song that is playing. It needs Moving background to be on (Settings > Appearance). The cards under the player follow it too, unless you gave them a color."
    ) { NeedleSwitch(NeedleSettings.adaptiveNowPlayingGlow.value) { NeedleSettings.setAdaptiveNowPlayingGlow(it) } }

    Spacer(Modifier.height(10.dp))
    Label("Info cards")
    OptionPills(listOf("Same as cards", "Custom"), if (NeedleSettings.npCardCustom.value) 1 else 0) { NeedleSettings.setNpCardCustom(it == 1) }
    if (NeedleSettings.npCardCustom.value) {
        Note("Pick any color for About the artist, Credits, File details and From your library. Light colors can make the white text hard to read.")
        CardColorPicker(NeedleSettings.npCardArgb.intValue) { NeedleSettings.setNpCardArgb(it) }
    } else {
        Note("These cards follow the Cards setting in Appearance. Choose Custom to give them a color of their own.")
    }
}

/** RGB sliders plus opacity for the card color, with a live preview. */
@Composable
private fun CardColorPicker(argb: Int, onChange: (Int) -> Unit) {
    val a = (argb ushr 24) and 0xFF
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    fun set(na: Int, nr: Int, ng: Int, nb: Int) = onChange((na shl 24) or (nr shl 16) or (ng shl 8) or nb)
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(shape).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val swatch = RoundedCornerShape(16.dp)
            Box(
                Modifier.size(56.dp).clip(swatch).background(Palette.Bg).background(Color(argb))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), swatch)
            )
            Column(Modifier.padding(start = 14.dp)) {
                Text("#%02X%02X%02X".format(r, g, b), color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Opacity ${(a * 100f / 255f).roundToInt()}%", color = Palette.Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        ChannelSlider("Red", r, 0, Color(0xFFEB5757)) { set(a, it, g, b) }
        ChannelSlider("Green", g, 0, Color(0xFF6FCF97)) { set(a, r, it, b) }
        ChannelSlider("Blue", b, 0, Color(0xFF5B8DEF)) { set(a, r, g, it) }
        ChannelSlider("Opacity", a, 40, Color.White) { set(it, r, g, b) }
    }
}

@Composable
private fun ChannelSlider(label: String, value: Int, min: Int, color: Color, onValue: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Palette.Text, fontSize = 14.sp, modifier = Modifier.width(64.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onValue(it.roundToInt()) },
            valueRange = min.toFloat()..255f,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = color,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
        Text("$value", color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.width(36.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}

// ---- playback ----------------------------------------------------------------------------

@Composable
private fun PlaybackContent() {
    SettingRow("Gapless playback", note = "Songs follow each other with no gap. This is always on.") {
        Text("On", color = Palette.Muted, fontSize = 14.sp)
    }
    SettingRow("Skip silence", note = "Skips the silent stretches at the start and end of songs.") {
        NeedleSwitch(NeedleSettings.skipSilence.value) { NeedleSettings.setSkipSilence(it) }
    }
    SettingRow("Pause when headphones disconnect", note = "Stops the music when wired or Bluetooth headphones are unplugged or switch off.") {
        NeedleSwitch(NeedleSettings.pauseOnUnplug.value) { NeedleSettings.setPauseOnUnplug(it) }
    }

    Spacer(Modifier.height(10.dp))
    Label("A song counts as played after")
    OptionPills(CountAfter.entries.map { it.label }, NeedleSettings.countAfter.value.ordinal) {
        NeedleSettings.setCountAfter(CountAfter.entries[it])
    }
    Note("This feeds Popular, Most played and This week. Short songs always count at half their length. Skipping through a list counts nothing.")

    Spacer(Modifier.height(10.dp))
    Label("Coming later")
    SettingRow("Crossfade", note = "Fade one song into the next.") { Text("Soon", color = Palette.Muted, fontSize = 13.sp) }
    SettingRow("Volume levelling", note = "Make quiet and loud songs sound alike.") { Text("Soon", color = Palette.Muted, fontSize = 13.sp) }
}

// ---- ratings -----------------------------------------------------------------------------

@Composable
private fun RatingsContent() {
    val style = NeedleSettings.ratingStyle.value
    Label("How you rate")
    OptionPills(RatingStyle.entries.map { it.label }, style.ordinal) { NeedleSettings.setRatingStyle(RatingStyle.entries[it]) }
    Note(
        when (style) {
            RatingStyle.STARS -> "Tap one to five stars. Tap the same star again to take the rating back."
            RatingStyle.DECIMAL -> "Slide from 1.00 to 5.00 in steps of a quarter, like 3.75 or 4.25, for the fine differences."
            RatingStyle.TEN -> "Pick a number from 1 to 10."
        }
    )

    Spacer(Modifier.height(10.dp))
    Label("The same rating, three ways")
    listOf(RatingStyle.STARS, RatingStyle.DECIMAL, RatingStyle.TEN).forEach { s ->
        SettingRow(s.label, note = null) {
            Text(RatingScale.label(s, 80), color = if (s == style) Palette.Accent else Palette.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
    Note("Switching never loses a rating. A song rated 4.25 shows as 4 stars in 5 stars, and as 8.5 in 1 to 10.")

    Spacer(Modifier.height(10.dp))
    Label("Where ratings count")
    Note("Songs: sort by Rating, best first. Artist pages: Top songs start with your best rated. Playlists: the Top rated chip. Songs list: a star and the rating next to the album.")
    Note("To rate a song, press and hold the star on Now Playing, or use Rate song in Player controls or in a song's menu.")
}

// ---- library -----------------------------------------------------------------------------

@Composable
private fun LibraryContent(
    songCount: Int,
    isScanning: Boolean,
    onRescan: () -> Unit,
    tagsRead: Int,
    tagProgress: Pair<Int, Int>?,
    onRereadTags: () -> Unit,
    onChooseGenres: () -> Unit
) {
    val favorites by GenrePrefs.selected.collectAsState()
    SettingRow(
        "Favourite genres",
        note = if (favorites.isEmpty()) "None chosen. Chosen genres come first on Home."
        else favorites.sortedBy { it.lowercase() }.joinToString(", "),
        onClick = onChooseGenres
    ) { Text("Choose", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    Spacer(Modifier.height(10.dp))
    SettingRow(
        "Songs in your library",
        note = if (isScanning) "Looking for music..." else "$songCount songs. Tap to look for new music now.",
        onClick = if (isScanning) null else onRescan
    ) {
        Text(if (isScanning) "" else "Rescan", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    SettingRow(
        "Scan when Needle opens",
        note = "Looks for new music every time. Off starts faster; use Rescan when you add songs."
    ) { NeedleSwitch(NeedleSettings.scanOnLaunch.value) { NeedleSettings.setScanOnLaunch(it) } }

    Spacer(Modifier.height(10.dp))
    Label("Ignore songs shorter than")
    val lengths = listOf(0, 10, 30, 60)
    OptionPills(listOf("Off", "10 s", "30 s", "1 min"), lengths.indexOf(NeedleSettings.minSongSeconds.intValue).coerceAtLeast(0)) {
        NeedleSettings.setMinSongSeconds(lengths[it])
    }
    Note("Hides voice notes, ringtones and sound effects. It applies on the next scan: tap Rescan above.")

    Spacer(Modifier.height(10.dp))
    Label("What a disc is called")
    val discWord = AlbumPrefs.discWord.value
    val discLetters = AlbumPrefs.discLetters.value
    val presets = listOf("Disc", "Side", "Part", "Volume")
    OptionPills(presets, presets.indexOf(discWord)) { AlbumPrefs.setDiscWord(presets[it]) }
    Box(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        BasicTextField(
            value = discWord,
            onValueChange = { AlbumPrefs.setDiscWord(it.take(20)) },
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth()
        )
        if (discWord.isEmpty()) Text("Type your own name, for example Act", color = Palette.Muted, fontSize = 15.sp)
    }
    SettingRow(
        "Use letters",
        note = "A, B, C instead of 1, 2, 3. Good for records: Side A, Side B."
    ) { NeedleSwitch(discLetters) { AlbumPrefs.setDiscLetters(it) } }
    Note(
        "Album pages group the tracks by the Disc tag and show: " +
            "${discLabel(1, discWord, discLetters)}, ${discLabel(2, discWord, discLetters)}, ${discLabel(3, discWord, discLetters)}. " +
            "On an album page, the record button next to the tag button sets them."
    )

    Spacer(Modifier.height(10.dp))
    Label("Tags in your files")
    SettingRow(
        "Read tags from files",
        note = if (tagProgress != null) "Reading ${tagProgress.first} of ${tagProgress.second} songs..."
        else "Needle reads composer, comment, lyrics and the other tags inside each file once. " +
            "$tagsRead of $songCount songs read. Tap to read them all again, for example after changing files on a computer.",
        onClick = if (tagProgress == null) onRereadTags else null
    ) {
        Text(if (tagProgress == null) "Re-read" else "", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- tags and covers ---------------------------------------------------------------------

private enum class Reset { EDITS, COVERS }

@Composable
private fun TagsContent(
    vm: SettingsViewModel,
    writeToFiles: Boolean,
    onWriteToFilesChange: (Boolean) -> Unit,
    writeProgress: Pair<Int, Int>?,
    onWriteAll: () -> Unit
) {
    val edits by vm.editCount.collectAsState()
    val extras by vm.extraCount.collectAsState()
    var confirm by remember { mutableStateOf<Reset?>(null) }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$edits", "edited songs", Modifier.weight(1f))
        CountTile("$extras", "extra fields", Modifier.weight(1f))
        CountTile("${vm.coverCount}", "custom covers", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))

    SettingRow(
        "Write tags into the files",
        note = "When you save in the tag editor, Needle also writes the tags (and the cover) into the audio file, so " +
            "other players like Symfonium and programs like Mp3tag see them. MP3, FLAC and M4A. Every file is " +
            "checked before it is replaced and a backup is kept while it happens. Needs \"All files access\"."
    ) { NeedleSwitch(writeToFiles, onWriteToFilesChange) }
    SettingRow(
        "Write all edits to the files now",
        note = if (writeProgress != null) "Writing ${writeProgress.first} of ${writeProgress.second} files..."
        else "Writes every tag and cover you have edited in Needle into its file, for songs edited before this was turned on.",
        onClick = if (writeProgress == null) onWriteAll else null
    ) {
        Text(if (writeProgress == null) "Write" else "", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }

    Spacer(Modifier.height(10.dp))
    Label("Reset")
    SettingRow("Reset all tag edits", note = "Removes every tag and extra field you changed inside Needle.", onClick = { confirm = Reset.EDITS }) {
        Text("Reset", color = Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    SettingRow("Remove custom covers", note = "Songs go back to the cover inside their file.", onClick = { confirm = Reset.COVERS }) {
        Text("Remove", color = Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    Note("Resets only change what Needle shows. Files that tags were already written into keep them.")
    vm.message?.let { MessageCard(it) { vm.clearMessage() } }

    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == Reset.EDITS) "Reset all tag edits?" else "Remove custom covers?") },
            text = {
                Text(
                    if (kind == Reset.EDITS) "$edits edited songs and $extras extra fields will go back to what is in the files."
                    else "${vm.coverCount} custom covers will be removed."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == Reset.EDITS) vm.resetEdits() else vm.resetCovers()
                    confirm = null
                }) { Text(if (kind == Reset.EDITS) "Reset" else "Remove", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Palette.Text) } },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted
        )
    }
}

@Composable
private fun MessageCard(text: String, onDismiss: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).glass(RoundedCornerShape(18.dp)).clickable(onClick = onDismiss).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Palette.Text, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(10.dp))
        Text("OK", color = Palette.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- backup ------------------------------------------------------------------------------

@Composable
private fun BackupContent(vm: SettingsViewModel, glowOn: Boolean, onGlowChange: (Boolean) -> Unit) {
    val plays by vm.playCount.collectAsState()
    val edits by vm.editCount.collectAsState()
    val extras by vm.extraCount.collectAsState()
    val notes by vm.noteCount.collectAsState()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri, glowOn)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.restoreFrom(uri) { onGlowChange(it) }
    }

    Text(
        "One file with what Needle can't rebuild by scanning: your play history, the tags you edited, extra fields, " +
            "artist notes and these settings. Covers you picked are not included. Songs are matched by their id on this phone, " +
            "so a backup restores on this phone with the same music.",
        color = Palette.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(horizontal = 4.dp)
    )
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$plays", "plays", Modifier.weight(1f))
        CountTile("$edits", "edited songs", Modifier.weight(1f))
        CountTile("$extras", "extra fields", Modifier.weight(1f))
        CountTile("$notes", "notes", Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PillButton("Export backup", onClick = {
            exportLauncher.launch("needle-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json")
        }, filled = true)
        PillButton("Restore from file", onClick = { restoreLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) })
    }
    Note("Restoring adds to what is here: plays are never counted twice, and edits and notes in the file replace the ones on the phone.")
    vm.message?.let { MessageCard(it) { vm.clearMessage() } }
}

// ---- about -------------------------------------------------------------------------------

@Composable
private fun AboutContent(vm: SettingsViewModel, songCount: Int) {
    val plays by vm.playCount.collectAsState()
    val version = appVersion()
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(18.dp)) {
        Text("Needle", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp)
        Text("Version $version", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            "No account, no ads, no uploads. Your music, play history and edits live on this phone.",
            color = Palette.Text, fontSize = 14.sp, lineHeight = 20.sp
        )
    }
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$songCount", "songs", Modifier.weight(1f))
        CountTile("$plays", "plays recorded", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Label("Built with")
    Note("Media3 (the player), Room (the library database), Jetpack Compose (everything you see), and LRCLIB for optional lyrics lookups.")
}
