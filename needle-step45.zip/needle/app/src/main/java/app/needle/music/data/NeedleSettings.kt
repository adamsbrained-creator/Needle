package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import org.json.JSONObject

class AccentChoice(val name: String, val color: Color)

/** The accent colors on the Appearance page. The first one is the original violet. */
val AccentChoices = listOf(
    AccentChoice("Violet", Color(0xFFAF65F5)),
    AccentChoice("Pink", Color(0xFFEF42B8)),
    AccentChoice("Blue", Color(0xFF5B8DEF)),
    AccentChoice("Teal", Color(0xFF2DD4BF)),
    AccentChoice("Green", Color(0xFF6FCF97)),
    AccentChoice("Orange", Color(0xFFF2994A)),
    AccentChoice("Red", Color(0xFFEB5757))
)

/** When a song counts as "played" for Popular, Most played and This week. */
enum class CountAfter(val label: String, private val fixedMs: Long) {
    SEC10("10 s", 10_000L),
    SEC30("30 s", 30_000L),
    MIN1("1 min", 60_000L),
    HALF("Half the song", 0L);

    /** Short songs always count at half their length, so a 20 second song can still count. */
    fun thresholdMs(durationMs: Long): Long {
        val known = durationMs > 0L
        return when {
            this == HALF -> if (known) durationMs / 2 else 30_000L
            known -> minOf(fixedMs, durationMs / 2)
            else -> fixedMs
        }
    }
}

/**
 * Everything on the Settings pages, remembered between launches. Values are Compose state, so a page
 * that reads one redraws the moment it changes, and the playback service can watch them too.
 */
object NeedleSettings {
    private var prefs: SharedPreferences? = null

    // Appearance
    val accentIndex = mutableIntStateOf(0)
    val serifTitles = mutableStateOf(true)
    val amoled = mutableStateOf(false)
    /** Cards: false = Auto (classic gray on a plain background, tinted by the accent on the glow), true = the color below. */
    val cardCustom = mutableStateOf(false)
    /** Animated covers on Now playing (Apple Music looping cover videos). Off until the person turns it on. */
    val animatedCovers = mutableStateOf(false)
    /** true = only on Wi-Fi or Ethernet, false = also on mobile data. */
    val animatedCoversWifiOnly = mutableStateOf(true)
    /** Also play Apple Music's artist videos in the artist header (needs [animatedCovers] on). */
    val animatedArtistCovers = mutableStateOf(true)
    /** The moving glow on Now playing takes its colors from the playing song's cover. */
    val adaptiveNowPlayingGlow = mutableStateOf(false)
    /** The animated cover fills the whole Now playing page (like Spotify's Canvas) instead of only the cover. */
    val animatedFullPage = mutableStateOf(false)
    /** Look up covers online (iTunes, Deezer) for songs that have none. */
    val fetchMissingCovers = mutableStateOf(false)
    /** Artist background pictures from Fanart.tv, with the person's own API key (the key is not part of backups). */
    val artistBackgrounds = mutableStateOf(false)
    val fanartKey = mutableStateOf("")
    /** The custom card color as ARGB. The alpha part is the card opacity. */
    val cardArgb = mutableIntStateOf(0xB37B5A9A.toInt())
    /** The info cards on Now playing (About the artist, Credits, File details, From your library). false = same as the other cards. */
    val npCardCustom = mutableStateOf(false)
    val npCardArgb = mutableIntStateOf(0xB36B5A8AL.toInt())

    // Playback
    val skipSilence = mutableStateOf(false)
    val pauseOnUnplug = mutableStateOf(true)
    val countAfter = mutableStateOf(CountAfter.SEC30)

    // Ratings
    val ratingStyle = mutableStateOf(RatingStyle.STARS)

    // Library
    val scanOnLaunch = mutableStateOf(true)
    val minSongSeconds = mutableIntStateOf(0)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_settings", Context.MODE_PRIVATE)
        prefs = p
        accentIndex.intValue = p.getInt("accent", 0).coerceIn(0, AccentChoices.lastIndex)
        serifTitles.value = p.getBoolean("serifTitles", true)
        amoled.value = p.getBoolean("amoled", false)
        cardCustom.value = p.getBoolean("cardCustom", false)
        animatedCovers.value = p.getBoolean("animatedCovers", false)
        animatedCoversWifiOnly.value = p.getBoolean("animatedCoversWifiOnly", true)
        animatedArtistCovers.value = p.getBoolean("animatedArtistCovers", true)
        adaptiveNowPlayingGlow.value = p.getBoolean("adaptiveNowPlayingGlow", false)
        animatedFullPage.value = p.getBoolean("animatedFullPage", false)
        fetchMissingCovers.value = p.getBoolean("fetchMissingCovers", false)
        artistBackgrounds.value = p.getBoolean("artistBackgrounds", false)
        fanartKey.value = p.getString("fanartKey", "").orEmpty()
        cardArgb.intValue = p.getInt("cardArgb", 0xB37B5A9A.toInt())
        npCardCustom.value = p.getBoolean("npCardCustom", false)
        npCardArgb.intValue = p.getInt("npCardArgb", 0xB36B5A8AL.toInt())
        skipSilence.value = p.getBoolean("skipSilence", false)
        pauseOnUnplug.value = p.getBoolean("pauseOnUnplug", true)
        countAfter.value = runCatching { CountAfter.valueOf(p.getString("countAfter", "SEC30") ?: "SEC30") }
            .getOrDefault(CountAfter.SEC30)
        ratingStyle.value = runCatching { RatingStyle.valueOf(p.getString("ratingStyle", "STARS") ?: "STARS") }
            .getOrDefault(RatingStyle.STARS)
        scanOnLaunch.value = p.getBoolean("scanOnLaunch", true)
        minSongSeconds.intValue = p.getInt("minSongSeconds", 0)
    }

    fun setAccent(index: Int) { accentIndex.intValue = index; prefs?.edit()?.putInt("accent", index)?.apply() }
    fun setSerifTitles(on: Boolean) { serifTitles.value = on; prefs?.edit()?.putBoolean("serifTitles", on)?.apply() }
    fun setAmoled(on: Boolean) { amoled.value = on; prefs?.edit()?.putBoolean("amoled", on)?.apply() }
    fun setAnimatedCovers(on: Boolean) { animatedCovers.value = on; prefs?.edit()?.putBoolean("animatedCovers", on)?.apply() }
    fun setFetchMissingCovers(on: Boolean) { fetchMissingCovers.value = on; prefs?.edit()?.putBoolean("fetchMissingCovers", on)?.apply() }
    fun setArtistBackgrounds(on: Boolean) { artistBackgrounds.value = on; prefs?.edit()?.putBoolean("artistBackgrounds", on)?.apply() }
    fun setFanartKey(key: String) { fanartKey.value = key; prefs?.edit()?.putString("fanartKey", key)?.apply() }
    fun setAnimatedFullPage(on: Boolean) { animatedFullPage.value = on; prefs?.edit()?.putBoolean("animatedFullPage", on)?.apply() }
    fun setAdaptiveNowPlayingGlow(on: Boolean) { adaptiveNowPlayingGlow.value = on; prefs?.edit()?.putBoolean("adaptiveNowPlayingGlow", on)?.apply() }
    fun setAnimatedArtistCovers(on: Boolean) { animatedArtistCovers.value = on; prefs?.edit()?.putBoolean("animatedArtistCovers", on)?.apply() }
    fun setAnimatedCoversWifiOnly(on: Boolean) { animatedCoversWifiOnly.value = on; prefs?.edit()?.putBoolean("animatedCoversWifiOnly", on)?.apply() }
    fun setNpCardCustom(on: Boolean) { npCardCustom.value = on; prefs?.edit()?.putBoolean("npCardCustom", on)?.apply() }
    fun setNpCardArgb(argb: Int) { npCardArgb.intValue = argb; prefs?.edit()?.putInt("npCardArgb", argb)?.apply() }
    fun setCardCustom(on: Boolean) { cardCustom.value = on; prefs?.edit()?.putBoolean("cardCustom", on)?.apply() }
    fun setCardArgb(argb: Int) { cardArgb.intValue = argb; prefs?.edit()?.putInt("cardArgb", argb)?.apply() }
    fun setSkipSilence(on: Boolean) { skipSilence.value = on; prefs?.edit()?.putBoolean("skipSilence", on)?.apply() }
    fun setPauseOnUnplug(on: Boolean) { pauseOnUnplug.value = on; prefs?.edit()?.putBoolean("pauseOnUnplug", on)?.apply() }
    fun setCountAfter(v: CountAfter) { countAfter.value = v; prefs?.edit()?.putString("countAfter", v.name)?.apply() }
    fun setRatingStyle(v: RatingStyle) { ratingStyle.value = v; prefs?.edit()?.putString("ratingStyle", v.name)?.apply() }
    fun setScanOnLaunch(on: Boolean) { scanOnLaunch.value = on; prefs?.edit()?.putBoolean("scanOnLaunch", on)?.apply() }
    fun setMinSongSeconds(s: Int) { minSongSeconds.intValue = s; prefs?.edit()?.putInt("minSongSeconds", s)?.apply() }

    fun toJson(): JSONObject = JSONObject()
        .put("accent", accentIndex.intValue)
        .put("serifTitles", serifTitles.value)
        .put("amoled", amoled.value)
        .put("cardCustom", cardCustom.value)
        .put("npCardCustom", npCardCustom.value)
        .put("npCardArgb", npCardArgb.intValue)
        .put("animatedCovers", animatedCovers.value)
        .put("animatedCoversWifiOnly", animatedCoversWifiOnly.value)
        .put("animatedArtistCovers", animatedArtistCovers.value)
        .put("adaptiveNowPlayingGlow", adaptiveNowPlayingGlow.value)
        .put("animatedFullPage", animatedFullPage.value)
        .put("fetchMissingCovers", fetchMissingCovers.value)
        .put("artistBackgrounds", artistBackgrounds.value)
        .put("cardArgb", cardArgb.intValue)
        .put("skipSilence", skipSilence.value)
        .put("pauseOnUnplug", pauseOnUnplug.value)
        .put("countAfter", countAfter.value.name)
        .put("ratingStyle", ratingStyle.value.name)
        .put("scanOnLaunch", scanOnLaunch.value)
        .put("minSongSeconds", minSongSeconds.intValue)

    /** Anything missing from the file keeps its current value. */
    fun fromJson(o: JSONObject) {
        if (o.has("accent")) setAccent(o.optInt("accent", 0).coerceIn(0, AccentChoices.lastIndex))
        if (o.has("serifTitles")) setSerifTitles(o.optBoolean("serifTitles", true))
        if (o.has("amoled")) setAmoled(o.optBoolean("amoled", false))
        if (o.has("animatedCovers")) setAnimatedCovers(o.optBoolean("animatedCovers", false))
        if (o.has("fetchMissingCovers")) setFetchMissingCovers(o.optBoolean("fetchMissingCovers", false))
        if (o.has("artistBackgrounds")) setArtistBackgrounds(o.optBoolean("artistBackgrounds", false))
        if (o.has("animatedFullPage")) setAnimatedFullPage(o.optBoolean("animatedFullPage", false))
        if (o.has("adaptiveNowPlayingGlow")) setAdaptiveNowPlayingGlow(o.optBoolean("adaptiveNowPlayingGlow", false))
        if (o.has("animatedArtistCovers")) setAnimatedArtistCovers(o.optBoolean("animatedArtistCovers", true))
        if (o.has("animatedCoversWifiOnly")) setAnimatedCoversWifiOnly(o.optBoolean("animatedCoversWifiOnly", true))
        if (o.has("npCardCustom")) setNpCardCustom(o.optBoolean("npCardCustom", false))
        if (o.has("npCardArgb")) setNpCardArgb(o.optInt("npCardArgb", 0xB36B5A8AL.toInt()))
        if (o.has("cardCustom")) setCardCustom(o.optBoolean("cardCustom", false))
        if (o.has("cardArgb")) setCardArgb(o.optInt("cardArgb", 0xB37B5A9A.toInt()))
        if (o.has("skipSilence")) setSkipSilence(o.optBoolean("skipSilence", false))
        if (o.has("pauseOnUnplug")) setPauseOnUnplug(o.optBoolean("pauseOnUnplug", true))
        if (o.has("countAfter")) {
            runCatching { CountAfter.valueOf(o.getString("countAfter")) }.getOrNull()?.let { setCountAfter(it) }
        }
        if (o.has("ratingStyle")) {
            runCatching { RatingStyle.valueOf(o.getString("ratingStyle")) }.getOrNull()?.let { setRatingStyle(it) }
        }
        if (o.has("scanOnLaunch")) setScanOnLaunch(o.optBoolean("scanOnLaunch", true))
        if (o.has("minSongSeconds")) setMinSongSeconds(o.optInt("minSongSeconds", 0))
    }
}
