Test tools for FileTagReader.kt (not part of the app build).
ref.py is the reference version the Kotlin reader was ported from. gen.sh and build_tests.py make
test files (ID3v2.3/2.4, FLAC, OGG, Opus, M4A, unsynchronised tags, huge comments) with ffmpeg and
by hand. Run: bash gen.sh && python3 build_tests.py && python3 ref.py yourfile.mp3
