package app.needle.music.data

import android.content.Context
import android.os.ParcelFileDescriptor
import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import androidx.room.withTransaction
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/** A tag Needle found inside the audio file itself. Needle's own edits ([ExtraTag]) are laid on top of these. */
@Entity(tableName = "file_tags", primaryKeys = ["songId", "field"])
data class FileTag(
    val songId: Long,
    val field: String,
    val value: String
)

/** Songs whose file has been read, so each file is read only once. */
@Entity(tableName = "tag_scans")
data class TagScan(
    @PrimaryKey val songId: Long,
    val scannedAt: Long
)

@Dao
interface FileTagDao {
    @Query("SELECT * FROM file_tags")
    fun observeAll(): Flow<List<FileTag>>

    @Query("SELECT value FROM file_tags WHERE songId = :id AND field = :field")
    suspend fun valueOf(id: Long, field: String): String?

    @Query("SELECT songId FROM tag_scans")
    suspend fun scannedIds(): List<Long>

    @Query("SELECT COUNT(*) FROM tag_scans")
    fun observeScannedCount(): Flow<Int>

    @Upsert
    suspend fun upsertTags(tags: List<FileTag>)

    @Upsert
    suspend fun upsertScans(scans: List<TagScan>)

    @Query("DELETE FROM file_tags WHERE songId IN (:ids)")
    suspend fun deleteTags(ids: List<Long>)

    @Query("DELETE FROM file_tags")
    suspend fun deleteAllTags()

    @Query("DELETE FROM tag_scans")
    suspend fun deleteAllScans()
}

/** Reads the tags inside every song's file once, in the background, and keeps them in the database. */
object TagScanner {
    private const val CHUNK = 200
    private const val PARALLEL = 4

    /**
     * Reads every song that has not been read yet (or all of them when [all] is true).
     * [onProgress] gets (done, total) after each batch. Safe to cancel: finished batches are kept.
     */
    suspend fun run(context: Context, db: NeedleDatabase, all: Boolean, onProgress: (Int, Int) -> Unit) {
        val dao = db.fileTagDao()
        if (all) db.withTransaction {
            dao.deleteAllTags()
            dao.deleteAllScans()
        }
        val done = dao.scannedIds().toHashSet()
        val todo = db.songDao().getAllOnce().filter { it.id !in done }
        if (todo.isEmpty()) return
        val gate = Semaphore(PARALLEL)
        var finished = 0
        onProgress(0, todo.size)

        for (chunk in todo.chunked(CHUNK)) {
            val results: List<Pair<Song, Map<String, String>>> = withContext(Dispatchers.IO) {
                coroutineScope {
                    chunk.map { song ->
                        async { gate.withPermit { song to readOne(context, song) } }
                    }.awaitAll()
                }
            }
            val now = System.currentTimeMillis()
            db.withTransaction {
                dao.deleteTags(results.map { it.first.id })
                dao.upsertTags(results.flatMap { (song, tags) -> tags.map { (f, v) -> FileTag(song.id, f, v) } })
                dao.upsertScans(results.map { TagScan(it.first.id, now) })
            }
            finished += chunk.size
            onProgress(finished, todo.size)
        }
    }

    private fun readOne(context: Context, song: Song): Map<String, String> = try {
        val pfd = context.contentResolver.openFileDescriptor(song.uri, "r")
        if (pfd == null) emptyMap()
        else ParcelFileDescriptor.AutoCloseInputStream(pfd).use { FileTagReader.read(it.channel) }
    } catch (e: Exception) {
        emptyMap()
    }
}
