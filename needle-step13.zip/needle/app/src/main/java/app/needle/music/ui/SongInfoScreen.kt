package app.needle.music.ui

import android.content.Context
import android.content.Intent
import android.provider.DocumentsContract
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song
import app.needle.music.data.SongInfoData
import app.needle.music.data.SongInfoLoader
import app.needle.music.data.TagFields
import app.needle.music.data.dayLabel

/** Share the audio file through the usual share sheet. */
internal fun shareSong(context: Context, song: Song) {
    try {
        val send = Intent(Intent.ACTION_SEND).apply {
            type = context.contentResolver.getType(song.uri) ?: "audio/*"
            putExtra(Intent.EXTRA_STREAM, song.uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not share this file", Toast.LENGTH_SHORT).show()
    }
}

/** Open the folder of the song in the phone's file manager. */
internal fun openSongFolder(context: Context, song: Song) {
    val path = song.folder.trim('/')
    if (path.isEmpty()) {
        Toast.makeText(context, "The folder of this file is not known", Toast.LENGTH_SHORT).show()
        return
    }
    try {
        val uri = DocumentsContract.buildDocumentUri("com.android.externalstorage.documents", "primary:$path")
        val view = Intent(Intent.ACTION_VIEW).setDataAndType(uri, DocumentsContract.Document.MIME_TYPE_DIR)
        context.startActivity(view)
    } catch (e: Exception) {
        Toast.makeText(context, "No file manager could open this folder", Toast.LENGTH_SHORT).show()
    }
}

private fun sizeText(bytes: Long): String =
    if (bytes >= 1024L * 1024) "%.1f MB".format(bytes / 1048576.0) else "${bytes / 1024} KB"

/**
 * Song info page from the mockup: cover, title, the core tags, then what is known about the file.
 * Under that, every other tag the song has, with a small note on the ones edited in Needle.
 */
@Composable
fun SongInfoScreen(
    song: Song,
    albumTrackCount: Int,
    extras: Map<String, String>,
    onBack: () -> Unit,
    onEditTags: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val info by produceState<SongInfoData?>(null, song.id) { value = SongInfoLoader.load(context, song) }
    val now = System.currentTimeMillis()

    val rows = ArrayList<Pair<String, String>>()
    if (song.album != "Unknown album") rows += "Album" to song.album
    if (song.genre.isNotBlank()) rows += "Genre" to song.genre
    if (song.year > 0) rows += "Year" to song.year.toString()
    if (song.trackNumber > 0) {
        rows += "Track" to if (albumTrackCount > 1) "${song.trackNumber} of $albumTrackCount" else "${song.trackNumber}"
    }
    info?.let { i ->
        i.format?.let { rows += "Format" to it }
        i.quality?.let { rows += "Quality" to it }
        i.bitrateKbps?.let { rows += "Bitrate" to "%,d kbps".format(it) }
        i.sizeBytes?.let { rows += "Size" to sizeText(it) }
        rows += "Plays" to i.plays.toString()
        i.lastPlayedAt?.let { rows += "Last played" to dayLabel(it / 1000, now) }
    }
    rows += "Added" to dayLabel(song.dateAdded, now)
    val where = listOfNotNull(song.folder.takeIf { it.isNotBlank() }, info?.fileName).joinToString("")
    if (where.isNotBlank()) rows += "File" to where

    val otherTags = TagFields.sortKeys(extras.filterValues { it.isNotBlank() }.keys)

    Column(
        modifier.safeDrawingPadding().verticalScroll(rememberScrollState()).padding(horizontal = 16.dp)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundButton(NeedleIcon.BACK, onBack)
            Spacer(Modifier.weight(1f))
            RoundButton(NeedleIcon.PENCIL, onEditTags)
        }

        val coverShape = RoundedCornerShape(26.dp)
        val glow = Palette.Pink.copy(alpha = 0.45f)
        Box(
            Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 6.dp)
                .size(150.dp)
                .shadow(30.dp, coverShape, ambientColor = glow, spotColor = glow)
                .clip(coverShape)
                .background(Palette.Card)
        ) { Cover(song, Modifier.fillMaxSize()) }

        Text(
            song.title, color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 30.sp, lineHeight = 33.sp,
            textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(top = 16.dp)
        )
        Text(
            song.artist, color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
            maxLines = 2, overflow = TextOverflow.Ellipsis,
            modifier = Modifier.fillMaxWidth().padding(top = 4.dp, bottom = 16.dp)
        )

        GlassCard {
            rows.forEachIndexed { i, (label, value) ->
                InfoRow(label, value, divider = i < rows.lastIndex)
            }
        }

        if (otherTags.isNotEmpty()) {
            Text(
                "OTHER TAGS", color = Palette.Muted, fontSize = 11.sp,
                modifier = Modifier.padding(start = 6.dp, top = 18.dp, bottom = 8.dp)
            )
            GlassCard {
                otherTags.forEachIndexed { i, key ->
                    val edited = info?.editedFields?.contains(key) == true
                    InfoRow(
                        label = TagFields.find(key)?.label ?: key,
                        value = extras.getValue(key),
                        divider = i < otherTags.lastIndex,
                        note = if (edited) "edited in Needle" else null,
                        maxLines = 6
                    )
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 24.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            ActionButton("Edit tags", NeedleIcon.PENCIL, filled = true, modifier = Modifier.weight(1f), onClick = onEditTags)
            ActionButton("Folder", NeedleIcon.FOLDER, filled = false, modifier = Modifier.weight(1f)) { openSongFolder(context, song) }
            ActionButton("Share", NeedleIcon.SHARE, filled = false, modifier = Modifier.weight(1f)) { shareSong(context, song) }
        }
    }
}

@Composable
private fun RoundButton(icon: NeedleIcon, onClick: () -> Unit) {
    Box(
        Modifier.size(38.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { NeedleIconView(icon, Palette.Text, size = 20.dp) }
}

@Composable
private fun GlassCard(content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.03f))))
            .border(1.dp, Color.White.copy(alpha = 0.1f), shape)
            .padding(horizontal = 18.dp, vertical = 4.dp)
    ) { content() }
}

@Composable
private fun InfoRow(label: String, value: String, divider: Boolean, note: String? = null, maxLines: Int = 3) {
    Column {
        Row(Modifier.fillMaxWidth().padding(vertical = 13.dp), verticalAlignment = Alignment.Top) {
            Column(Modifier.width(112.dp)) {
                Text(label, color = Palette.Muted, fontSize = 13.5.sp)
                if (note != null) Text(note, color = Palette.Accent, fontSize = 10.5.sp)
            }
            Text(
                value, color = Palette.Text, fontSize = 13.5.sp, fontWeight = FontWeight.Medium,
                textAlign = TextAlign.End, maxLines = maxLines, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f)
            )
        }
        if (divider) Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
    }
}

@Composable
private fun ActionButton(text: String, icon: NeedleIcon, filled: Boolean, modifier: Modifier, onClick: () -> Unit) {
    val ink = if (filled) Color(0xFF111111) else Color.White
    Row(
        modifier
            .height(46.dp)
            .clip(CircleShape)
            .then(
                if (filled) Modifier.background(Color.White)
                else Modifier.border(1.dp, Color.White.copy(alpha = 0.25f), CircleShape)
            )
            .clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center
    ) {
        NeedleIconView(icon, ink, size = 16.dp)
        Spacer(Modifier.width(6.dp))
        Text(text, color = ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
    }
}
