package app.needle.music.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SongDao {
    @Query("SELECT * FROM songs")
    abstract fun observeAll(): Flow<List<Song>>

    @Query("SELECT * FROM songs")
    abstract suspend fun getAllOnce(): List<Song>

    @Query("DELETE FROM songs")
    abstract suspend fun clear()

    @Insert
    abstract suspend fun insertAll(songs: List<Song>)

    /** Swap the whole library in one transaction, so the UI updates once. */
    @Transaction
    open suspend fun replaceAll(songs: List<Song>) {
        clear()
        insertAll(songs)
    }
}

@Database(entities = [Song::class, PlayEvent::class, TagEdit::class, ExtraTag::class, FileTag::class, TagScan::class, LyricsCache::class], version = 6, exportSchema = false)
abstract class NeedleDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun playDao(): PlayDao
    abstract fun tagDao(): TagDao
    abstract fun extraTagDao(): ExtraTagDao
    abstract fun fileTagDao(): FileTagDao
    abstract fun lyricsDao(): LyricsDao

    companion object {
        /** v1 -> v2: adds play history, keeps the songs table as it is. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `play_events` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`songId` INTEGER NOT NULL, " +
                        "`playedAt` INTEGER NOT NULL, " +
                        "`listenedMs` INTEGER NOT NULL)"
                )
            }
        }

        /**
         * v2 -> v3: songs get a genre column, and tag edits get their table.
         * The songs table is rebuilt (the copy-and-rename way Room recommends); every song keeps its data.
         */
        private val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `songs_new` (" +
                        "`id` INTEGER NOT NULL, `title` TEXT NOT NULL, `artist` TEXT NOT NULL, " +
                        "`album` TEXT NOT NULL, `albumId` INTEGER NOT NULL, `durationMs` INTEGER NOT NULL, " +
                        "`trackNumber` INTEGER NOT NULL, `year` INTEGER NOT NULL, `dateAdded` INTEGER NOT NULL, " +
                        "`folder` TEXT NOT NULL, `genre` TEXT NOT NULL, PRIMARY KEY(`id`))"
                )
                db.execSQL(
                    "INSERT INTO `songs_new` (id, title, artist, album, albumId, durationMs, trackNumber, year, dateAdded, folder, genre) " +
                        "SELECT id, title, artist, album, albumId, durationMs, trackNumber, year, dateAdded, folder, '' FROM `songs`"
                )
                db.execSQL("DROP TABLE `songs`")
                db.execSQL("ALTER TABLE `songs_new` RENAME TO `songs`")
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tag_edits` (" +
                        "`songId` INTEGER NOT NULL, `title` TEXT, `artist` TEXT, `album` TEXT, `genre` TEXT, " +
                        "`year` INTEGER, `trackNumber` INTEGER, PRIMARY KEY(`songId`))"
                )
            }
        }

        /** v3 -> v4: the table for all the other tags. */
        private val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `extra_tags` (" +
                        "`songId` INTEGER NOT NULL, `field` TEXT NOT NULL, `value` TEXT NOT NULL, " +
                        "PRIMARY KEY(`songId`, `field`))"
                )
            }
        }

        /** v4 -> v5: tags read from the audio files, and the list of files already read. */
        private val MIGRATION_4_5 = object : Migration(4, 5) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `file_tags` (" +
                        "`songId` INTEGER NOT NULL, `field` TEXT NOT NULL, `value` TEXT NOT NULL, " +
                        "PRIMARY KEY(`songId`, `field`))"
                )
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `tag_scans` (" +
                        "`songId` INTEGER NOT NULL, `scannedAt` INTEGER NOT NULL, PRIMARY KEY(`songId`))"
                )
            }
        }

        /** v5 -> v6: the table for lyrics found online. */
        private val MIGRATION_5_6 = object : Migration(5, 6) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `lyrics_cache` (" +
                        "`songId` INTEGER NOT NULL, `text` TEXT NOT NULL, `synced` INTEGER NOT NULL, " +
                        "`source` TEXT NOT NULL, `fetchedAt` INTEGER NOT NULL, PRIMARY KEY(`songId`))"
                )
            }
        }

        @Volatile
        private var instance: NeedleDatabase? = null

        fun get(context: Context): NeedleDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    NeedleDatabase::class.java,
                    "needle.db"
                )
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4, MIGRATION_4_5, MIGRATION_5_6)
                    // Play history now exists, so from here on every change needs a real migration.
                    .build()
                    .also { instance = it }
            }
    }
}
