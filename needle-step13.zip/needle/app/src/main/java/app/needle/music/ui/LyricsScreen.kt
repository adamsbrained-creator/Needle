package app.needle.music.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.FileAccess
import app.needle.music.data.LrcParser
import app.needle.music.data.LyricsQuery
import app.needle.music.data.LyricsSource
import app.needle.music.data.LyricsViewModel
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

private val Dim = Color.White.copy(alpha = 0.35f)

/**
 * The lyrics page from the mockup: the current line big and serif, the others dimmed, tap a line to jump there,
 * a text-size slider on the right edge, keep-screen-on, share. Timed lyrics follow the song; plain lyrics scroll.
 */
@Composable
fun LyricsScreen(
    player: PlayerViewModel,
    lyricsVm: LyricsViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val view = LocalView.current
    val state = lyricsVm.state
    val lyrics = state.lyrics
    val fileAccess by FileAccess.granted

    // The song that is playing right now decides which lyrics to show.
    val songId = player.currentMediaId?.toLongOrNull()
    LaunchedEffect(songId, player.title) {
        if (songId != null) {
            lyricsVm.load(LyricsQuery(songId, player.title.orEmpty(), player.artist.orEmpty(), player.album.orEmpty(), player.durationMs))
        }
    }
    // Coming back from the "all files access" settings page: look for .lrc files again.
    LaunchedEffect(fileAccess) { lyricsVm.reload() }
    // Keep the position fresh while the song plays.
    LaunchedEffect(player.isPlaying) {
        while (player.isPlaying) {
            player.refreshPosition()
            delay(200)
        }
    }

    var locked by rememberSaveable { mutableStateOf(false) }
    DisposableEffect(locked) {
        view.keepScreenOn = locked
        onDispose { view.keepScreenOn = false }
    }

    val prefs = remember { context.getSharedPreferences("needle_ui", Context.MODE_PRIVATE) }
    var scale by remember { mutableFloatStateOf(prefs.getFloat("lyrics_scale", 1f).coerceIn(0.8f, 1.5f)) }
    var showInfo by remember { mutableStateOf(false) }

    Box(modifier.fillMaxSize().safeDrawingPadding()) {
        // ---- lyrics (or the empty state) ----
        Box(Modifier.fillMaxSize().padding(top = 72.dp, bottom = 84.dp)) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
                lyrics != null -> LyricsList(
                    lines = lyrics.lines,
                    synced = lyrics.synced,
                    positionMs = { player.positionMs },
                    scale = scale,
                    onSeek = { player.seekTo(it) }
                )
                else -> EmptyState(
                    searching = state.searching,
                    message = state.message,
                    fileAccess = fileAccess,
                    onSearch = { lyricsVm.searchOnline() },
                    onAllowFiles = { FileAccess.openSettings(context) }
                )
            }
        }

        // ---- header ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RoundIconButton(NeedleIcon.CHEVRON_DOWN, onClose, size = 42.dp, iconSize = 22.dp, background = Color.White.copy(alpha = 0.12f))
            Column(Modifier.weight(1f)) {
                Text(player.title.orEmpty(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text(player.artist.orEmpty(), color = Color(0xFFB9BDD0), fontSize = 11.5.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            RoundIconButton(
                if (locked) NeedleIcon.LOCK else NeedleIcon.UNLOCK, { locked = !locked },
                size = 42.dp, iconSize = 21.dp,
                background = if (locked) Palette.Accent.copy(alpha = 0.55f) else Color.White.copy(alpha = 0.12f)
            )
            RoundIconButton(NeedleIcon.INFO, { showInfo = true }, size = 42.dp, iconSize = 21.dp, background = Color.White.copy(alpha = 0.12f))
        }

        // ---- text size slider ----
        if (lyrics != null) {
            val fraction = ((1.5f - scale) / 0.7f).coerceIn(0f, 1f)
            TextSizeSlider(
                fraction = fraction,
                onFraction = { scale = 1.5f - 0.7f * it },
                onDone = { prefs.edit().putFloat("lyrics_scale", scale).apply() },
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)
            )
        }

        // ---- bottom bar ----
        if (lyrics != null) {
            Row(Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp), horizontalArrangement = Arrangement.End) {
                RoundIconButton(
                    NeedleIcon.SHARE,
                    {
                        val text = "${player.title.orEmpty()} - ${player.artist.orEmpty()}\n\n${lyrics.plainText()}"
                        val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                        context.startActivity(Intent.createChooser(send, "Share lyrics"))
                    },
                    size = 42.dp, iconSize = 21.dp, background = Color.White.copy(alpha = 0.16f)
                )
            }
        }
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted,
            title = { Text("Lyrics") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (lyrics == null) "No lyrics found for this song yet."
                        else "From ${lyrics.source.label}. ${if (lyrics.synced) "Timed lyrics: they follow the song." else "Plain text: no timing, so no highlight."}"
                    )
                    Text(
                        if (fileAccess) "Needle can read .lrc files next to your songs."
                        else "Needle can't read .lrc files next to your songs yet. Allow access to all files to use them."
                    )
                    if (!fileAccess) {
                        TextButton(onClick = { FileAccess.openSettings(context) }) { Text("Allow access to files", color = Palette.Accent) }
                    }
                    TextButton(onClick = { lyricsVm.searchOnline(); showInfo = false }) { Text("Search online again", color = Palette.Accent) }
                    if (lyrics?.source == LyricsSource.SAVED) {
                        TextButton(onClick = { lyricsVm.forgetSaved(); showInfo = false }) { Text("Forget the saved lyrics", color = Palette.Accent) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close", color = Palette.Accent) } }
        )
    }
}

@Composable
private fun LyricsList(
    lines: List<app.needle.music.data.LyricLine>,
    synced: Boolean,
    positionMs: () -> Long,
    scale: Float,
    onSeek: (Long) -> Unit
) {
    val listState = rememberLazyListState()
    val active by remember(lines, synced) {
        derivedStateOf { if (synced) LrcParser.activeIndex(lines, positionMs()) else -1 }
    }
    // Keep the line being sung a little above the middle, unless the person is scrolling by hand.
    LaunchedEffect(active, lines) {
        if (synced && active >= 0 && !listState.isScrollInProgress) {
            listState.animateScrollToItem(active, -(listState.layoutInfo.viewportSize.height * 0.22f).toInt())
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(start = 22.dp, end = 52.dp, top = 40.dp, bottom = 220.dp),
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 0.06f to Color.Black, 0.88f to Color.Black, 1f to Color.Transparent),
                    blendMode = BlendMode.DstIn
                )
            }
    ) {
        itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
            if (line.text.isEmpty()) {
                Spacer(Modifier.height(if (synced) 14.dp else 18.dp))
            } else if (synced) {
                val on = i == active
                val color by animateColorAsState(if (on) Color.White else Dim, label = "lineColor")
                val size by animateFloatAsState(if (on) 30f * scale else 21f * scale, label = "lineSize")
                Text(
                    line.text,
                    color = color,
                    fontSize = size.sp,
                    lineHeight = (size * (if (on) 1.15f else 1.25f)).sp,
                    fontFamily = if (on) FontFamily.Serif else FontFamily.Default,
                    fontWeight = if (on) FontWeight.Medium else FontWeight.SemiBold,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSeek(line.timeMs) }
                        .padding(bottom = 18.dp)
                )
            } else {
                Text(
                    line.text,
                    color = Color(0xFFF2F3F8),
                    fontSize = (19f * scale).sp,
                    lineHeight = (19f * scale * 1.5f).sp,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyState(
    searching: Boolean,
    message: String?,
    fileAccess: Boolean,
    onSearch: () -> Unit,
    onAllowFiles: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("No lyrics yet", color = Color.White, fontFamily = FontFamily.Serif, fontSize = 28.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(8.dp))
        Text(
            message ?: "Needle looks for a .lrc file next to the song, then for the Lyrics tag. You can also search online.",
            color = Color(0xFFD6D8E4), fontSize = 14.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        if (searching) {
            CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 2.5.dp)
        } else {
            PillButton("Search online", onSearch, filled = true)
        }
        if (!fileAccess) {
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    ".lrc files next to your songs can only be read if you allow access to all files.",
                    color = Color(0xFFD6D8E4), fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                PillButton("Allow access to files", onAllowFiles)
            }
        }
    }
}

/** The vertical slider on the right edge: drag or tap anywhere on it. Top is the biggest text. */
@Composable
private fun TextSizeSlider(fraction: Float, onFraction: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier
            .width(30.dp)
            .height(250.dp)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { onFraction((it.y / size.height).coerceIn(0f, 1f)) },
                    onDragEnd = onDone,
                    onDragCancel = onDone,
                    onVerticalDrag = { change, _ -> onFraction((change.position.y / size.height).coerceIn(0f, 1f)) }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures { onFraction((it.y / size.height).coerceIn(0f, 1f)); onDone() }
            }
    ) {
        Box(
            Modifier
                .align(Alignment.Center)
                .width(8.dp)
                .fillMaxHeight()
                .clip(RoundedCornerShape(9.dp))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f))))
        )
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .offset(y = maxHeight * fraction - 11.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
