package app.needle.music.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.music.cast.CastHub
import app.needle.music.cast.CastPhase
import app.needle.music.cast.CastSettings
import app.needle.music.data.HomeViewModel
import app.needle.music.data.LibraryViewModel
import app.needle.music.data.Song
import app.needle.music.data.TagsViewModel
import app.needle.music.playback.PlayerViewModel

@Composable
fun NeedleApp() {
    val library: LibraryViewModel = viewModel()
    val homeVm: HomeViewModel = viewModel()
    val tagsVm: TagsViewModel = viewModel()
    val player: PlayerViewModel = viewModel()
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    var homeTab by rememberSaveable { mutableStateOf(HomeTab.POPULAR) }
    var showSingles by rememberSaveable { mutableStateOf(false) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var openAlbumId by rememberSaveable { mutableStateOf<Long?>(null) }
    // The tag editor. The ids stay put while it slides away, so it does not go blank mid-animation.
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var editorIds by rememberSaveable { mutableStateOf(longArrayOf()) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        library.refreshPermission()
    }

    // ---- casting (DLNA / UPnP) ----
    val context = LocalContext.current
    var showPlayOn by rememberSaveable { mutableStateOf(false) }
    var castSettingsUdn by rememberSaveable { mutableStateOf<String?>(null) }
    var lanDenied by rememberSaveable { mutableStateOf(false) }
    val castDevices by CastHub.devices.collectAsState()
    val castHidden by CastHub.hidden.collectAsState()
    val castScanning by CastHub.scanning.collectAsState()
    val castState by CastHub.state.collectAsState()
    val castSettingsMap by CastHub.settings.collectAsState()
    val lanGranted by CastHub.localNetworkGranted.collectAsState()
    val lanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        CastHub.refreshPermission()
        lanDenied = !granted
        if (granted) CastHub.startScan()
    }
    val openAppSettings = {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        )
    }
    // Opening "Play on" asks for local network access (Android 17+) and starts looking for devices.
    LaunchedEffect(showPlayOn, lanGranted) {
        if (showPlayOn) {
            if (lanGranted) CastHub.startScan()
            else if (!lanDenied) lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
        }
    }
    // Short messages from the casting engine ("Lost connection to ...", volume).
    LaunchedEffect(Unit) {
        var toast: Toast? = null
        CastHub.messages.collect { message ->
            toast?.cancel()
            toast = Toast.makeText(context, message, Toast.LENGTH_SHORT).also { it.show() }
        }
    }

    // Ask once on launch; scan whenever access becomes available.
    LaunchedEffect(Unit) {
        if (!library.hasPermission) permissionLauncher.launch(library.audioPermission)
    }
    LaunchedEffect(library.hasPermission) {
        if (library.hasPermission) library.scan()
    }

    BackHandler(enabled = destination != Destination.HOME) { destination = Destination.HOME }
    BackHandler(enabled = showSingles) { showSingles = false }
    BackHandler(enabled = openAlbumId != null) { openAlbumId = null }
    BackHandler(enabled = showSearch) { showSearch = false }
    BackHandler(enabled = showPlayOn) { showPlayOn = false }
    BackHandler(enabled = castSettingsUdn != null) { castSettingsUdn = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = showEditor) { showEditor = false }
    BackHandler(enabled = showQueue) { showQueue = false } // registered last, so it wins

    Box(Modifier.fillMaxSize().background(Palette.Bg)) {
        if (!library.hasPermission) {
            PermissionScreen(onRequest = { permissionLauncher.launch(library.audioPermission) })
        } else {
            val songs by library.songs.collectAsState()
            val extras by library.extras.collectAsState()
            val sort by library.sort.collectAsState()
            val home by homeVm.home.collectAsState()
            val newState by homeVm.newState.collectAsState()
            val singlesState by homeVm.singles.collectAsState()
            val albums by homeVm.albums.collectAsState()
            // Look the open album up again each time, so it shows the latest tags. If an edit renamed it
            // into another album (it gets a new id), go back to the Albums grid.
            val albumToShow = openAlbumId?.let { id -> albums?.firstOrNull { it.id == id } }
            LaunchedEffect(albums, openAlbumId) {
                if (albums != null && openAlbumId != null && albumToShow == null) openAlbumId = null
            }

            val openEditor: (List<Song>) -> Unit = { list ->
                editorIds = list.map { it.id }.toLongArray()
                showEditor = true
            }

            // Singles opens as its own page; the other pills switch the Home page itself.
            val selectTab: (HomeTab) -> Unit = { tab ->
                if (tab == HomeTab.SINGLES) {
                    showSingles = true
                } else {
                    homeTab = tab
                }
            }

            // The dock floats over every screen: room to scroll past it (with / without the player row).
            val dockPadding = if (player.hasMedia) 160.dp else 100.dp

            val settingsUdn = castSettingsUdn

            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                when {
                    settingsUdn != null -> CastDeviceSettingsScreen(
                        device = castDevices.firstOrNull { it.udn == settingsUdn },
                        settings = castSettingsMap[settingsUdn] ?: CastSettings(),
                        connected = castState.phase == CastPhase.CONNECTED && castState.device?.udn == settingsUdn,
                        bottomPadding = dockPadding,
                        onBack = { castSettingsUdn = null },
                        onChange = { change -> CastHub.updateSettings(settingsUdn, change) },
                        onRestore = { CastHub.restoreDefaults(settingsUdn) },
                        modifier = Modifier.fillMaxSize()
                    )
                    showPlayOn -> PlayOnScreen(
                        devices = castDevices,
                        hidden = castHidden,
                        scanning = castScanning,
                        cast = castState,
                        isPlaying = player.isPlaying,
                        volumeStep = castState.device?.let { (castSettingsMap[it.udn] ?: CastSettings()).volumeStep } ?: 10,
                        permissionGranted = lanGranted,
                        permissionDenied = lanDenied,
                        bottomPadding = dockPadding,
                        onBack = { showPlayOn = false },
                        onRefresh = { CastHub.startScan(clear = true) },
                        onUsePhone = { CastHub.disconnect() },
                        onUseDevice = { CastHub.connect(it) },
                        onHide = { CastHub.hide(it.udn) },
                        onUnhide = { CastHub.unhide(it.udn) },
                        onSettings = { castSettingsUdn = it.udn },
                        onVolume = { CastHub.stepVolume(it) },
                        onRequestPermission = {
                            if (lanDenied) openAppSettings() else lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSearch -> SearchScreen(
                        songs = songs.orEmpty(),
                        extras = extras,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { showSearch = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onEditTags = { song -> openEditor(listOf(song)) }
                    )
                    albumToShow != null -> AlbumScreen(
                        album = albumToShow,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { openAlbumId = null },
                        onTrack = { index -> player.playSongs(albumToShow.songs, index) },
                        onPlay = { player.playSongs(albumToShow.songs, 0, shuffle = false) },
                        onShuffle = { player.shuffleAll(albumToShow.songs) },
                        onEditTags = openEditor,
                        onEditTrack = { song -> openEditor(listOf(song)) }
                    )
                    showSingles -> SinglesScreen(
                        state = singlesState,
                        bottomPadding = dockPadding,
                        onBack = { showSingles = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onEditTags = { song -> openEditor(listOf(song)) }
                    )
                    destination == Destination.SONGS -> SongsScreen(
                        songs = songs,
                        isScanning = library.isScanning,
                        currentMediaId = player.currentMediaId,
                        sort = sort,
                        bottomPadding = dockPadding,
                        onSongClick = { index -> songs?.let { player.playSongs(it, index) } },
                        onSongLongClick = { song -> openEditor(listOf(song)) },
                        onShuffleAll = { songs?.let { player.shuffleAll(it) } },
                        onSortSelected = library::setSort,
                        onRescan = library::scan
                    )
                    destination == Destination.ALBUMS -> AlbumsScreen(
                        albums = albums,
                        bottomPadding = dockPadding,
                        onOpenAlbum = { openAlbumId = it.id },
                        onSearch = { showSearch = true },
                        onEditTags = { album -> openEditor(album.songs) }
                    )
                    else -> when (homeTab) {
                        HomeTab.NEW -> NewScreen(
                            state = newState,
                            bottomPadding = dockPadding,
                            onPlay = { list, index -> player.playSongs(list, index) },
                            onShuffle = { list -> player.shuffleAll(list) },
                            onEditTags = openEditor,
                            onSearch = { showSearch = true },
                            onTabSelected = selectTab
                        )
                        else -> HomeScreen(
                            home = home,
                            bottomPadding = dockPadding,
                            onPlay = { list -> player.playSongs(list, 0) },
                            onSearch = { showSearch = true },
                            onTabSelected = selectTab
                        )
                    }
                }
                NeedleDock(
                    selected = destination,
                    // Library has no page yet, so that button does nothing for now.
                    onSelect = {
                        if (it != Destination.LIBRARY) {
                            destination = it
                            showSingles = false
                            openAlbumId = null
                            showSearch = false
                            showPlayOn = false
                            castSettingsUdn = null
                        }
                    },
                    player = player,
                    onOpenPlayer = { showPlayer = true },
                    castName = castState.device?.name?.takeIf { castState.phase == CastPhase.CONNECTED },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            AnimatedVisibility(
                visible = showPlayer,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                NowPlayingScreen(
                    vm = player,
                    onClose = { showPlayer = false },
                    onOpenQueue = { showQueue = true },
                    castActive = castState.phase == CastPhase.CONNECTED,
                    onOpenPlayOn = {
                        showPlayer = false
                        showPlayOn = true
                    },
                    // swallow taps so they don't reach the list underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }

            AnimatedVisibility(
                visible = showEditor,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val all = songs
                val ids = editorIds.toList()
                val editing = remember(all, editorIds) { all?.filter { it.id in ids }.orEmpty() }
                val trackTotal = remember(all, editing) {
                    editing.firstOrNull()?.let { first -> all?.count { it.albumId == first.albumId } } ?: 0
                }
                TagEditorScreen(
                    songs = editing,
                    extras = extras,
                    trackTotal = trackTotal,
                    onClose = { showEditor = false },
                    onSave = { changes, cover -> tagsVm.save(ids, changes, cover) { showEditor = false } },
                    // swallow taps so they don't reach the screen underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }

            AnimatedVisibility(
                visible = showQueue,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                QueueScreen(
                    vm = player,
                    onClose = { showQueue = false },
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
        }
    }
}
