# First launch, scan screen, folder switches, empty library (Step 67, built on Step 66)

## New files
- data/Onboarding.kt        which first-launch screens were seen; "Not now" on the permission screen
- data/ExcludedFolders.kt   the folder switches (a folder switched off is left out of every list)
- (ui/PermissionScreen.kt now holds all the first-launch screens)

## First launch (the mockup's "First launch" group)
1. Welcome: logo, "Needle", "Your music, on your phone, looking the way you want.", a row of accent colors
   (tapping one repaints the screen right away) and "Pick an accent. You can change everything later." / Get started.
2. "Let Needle find your music": "Needle needs to read the audio files on this phone. Nothing is uploaded or shared.",
   a "Playback controls" switch (Notification with play, pause and skip; on by default), Allow access to music, Not now.
   On Android 13 and newer, Allow asks for the notification first when that switch is on, then for the music; refusing
   the notification does not stop the music question.
3. "Scanning your library": a ring that fills while Needle reads the tags in your songs ("1,012 of 1,284 songs", a
   turning arc while it is still listing the files), "Found 96 albums and 71 artists so far.", a switch for each folder,
   and Continue in background. It closes by itself when the scan and the tag reading are done.
Someone who updates from an older Needle and already gave access sees none of this.
"Not now" opens Needle without music; the Songs page then shows "No music yet" with Allow access to music, and Needle
does not ask again by itself at the next start.

## Folder switches
Each top folder of your music is a switch ("Music", "Download", "WhatsApp Audio" for WhatsApp's audio, ...) with its
song count. Off = those songs are left out of Songs, Albums, Artists, search, Home, stats and playlists' lists; nothing
is deleted and switching it back on brings them back. They are on the scan screen and in Settings > Library > Folders
(shown when there is more than one folder; phones older than Android 10 give no folders). They are in backups.
Folders are grouped by their first name, so "Music/Indie" and "Music/Jazz" are both "Music".

## Empty library ("No music yet")
The Songs page, when there is no music: "Add songs to your Music folder, or choose which folders Needle should scan."
with Choose folders (opens Settings > Library) and Scan again; without the permission it asks for it instead.

## Changed
- ui/NeedleApp.kt: the first-launch gate, the notification-then-music permission chain, the scan screen
- ui/SongsScreen.kt (empty state), ui/SettingsScreen.kt (Folders), data/Library.kt (folder filter, plus
  observeEverything for the switches), data/LibraryViewModel.kt (folderGroups), data/Backup.kt, MainActivity.kt

## Not done
- The mockup's other empty state ("Nothing played yet" on Home's Recently played) is not added.
- The first scan screen's percent follows the tag reading, because listing the files is nearly instant. On a library
  that was already read it just flashes by.
- No compiler or device here: checked brace balance, imports and names against Step 66. Please build once.
