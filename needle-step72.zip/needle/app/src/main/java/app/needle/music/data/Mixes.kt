package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import java.time.Instant
import java.time.ZoneId
import kotlin.random.Random

const val MIX_NEW = "new"
const val MIX_REDISCOVER = "rediscover"

private const val DAY_MS = 86_400_000L

/**
 * A mix Needle makes for you from the library and what you played. It is not a saved playlist: it changes every
 * day (or when you press Refresh), and "Save as playlist" turns the current one into a real playlist.
 */
class MixData(
    val id: String,
    val name: String,
    val about: String,
    val songs: List<Song>,
    /** When this version of the mix was made: the start of today, or the last Refresh if that was later. */
    val updatedAt: Long,
    /** How many of its songs you played since [updatedAt]. */
    val played: Int,
    /** The mix dressed as a playlist, only for its cover mosaic. */
    val cover: PlaylistData,
    /** A smart playlist made by the person (same tile and page as a mix, but it has no Refresh). */
    val smart: Boolean = false
) {
    val durationMs: Long get() = songs.sumOf { it.durationMs }
}

/** How often a mix was refreshed by hand, and when the last time was. */
class MixState(val refreshes: Int, val refreshedAt: Long)

/** The Refresh presses, remembered so a mix stays the same while you listen to it. */
object MixPrefs {
    private var prefs: SharedPreferences? = null

    val states = MutableStateFlow<Map<String, MixState>>(emptyMap())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        states.value = p.getString("mix_states", "").orEmpty().lines().mapNotNull { line ->
            val parts = line.split(',')
            if (parts.size != 3) return@mapNotNull null
            val n = parts[1].toIntOrNull() ?: return@mapNotNull null
            val at = parts[2].toLongOrNull() ?: return@mapNotNull null
            parts[0] to MixState(n, at)
        }.toMap()
    }

    /** A new version of the mix, right now. */
    fun refresh(id: String) {
        val old = states.value[id]
        val next = states.value + (id to MixState((old?.refreshes ?: 0) + 1, System.currentTimeMillis()))
        states.value = next
        prefs?.edit()?.putString("mix_states", next.entries.joinToString("\n") { "${it.key},${it.value.refreshes},${it.value.refreshedAt}" })?.apply()
    }
}

/** Takes up to [n] songs in random order, but no more than [perArtist] from one artist. */
private fun spreadPick(list: List<Song>, n: Int, perArtist: Int, random: Random): List<Song> {
    val counts = HashMap<String, Int>()
    val out = ArrayList<Song>()
    for (song in list.shuffled(random)) {
        if (out.size >= n) break
        val key = artistKey(song.artist)
        val c = counts[key] ?: 0
        if (c >= perArtist) continue
        counts[key] = c + 1
        out += song
    }
    return out
}

/** Mixes the order so the same artist does not play twice in a row when it can be avoided. */
private fun arrange(list: List<Song>, random: Random): List<Song> {
    val rest = list.shuffled(random).toMutableList()
    val out = ArrayList<Song>(rest.size)
    while (rest.isNotEmpty()) {
        val last = out.lastOrNull()?.let { artistKey(it.artist) }
        val i = rest.indexOfFirst { last == null || artistKey(it.artist) != last }.let { if (it < 0) 0 else it }
        out += rest.removeAt(i)
    }
    return out
}

/**
 * The mixes of today. Songs are picked with a random generator that starts from the day and the Refresh count of
 * that mix, so the same day gives the same mix. What counts as "not played in a while" looks only at plays from
 * before the mix was made, so playing the mix does not change it.
 *
 * - New Music Mix: songs added in the last 30 days plus a few you have not played for two months (needs 5 new songs).
 * - Rediscover Mix: songs you played at least twice but not for two months (needs 8 of them).
 */
fun buildMixes(songs: List<Song>, plays: List<PlayEvent>, states: Map<String, MixState>, now: Long): List<MixData> {
    val zone = ZoneId.systemDefault()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    val startOfDay = today.atStartOfDay(zone).toInstant().toEpochMilli()
    val day = today.toEpochDay()
    val staleBefore = now - 60 * DAY_MS
    val monthAgoSec = now / 1000 - 30 * 86_400L

    fun finish(id: String, name: String, about: String, picked: List<Song>, updatedAt: Long): MixData {
        val ids = picked.mapTo(HashSet()) { it.id }
        val playedIds = plays.filter { it.playedAt >= updatedAt && it.songId in ids }.mapTo(HashSet()) { it.songId }
        val cover = PlaylistData(id = -1L, name = name, liked = false, songs = picked, addedAt = emptyMap(), updatedAt = updatedAt)
        return MixData(id, name, about, picked, updatedAt, playedIds.size, cover)
    }

    fun seedOf(id: String): Pair<Random, Long> {
        val state = states[id]
        val updatedAt = maxOf(startOfDay, state?.refreshedAt ?: 0L)
        val seed = day * 1_000_003L + (state?.refreshes ?: 0) * 7_919L + id.hashCode()
        return Random(seed) to updatedAt
    }

    val out = ArrayList<MixData>()

    // ---- New Music Mix ----
    run {
        val (random, updatedAt) = seedOf(MIX_NEW)
        val recent = songs.filter { it.dateAdded >= monthAgoSec }
        if (recent.size < 5) return@run
        val lastBefore = HashMap<Long, Long>()
        for (e in plays) if (e.playedAt < updatedAt) lastBefore[e.songId] = maxOf(lastBefore[e.songId] ?: 0L, e.playedAt)
        val fromRecent = spreadPick(recent, 24, 4, random)
        val used = fromRecent.mapTo(HashSet()) { it.id }
        val stale = songs.filter { it.id !in used && (lastBefore[it.id] ?: 0L) < staleBefore }
        val fromStale = spreadPick(stale, 30 - fromRecent.size, 4, random)
        out += finish(
            MIX_NEW, "New Music Mix",
            "Songs added in the last 30 days, plus a few you haven't played in a while.",
            arrange(fromRecent + fromStale, random), updatedAt
        )
    }

    // ---- Rediscover Mix ----
    run {
        val (random, updatedAt) = seedOf(MIX_REDISCOVER)
        val lastBefore = HashMap<Long, Long>()
        val countBefore = HashMap<Long, Int>()
        for (e in plays) if (e.playedAt < updatedAt) {
            lastBefore[e.songId] = maxOf(lastBefore[e.songId] ?: 0L, e.playedAt)
            countBefore[e.songId] = (countBefore[e.songId] ?: 0) + 1
        }
        val candidates = songs.filter { (countBefore[it.id] ?: 0) >= 2 && (lastBefore[it.id] ?: 0L) < staleBefore }
        if (candidates.size < 8) return@run
        // Songs you played the most come first in line, with some luck so it is not the same list each time.
        val ranked = candidates.sortedByDescending { (countBefore[it.id] ?: 0) + random.nextDouble() * 3.0 }
        val counts = HashMap<String, Int>()
        val picked = ArrayList<Song>()
        for (song in ranked) {
            if (picked.size >= 30) break
            val key = artistKey(song.artist)
            val c = counts[key] ?: 0
            if (c >= 3) continue
            counts[key] = c + 1
            picked += song
        }
        out += finish(
            MIX_REDISCOVER, "Rediscover Mix",
            "Songs you played a lot, but not in the last two months.",
            arrange(picked, random), updatedAt
        )
    }
    return out
}
