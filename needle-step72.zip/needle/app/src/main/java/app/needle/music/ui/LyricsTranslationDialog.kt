package app.needle.music.ui

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Add or change the translation of this song's lyrics: paste it, take it from the clipboard, or open a text or .lrc
 * file. Needle does not translate by itself (nothing is sent over the internet); the text stays on this phone.
 */
@Composable
fun LyricsTranslationDialog(
    songTitle: String,
    existing: String?,
    onSave: (String) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    var text by remember { mutableStateOf(existing.orEmpty()) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val read = runCatching {
                context.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
            }.getOrNull()
            if (read.isNullOrBlank()) Toast.makeText(context, "Could not read that file.", Toast.LENGTH_SHORT).show()
            else text = read.take(60_000)
        }
    }
    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Translation for $songTitle") },
        text = {
            Column {
                Text(
                    "One line for each line of the lyrics, in the same order, or a timed .lrc file. Needle does not translate by itself; the text stays on this phone.",
                    color = Palette.Muted, fontSize = 12.5.sp
                )
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(60_000) },
                    placeholder = { Text("Paste the translation here", color = Palette.Muted) },
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp).heightIn(min = 140.dp, max = 260.dp)
                )
                Row(Modifier.padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(
                        "Paste", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(CircleShape).clickable { clipboardText(context)?.let { text = it } }.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                    Text(
                        "Open a file", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(CircleShape).clickable { picker.launch(arrayOf("text/*", "application/octet-stream", "*/*")) }.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Save", color = Palette.Accent) } },
        dismissButton = {
            Row {
                if (existing != null) TextButton(onClick = { onSave("") }) { Text("Remove", color = Palette.Muted) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) }
            }
        }
    )
}

private fun clipboardText(context: Context): String? {
    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager ?: return null
    return cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()
}
