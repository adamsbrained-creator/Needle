package app.needle.music.ui

import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.CornerBasedShape
import androidx.compose.foundation.shape.CornerSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.Outline
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.LayoutDirection
import app.needle.music.data.NeedleSettings

/*
 * The shape options of Settings > Customization (Surfaces, Corners, Cover shape). They are applied at the few places
 * every screen draws through: the glass cards, the glass buttons, and the covers.
 */

/** A rounded shape with every corner made smaller (never more than half of the shortest side); pills and circles stay round. */
private class ScaledCorners(private val base: CornerBasedShape, private val factor: Float) : Shape {
    override fun createOutline(size: Size, layoutDirection: LayoutDirection, density: Density): Outline {
        val limit = minOf(size.width, size.height) / 2f
        // A corner that is already (nearly) half the shortest side makes a pill or a circle: those stay as they are.
        fun px(corner: CornerSize): Float {
            val original = corner.toPx(size, density)
            return if (original >= limit * 0.85f) original.coerceAtMost(limit) else (original * factor).coerceAtMost(limit)
        }
        return base.copy(
            topStart = CornerSize(px(base.topStart)),
            topEnd = CornerSize(px(base.topEnd)),
            bottomEnd = CornerSize(px(base.bottomEnd)),
            bottomStart = CornerSize(px(base.bottomStart))
        ).createOutline(size, layoutDirection, density)
    }
}

/** This shape with the Corners setting applied: Sharp is a quarter of the corner, Soft a bit over half, Round as drawn. */
internal fun Shape.withCornerStyle(): Shape {
    val factor = when (NeedleSettings.cornerStyle.intValue) {
        0 -> 0.25f
        1 -> 0.6f
        else -> 1f
    }
    return if (factor == 1f || this !is CornerBasedShape) this else ScaledCorners(this, factor)
}

/** The shape of a cover that is drawn as a rounded square with [corner]: Square, Rounded (as drawn), Squircle or Circle. */
internal fun coverClip(corner: Dp): Shape = when (NeedleSettings.coverStyle.intValue) {
    0 -> RectangleShape
    2 -> RoundedCornerShape(percent = 30)
    3 -> CircleShape
    else -> RoundedCornerShape(corner)
}

/** A rounded shape that follows the Corners setting: use it wherever a screen draws a rounded card, row, tile or sheet. */
internal fun cornerShape(size: Dp): Shape = RoundedCornerShape(size).withCornerStyle()

/** The same with a different radius for each corner (sheets: only the top two). */
internal fun cornerShapeOf(topStart: Dp = 0.dp, topEnd: Dp = 0.dp, bottomEnd: Dp = 0.dp, bottomStart: Dp = 0.dp): Shape =
    RoundedCornerShape(topStart, topEnd, bottomEnd, bottomStart).withCornerStyle()

/** With Surfaces set to Flat, a frosted gradient becomes one flat color; otherwise the gradient as it is. */
internal fun Brush.flatOr(solid: Color): Brush = if (NeedleSettings.surfaceFlat.value) SolidColor(solid) else this

/** The bottom navigation in use: 0 Pill + dock, 1 Pill only, 2 Classic bar. Without a choice, the skin decides. */
internal fun effectiveNavStyle(): Int {
    val chosen = NeedleSettings.navStyle.intValue
    return if (chosen in 0..2) chosen else if (Skins.blackGreen) 2 else 0
}
