package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.GenericShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.GenreCount
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

private const val FIRST_SHOWN = 40

/**
 * "Choose your genres" from the mockup: the genres of your library as a cloud of chips. The ones you pick turn
 * into coloured shapes. Picked genres come first on Home (the picks, Rediscover and the tags on the tiles).
 * Saving with nothing picked clears the choice.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun GenrePickerScreen(
    genres: List<GenreCount>,
    initial: Set<String>,
    onSave: (Set<String>) -> Unit,
    onSkip: () -> Unit,
    modifier: Modifier = Modifier
) {
    var picked by remember { mutableStateOf(initial.map { it.lowercase() }.toSet()) }
    var showAll by remember { mutableStateOf(false) }

    // The most common genres, plus any picked one that is further down the list.
    val shown = if (showAll || genres.size <= FIRST_SHOWN) genres
    else genres.take(FIRST_SHOWN) + genres.drop(FIRST_SHOWN).filter { it.name.lowercase() in picked }
    val chosenNames = genres.filter { it.name.lowercase() in picked }.map { it.name }

    Column(modifier.safeDrawingPadding().padding(horizontal = 18.dp)) {
        Text(
            "Choose your genres", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 32.sp,
            lineHeight = 36.sp, modifier = Modifier.padding(top = 28.dp)
        )
        Text(
            "Selected genres appear first on Home.", color = Palette.Muted, fontSize = 14.sp,
            modifier = Modifier.padding(top = 6.dp)
        )

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(top = 24.dp, bottom = 16.dp)
        ) {
            if (genres.isEmpty()) {
                Text(
                    "No genres found yet. Give some songs a Genre in the tag editor, or let Needle read the tags in " +
                        "your files (Settings, Library), then come back.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp)
                )
            }
            FlowRow(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterHorizontally),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                shown.forEach { g ->
                    val key = g.name.lowercase()
                    GenreChip(
                        name = g.name,
                        selected = key in picked,
                        onClick = { picked = if (key in picked) picked - key else picked + key }
                    )
                }
            }
            if (!showAll && genres.size > FIRST_SHOWN) {
                Text(
                    "Show all ${genres.size} genres", color = Palette.Accent, fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().clickable { showAll = true }.padding(vertical = 22.dp)
                )
            }
        }

        Row(Modifier.fillMaxWidth().padding(bottom = 14.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.weight(1f).height(54.dp).clip(CircleShape).background(Color.White)
                    .clickable { onSave(chosenNames.toSet()) },
                contentAlignment = Alignment.Center
            ) {
                Text(
                    if (chosenNames.isEmpty()) "Save" else "Save ${chosenNames.size}",
                    color = Color(0xFF111111), fontSize = 16.sp, fontWeight = FontWeight.SemiBold
                )
            }
            Box(
                Modifier.weight(0.6f).height(54.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f))
                    .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape).clickable(onClick = onSkip),
                contentAlignment = Alignment.Center
            ) { Text("Skip", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold) }
        }
    }
}

private val chipColors = listOf(Palette.Accent, Palette.Green, Palette.Pink, Color(0xFFF08A4B))

/**
 * One genre. Not picked: a soft, slightly tilted pill. Picked: a coloured shape (round, wobbly or a star), the
 * colour and shape chosen from the name so a genre always looks the same.
 */
@Composable
private fun GenreChip(name: String, selected: Boolean, onClick: () -> Unit) {
    val h = abs(name.lowercase().hashCode())
    val angle = ((h % 7) - 3).toFloat() // a little tilt, -3 to +3 degrees
    val color = chipColors[h % 4]
    val kind = (h / 4) % 3 // 0 round, 1 wobbly, 2 star

    val shape: Shape = when {
        !selected -> cornerShape(18.dp + (h % 3 * 4).dp)
        kind == 0 -> cornerShape(30.dp)
        kind == 1 -> blobShape(h)
        else -> starShape
    }
    val padding = when {
        !selected -> PaddingValues(horizontal = 18.dp, vertical = 11.dp)
        kind == 0 -> PaddingValues(horizontal = 24.dp, vertical = 16.dp)
        kind == 1 -> PaddingValues(horizontal = 26.dp, vertical = 18.dp)
        else -> PaddingValues(horizontal = 32.dp, vertical = 26.dp)
    }
    Box(
        Modifier
            .rotate(angle)
            .clip(shape)
            .background(if (selected) color else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(padding),
        contentAlignment = Alignment.Center
    ) {
        Text(
            name, color = Color.White, fontSize = 14.5.sp,
            fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal, maxLines = 1
        )
    }
}

/** A plump four-pointed star. */
private val starShape = GenericShape { size, _ ->
    val w = size.width
    val h = size.height
    val cx = w / 2
    val cy = h / 2
    val k = 0.56f
    moveTo(cx, 0f)
    lineTo(cx + cx * k, cy - cy * k)
    lineTo(w, cy)
    lineTo(cx + cx * k, cy + cy * k)
    lineTo(cx, h)
    lineTo(cx - cx * k, cy + cy * k)
    lineTo(0f, cy)
    lineTo(cx - cx * k, cy - cy * k)
    close()
}

/** A soft, wobbly blob. The same [seed] gives the same blob. */
private fun blobShape(seed: Int): Shape = GenericShape { size, _ ->
    val n = 8
    val cx = size.width / 2
    val cy = size.height / 2
    val xs = FloatArray(n)
    val ys = FloatArray(n)
    for (i in 0 until n) {
        val a = (i * 2 * Math.PI / n).toFloat()
        val r = 0.84f + 0.16f * (((seed * (i + 3)) % 100) / 100f)
        xs[i] = cx + cx * r * cos(a)
        ys[i] = cy + cy * r * sin(a)
    }
    // curves through the middle of each side, with the points as the bends
    moveTo((xs[n - 1] + xs[0]) / 2, (ys[n - 1] + ys[0]) / 2)
    for (i in 0 until n) {
        val j = (i + 1) % n
        quadraticTo(xs[i], ys[i], (xs[i] + xs[j]) / 2, (ys[i] + ys[j]) / 2)
    }
    close()
}
