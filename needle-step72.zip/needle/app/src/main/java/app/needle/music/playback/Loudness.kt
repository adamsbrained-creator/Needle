package app.needle.music.playback

import android.content.Context
import android.content.SharedPreferences
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.abs
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.tanh

/**
 * Volume levelling ("Loudness normalization" in the equalizer): quiet and loud songs end up about equally loud.
 *
 * Where a song's gain comes from:
 *  1. Its ReplayGain tag (track gain, else album gain) if the file has one. Needle reads them with the other tags.
 *  2. Otherwise what Needle learned by listening: while a song plays, [LoudnessProcessor] measures how loud it is
 *     and remembers it, so the next time that song plays it is levelled. A song heard for the first time plays
 *     untouched (a gain that changed in the middle of a song would be heard as pumping).
 * The gain is limited to -12 dB .. +6 dB, and a boost goes through a soft limiter so it cannot crackle.
 * It works on this phone's playback; a cast TV gets the original sound.
 */
object Loudness {
    /** About -18 LUFS (the ReplayGain reference) measured as plain RMS. */
    const val TARGET_DB = -15f
    private const val MAX_BOOST_DB = 6f
    private const val MAX_CUT_DB = -12f

    /** The song whose sound is passing through, for the processor to measure. */
    @Volatile
    var currentSongId: Long = -1L
        private set

    /** The linear gain the processor moves towards (1.0 = untouched). */
    @Volatile
    var targetLinear: Double = 1.0
        private set

    val processor = LoudnessProcessor()

    @Volatile private var enabled = false
    @Volatile private var tagGainDb: Float? = null
    private val learned = ConcurrentHashMap<Long, Float>()   // song id -> measured loudness in dB (RMS)
    private var prefs: SharedPreferences? = null
    @Volatile private var dirty = false

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_loudness", Context.MODE_PRIVATE)
        prefs = p
        p.getString("learned", "").orEmpty().lineSequence().forEach { line ->
            val parts = line.split(',')
            if (parts.size == 2) {
                val id = parts[0].toLongOrNull()
                val v = parts[1].toFloatOrNull()
                if (id != null && v != null) learned[id] = v
            }
        }
    }

    fun setEnabled(on: Boolean) {
        enabled = on
        recompute()
    }

    /** A different song started. Its gain is worked out from what is known; the tag arrives a moment later. */
    fun songChanged(id: Long?) {
        saveIfDirty()
        currentSongId = id ?: -1L
        tagGainDb = null
        recompute()
    }

    /** The ReplayGain gain (dB) found in the file of song [id], or null. Ignored if that song is no longer the current one. */
    fun tagLoaded(id: Long, gainDb: Float?) {
        if (id != currentSongId) return
        tagGainDb = gainDb
        recompute()
    }

    /** From the audio thread: song [id] measures [rmsDb] so far. */
    fun report(id: Long, rmsDb: Float) {
        if (id < 0 || rmsDb.isNaN() || rmsDb < -60f || rmsDb > 0f) return
        learned[id] = rmsDb
        dirty = true
    }

    fun saveIfDirty() {
        if (!dirty) return
        dirty = false
        prefs?.edit()?.putString("learned", learned.entries.joinToString("\n") { "${it.key},${"%.1f".format(java.util.Locale.US, it.value)}" })?.apply()
    }

    private fun recompute() {
        val db = when {
            !enabled -> 0f
            tagGainDb != null -> tagGainDb!!.coerceIn(MAX_CUT_DB, MAX_BOOST_DB)
            else -> learned[currentSongId]?.let { (TARGET_DB - it).coerceIn(MAX_CUT_DB, MAX_BOOST_DB) } ?: 0f
        }
        targetLinear = 10.0.pow(db / 20.0)
    }

    /** "-7.30 dB", "-7.3", "+2.1dB" -> -7.3. null when there is no number in it. */
    fun parseDb(text: String?): Float? =
        text?.let { Regex("[-+]?\\d+(?:[.,]\\d+)?").find(it)?.value?.replace(',', '.')?.toFloatOrNull() }

    /** The largest gain that keeps a song with this ReplayGain peak (1.0 = full scale) from clipping. */
    fun gainLimitForPeak(peak: Float?): Float? = peak?.takeIf { it > 0f }?.let { -20f * log10(it) }
}

/**
 * Applies [Loudness]'s gain (16-bit or float sound; other formats pass through unchanged) and measures how loud
 * the song is while it passes. The gain moves smoothly (about a quarter of a second) when it changes.
 */
@OptIn(UnstableApi::class)
class LoudnessProcessor : BaseAudioProcessor() {
    private var channels = 2
    private var sampleRate = 44100
    private var isFloat = false
    private var smoothing = 0.0
    private var gain = 1.0

    // measuring
    private var measuredId = -1L
    private var sumSq = 0.0
    private var counted = 0L
    private var sinceReport = 0L

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val encoding = inputAudioFormat.encoding
        if (encoding != C.ENCODING_PCM_16BIT && encoding != C.ENCODING_PCM_FLOAT) return AudioProcessor.AudioFormat.NOT_SET
        isFloat = encoding == C.ENCODING_PCM_FLOAT
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        smoothing = 1.0 - exp(-1.0 / (0.25 * sampleRate))
        gain = Loudness.targetLinear
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        val id = Loudness.currentSongId
        if (id != measuredId) {
            measuredId = id
            sumSq = 0.0; counted = 0; sinceReport = 0
        }
        val target = Loudness.targetLinear
        val out = replaceOutputBuffer(size)
        if (isFloat) {
            val frameBytes = 4 * channels
            while (inputBuffer.remaining() >= frameBytes) {
                gain += (target - gain) * smoothing
                for (ch in 0 until channels) out.putFloat(handle(inputBuffer.getFloat().toDouble()).toFloat())
            }
        } else {
            val frameBytes = 2 * channels
            while (inputBuffer.remaining() >= frameBytes) {
                gain += (target - gain) * smoothing
                for (ch in 0 until channels) {
                    val v = handle(inputBuffer.getShort() / 32768.0)
                    out.putShort((v * 32767.0).roundToInt().coerceIn(-32768, 32767).toShort())
                }
            }
        }
        out.put(inputBuffer) // a partial frame at the end (should not happen) goes on as it is
        out.flip()
        maybeReport()
    }

    /** Measures one sample (silence is left out) and returns it with the gain applied. */
    private fun handle(s: Double): Double {
        val a = abs(s)
        if (a > SILENCE) {
            sumSq += s * s
            counted++
        }
        sinceReport++
        val g = gain
        if (g == 1.0) return s
        val v = s * g
        return if (g > 1.0) limit(v) else v
    }

    private fun maybeReport() {
        val perSecond = sampleRate.toLong() * channels
        if (measuredId < 0 || counted < MIN_SECONDS * perSecond || sinceReport < REPORT_EVERY_SECONDS * perSecond) return
        sinceReport = 0
        Loudness.report(measuredId, (10.0 * log10(sumSq / counted)).toFloat())
    }

    /** Linear up to 0.95, then a smooth curve that never passes 1.0. */
    private fun limit(v: Double): Double {
        val a = abs(v)
        if (a <= KNEE) return v
        val over = KNEE + (1.0 - KNEE) * tanh((a - KNEE) / (1.0 - KNEE))
        return if (v < 0) -over else over
    }

    private companion object {
        const val SILENCE = 0.0003      // about -70 dB: not counted as part of the song's loudness
        const val MIN_SECONDS = 15L     // measure at least this much music before trusting it
        const val REPORT_EVERY_SECONDS = 5L
        const val KNEE = 0.95
    }
}
