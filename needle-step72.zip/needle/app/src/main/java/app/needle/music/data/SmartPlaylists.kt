package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject

/** What a smart playlist picks songs by. [needsValue] rules take a number or a name. */
enum class SmartRule(val label: String, val valueHint: String?, val numeric: Boolean, val default: String) {
    ADDED("Added recently", "in the last how many days", true, "30"),
    PLAYED_OFTEN("Played often", "at least how many times", true, "5"),
    NOT_PLAYED("Not played for a while", "how many months", true, "6"),
    NEVER_PLAYED("Never played", null, false, ""),
    GENRE("Genre", "genre name", false, ""),
    ARTIST("Artist", "artist name", false, "");

    val needsValue: Boolean get() = valueHint != null
}

enum class SmartSort(val label: String) {
    NEWEST("Newest first"),
    MOST_PLAYED("Most played"),
    A_Z("A to Z"),
    SHUFFLE("Shuffled daily")
}

/** A playlist defined by one rule; it fills itself from the library and updates as the library and your plays change. */
class SmartPlaylist(
    val id: String,
    val name: String,
    val rule: SmartRule,
    val value: String,
    /** 0 = no limit. */
    val limit: Int,
    val sort: SmartSort
) {
    /** The rule in words, for the page of the playlist. */
    val description: String
        get() = when (rule) {
            SmartRule.ADDED -> "Songs added in the last $value days."
            SmartRule.PLAYED_OFTEN -> "Songs you played $value or more times."
            SmartRule.NOT_PLAYED -> "Songs you have not played for $value months, or never."
            SmartRule.NEVER_PLAYED -> "Songs you have never played."
            SmartRule.GENRE -> "Songs with the genre \"$value\"."
            SmartRule.ARTIST -> "Songs by $value."
        } + (if (limit > 0) " The first $limit, ${sort.label.lowercase()}." else " ${sort.label}.")
}

/** The smart playlists the person made. Remembered. */
object SmartPlaylists {
    private var prefs: SharedPreferences? = null

    val items = MutableStateFlow<List<SmartPlaylist>>(emptyList())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        items.value = fromJson(p.getString("smart_playlists", null))
    }

    fun get(id: String): SmartPlaylist? = items.value.firstOrNull { it.id == id }

    /** Adds a new one (id empty) or replaces the one with that id. Returns the id. */
    fun save(p: SmartPlaylist): String {
        val id = p.id.ifEmpty { "s" + System.currentTimeMillis() }
        val saved = SmartPlaylist(id, p.name.trim().ifEmpty { "Smart playlist" }, p.rule, p.value.trim(), p.limit, p.sort)
        persist(if (items.value.any { it.id == id }) items.value.map { if (it.id == id) saved else it } else items.value + saved)
        return id
    }

    fun delete(id: String) = persist(items.value.filter { it.id != id })

    private fun persist(list: List<SmartPlaylist>) {
        items.value = list
        prefs?.edit()?.putString("smart_playlists", toJson(list).toString())?.apply()
    }

    fun toJson(list: List<SmartPlaylist> = items.value): JSONArray = JSONArray().also { arr ->
        list.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.name).put("rule", it.rule.name).put("value", it.value).put("limit", it.limit).put("sort", it.sort.name))
        }
    }

    private fun fromJson(json: String?): List<SmartPlaylist> {
        if (json.isNullOrBlank()) return emptyList()
        return try {
            val arr = JSONArray(json)
            (0 until arr.length()).mapNotNull { i -> parse(arr.getJSONObject(i)) }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parse(o: JSONObject): SmartPlaylist? {
        val rule = runCatching { SmartRule.valueOf(o.optString("rule")) }.getOrNull() ?: return null
        val sort = runCatching { SmartSort.valueOf(o.optString("sort")) }.getOrDefault(SmartSort.NEWEST)
        val id = o.optString("id").ifEmpty { return null }
        return SmartPlaylist(id, o.optString("name"), rule, o.optString("value"), o.optInt("limit", 0), sort)
    }

    /** From a backup: playlists with an id this phone does not have are added. */
    fun merge(arr: JSONArray) {
        val have = items.value.map { it.id }.toSet()
        val incoming = (0 until arr.length()).mapNotNull { parse(arr.getJSONObject(it)) }.filter { it.id !in have }
        if (incoming.isNotEmpty()) persist(items.value + incoming)
    }
}

/** The songs of a smart playlist right now. */
fun evaluateSmart(sp: SmartPlaylist, songs: List<Song>, plays: List<PlayEvent>, now: Long): List<Song> {
    val number = sp.value.trim().toIntOrNull()?.coerceAtLeast(0) ?: 0
    val count = HashMap<Long, Int>()
    val last = HashMap<Long, Long>()
    for (e in plays) {
        count[e.songId] = (count[e.songId] ?: 0) + 1
        last[e.songId] = maxOf(last[e.songId] ?: 0L, e.playedAt)
    }
    val picked = when (sp.rule) {
        SmartRule.ADDED -> {
            val since = now / 1000 - number * 86_400L
            songs.filter { it.dateAdded >= since }
        }
        SmartRule.PLAYED_OFTEN -> songs.filter { (count[it.id] ?: 0) >= number.coerceAtLeast(1) }
        SmartRule.NOT_PLAYED -> {
            val before = now - number * 30L * 86_400_000L
            songs.filter { (last[it.id] ?: 0L) < before }
        }
        SmartRule.NEVER_PLAYED -> songs.filter { (count[it.id] ?: 0) == 0 }
        SmartRule.GENRE -> {
            val g = sp.value.trim().lowercase()
            if (g.isEmpty()) emptyList() else songs.filter { s -> genresOf(s).any { it.lowercase() == g } }
        }
        SmartRule.ARTIST -> {
            val a = artistKey(sp.value)
            if (a.isEmpty()) emptyList() else songs.filter { artistKey(it.artist) == a }
        }
    }
    val sorted = when (sp.sort) {
        SmartSort.NEWEST -> picked.sortedByDescending { it.dateAdded }
        SmartSort.MOST_PLAYED -> picked.sortedWith(compareByDescending<Song> { count[it.id] ?: 0 }.thenByDescending { it.dateAdded })
        SmartSort.A_Z -> picked.sortedBy { sortKey(it.title) }
        SmartSort.SHUFFLE -> {
            val day = now / 86_400_000L
            picked.shuffled(kotlin.random.Random(day * 31L + sp.id.hashCode()))
        }
    }
    return if (sp.limit > 0) sorted.take(sp.limit) else sorted
}

/** A smart playlist as a [MixData], so it can use the same tile and page as the mixes. */
fun smartAsMix(sp: SmartPlaylist, songs: List<Song>, now: Long): MixData {
    val cover = PlaylistData(id = -1L, name = sp.name, liked = false, songs = songs, addedAt = emptyMap(), updatedAt = now)
    return MixData("smart:" + sp.id, sp.name, sp.description, songs, now, 0, cover, smart = true)
}
