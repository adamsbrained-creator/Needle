package app.needle.music.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/** The one place that answers "what songs does the person have": the scan plus their tag edits. */
object Library {
    /** Every song the scan found, with nothing left out (not even hidden songs or switched-off folders). */
    fun observeEverything(db: NeedleDatabase): Flow<List<Song>> =
        combine(db.songDao().observeAll(), db.tagDao().observeAll(), db.fileTagDao().observeCore()) { songs, edits, core ->
            applyEdits(repairGarbledText(songs, core), edits)
        }

    /** Every song except the ones hidden with "Hide from library" and those in folders that are switched off. */
    fun observe(db: NeedleDatabase): Flow<List<Song>> =
        combine(observeEverything(db), HiddenSongs.ids, ExcludedFolders.names) { songs, hidden, folders ->
            if (hidden.isEmpty() && folders.isEmpty()) songs
            else songs.filter { it.id !in hidden && (folders.isEmpty() || folderGroupOf(it.folder) !in folders) }
        }

    /** Only the hidden songs, for Settings > Library > Hidden songs. */
    fun observeHidden(db: NeedleDatabase): Flow<List<Song>> =
        combine(observeEverything(db), HiddenSongs.ids) { songs, hidden ->
            if (hidden.isEmpty()) emptyList() else songs.filter { it.id in hidden }
        }

    /** The other tags (composer, comment, sort names ...) of every song that has any. */
    fun observeExtras(db: NeedleDatabase): Flow<ExtraTags> =
        combine(db.fileTagDao().observeAll(), db.extraTagDao().observeAll()) { fromFiles, edits ->
            mergeExtras(groupFileTags(fromFiles), groupExtras(edits))
        }

    suspend fun load(db: NeedleDatabase): List<Song> =
        applyEdits(repairGarbledText(db.songDao().getAllOnce(), db.fileTagDao().getCore()), db.tagDao().getAll())
}
