package app.needle.music.widget

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.io.File

/**
 * What the home screen widgets show. The player (when a song changes, plays or pauses) and Home (the week's stats) save
 * it here, because a widget can be drawn when Needle itself is not running.
 */
object WidgetState {
    class Snapshot(
        val hasSong: Boolean,
        val title: String,
        val artist: String,
        val playing: Boolean,
        val positionMs: Long,
        val durationMs: Long,
        val listenedMs: Long,
        val plays: Int,
        /** Listening time (ms) of Monday .. Sunday this week. */
        val weekdays: List<Long>
    )

    private fun prefs(context: Context) = context.applicationContext.getSharedPreferences("needle_widget", Context.MODE_PRIVATE)

    fun savePlayer(context: Context, hasSong: Boolean, title: String, artist: String, playing: Boolean, positionMs: Long, durationMs: Long) {
        prefs(context).edit()
            .putBoolean("has_song", hasSong)
            .putString("title", title)
            .putString("artist", artist)
            .putBoolean("playing", playing)
            .putLong("position", positionMs)
            .putLong("duration", durationMs)
            .apply()
    }

    fun saveStats(context: Context, listenedMs: Long, plays: Int, weekdays: List<Long>) {
        prefs(context).edit()
            .putLong("listened", listenedMs)
            .putInt("plays", plays)
            .putString("weekdays", weekdays.joinToString(","))
            .apply()
    }

    fun load(context: Context): Snapshot {
        val p = prefs(context)
        val days = (p.getString("weekdays", "") ?: "").split(',').mapNotNull { it.toLongOrNull() }
        return Snapshot(
            hasSong = p.getBoolean("has_song", false),
            title = p.getString("title", "") ?: "",
            artist = p.getString("artist", "") ?: "",
            playing = p.getBoolean("playing", false),
            positionMs = p.getLong("position", 0L),
            durationMs = p.getLong("duration", 0L),
            listenedMs = p.getLong("listened", 0L),
            plays = p.getInt("plays", 0),
            weekdays = if (days.size == 7) days else List(7) { 0L }
        )
    }

    private fun coverFile(context: Context) = File(context.filesDir, "widget_cover.png")

    /** Keeps a small copy of the cover for the widgets; null removes it. */
    fun saveCover(context: Context, bitmap: Bitmap?) {
        val file = coverFile(context)
        if (bitmap == null) {
            file.delete()
            return
        }
        val scale = 400f / maxOf(bitmap.width, bitmap.height)
        val small = if (scale < 1f) Bitmap.createScaledBitmap(bitmap, (bitmap.width * scale).toInt(), (bitmap.height * scale).toInt(), true) else bitmap
        runCatching { file.outputStream().use { small.compress(Bitmap.CompressFormat.PNG, 100, it) } }
    }

    fun loadCover(context: Context): Bitmap? = coverFile(context).takeIf { it.exists() }?.let { runCatching { BitmapFactory.decodeFile(it.path) }.getOrNull() }
}
