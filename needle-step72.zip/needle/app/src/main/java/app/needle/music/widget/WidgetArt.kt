package app.needle.music.widget

import android.graphics.Bitmap
import android.graphics.BitmapShader
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader

/**
 * The pictures of the widgets, drawn here instead of kept as files, so they take the accent color you picked and the
 * covers get rounded corners (a widget cannot round an image on its own on older Android).
 */
object WidgetArt {
    private fun paint() = Paint(Paint.ANTI_ALIAS_FLAG)

    /** The cover as a rounded square; without a cover, a soft gradient of the accent color. */
    fun cover(src: Bitmap?, sizePx: Int, radiusPx: Float, accent: Int): Bitmap {
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(out)
        val p = paint()
        if (src != null) {
            val shader = BitmapShader(src, Shader.TileMode.CLAMP, Shader.TileMode.CLAMP)
            val scale = maxOf(sizePx.toFloat() / src.width, sizePx.toFloat() / src.height)
            val m = Matrix()
            m.setScale(scale, scale)
            m.postTranslate((sizePx - src.width * scale) / 2f, (sizePx - src.height * scale) / 2f)
            shader.setLocalMatrix(m)
            p.shader = shader
        } else {
            p.shader = LinearGradient(0f, 0f, sizePx.toFloat(), sizePx.toFloat(), accent, 0xFFEF42B8.toInt(), Shader.TileMode.CLAMP)
        }
        canvas.drawRoundRect(RectF(0f, 0f, sizePx.toFloat(), sizePx.toFloat()), radiusPx, radiusPx, p)
        return out
    }

    /** A round accent button with a white play or pause sign. */
    fun playButton(playing: Boolean, accent: Int, sizePx: Int): Bitmap {
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = paint()
        p.color = accent
        c.drawCircle(sizePx / 2f, sizePx / 2f, sizePx / 2f, p)
        p.color = Color.WHITE
        val s = sizePx.toFloat()
        if (playing) {
            val w = s * 0.11f
            val h = s * 0.34f
            c.drawRoundRect(RectF(s / 2 - w * 1.7f, s / 2 - h / 2, s / 2 - w * 0.7f, s / 2 + h / 2), w / 3, w / 3, p)
            c.drawRoundRect(RectF(s / 2 + w * 0.7f, s / 2 - h / 2, s / 2 + w * 1.7f, s / 2 + h / 2), w / 3, w / 3, p)
        } else {
            val path = Path()
            path.moveTo(s * 0.40f, s * 0.30f)
            path.lineTo(s * 0.72f, s * 0.50f)
            path.lineTo(s * 0.40f, s * 0.70f)
            path.close()
            c.drawPath(path, p)
        }
        return out
    }

    /** Previous or next: a triangle and a bar, white, no background. */
    fun skipButton(next: Boolean, sizePx: Int): Bitmap {
        val out = Bitmap.createBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = paint()
        p.color = Color.argb(230, 255, 255, 255)
        val s = sizePx.toFloat()
        val path = Path()
        if (next) {
            path.moveTo(s * 0.30f, s * 0.30f); path.lineTo(s * 0.62f, s * 0.50f); path.lineTo(s * 0.30f, s * 0.70f); path.close()
            c.drawRoundRect(RectF(s * 0.66f, s * 0.30f, s * 0.72f, s * 0.70f), s * 0.02f, s * 0.02f, p)
        } else {
            path.moveTo(s * 0.70f, s * 0.30f); path.lineTo(s * 0.38f, s * 0.50f); path.lineTo(s * 0.70f, s * 0.70f); path.close()
            c.drawRoundRect(RectF(s * 0.28f, s * 0.30f, s * 0.34f, s * 0.70f), s * 0.02f, s * 0.02f, p)
        }
        c.drawPath(path, p)
        return out
    }

    /** A thin progress bar: a faint track and the accent color up to [fraction]. */
    fun progress(fraction: Float, accent: Int, widthPx: Int, heightPx: Int): Bitmap {
        val out = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = paint()
        val r = heightPx / 2f
        p.color = Color.argb(46, 255, 255, 255)
        c.drawRoundRect(RectF(0f, 0f, widthPx.toFloat(), heightPx.toFloat()), r, r, p)
        val w = widthPx * fraction.coerceIn(0f, 1f)
        if (w > 0f) {
            p.color = accent
            c.drawRoundRect(RectF(0f, 0f, maxOf(w, heightPx.toFloat()), heightPx.toFloat()), r, r, p)
        }
        return out
    }

    /** Seven bars for Monday to Sunday with their letters; the busiest day is solid, the others lighter. */
    fun weekBars(values: List<Long>, accent: Int, widthPx: Int, heightPx: Int, density: Float): Bitmap {
        val out = Bitmap.createBitmap(widthPx, heightPx, Bitmap.Config.ARGB_8888)
        val c = Canvas(out)
        val p = paint()
        val letters = listOf("M", "T", "W", "T", "F", "S", "S")
        val label = 10f * density
        val text = paint().apply {
            color = Color.argb(160, 255, 255, 255)
            textSize = label
            textAlign = Paint.Align.CENTER
        }
        val max = (values.maxOrNull() ?: 0L).coerceAtLeast(1L)
        val busiest = values.indexOf(values.maxOrNull() ?: 0L)
        val gap = widthPx * 0.04f
        val barW = (widthPx - gap * 6) / 7f
        val chartH = heightPx - label - 6f * density
        for (i in 0 until 7) {
            val v = values.getOrElse(i) { 0L }
            val h = maxOf(4f * density, chartH * v / max)
            val left = i * (barW + gap)
            p.color = if (i == busiest && v > 0) accent else Color.argb(110, Color.red(accent), Color.green(accent), Color.blue(accent))
            c.drawRoundRect(RectF(left, chartH - h, left + barW, chartH), barW / 3, barW / 3, p)
            c.drawText(letters[i], left + barW / 2, heightPx - 1f * density, text)
        }
        return out
    }
}
