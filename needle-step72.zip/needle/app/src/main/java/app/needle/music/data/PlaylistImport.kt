package app.needle.music.data

import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What reading a playlist file found: its name, the songs of your library it matched, and how many lines it had. */
class ImportResult(val name: String, val songIds: List<Long>, val total: Int)

private class Entry(val path: String, val label: String)

/**
 * Reads an .m3u / .m3u8 playlist and finds each of its songs in the library, first by file name (and folder, when
 * several files share a name), then by the "Artist - Title" of its #EXTINF line. Lines that are web addresses or
 * songs that are not on this phone are skipped, and the result says how many it matched out of how many.
 */
suspend fun importM3u(context: Context, uri: Uri, songs: List<Song>): ImportResult = withContext(Dispatchers.IO) {
    val resolver = context.contentResolver

    val fileName = runCatching {
        resolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) c.getString(0) else null
        }
    }.getOrNull()
    val name = (fileName ?: "Imported playlist").substringBeforeLast('.').trim().ifEmpty { "Imported playlist" }

    val text = resolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }.orEmpty().removePrefix("\uFEFF")

    // ---- the lines of the file ----
    val entries = ArrayList<Entry>()
    var label = ""
    for (raw in text.lineSequence()) {
        val line = raw.trim()
        when {
            line.isEmpty() -> {}
            line.startsWith("#EXTINF", ignoreCase = true) -> label = line.substringAfter(',', "").trim()
            line.startsWith("#") -> {}
            else -> {
                entries += Entry(line, label)
                label = ""
            }
        }
    }

    // ---- every audio file on the phone, by file name ----
    class File(val id: Long, val path: String)   // path = lower case "folder/name"
    val byName = HashMap<String, MutableList<File>>()
    val visible = songs.mapTo(HashSet()) { it.id }
    val withFolder = Build.VERSION.SDK_INT >= 29   // RELATIVE_PATH exists from Android 10; before that the name alone matches
    val projection = ArrayList<String>().apply {
        add(MediaStore.Audio.Media._ID)
        add(MediaStore.Audio.Media.DISPLAY_NAME)
        if (withFolder) add(MediaStore.Audio.Media.RELATIVE_PATH)
    }.toTypedArray()
    runCatching {
        resolver.query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, projection, null, null, null)?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (id !in visible) continue
                val display = c.getString(1) ?: continue
                val folder = if (withFolder) c.getString(2).orEmpty() else ""
                byName.getOrPut(display.lowercase()) { ArrayList() } += File(id, (folder + display).replace('\\', '/').lowercase())
            }
        }
    }

    // ---- the songs by "artist - title" and by title, for lines whose file name did not match ----
    val byLabel = HashMap<String, Long>()
    val byTitle = HashMap<String, MutableList<Long>>()
    for (s in songs) {
        byLabel["${artistKey(s.artist)} - ${s.title.trim().lowercase()}"] = s.id
        byTitle.getOrPut(s.title.trim().lowercase()) { ArrayList() } += s.id
    }

    val found = LinkedHashSet<Long>()
    for (e in entries) {
        if (e.path.contains("://") && !e.path.startsWith("file://", ignoreCase = true)) continue   // a web address
        val normal = e.path.removePrefix("file://").replace('\\', '/').lowercase()
        val base = normal.substringAfterLast('/')
        var id: Long? = null

        val candidates = byName[base]
        if (candidates != null) {
            id = if (candidates.size == 1) candidates[0].id
            else candidates.maxByOrNull { commonSuffix(it.path, normal) }?.id
        }
        if (id == null && e.label.isNotEmpty()) {
            val lower = e.label.lowercase()
            val artist = lower.substringBefore(" - ", "")
            val title = lower.substringAfter(" - ", lower)
            id = byLabel["${artistKey(artist)} - ${title.trim()}"]
                ?: byTitle[title.trim()]?.singleOrNull()
        }
        if (id == null) {
            // "Artist - Title.mp3" with no EXTINF line
            val stem = base.substringBeforeLast('.')
            id = byLabel["${artistKey(stem.substringBefore(" - ", ""))} - ${stem.substringAfter(" - ", stem).trim()}"]
        }
        if (id != null) found += id
    }
    ImportResult(name, found.toList(), entries.size)
}

/** How many characters two paths share at their ends. */
private fun commonSuffix(a: String, b: String): Int {
    var n = 0
    while (n < a.length && n < b.length && a[a.length - 1 - n] == b[b.length - 1 - n]) n++
    return n
}

/**
 * Writes [songs] as an .m3u8 playlist (UTF-8) to [uri], with the duration and "Artist - Title" of each song and its
 * path relative to the phone's storage ("Music/Indie/Song.flac"), which players on a computer can usually resolve.
 * Returns how many songs were written.
 */
suspend fun exportM3u(context: Context, uri: Uri, songs: List<Song>): Int = withContext(Dispatchers.IO) {
    val resolver = context.contentResolver
    val wanted = songs.mapTo(HashSet()) { it.id }
    val withFolder = Build.VERSION.SDK_INT >= 29
    @Suppress("DEPRECATION")
    val third = if (withFolder) MediaStore.Audio.Media.RELATIVE_PATH else MediaStore.Audio.Media.DATA
    val paths = HashMap<Long, String>()
    runCatching {
        resolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DISPLAY_NAME, third), null, null, null
        )?.use { c ->
            while (c.moveToNext()) {
                val id = c.getLong(0)
                if (id !in wanted) continue
                val name = c.getString(1) ?: continue
                val where = c.getString(2).orEmpty()
                // Android 10+: "Music/Indie/" + name. Older: the full path is in the third column already.
                paths[id] = if (withFolder) where + name else where.ifEmpty { name }
            }
        }
    }
    val text = StringBuilder("#EXTM3U\n")
    var written = 0
    for (s in songs) {
        val path = paths[s.id] ?: continue
        text.append("#EXTINF:").append(s.durationMs / 1000).append(',').append(s.artist).append(" - ").append(s.title).append('\n')
        text.append(path).append('\n')
        written++
    }
    resolver.openOutputStream(uri, "wt")?.use { it.write(text.toString().toByteArray(Charsets.UTF_8)) }
    written
}
