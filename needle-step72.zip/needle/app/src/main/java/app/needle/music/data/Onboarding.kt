package app.needle.music.data

import android.Manifest
import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.mutableStateOf
import androidx.core.content.ContextCompat

/**
 * Whether the first-launch screens (Welcome, the music permission, the first scan) were already seen. Someone who
 * updates from an older Needle and already gave access never sees them: that counts as seen.
 */
object Onboarding {
    /** The Welcome screen (accent pick) and the permission screen after it. */
    val welcomeDone = mutableStateOf(true)

    /** The "Scanning your library" screen that follows the first permission. */
    val scanIntroDone = mutableStateOf(true)

    /** "Not now" was chosen on the permission screen: Needle opens without music and the Songs page offers access again. */
    val permissionDeferred = mutableStateOf(false)

    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        if (!p.contains("welcome_done")) {
            val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
            val already = ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
            p.edit().putBoolean("welcome_done", already).putBoolean("scan_intro_done", already).apply()
        }
        welcomeDone.value = p.getBoolean("welcome_done", true)
        scanIntroDone.value = p.getBoolean("scan_intro_done", true)
        permissionDeferred.value = p.getBoolean("permission_deferred", false)
    }

    fun setPermissionDeferred(on: Boolean) {
        if (permissionDeferred.value == on) return
        permissionDeferred.value = on
        prefs?.edit()?.putBoolean("permission_deferred", on)?.apply()
    }

    fun finishWelcome() {
        welcomeDone.value = true
        prefs?.edit()?.putBoolean("welcome_done", true)?.apply()
    }

    fun finishScanIntro() {
        scanIntroDone.value = true
        prefs?.edit()?.putBoolean("scan_intro_done", true)?.apply()
    }
}
