package app.needle.music.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.zIndex
import androidx.media3.common.Player
import app.needle.music.data.Song
import app.needle.music.playback.PlayerViewModel
import app.needle.music.playback.QueueEntry
import kotlinx.coroutines.delay

/** Every row of Up next is this tall, which keeps the drag maths simple. */
private val RowHeight = 60.dp

private enum class QueueSort { REVERSE, TITLE, ARTIST }

/**
 * The queue: what is playing, then the songs that come next.
 * Tap a song to jump to it, X to take it out. Press and hold the dots and drag to change the order.
 * [playingFrom] is the name of the album, playlist or artist the queue was started from (null = unknown).
 */
@Composable
fun QueueScreen(
    vm: PlayerViewModel,
    songs: List<Song>,
    playingFrom: String?,
    onClose: () -> Unit,
    onSleepTimer: () -> Unit,
    onSaveQueue: () -> Unit,
    modifier: Modifier = Modifier
) {
    val byId = remember(songs) { songs.associateBy { it.id } }

    // Every song that comes after the playing song, in playback order. The list is lazy, so a long queue is fine.
    val fromPlayer = remember(vm.queueVersion, vm.currentMediaId, vm.shuffleEnabled) { vm.upNext(Int.MAX_VALUE) }
    val upcomingMs = remember(fromPlayer, byId) {
        fromPlayer.sumOf { byId[it.mediaId.toLongOrNull() ?: -1L]?.durationMs ?: 0L }
    }

    // The order on screen. After a drop it shows the new order at once, until the player confirms it.
    val order = remember { mutableStateOf(fromPlayer) }
    var awaiting by remember { mutableStateOf(false) }
    val latestFromPlayer by rememberUpdatedState(fromPlayer)
    LaunchedEffect(fromPlayer) {
        order.value = fromPlayer
        awaiting = false
    }
    LaunchedEffect(awaiting) {
        // If the player never confirms (it refused the change), fall back to what it really has.
        if (awaiting) {
            delay(2000)
            order.value = latestFromPlayer
            awaiting = false
        }
    }
    val list = order.value

    // Drag state
    val listState = rememberLazyListState()
    var dragKey by remember { mutableStateOf<Int?>(null) }
    var dragOffset by remember { mutableFloatStateOf(0f) }
    val rowPx = with(LocalDensity.current) { RowHeight.toPx() }
    val haptic = LocalHapticFeedback.current
    var showSort by remember { mutableStateOf(false) }

    // While a row is held, swap it with its neighbour each time it moves half a row past it.
    fun settleDrag() {
        val key = dragKey ?: return
        var current = order.value
        var i = current.indexOfFirst { it.index == key }
        if (i < 0) return
        var off = dragOffset
        while (off > rowPx / 2 && i < current.lastIndex) {
            val next = current.toMutableList()
            next.add(i + 1, next.removeAt(i))
            current = next
            i += 1
            off -= rowPx
        }
        while (off < -rowPx / 2 && i > 0) {
            val next = current.toMutableList()
            next.add(i - 1, next.removeAt(i))
            current = next
            i -= 1
            off += rowPx
        }
        if (i == current.lastIndex) off = off.coerceAtMost(0f)
        if (i == 0) off = off.coerceAtLeast(0f)
        if (current !== order.value) order.value = current
        dragOffset = off
    }

    fun commit(newOrder: List<QueueEntry>) {
        if (newOrder.map { it.index } == latestFromPlayer.map { it.index }) return
        order.value = newOrder
        awaiting = true
        vm.reorderUpNext(newOrder.map { it.index })
    }

    fun endDrag() {
        dragKey = null
        dragOffset = 0f
        commit(order.value)
    }

    // Scroll by itself when a row is held near the top or bottom edge.
    val dragging = dragKey != null
    LaunchedEffect(dragging) {
        if (!dragging) return@LaunchedEffect
        while (true) {
            withFrameNanos { }
            val key = dragKey ?: break
            val info = listState.layoutInfo
            val item = info.visibleItemsInfo.firstOrNull { it.key == key } ?: continue
            val top = item.offset + dragOffset
            val bottom = top + item.size
            val zone = rowPx
            val speed = when {
                bottom > info.viewportEndOffset - zone ->
                    ((bottom - (info.viewportEndOffset - zone)) / zone).coerceIn(0f, 1f) * 34f
                top < info.viewportStartOffset + zone ->
                    -((info.viewportStartOffset + zone - top) / zone).coerceIn(0f, 1f) * 34f
                else -> 0f
            }
            if (speed != 0f) {
                val used = listState.scrollBy(speed)
                dragOffset += used
                settleDrag()
            }
        }
    }

    // Header numbers
    val live = rememberLivePositionMs(vm, poll = true)
    val leftMinutes by remember(upcomingMs) {
        derivedStateOf {
            val ms = upcomingMs + (vm.durationMs - live.value).coerceAtLeast(0L)
            ((ms + 59_999L) / 60_000L).toInt()
        }
    }
    val subtitle = buildList {
        if (!playingFrom.isNullOrBlank()) add("Playing from $playingFrom")
        add(if (vm.queueSize == 1) "1 song" else "${vm.queueSize} songs")
        if (leftMinutes > 0) add(if (leftMinutes >= 60) "${leftMinutes / 60} h ${leftMinutes % 60} min left" else "$leftMinutes min left")
    }.joinToString(" \u00B7 ")

    val applySort: (QueueSort) -> Unit = { how ->
        val cur = order.value
        val sorted = when (how) {
            QueueSort.REVERSE -> cur.reversed()
            QueueSort.TITLE -> cur.sortedBy { it.title.lowercase() }
            QueueSort.ARTIST -> cur.sortedWith(compareBy<QueueEntry>({ it.artist.lowercase() }, { it.title.lowercase() }))
        }
        showSort = false
        commit(sorted)
    }

    Box(modifier.safeDrawingPadding()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            state = listState,
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 24.dp)
        ) {
            item("top") {
                Row(Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(NeedleIcon.BACK, onClose, size = 38.dp, iconSize = 20.dp)
                    Spacer(Modifier.weight(1f))
                    RoundIconButton(NeedleIcon.TIMER, onSleepTimer, size = 38.dp, iconSize = 20.dp)
                    Spacer(Modifier.width(10.dp))
                    RoundIconButton(NeedleIcon.SORT, { showSort = true }, size = 38.dp, iconSize = 20.dp, active = showSort)
                }
            }
            item("title") {
                Column(Modifier.padding(top = 4.dp, bottom = 14.dp)) {
                    Text("Queue", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                    Text(subtitle, color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
            item("playing") { QueueNowPlaying(vm, live) }

            if (list.isEmpty()) {
                item("empty") {
                    Text(
                        "Nothing is queued after this song.",
                        color = Palette.Muted, fontSize = 14.sp,
                        modifier = Modifier.padding(horizontal = 2.dp, vertical = 20.dp)
                    )
                }
            } else {
                item("next_label") {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 16.dp, bottom = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text("Next up", color = Palette.Muted, fontSize = 13.sp)
                        Text("Hold and drag to reorder", color = Palette.Muted, fontSize = 13.sp)
                    }
                }
                itemsIndexed(list, key = { _, e -> e.index }) { _, entry ->
                    val held = dragKey == entry.index
                    QueueRow(
                        entry = entry,
                        song = entry.mediaId.toLongOrNull()?.let { byId[it] },
                        dragging = held,
                        offset = { dragOffset },
                        onJump = { vm.jumpTo(entry.index) },
                        onRemove = { vm.removeFromQueue(entry.index) },
                        onDragStart = {
                            if (!awaiting) {
                                dragKey = entry.index
                                dragOffset = 0f
                                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            }
                        },
                        onDrag = { dy ->
                            if (dragKey == entry.index) {
                                dragOffset += dy
                                settleDrag()
                            }
                        },
                        onDragEnd = { if (dragKey == entry.index) endDrag() },
                        modifier = if (held) Modifier else Modifier.animateItem()
                    )
                }
            }

            item("actions") {
                Column(Modifier.padding(top = 12.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        QueueButton(
                            "Shuffle", NeedleIcon.SHUFFLE, vm.shuffleEnabled, { vm.toggleShuffle() },
                            Modifier.weight(1f)
                        )
                        QueueButton(
                            if (vm.repeatMode == Player.REPEAT_MODE_ONE) "Repeat 1" else "Repeat",
                            NeedleIcon.REPEAT, vm.repeatMode != Player.REPEAT_MODE_OFF, { vm.cycleRepeat() },
                            Modifier.weight(1f)
                        )
                        QueueButton("Clear", NeedleIcon.TRASH, false, { vm.clearUpNext() }, Modifier.weight(1f))
                    }
                    Spacer(Modifier.height(10.dp))
                    QueueButton(
                        "Save queue as playlist", null, false, onSaveQueue,
                        Modifier.fillMaxWidth(), filled = true
                    )
                }
            }
        }

        if (showSort) QueueSortMenu(onPick = applySort, onDismiss = { showSort = false })
    }
}

// ---- pieces ------------------------------------------------------------------------------------------

/** The card for the song that is playing: its cover, name, a thin progress line and little moving bars. */
@Composable
private fun QueueNowPlaying(vm: PlayerViewModel, live: State<Long>) {
    val shape = cornerShape(26.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Accent.copy(alpha = 0.45f), Color.White.copy(alpha = 0.06f))))
            .border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val art = vm.artwork
        Box(Modifier.size(62.dp).clip(cornerShape(16.dp))) {
            if (art != null) {
                Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                ArtworkPlaceholder(Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                vm.title.orEmpty(), color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.artist.orEmpty(), color = Color(0xFFD8CDF5), fontSize = 12.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            // The progress is only read while drawing, so it never recomposes the page
            Box(
                Modifier
                    .padding(top = 8.dp)
                    .fillMaxWidth()
                    .height(4.dp)
                    .clip(CircleShape)
                    .background(Color.White.copy(alpha = 0.25f))
                    .drawBehind {
                        val total = vm.durationMs
                        val f = if (total > 0) (live.value.toFloat() / total).coerceIn(0f, 1f) else 0f
                        drawRect(Color.White, size = Size(size.width * f, size.height))
                    }
            )
        }
        Spacer(Modifier.width(12.dp))
        QueueBars(vm.isPlaying)
    }
}

/** Three little bars that dance while the song plays and rest when it is paused. */
@Composable
private fun QueueBars(active: Boolean) {
    val transition = rememberInfiniteTransition(label = "queue_bars")
    val a by transition.animateFloat(
        5f, 20f, infiniteRepeatable(tween(520), RepeatMode.Reverse, StartOffset(0)), label = "a"
    )
    val b by transition.animateFloat(
        5f, 20f, infiniteRepeatable(tween(520), RepeatMode.Reverse, StartOffset(170)), label = "b"
    )
    val c by transition.animateFloat(
        5f, 20f, infiniteRepeatable(tween(520), RepeatMode.Reverse, StartOffset(340)), label = "c"
    )
    Row(Modifier.height(22.dp), horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.Bottom) {
        listOf(a, b, c).forEachIndexed { i, h ->
            val rest = floatArrayOf(10f, 16f, 7f)[i]
            Box(
                Modifier
                    .width(4.dp)
                    .height((if (active) h else rest).dp)
                    .clip(cornerShape(2.dp))
                    .background(Color.White)
            )
        }
    }
}

/** One song in Up next. Drag handle on the left, X on the right, tap anywhere between to jump to the song. */
@Composable
private fun QueueRow(
    entry: QueueEntry,
    song: Song?,
    dragging: Boolean,
    offset: () -> Float,
    onJump: () -> Unit,
    onRemove: () -> Unit,
    onDragStart: () -> Unit,
    onDrag: (Float) -> Unit,
    onDragEnd: () -> Unit,
    modifier: Modifier = Modifier
) {
    val startNow by rememberUpdatedState(onDragStart)
    val dragNow by rememberUpdatedState(onDrag)
    val endNow by rememberUpdatedState(onDragEnd)

    Row(
        modifier
            .fillMaxWidth()
            .height(RowHeight)
            .zIndex(if (dragging) 1f else 0f)
            .graphicsLayer { translationY = if (dragging) offset() else 0f }
            .then(if (dragging) Modifier.background(Palette.Surface.copy(alpha = 0.94f), cornerShape(16.dp)) else Modifier),
        verticalAlignment = Alignment.CenterVertically
    ) {
        // The handle: press and hold, then drag
        Box(
            Modifier
                .width(34.dp)
                .fillMaxHeight()
                .pointerInput(Unit) {
                    detectDragGesturesAfterLongPress(
                        onDragStart = { startNow() },
                        onDrag = { change, amount ->
                            change.consume()
                            dragNow(amount.y)
                        },
                        onDragEnd = { endNow() },
                        onDragCancel = { endNow() }
                    )
                },
            contentAlignment = Alignment.Center
        ) { GripDots() }

        Row(
            Modifier.weight(1f).fillMaxHeight().clickable(onClick = onJump),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (song != null) {
                SongArtwork(song, size = 44.dp, corner = 12.dp)
            } else {
                ArtworkPlaceholder(Modifier.size(44.dp).clip(cornerShape(12.dp)))
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    entry.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (song != null) "${entry.artist} \u00B7 ${formatTime(song.durationMs)}" else entry.artist,
                    color = Palette.Muted, fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        CloseButton(onClick = onRemove)
    }
}

/** Six little dots: the "hold here to drag" handle. */
@Composable
private fun GripDots() {
    Canvas(Modifier.size(width = 14.dp, height = 22.dp)) {
        val r = 1.6.dp.toPx()
        for (row in 0..2) {
            for (col in 0..1) {
                drawCircle(
                    Palette.Muted, r,
                    Offset(size.width * (0.25f + 0.5f * col), size.height * (0.15f + 0.35f * row))
                )
            }
        }
    }
}

/** The outlined pill buttons under the list. [active] lights up Shuffle and Repeat; [filled] is the white one. */
@Composable
private fun QueueButton(
    label: String,
    icon: NeedleIcon?,
    active: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    filled: Boolean = false
) {
    val bg = when {
        filled -> Color.White
        active -> Palette.Accent.copy(alpha = 0.28f)
        else -> Color.Transparent
    }
    val fg = if (filled) Color(0xFF111111) else Palette.Text
    val borderColor = if (active) Palette.Accent else Color.White.copy(alpha = 0.55f)
    Row(
        modifier
            .height(42.dp)
            .clip(CircleShape)
            .background(bg)
            .then(if (filled) Modifier else Modifier.border(1.dp, borderColor, CircleShape))
            .clickable(onClick = onClick)
            .padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (icon != null) {
            NeedleIconView(icon, fg, size = 17.dp)
            Spacer(Modifier.width(6.dp))
        }
        Text(
            label, color = fg, fontSize = if (filled) 14.sp else 13.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}

/** The small menu under the sort button. It reorders every song in Next up. */
@Composable
private fun QueueSortMenu(onPick: (QueueSort) -> Unit, onDismiss: () -> Unit) {
    Box(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { onDismiss() } }) {
        val shape = cornerShape(20.dp)
        Column(
            Modifier
                .align(Alignment.TopEnd)
                .padding(top = 54.dp, end = 16.dp)
                .width(210.dp)
                .clip(shape)
                .background(Palette.Surface)
                .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
                .pointerInput(Unit) { detectTapGestures { } }
                .padding(vertical = 6.dp)
        ) {
            listOf(
                QueueSort.REVERSE to "Reverse order",
                QueueSort.TITLE to "Title A\u2013Z",
                QueueSort.ARTIST to "Artist A\u2013Z"
            ).forEach { (how, label) ->
                Text(
                    label, color = Palette.Text, fontSize = 15.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onPick(how) }
                        .padding(horizontal = 18.dp, vertical = 13.dp)
                )
            }
        }
    }
}
