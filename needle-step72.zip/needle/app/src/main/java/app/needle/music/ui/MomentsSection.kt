package app.needle.music.ui

import android.content.Context
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.LyricsQuery
import app.needle.music.data.LyricsRepository
import app.needle.music.data.MomentNote
import app.needle.music.data.MomentNotes
import app.needle.music.data.Song
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * "Latest Moments" from the mockup, a shelf at the top of Home: a row of round covers (what you played or added
 * last, and songs you gave a note or photo), and under it one big card for the chosen one:
 *  - Album moment: the cover, large.
 *  - Lyric moment: a line from the song's lyrics (only lyrics already on the phone), on top of the cover.
 *  - Photo or note moment: your photo and your note.
 * The "+" adds or edits your own note and photo for the chosen song. Tap the card to play it.
 */
@Composable
fun MomentsSection(
    songs: List<Song>,
    player: PlayerViewModel?,
    onPlay: (Song) -> Unit,
    onAddToPlaylist: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    if (songs.isEmpty()) return
    val notes by MomentNotes.notes.collectAsState()
    var selected by rememberSaveable { mutableStateOf(0) }
    val index = selected.coerceIn(0, songs.lastIndex)
    val song = songs[index]
    val note = notes[song.id]
    var editing by remember { mutableStateOf(false) }

    Column(modifier.fillMaxWidth()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 18.dp, bottom = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("Latest Moments", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
            Box(
                Modifier.size(34.dp).glassCircle().clickable { editing = true },
                contentAlignment = Alignment.Center
            ) { Text("+", color = Palette.Text, fontSize = 20.sp) }
        }

        LazyRow(
            contentPadding = PaddingValues(horizontal = 18.dp),
            horizontalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            itemsIndexed(songs, key = { _, s -> s.id }) { i, s ->
                val on = i == index
                Box(
                    Modifier
                        .size(66.dp)
                        .then(if (on) Modifier.border(2.5.dp, Palette.Accent, CircleShape) else Modifier)
                        .padding(if (on) 4.dp else 2.dp)
                        .clickable { selected = i },
                    contentAlignment = Alignment.Center
                ) { SongArtwork(s, size = if (on) 58.dp else 62.dp, corner = 31.dp) }
            }
        }

        MomentCard(song, note, player, onPlay = { onPlay(song) }, onAddToPlaylist = { onAddToPlaylist(song) })
    }

    if (editing) {
        MomentEditor(song, note, onDismiss = { editing = false })
    }
}

@Composable
private fun MomentCard(song: Song, note: MomentNote?, player: PlayerViewModel?, onPlay: () -> Unit, onAddToPlaylist: () -> Unit) {
    val context = LocalContext.current
    val photo = rememberPhoto(note?.photoUri)

    // A line of the song's lyrics, from what is already on the phone (a .lrc file, the tags, the file itself, or saved).
    var lyric by remember(song.id) { mutableStateOf<Pair<String, String?>?>(null) }
    LaunchedEffect(song.id, note?.text) {
        lyric = if (note != null) null else runCatching {
            val found = LyricsRepository(context).local(LyricsQuery(song.id, song.title, song.artist, song.album, song.durationMs))
            val lines = found?.lines?.map { it.text.trim() }?.filter { it.length in 12..90 }.orEmpty()
            if (lines.isEmpty()) null else {
                // The same line all day for a song, from the middle of it (the first lines are often the intro).
                val day = System.currentTimeMillis() / 86_400_000L
                val start = lines.size / 4
                val span = (lines.size - start).coerceAtLeast(1)
                val i = start + ((song.id + day).mod(span.toLong())).toInt()
                lines[i] to lines.getOrNull(i + 1)
            }
        }.getOrNull()
    }

    val isCurrent = player != null && player.currentMediaId == song.id.toString()
    Box(
        Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 14.dp)
            .height(330.dp)
            .clip(cornerShape(32.dp))
            .background(Color(0xFF1A1A1E))
            .clickable(onClick = onPlay)
    ) {
        // The picture: your photo if you added one, else the cover.
        if (photo != null) {
            Image(photo, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            Cover(song, Modifier.fillMaxSize())
        }
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.10f), Color.Black.copy(alpha = 0.25f), Color.Black.copy(alpha = 0.78f)))
            )
        )

        // Lyric line or note, in the upper part of the card.
        when {
            note != null && note.text.isNotBlank() -> Text(
                note.text, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 4, overflow = TextOverflow.Ellipsis,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .padding(18.dp)
                    .clip(cornerShape(20.dp))
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 14.dp, vertical = 10.dp)
            )
            lyric != null -> Column(Modifier.align(Alignment.TopStart).padding(start = 22.dp, end = 22.dp, top = 24.dp)) {
                Text(
                    lyric!!.first, color = Color.White, fontFamily = Palette.TitleFont, fontSize = 24.sp, lineHeight = 29.sp,
                    maxLines = 4, overflow = TextOverflow.Ellipsis
                )
                lyric!!.second?.let {
                    Text(it, color = Color.White.copy(alpha = 0.75f), fontSize = 14.sp, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                }
            }
        }

        // The song, at the bottom of the card.
        Column(
            Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(14.dp)
                .glass(cornerShape(24.dp))
                .padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(song.title, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song.artist, color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Palette.Accent.copy(alpha = 0.85f)).clickable(onClick = onAddToPlaylist),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.ADD_QUEUE, Color.White, size = 20.dp) }
            }
            if (isCurrent && player != null && player.durationMs > 0) {
                val pos by rememberLivePositionMs(player, poll = true)
                Row(Modifier.fillMaxWidth().padding(top = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(clock(pos), color = Palette.Muted, fontSize = 11.sp)
                    Box(Modifier.weight(1f).padding(horizontal = 8.dp).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth((pos.toFloat() / player.durationMs).coerceIn(0f, 1f)).background(Palette.Accent))
                    }
                    Text("-" + clock((player.durationMs - pos).coerceAtLeast(0)), color = Palette.Muted, fontSize = 11.sp)
                }
            }
        }
    }
}

private fun clock(ms: Long): String {
    val s = (ms / 1000).toInt()
    return "%d:%02d".format(s / 60, s % 60)
}

/** Add, change or remove your own note and photo for a song. */
@Composable
private fun MomentEditor(song: Song, existing: MomentNote?, onDismiss: () -> Unit) {
    val context = LocalContext.current
    var text by remember { mutableStateOf(existing?.text.orEmpty()) }
    var photo by remember { mutableStateOf(existing?.photoUri) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            // Keep the permission to read it, so the photo is still there after a restart.
            runCatching { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) }
            photo = uri.toString()
        }
    }
    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Moment for ${song.title}") },
        text = {
            Column {
                OutlinedTextField(
                    value = text, onValueChange = { text = it.take(140) },
                    placeholder = { Text("Where were you? What does it remind you of?", color = Palette.Muted) },
                    maxLines = 3, modifier = Modifier.fillMaxWidth()
                )
                Spacer(Modifier.height(12.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        if (photo == null) "Add a photo" else "Change photo", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clip(CircleShape).clickable { picker.launch(arrayOf("image/*")) }.padding(horizontal = 12.dp, vertical = 8.dp)
                    )
                    if (photo != null) {
                        Text(
                            "Remove photo", color = Palette.Muted, fontSize = 14.sp,
                            modifier = Modifier.clip(CircleShape).clickable { photo = null }.padding(horizontal = 12.dp, vertical = 8.dp)
                        )
                    }
                }
                Text("Stays on this phone. It shows on the Latest Moments card of this song.", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            }
        },
        confirmButton = {
            TextButton(onClick = { MomentNotes.set(song.id, text, photo); onDismiss() }) { Text("Save", color = Palette.Accent) }
        },
        dismissButton = {
            Row {
                if (existing != null) TextButton(onClick = { MomentNotes.remove(song.id); onDismiss() }) { Text("Remove", color = Palette.Muted) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) }
            }
        }
    )
}

/** The photo a moment points to, decoded smaller than the screen. null while it loads, or if it is gone. */
@Composable
private fun rememberPhoto(uri: String?): ImageBitmap? {
    val context = LocalContext.current
    var bitmap by remember(uri) { mutableStateOf<ImageBitmap?>(null) }
    LaunchedEffect(uri) {
        bitmap = if (uri == null) null else withContext(Dispatchers.IO) { runCatching { decodePhoto(context, Uri.parse(uri)) }.getOrNull() }
    }
    return bitmap
}

private fun decodePhoto(context: Context, uri: Uri): ImageBitmap? {
    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
    context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
    var sample = 1
    while (bounds.outWidth / sample > 1600 || bounds.outHeight / sample > 1600) sample *= 2
    val options = BitmapFactory.Options().apply { inSampleSize = sample }
    return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }?.asImageBitmap()
}
