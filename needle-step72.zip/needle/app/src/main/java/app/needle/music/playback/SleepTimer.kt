package app.needle.music.playback

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlin.math.ceil

/**
 * The sleep timer. It runs inside the playback service (the service gives it the player), so it keeps counting when
 * the app is closed or the screen is off. The Sleep timer page just starts it and shows its state.
 *
 * Three ways to stop the music: after some minutes, at the end of the song, or at the end of the album.
 */
object SleepTimer {
    enum class Mode { OFF, TIME, SONG, ALBUM }

    // ---- what the screen shows ----
    val mode = mutableStateOf(Mode.OFF)
    val remainingMs = mutableLongStateOf(0L)
    val totalMs = mutableLongStateOf(0L)
    /** The minutes of the chip the timer was started from (5, 10 ...), or 0 after "Add 5 minutes". */
    val chipMinutes = mutableIntStateOf(0)
    /** The time is up, but the song is allowed to finish first. */
    val finishing = mutableStateOf(false)

    // ---- settings (remembered) ----
    val fadeOut = mutableStateOf(true)
    val finishSong = mutableStateOf(false)

    private const val FADE_MS = 30_000L

    private var prefs: android.content.SharedPreferences? = null
    private var player: ExoPlayer? = null
    private val handler = Handler(Looper.getMainLooper())
    private var endAt = 0L
    private var savedVolume = 1f
    private var fading = false

    /** True while the sleep timer is fading the music out (nothing else may touch the volume then). */
    val isFading: Boolean get() = fading

    /** "Off", "19:42 left", "End of song", "End of album" */
    val summary: String
        get() = when (mode.value) {
            Mode.OFF -> "Off"
            Mode.TIME -> if (finishing.value) "Finishing song" else clock(remainingMs.longValue) + " left"
            Mode.SONG -> "End of song"
            Mode.ALBUM -> "End of album"
        }

    fun clock(ms: Long): String {
        val total = ceil(ms.coerceAtLeast(0) / 1000.0).toLong()
        val h = total / 3600
        val m = (total % 3600) / 60
        val s = total % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, s) else "%d:%02d".format(m, s)
    }

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_sleep", Context.MODE_PRIVATE)
        prefs = p
        fadeOut.value = p.getBoolean("fade", true)
        finishSong.value = p.getBoolean("finish", false)
    }

    fun setFadeOut(v: Boolean) {
        fadeOut.value = v
        prefs?.edit()?.putBoolean("fade", v)?.apply()
    }

    fun setFinishSong(v: Boolean) {
        finishSong.value = v
        prefs?.edit()?.putBoolean("finish", v)?.apply()
        // Switched while the time is already up and the song is playing out: it should stop right now instead.
        if (!v && finishing.value) pauseNow()
    }

    // ---- the service gives and takes the player ----

    fun attach(player: ExoPlayer) {
        this.player = player
        player.addListener(listener)
    }

    fun detach() {
        stop()
        player?.removeListener(listener)
        player = null
    }

    // ---- starting and stopping (all on the main thread, like the player) ----

    /** false when there is no player to stop (the service is not running). */
    fun startMinutes(minutes: Int): Boolean {
        val p = player ?: return false
        clearEffects(p)
        totalMs.longValue = minutes * 60_000L
        remainingMs.longValue = totalMs.longValue
        endAt = SystemClock.elapsedRealtime() + totalMs.longValue
        chipMinutes.intValue = minutes
        mode.value = Mode.TIME
        handler.postDelayed(tick, TICK_MS)
        return true
    }

    /** Adds time to a running countdown, or starts a new one of that length. */
    fun addMinutes(minutes: Int): Boolean {
        val p = player ?: return false
        if (mode.value != Mode.TIME) return startMinutes(minutes)
        // If the time was up and the song was playing out, the countdown is alive again.
        if (finishing.value) {
            finishing.value = false
            p.pauseAtEndOfMediaItems = false
        }
        val now = SystemClock.elapsedRealtime()
        endAt = maxOf(endAt, now) + minutes * 60_000L
        totalMs.longValue = (endAt - now).coerceAtLeast(minutes * 60_000L)
        remainingMs.longValue = endAt - now
        chipMinutes.intValue = 0
        stopFade(p)
        handler.removeCallbacks(tick)
        handler.postDelayed(tick, TICK_MS)
        return true
    }

    fun startEndOfSong(): Boolean {
        val p = player ?: return false
        clearEffects(p)
        mode.value = Mode.SONG
        p.pauseAtEndOfMediaItems = true
        return true
    }

    fun startEndOfAlbum(): Boolean {
        val p = player ?: return false
        clearEffects(p)
        mode.value = Mode.ALBUM
        updateAlbumPause()
        return true
    }

    fun stop() {
        player?.let { clearEffects(it) }
        mode.value = Mode.OFF
        remainingMs.longValue = 0
    }

    // ---- inside ----

    private const val TICK_MS = 500L
    private const val FADE_TICK_MS = 100L

    private val tick = Runnable { onTick() }

    private fun onTick() {
        val p = player ?: return
        if (mode.value != Mode.TIME || finishing.value) return
        val left = (endAt - SystemClock.elapsedRealtime()).coerceAtLeast(0)
        remainingMs.longValue = left
        if (left > 0) {
            val inFade = fadeOut.value && !finishSong.value && left <= FADE_MS
            if (inFade) {
                if (!fading) {
                    fading = true
                    // While casting the phone's player is already at 0 (the TV plays), so it simply stays quiet.
                    savedVolume = p.volume
                }
                p.volume = savedVolume * (left / FADE_MS.toFloat())
            }
            handler.postDelayed(tick, if (inFade) FADE_TICK_MS else TICK_MS)
            return
        }
        // Time is up.
        if (finishSong.value && p.isPlaying) {
            finishing.value = true
            p.pauseAtEndOfMediaItems = true   // stops by itself when the song ends (see the listener)
        } else {
            pauseNow()
        }
    }

    private fun pauseNow() {
        val p = player ?: return
        p.pause()
        complete()
    }

    /** The music stopped: the timer is done. */
    private fun complete() {
        player?.let { clearEffects(it) }
        mode.value = Mode.OFF
        remainingMs.longValue = 0
    }

    /** Back to normal: no pending stop, full volume again. */
    private fun clearEffects(p: ExoPlayer) {
        handler.removeCallbacks(tick)
        p.pauseAtEndOfMediaItems = false
        stopFade(p)
        finishing.value = false
    }

    private fun stopFade(p: ExoPlayer) {
        if (fading) {
            p.volume = savedVolume
            fading = false
        }
    }

    /** "End of album": pause at the end of this song only if the next one is from another album. */
    private fun updateAlbumPause() {
        val p = player ?: return
        val current = p.currentMediaItem ?: return
        val next: MediaItem? = if (p.hasNextMediaItem()) p.getMediaItemAt(p.nextMediaItemIndex) else null
        val lastOfAlbum = next == null ||
            next.mediaMetadata.albumTitle?.toString() != current.mediaMetadata.albumTitle?.toString()
        p.pauseAtEndOfMediaItems = lastOfAlbum
    }

    private val listener = object : Player.Listener {
        override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
            // The player paused itself at the end of the song: that was the point of the timer.
            if (!playWhenReady && reason == Player.PLAY_WHEN_READY_CHANGE_REASON_END_OF_MEDIA_ITEM &&
                (mode.value == Mode.SONG || mode.value == Mode.ALBUM || finishing.value)
            ) complete()
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            if (mode.value == Mode.ALBUM) updateAlbumPause()
        }

        override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
            if (mode.value == Mode.ALBUM) updateAlbumPause()
        }
    }
}
