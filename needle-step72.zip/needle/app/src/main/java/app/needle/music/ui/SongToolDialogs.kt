package app.needle.music.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/** "Go to genre" for a song with several genres: pick which one. */
@Composable
fun GenreChoiceDialog(genres: List<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Go to genre") },
        text = {
            Column {
                genres.forEach { g ->
                    Text(
                        g, color = Palette.Text, fontSize = 16.sp,
                        modifier = Modifier.fillMaxWidth().clickable { onPick(g) }.padding(vertical = 12.dp)
                    )
                }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}

/** Delete file, on Android 10 and older (newer versions show their own box). */
@Composable
fun DeleteFileDialog(title: String, onDelete: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        textContentColor = Palette.Muted,
        title = { Text("Delete this file?") },
        text = { Text("\"$title\" will be deleted from this phone. This cannot be undone.") },
        confirmButton = { TextButton(onClick = onDelete) { Text("Delete", color = Color(0xFFEB5757)) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}
