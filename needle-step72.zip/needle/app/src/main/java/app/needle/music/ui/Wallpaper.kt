package app.needle.music.ui

import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/**
 * The picture chosen in Settings > Customization > Colors & themes > Wallpaper, decoded once and drawn behind every page
 * by the glow layer (Now playing keeps its own glow from the cover). The picture stays where it is on the phone.
 */
object Wallpaper {
    val bitmap = mutableStateOf<ImageBitmap?>(null)

    /** Reads the picture at [uri] smaller than the screen; empty or unreadable means no wallpaper. */
    suspend fun load(context: Context, uri: String) {
        bitmap.value = if (uri.isEmpty()) null else withContext(Dispatchers.IO) { runCatching { decode(context, Uri.parse(uri)) }.getOrNull() }
    }

    private fun decode(context: Context, uri: Uri): ImageBitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / sample > 1800 || bounds.outHeight / sample > 1800) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }?.asImageBitmap()
    }
}
