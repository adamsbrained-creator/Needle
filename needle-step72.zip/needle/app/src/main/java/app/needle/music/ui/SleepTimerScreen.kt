package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.playback.SleepTimer
import app.needle.music.playback.SleepTimer.Mode

private val Minutes = listOf(5, 10, 15, 30, 45, 60)

/**
 * The Sleep timer page from the mockup: a ring that counts down, chips for 5 to 60 minutes, end of song and end
 * of album, a fade out, and Add 5 minutes / Stop timer. The timer itself runs in the playback service.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun SleepTimerScreen(
    bottomPadding: Dp,
    onBack: () -> Unit,
    onUnavailable: () -> Unit,
    modifier: Modifier = Modifier
) {
    val mode = SleepTimer.mode.value
    val active = mode != Mode.OFF
    fun run(started: Boolean) { if (!started) onUnavailable() }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Sleep timer", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 36.sp)
        Text("Music stops when the time runs out.", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))

        // ---- the ring ----
        Box(Modifier.align(Alignment.CenterHorizontally).size(230.dp), contentAlignment = Alignment.Center) {
            val progress = when (mode) {
                Mode.TIME -> if (SleepTimer.totalMs.longValue > 0) {
                    (SleepTimer.remainingMs.longValue.toFloat() / SleepTimer.totalMs.longValue).coerceIn(0f, 1f)
                } else 0f
                Mode.SONG, Mode.ALBUM -> 1f
                Mode.OFF -> 0f
            }
            Canvas(Modifier.size(230.dp)) {
                val sw = 12.dp.toPx()
                val arcSize = Size(size.width - sw, size.height - sw)
                val topLeft = Offset(sw / 2, sw / 2)
                drawArc(Color.White.copy(alpha = 0.10f), 0f, 360f, false, topLeft, arcSize, style = Stroke(sw))
                if (progress > 0f) {
                    // the arc starts at 12 o'clock (the gradient is turned along with it)
                    rotate(-90f) {
                        drawArc(
                            Brush.sweepGradient(listOf(Palette.Accent, Palette.Pink)), 0f, 360f * progress, false,
                            topLeft, arcSize, alpha = 0.22f, style = Stroke(sw * 1.9f, cap = StrokeCap.Round)
                        )
                        drawArc(
                            Brush.sweepGradient(listOf(Palette.Accent, Palette.Pink)), 0f, 360f * progress, false,
                            topLeft, arcSize, style = Stroke(sw, cap = StrokeCap.Round)
                        )
                    }
                }
            }
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                val big = when (mode) {
                    Mode.OFF -> "Off"
                    Mode.TIME -> SleepTimer.clock(SleepTimer.remainingMs.longValue)
                    Mode.SONG -> "End of song"
                    Mode.ALBUM -> "End of album"
                }
                Text(
                    big, color = Palette.Text, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center,
                    fontSize = if (mode == Mode.SONG || mode == Mode.ALBUM) 28.sp else 44.sp
                )
                Text(
                    when {
                        mode == Mode.OFF -> "No timer is running"
                        SleepTimer.finishing.value -> "waiting for the song to end"
                        mode == Mode.TIME -> "until the music stops"
                        else -> "then the music stops"
                    },
                    color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
        Spacer(Modifier.height(18.dp))

        // ---- the choices ----
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Minutes.forEach { m ->
                TimerChip("$m min", mode == Mode.TIME && SleepTimer.chipMinutes.intValue == m) { run(SleepTimer.startMinutes(m)) }
            }
            TimerChip("End of song", mode == Mode.SONG) { run(SleepTimer.startEndOfSong()) }
            TimerChip("End of album", mode == Mode.ALBUM) { run(SleepTimer.startEndOfAlbum()) }
        }
        Spacer(Modifier.height(14.dp))

        // ---- settings ----
        SleepRow("Fade out at the end", "Last 30 seconds") {
            NeedleSwitch(SleepTimer.fadeOut.value) { SleepTimer.setFadeOut(it) }
        }
        Spacer(Modifier.height(12.dp))
        SleepRow("Finish the current song", null) {
            NeedleSwitch(SleepTimer.finishSong.value) { SleepTimer.setFinishSong(it) }
        }

        // ---- buttons ----
        Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            PillButton("Add 5 minutes", { run(SleepTimer.addMinutes(5)) }, Modifier.weight(1f), filled = true)
            PillButton("Stop timer", { SleepTimer.stop() }, Modifier.weight(1f).alpha(if (active) 1f else 0.45f))
        }
    }
}

@Composable
private fun TimerChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (selected) Palette.Bg else Palette.Text)
    }
}

@Composable
private fun SleepRow(title: String, note: String?, trailing: @Composable () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .glass(cornerShape(22.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            if (note != null) Text(note, color = Palette.Muted, fontSize = 12.5.sp)
        }
        trailing()
    }
}
