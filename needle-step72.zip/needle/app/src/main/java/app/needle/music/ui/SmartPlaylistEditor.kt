package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.SmartPlaylist
import app.needle.music.data.SmartRule
import app.needle.music.data.SmartSort

/**
 * Makes or changes a smart playlist: a name, one rule (with its number or name), how many songs, and their order.
 * The playlist is then filled from the library by itself and changes as the library and your plays change.
 */
@Composable
fun SmartPlaylistEditor(
    initial: SmartPlaylist?,
    onSave: (SmartPlaylist) -> Unit,
    onDelete: (() -> Unit)?,
    onDismiss: () -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var rule by remember { mutableStateOf(initial?.rule ?: SmartRule.ADDED) }
    var value by remember { mutableStateOf(initial?.value ?: SmartRule.ADDED.default) }
    var limit by remember { mutableStateOf(initial?.limit ?: 50) }
    var sort by remember { mutableStateOf(initial?.sort ?: SmartSort.NEWEST) }
    val valid = !rule.needsValue || value.isNotBlank()

    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text(if (initial == null) "New smart playlist" else "Edit smart playlist") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                OutlinedTextField(
                    value = name, onValueChange = { name = it.take(60) }, singleLine = true,
                    placeholder = { Text("Name", color = Palette.Muted) }, modifier = Modifier.fillMaxWidth()
                )
                EditorLabel("Songs that match")
                SmartRule.entries.forEach { r ->
                    Row(
                        Modifier
                            .fillMaxWidth()
                            .clip(cornerShape(12.dp))
                            .clickable { if (rule != r) { rule = r; value = r.default } }
                            .padding(vertical = 9.dp, horizontal = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            Modifier.size(18.dp).clip(CircleShape).background(if (rule == r) Palette.Accent else Color.White.copy(alpha = 0.18f)),
                            contentAlignment = Alignment.Center
                        ) { if (rule == r) Box(Modifier.size(7.dp).clip(CircleShape).background(Color.White)) }
                        Spacer(Modifier.width(12.dp))
                        Text(r.label, color = Palette.Text, fontSize = 15.sp)
                    }
                }
                if (rule.needsValue) {
                    Spacer(Modifier.height(6.dp))
                    OutlinedTextField(
                        value = value, onValueChange = { value = if (rule.numeric) it.filter(Char::isDigit).take(4) else it.take(60) },
                        singleLine = true,
                        label = { Text(rule.valueHint.orEmpty(), color = Palette.Muted) },
                        keyboardOptions = KeyboardOptions(keyboardType = if (rule.numeric) KeyboardType.Number else KeyboardType.Text),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
                EditorLabel("How many songs")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(25 to "25", 50 to "50", 100 to "100", 0 to "All").forEach { (n, label) -> EditorPill(label, limit == n) { limit = n } }
                }
                EditorLabel("Order")
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmartSort.entries.forEach { s -> EditorPill(s.label, sort == s) { sort = s } }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = valid,
                onClick = { onSave(SmartPlaylist(initial?.id ?: "", name, rule, value, limit, sort)) }
            ) { Text("Save", color = if (valid) Palette.Accent else Palette.Muted) }
        },
        dismissButton = {
            Row {
                if (onDelete != null) TextButton(onClick = onDelete) { Text("Delete", color = Palette.Muted) }
                TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) }
            }
        }
    )
}

@Composable
private fun EditorLabel(text: String) {
    Text(text, color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp, bottom = 6.dp))
}

@Composable
private fun EditorPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color(0xFF111111) else Palette.Text,
        fontSize = 13.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    )
}
