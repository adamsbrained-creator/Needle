package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** One folder switch of the scan screen and Settings > Library: a top folder and how many songs are in it. */
class FolderGroup(val name: String, val songs: Int)

/**
 * The folder a song counts under: the first folder of its path ("Music/Indie/" -> "Music"), with WhatsApp's audio
 * folder (deep inside Android/media) shown under its own name. Phones older than Android 10 give no folders at all,
 * so everything is "Other".
 */
fun folderGroupOf(folder: String): String {
    val parts = folder.trim('/').split('/').filter { it.isNotEmpty() }
    return when {
        parts.isEmpty() -> "Other"
        parts.any { it.equals("WhatsApp Audio", ignoreCase = true) } -> "WhatsApp Audio"
        else -> parts[0]
    }
}

/** The folder switches for these songs, the biggest folder first. */
fun groupFolders(songs: List<Song>): List<FolderGroup> =
    songs.groupingBy { folderGroupOf(it.folder) }.eachCount()
        .map { FolderGroup(it.key, it.value) }
        .sortedWith(compareByDescending<FolderGroup> { it.songs }.thenBy { it.name.lowercase() })

/**
 * Folders the person switched off. Songs in them are left out of every list, like hidden songs, but nothing is
 * deleted. Stored by folder name. Remembered.
 */
object ExcludedFolders {
    private var prefs: SharedPreferences? = null

    val names = MutableStateFlow<Set<String>>(emptySet())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        names.value = p.getString("excluded_folders", "").orEmpty().split('\n').filter { it.isNotBlank() }.toSet()
    }

    fun toggle(name: String) = save(if (name in names.value) names.value - name else names.value + name)

    fun replaceAll(list: Collection<String>) = save(list.filter { it.isNotBlank() }.toSet())

    private fun save(set: Set<String>) {
        names.value = set
        prefs?.edit()?.putString("excluded_folders", set.joinToString("\n"))?.apply()
    }
}
