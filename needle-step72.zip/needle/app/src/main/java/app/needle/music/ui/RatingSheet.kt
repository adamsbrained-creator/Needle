package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.RatingScale
import app.needle.music.data.RatingStyle
import app.needle.music.data.Song
import kotlin.math.roundToInt

/**
 * The "Rate song" sheet. How you rate depends on the style chosen in Settings: five stars, a 1.00 to 5.00 slider
 * in steps of a quarter, or a number from 1 to 10. Every pick is saved at once (tap the same star or number again,
 * or "Clear rating", to take it back). The saved value is the same for all three styles.
 */
@Composable
fun RatingSheet(
    song: Song,
    value: Int,                       // 0 = not rated
    style: RatingStyle,
    onRate: (Int) -> Unit,            // 0 clears
    onCycleStyle: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    // The slider keeps its own position while you drag; it saves when you let go.
    var slider by remember(song.id, value) { mutableFloatStateOf(if (value > 0) value / 20f else 3f) }
    var touched by remember(song.id, style) { mutableStateOf(false) }
    val shownValue = if (style == RatingStyle.DECIMAL && touched) (slider * 20f).roundToInt() else value

    Column(
        modifier
            .fillMaxWidth()
            .clip(cornerShapeOf(topStart = 32.dp, topEnd = 32.dp))
            .background(
                Brush.linearGradient(
                    listOf(Color(0xF53C3256), Color(0xFA202024)), start = Offset(0f, 0f), end = Offset(1400f, 2400f)
                ).flatOr(Palette.Surface)
            )
            .padding(start = 20.dp, end = 20.dp, top = 10.dp)
    ) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(5.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.4f))
        )
        Text("Rate song", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 26.sp, modifier = Modifier.padding(top = 14.dp))
        Text(
            "${song.title} · ${song.artist}", color = Palette.Muted, fontSize = 13.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )

        // The rating, big
        Box(Modifier.fillMaxWidth().padding(vertical = 18.dp), contentAlignment = Alignment.Center) {
            if (shownValue > 0) {
                Text(RatingScale.label(style, shownValue), color = Palette.Text, fontSize = 40.sp, fontWeight = FontWeight.SemiBold)
            } else {
                Text("Not rated", color = Palette.Muted, fontSize = 24.sp)
            }
        }

        when (style) {
            RatingStyle.STARS -> {
                val n = if (value > 0) RatingScale.stars(value) else 0
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                    for (i in 0 until 5) {
                        val stars = (i + 1) * 20
                        Box(
                            Modifier.size(56.dp).clip(CircleShape).clickable { onRate(if (value == stars) 0 else stars) },
                            contentAlignment = Alignment.Center
                        ) {
                            if (i < n) NeedleIconView(NeedleIcon.STAR_FILLED, Palette.Accent, size = 40.dp)
                            else NeedleIconView(NeedleIcon.STAR, Palette.Muted, size = 40.dp)
                        }
                    }
                }
            }
            RatingStyle.DECIMAL -> {
                Slider(
                    value = slider,
                    onValueChange = { slider = it; touched = true },
                    onValueChangeFinished = { if (touched) onRate((slider * 20f).roundToInt()) },
                    valueRange = 1f..5f,
                    steps = 15,                       // 1.00, 1.25 ... 5.00
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Palette.Accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                        activeTickColor = Color.Transparent,
                        inactiveTickColor = Color.Transparent
                    )
                )
                Row(Modifier.fillMaxWidth().padding(horizontal = 4.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("1.00", color = Palette.Muted, fontSize = 12.sp)
                    Text("5.00", color = Palette.Muted, fontSize = 12.sp)
                }
            }
            RatingStyle.TEN -> {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    for (row in 0..1) {
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                            for (col in 0..4) {
                                val n = row * 5 + col + 1
                                val selected = value == n * 10
                                Box(
                                    Modifier
                                        .size(48.dp)
                                        .clip(CircleShape)
                                        .then(
                                            if (selected) Modifier.background(Palette.Accent)
                                            else Modifier.glass(CircleShape)
                                        )
                                        .clickable { onRate(if (selected) 0 else n * 10) },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text("$n", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                }
            }
        }

        Row(Modifier.fillMaxWidth().padding(top = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            TextButton(onClick = { onRate(0); touched = false }, enabled = value > 0) {
                Text("Clear rating", color = if (value > 0) Palette.Muted else Palette.Muted.copy(alpha = 0.4f))
            }
            Spacer(Modifier.weight(1f))
            // Quick switch between the ways of rating (the same choice as Settings > Ratings)
            Row(
                Modifier.clip(cornerShape(12.dp)).clickable(onClick = onCycleStyle).padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Style: ${style.label}", color = Palette.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        PillButton("Done", onDone, Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 16.dp).navigationBarsPadding(), filled = true)
    }
}
