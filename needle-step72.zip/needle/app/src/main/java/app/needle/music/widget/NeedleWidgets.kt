package app.needle.music.widget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.BroadcastReceiver
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews
import androidx.compose.ui.graphics.toArgb
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.needle.music.MainActivity
import app.needle.music.R
import app.needle.music.data.AccentChoices
import app.needle.music.data.NeedleSettings
import app.needle.music.playback.PlaybackService

/*
 * Home screen widgets from the mockup:
 *  - Player: cover, title, artist, a progress bar and previous / play / next
 *  - Cover: just the cover, with a play button
 *  - This week: listening time, plays and a bar for each weekday
 *  - Mini bar: a slim bar with the cover, the song and play
 * The player widgets are redrawn by the playback service when the song or play state changes (and every 15 seconds
 * while music plays, for the progress); the week widget is redrawn when Home has new numbers.
 */

class PlayerWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) =
        WidgetUpdater.update(context, manager, ids, WidgetKind.PLAYER)
}

class CoverWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) =
        WidgetUpdater.update(context, manager, ids, WidgetKind.COVER)
}

class StatsWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) =
        WidgetUpdater.update(context, manager, ids, WidgetKind.STATS)
}

class MiniWidget : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) =
        WidgetUpdater.update(context, manager, ids, WidgetKind.MINI)
}

enum class WidgetKind(val provider: Class<*>) {
    PLAYER(PlayerWidget::class.java),
    COVER(CoverWidget::class.java),
    STATS(StatsWidget::class.java),
    MINI(MiniWidget::class.java)
}

object WidgetUpdater {
    const val ACTION_PLAY_PAUSE = "app.needle.music.widget.PLAY_PAUSE"
    const val ACTION_NEXT = "app.needle.music.widget.NEXT"
    const val ACTION_PREVIOUS = "app.needle.music.widget.PREVIOUS"

    /** Redraws every widget of Needle that is on the home screen. */
    fun updateAll(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        for (kind in WidgetKind.entries) {
            val ids = manager.getAppWidgetIds(ComponentName(context, kind.provider))
            if (ids.isNotEmpty()) update(context, manager, ids, kind)
        }
    }

    fun update(context: Context, manager: AppWidgetManager, ids: IntArray, kind: WidgetKind) {
        NeedleSettings.init(context)
        val snap = WidgetState.load(context)
        val accent = accentArgb()
        val d = context.resources.displayMetrics.density
        val views = when (kind) {
            WidgetKind.PLAYER -> playerViews(context, snap, accent, d)
            WidgetKind.COVER -> coverViews(context, snap, accent, d)
            WidgetKind.STATS -> statsViews(context, snap, accent, d)
            WidgetKind.MINI -> miniViews(context, snap, accent, d)
        }
        manager.updateAppWidget(ids, views)
    }

    private fun accentArgb(): Int {
        val i = NeedleSettings.accentIndex.intValue
        return if (i >= AccentChoices.size) NeedleSettings.customAccent.intValue else AccentChoices[i].color.toArgb()
    }

    private fun openApp(context: Context): PendingIntent = PendingIntent.getActivity(
        context, 0,
        Intent(context, MainActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_SINGLE_TOP),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun action(context: Context, action: String, code: Int): PendingIntent = PendingIntent.getBroadcast(
        context, code,
        Intent(context, WidgetActionReceiver::class.java).setAction(action),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
    )

    private fun title(s: WidgetState.Snapshot) = if (s.hasSong && s.title.isNotBlank()) s.title else "Needle"
    private fun artist(s: WidgetState.Snapshot) = if (s.hasSong) s.artist else "Open Needle to play something"
    private fun fraction(s: WidgetState.Snapshot) = if (s.durationMs > 0) (s.positionMs.toFloat() / s.durationMs).coerceIn(0f, 1f) else 0f

    private fun playerViews(context: Context, s: WidgetState.Snapshot, accent: Int, d: Float): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_player)
        v.setImageViewBitmap(R.id.cover, WidgetArt.cover(WidgetState.loadCover(context), (92 * d).toInt(), 18 * d, accent))
        v.setTextViewText(R.id.title, title(s))
        v.setTextViewText(R.id.artist, artist(s))
        v.setImageViewBitmap(R.id.progress, WidgetArt.progress(fraction(s), accent, (260 * d).toInt(), (4 * d).toInt().coerceAtLeast(3)))
        v.setImageViewBitmap(R.id.prev, WidgetArt.skipButton(false, (40 * d).toInt()))
        v.setImageViewBitmap(R.id.play, WidgetArt.playButton(s.playing, accent, (46 * d).toInt()))
        v.setImageViewBitmap(R.id.next, WidgetArt.skipButton(true, (40 * d).toInt()))
        v.setOnClickPendingIntent(R.id.root, openApp(context))
        v.setOnClickPendingIntent(R.id.prev, action(context, ACTION_PREVIOUS, 1))
        v.setOnClickPendingIntent(R.id.play, action(context, ACTION_PLAY_PAUSE, 2))
        v.setOnClickPendingIntent(R.id.next, action(context, ACTION_NEXT, 3))
        return v
    }

    private fun coverViews(context: Context, s: WidgetState.Snapshot, accent: Int, d: Float): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_cover)
        v.setImageViewBitmap(R.id.cover, WidgetArt.cover(WidgetState.loadCover(context), (240 * d).toInt().coerceAtMost(520), 24 * d, accent))
        v.setImageViewBitmap(R.id.play, WidgetArt.playButton(s.playing, accent, (46 * d).toInt()))
        v.setOnClickPendingIntent(R.id.cover, openApp(context))
        v.setOnClickPendingIntent(R.id.play, action(context, ACTION_PLAY_PAUSE, 2))
        return v
    }

    private fun statsViews(context: Context, s: WidgetState.Snapshot, accent: Int, d: Float): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_stats)
        v.setTextViewText(R.id.value, if (s.plays == 0) "Nothing yet" else listened(s.listenedMs))
        v.setTextViewText(R.id.sub, if (s.plays == 1) "1 play" else "${s.plays} plays")
        v.setImageViewBitmap(R.id.bars, WidgetArt.weekBars(s.weekdays, accent, (220 * d).toInt(), (60 * d).toInt(), d))
        v.setOnClickPendingIntent(R.id.root, openApp(context))
        return v
    }

    private fun miniViews(context: Context, s: WidgetState.Snapshot, accent: Int, d: Float): RemoteViews {
        val v = RemoteViews(context.packageName, R.layout.widget_mini)
        v.setImageViewBitmap(R.id.cover, WidgetArt.cover(WidgetState.loadCover(context), (44 * d).toInt(), 12 * d, accent))
        v.setTextViewText(R.id.title, title(s))
        v.setTextViewText(R.id.artist, artist(s))
        v.setImageViewBitmap(R.id.play, WidgetArt.playButton(s.playing, accent, (40 * d).toInt()))
        v.setOnClickPendingIntent(R.id.root, openApp(context))
        v.setOnClickPendingIntent(R.id.play, action(context, ACTION_PLAY_PAUSE, 2))
        return v
    }

    /** "14 h 20 m", "45 m", "1 h" */
    private fun listened(ms: Long): String {
        val minutes = ms / 60_000
        val h = minutes / 60
        val m = minutes % 60
        return when {
            h == 0L -> "$m m"
            m == 0L -> "$h h"
            else -> "$h h $m m"
        }
    }
}

/**
 * The buttons on the widgets. It connects to the player for a moment, does the one thing, and lets go. This works
 * even when Needle is closed: connecting starts the player.
 */
class WidgetActionReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val action = intent.action ?: return
        val pending = goAsync()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val controller = future.get()
                when (action) {
                    WidgetUpdater.ACTION_PLAY_PAUSE -> if (controller.isPlaying) controller.pause() else controller.play()
                    WidgetUpdater.ACTION_NEXT -> controller.seekToNext()
                    WidgetUpdater.ACTION_PREVIOUS -> controller.seekToPrevious()
                }
                controller.release()
            } catch (_: Exception) {
                // the player could not be reached; nothing to do
            } finally {
                pending.finish()
            }
        }, ContextCompat.getMainExecutor(context))
    }
}
