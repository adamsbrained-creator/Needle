package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject

/** A note and/or a photo the person attached to a song: the "photo or note moment" of Latest Moments. */
class MomentNote(val text: String, val photoUri: String?, val createdAt: Long)

/** The notes and photos of Latest Moments, by song id. Remembered. */
object MomentNotes {
    private var prefs: SharedPreferences? = null

    val notes = MutableStateFlow<Map<Long, MomentNote>>(emptyMap())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_moments", Context.MODE_PRIVATE)
        prefs = p
        notes.value = parse(p.getString("notes", null))
    }

    private fun parse(json: String?): Map<Long, MomentNote> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val o = JSONObject(json)
            o.keys().asSequence().mapNotNull { key ->
                val id = key.toLongOrNull() ?: return@mapNotNull null
                val n = o.optJSONObject(key) ?: return@mapNotNull null
                id to MomentNote(n.optString("t"), n.optString("p").ifBlank { null }, n.optLong("at"))
            }.toMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun toJson(): JSONObject {
        val o = JSONObject()
        notes.value.forEach { (id, n) ->
            o.put(id.toString(), JSONObject().put("t", n.text).put("p", n.photoUri ?: "").put("at", n.createdAt))
        }
        return o
    }

    /** Saves the moment of a song; with no text and no photo it is removed instead. */
    fun set(songId: Long, text: String, photoUri: String?) {
        val clean = text.trim()
        if (clean.isEmpty() && photoUri == null) {
            remove(songId)
            return
        }
        save(notes.value + (songId to MomentNote(clean, photoUri, System.currentTimeMillis())))
    }

    fun remove(songId: Long) {
        if (songId in notes.value) save(notes.value - songId)
    }

    /** Adds the notes of a backup to the ones here (the ones here win when both have the same song). */
    fun merge(json: JSONObject) {
        val incoming = parse(json.toString())
        save(incoming + notes.value)
    }

    private fun save(map: Map<Long, MomentNote>) {
        notes.value = map
        prefs?.edit()?.putString("notes", toJson().toString())?.apply()
    }
}

private const val MAX_MOMENTS = 8

/**
 * The songs of the Latest Moments row, newest moment first: songs with your own note or photo, then what you played
 * most recently, then what was added most recently. At most one song per album, so the row is not eight times the
 * same cover.
 */
fun buildMomentSongs(songs: List<Song>, plays: List<PlayEvent>, notes: Map<Long, MomentNote>): List<Song> {
    if (songs.isEmpty()) return emptyList()
    val byId = songs.associateBy { it.id }
    val out = ArrayList<Song>()
    val seenAlbums = HashSet<Long>()
    val seenSongs = HashSet<Long>()

    fun add(song: Song, oneAlbum: Boolean) {
        if (out.size >= MAX_MOMENTS || song.id in seenSongs) return
        if (oneAlbum && song.albumId in seenAlbums) return
        seenSongs += song.id
        seenAlbums += song.albumId
        out += song
    }

    // The person's own moments come first, even from the same album.
    notes.entries.sortedByDescending { it.value.createdAt }.forEach { (id, _) -> byId[id]?.let { add(it, oneAlbum = false) } }
    plays.sortedByDescending { it.playedAt }.forEach { e -> byId[e.songId]?.let { add(it, oneAlbum = true) } }
    songs.sortedByDescending { it.dateAdded }.forEach { add(it, oneAlbum = true) }
    return out
}
