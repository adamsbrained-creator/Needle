package app.needle.music.ui

import app.needle.music.data.Skins
import android.graphics.Bitmap
import androidx.compose.foundation.background
import androidx.compose.ui.layout.ContentScale
import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import android.widget.Toast
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtistPageData
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.HomeAlbum
import app.needle.music.data.Song
import app.needle.music.data.PinnedArtists
import app.needle.music.data.artistKey
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The colors of one artist page: a dark background tinted with the artist's color, and the button color. */
class ArtistTheme(val bg: Color, val button: Color, val muted: Color)

private val FallbackHues = floatArrayOf(265f, 38f, 355f, 190f, 215f, 140f)

private fun hsv(h: Float, s: Float, v: Float): Color = Color(android.graphics.Color.HSVToColor(floatArrayOf(h, s, v)))

private fun themeFor(hue: Float, sat: Float) = ArtistTheme(
    bg = hsv(hue, (sat * 0.85f).coerceIn(0.35f, 0.75f), 0.20f),
    button = hsv(hue, sat.coerceIn(0.4f, 0.8f), 0.95f).copy(alpha = 0.35f),
    muted = hsv(hue, 0.18f, 0.78f)
)

/** The most colorful, not too dark pixel of the cover (a blurred average would just be muddy brown). */
private fun dominantArgb(art: ImageBitmap): Int? = runCatching {
    val small = Bitmap.createScaledBitmap(art.asAndroidBitmap().copy(Bitmap.Config.ARGB_8888, false), 24, 24, true)
    val px = IntArray(24 * 24)
    small.getPixels(px, 0, 24, 0, 0, 24, 24)
    val hsv = FloatArray(3)
    var best = 0f
    var bestColor: Int? = null
    for (c in px) {
        android.graphics.Color.colorToHSV(c, hsv)
        val score = if (hsv[2] < 0.2f) 0f else hsv[1] * (0.3f + hsv[2])
        if (score > best) { best = score; bestColor = c }
    }
    if (best < 0.12f) null else bestColor   // grey covers get one of the fallback colors instead
}.getOrNull()

@Composable
private fun rememberArtistTheme(name: String, cover: Song?): ArtistTheme {
    val context = LocalContext.current
    val argb by produceState<Int?>(null, cover?.id) {
        value = if (cover == null) null else withContext(Dispatchers.Default) {
            val art = ArtworkLoader.peekLarge(cover) ?: ArtworkLoader.loadLarge(context, cover)
            art?.let { dominantArgb(it) }
        }
    }
    val c = argb
    return remember(name, c) {
        if (c != null) {
            val hsv = FloatArray(3)
            android.graphics.Color.colorToHSV(c, hsv)
            themeFor(hsv[0], hsv[1])
        } else {
            themeFor(FallbackHues[(artistKey(name).hashCode() and 0x7fffffff) % FallbackHues.size], 0.6f)
        }
    }
}

/**
 * The artist page from the mockup: the artist's covers as the header with the name over it, play / shuffle,
 * the latest release, top songs, and the albums and singles in your library.
 * The page color follows the artist's covers. [onChrome] gives the color to the app, which paints it behind the
 * status bar too, and gets null again when the page goes away.
 */
@Composable
fun ArtistScreen(
    data: ArtistPageData,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
    onPlayList: (List<Song>, Int) -> Unit,
    onOpenAlbum: (HomeAlbum) -> Unit,
    onQueueLatest: () -> Unit,
    onSongMenu: (Song) -> Unit,
    onMenu: () -> Unit,
    onChrome: (Color?) -> Unit,
    modifier: Modifier = Modifier
) {
    val theme = rememberArtistTheme(data.name, data.covers.firstOrNull())
    SideEffect { onChrome(theme.bg) }
    DisposableEffect(Unit) { onDispose { onChrome(null) } }

    val artistVideo = rememberAnimatedArtistUrl(data.name)
    val artistBackground = rememberArtistBackground(data.name)
    var showAllTop by remember(data.name) { mutableStateOf(false) }
    // The star pins the artist to the top of the Artists page.
    val pinnedKeys by PinnedArtists.keys.collectAsState()
    val pinned = artistKey(data.name) in pinnedKeys
    val context = LocalContext.current
    val topShown = if (showAllTop) data.top else data.top.take(5)

    Column(modifier.fillMaxSize().verticalScroll(rememberScrollState())) {
        // ---- header: covers side by side, fading into the page, name at the bottom ----
        Box(Modifier.fillMaxWidth().height(340.dp)) {
            Row(Modifier.fillMaxSize().background(Palette.Card2)) {
                data.covers.forEach { Cover(it, Modifier.weight(1f).fillMaxHeight()) }
            }
            if (artistBackground != null) Image(artistBackground, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            if (artistVideo != null) AnimatedCoverVideo(artistVideo, playing = true, modifier = Modifier.fillMaxSize())
            // the top blends into the status bar color, the bottom into the page
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(
                        0f to theme.bg, 0.12f to Color.Transparent, 0.5f to Color.Transparent, 1f to theme.bg
                    )
                )
            )
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(NeedleIcon.BACK, onBack, size = 40.dp, iconSize = 22.dp, scrim = true, tint = Color.White)
                Spacer(Modifier.weight(1f))
                RoundIconButton(NeedleIcon.MORE, onMenu, size = 40.dp, iconSize = 22.dp, scrim = true, tint = Color.White)
            }
            Text(
                data.name, color = Color.White, fontFamily = Palette.TitleFont, fontSize = 36.sp, lineHeight = 40.sp,
                textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 20.dp, vertical = 6.dp)
            )
        }

        // ---- star (soon), play, shuffle ----
        Row(
            Modifier.fillMaxWidth().padding(top = 10.dp, bottom = 16.dp),
            horizontalArrangement = Arrangement.spacedBy(14.dp, Alignment.CenterHorizontally),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundAction(if (pinned) NeedleIcon.STAR_FILLED else NeedleIcon.STAR, theme.button, 54.dp, {
                val now = PinnedArtists.toggle(data.name)
                Toast.makeText(context, if (now) "Pinned ${data.name}" else "Unpinned ${data.name}", Toast.LENGTH_SHORT).show()
            })
            RoundAction(NeedleIcon.PLAY, theme.button, 60.dp, onPlay)
            RoundAction(NeedleIcon.SHUFFLE, theme.button, 54.dp, onShuffle)
        }

        // ---- latest release ----
        data.latest?.let { latest ->
            Row(
                Modifier
                    .padding(horizontal = 14.dp)
                    .fillMaxWidth()
                    .clip(cornerShape(20.dp))
                    .background(Color.White.copy(alpha = 0.08f))
                    .clickable(enabled = latest.album != null) { latest.album?.let(onOpenAlbum) }
                    .padding(10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Cover(latest.cover, Modifier.size(54.dp).clip(coverClip(10.dp)))
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(latest.label, color = theme.muted, fontSize = 10.sp, letterSpacing = 0.3.sp)
                    Text(latest.title, color = Color.White, fontSize = 14.5.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(latest.line, color = theme.muted, fontSize = 12.sp)
                }
                RoundAction(NeedleIcon.ADD_QUEUE, theme.button, 34.dp, onQueueLatest, iconSize = 17.dp)
            }
        }

        // ---- top songs ----
        if (data.top.isNotEmpty()) {
            Row(
                Modifier
                    .padding(start = 16.dp, top = 18.dp, bottom = 8.dp)
                    .clip(cornerShape(8.dp))
                    .clickable(enabled = data.top.size > 5) { showAllTop = !showAllTop },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Top songs", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                if (data.top.size > 5) {
                    Spacer(Modifier.width(4.dp))
                    // points right to open the longer list, and up when it is open
                    NeedleIconView(
                        NeedleIcon.CHEVRON_RIGHT, Color.White,
                        Modifier.rotate(if (showAllTop) -90f else 0f), size = 16.dp
                    )
                }
            }
            topShown.forEachIndexed { i, song ->
                SongRow(
                    song, data.subtitle(song), theme, isCurrent = song.id.toString() == currentMediaId,
                    onClick = { onPlayList(data.top, i) },
                    onMore = { onSongMenu(song) }
                )
            }
        }

        // ---- albums ----
        if (data.albums.isNotEmpty()) {
            SectionTitle("Albums")
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                data.albums.forEach { album ->
                    ReleaseTile(album.cover, album.title, "${data.year(album.cover)} · ${tracksText(album.songs.size)}", theme) { onOpenAlbum(album) }
                }
            }
        }

        // ---- singles ----
        if (data.singles.isNotEmpty()) {
            SectionTitle("Singles")
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                data.singles.forEachIndexed { i, song ->
                    ReleaseTile(song, song.title, "Single · ${data.year(song)}", theme) { onPlayList(data.singles, i) }
                }
            }
        }

        Spacer(Modifier.height(bottomPadding))
    }
}

@Composable
private fun SectionTitle(text: String) {
    Text(
        text, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold,
        modifier = Modifier.padding(start = 16.dp, top = 22.dp, bottom = 10.dp)
    )
}

@Composable
private fun RoundAction(icon: NeedleIcon, color: Color, size: Dp, onClick: () -> Unit, iconSize: Dp = 24.dp) {
    // Black & Green: Play is the green button, the others are dark.
    val skin = Skins.blackGreen
    val main = skin && icon == NeedleIcon.PLAY
    Box(
        Modifier.size(size).clip(CircleShape)
            .background(if (skin) (if (main) Palette.Accent else Palette.Card2) else color)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { NeedleIconView(icon, if (main) Color.Black else Color.White, size = iconSize) }
}

@Composable
private fun SongRow(song: Song, subtitle: String, theme: ArtistTheme, isCurrent: Boolean, onClick: () -> Unit, onMore: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tapOrHold(onClick, onMore).padding(horizontal = 16.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(song, size = 46.dp, corner = 9.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, color = if (isCurrent) Palette.Accent else Color.White, fontSize = 14.5.sp,
                fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(subtitle, color = theme.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(Modifier.size(36.dp).clip(CircleShape).clickable(onClick = onMore), contentAlignment = Alignment.Center) {
            NeedleIconView(NeedleIcon.MORE, theme.muted, size = 20.dp)
        }
    }
}

@Composable
private fun ReleaseTile(cover: Song, title: String, sub: String, theme: ArtistTheme, onClick: () -> Unit) {
    Column(Modifier.width(138.dp).clip(cornerShape(16.dp)).clickable(onClick = onClick)) {
        Cover(cover, Modifier.size(138.dp).clip(coverClip(16.dp)))
        Text(
            title, color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
        )
        Text(sub, color = theme.muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
