package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.MixData
import app.needle.music.data.playlistDuration
import app.needle.music.data.songsText

/**
 * One mix from the mockup ("Mix or playlist"): Refresh, the cover, when it was made, how many of its songs you
 * already played, a short "About this mix", Play and Shuffle, "Save as playlist", then the songs.
 * Tap a song to play the mix from it, press and hold for the song menu.
 */
@Composable
fun MixScreen(
    mix: MixData,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onPlay: (List<app.needle.music.data.Song>, Int) -> Unit,
    onShuffle: (List<app.needle.music.data.Song>) -> Unit,
    onSavePlaylist: () -> Unit,
    onSongMenu: (app.needle.music.data.Song) -> Unit,
    modifier: Modifier = Modifier,
    onEdit: (() -> Unit)? = null
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack, size = 42.dp)
                    Spacer(Modifier.weight(1f))
                    Row(
                        Modifier
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.1f))
                            .clickable(onClick = if (mix.smart) (onEdit ?: {}) else onRefresh)
                            .padding(horizontal = 14.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // A mix is made new with Refresh; a smart playlist is changed with Edit (its rule).
                        NeedleIconView(if (mix.smart) NeedleIcon.PENCIL else NeedleIcon.REFRESH, Palette.Text, size = 18.dp)
                        Spacer(Modifier.width(7.dp))
                        Text(if (mix.smart) "Edit" else "Refresh", color = Palette.Text, fontSize = 13.5.sp, fontWeight = FontWeight.Medium)
                    }
                }
                Spacer(Modifier.height(8.dp))
                PlaylistCover(mix.cover, Modifier.size(180.dp), corner = 26.dp, iconSize = 56.dp)
                Text(if (mix.smart) "Smart playlist" else "Mix", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
                Text(
                    mix.name, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 32.sp, lineHeight = 36.sp,
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    (if (mix.smart) "" else "Updated today · ") + "${songsText(mix.songs.size)} · ${playlistDuration(mix.durationMs)}",
                    color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)
                )
                if (!mix.smart) Text(
                    "${mix.played} of ${mix.songs.size} played",
                    color = Palette.Text, fontSize = 12.5.sp, fontWeight = FontWeight.Medium,
                    modifier = Modifier
                        .padding(top = 10.dp)
                        .clip(CircleShape)
                        .background(Palette.Accent.copy(alpha = 0.25f))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", { if (mix.songs.isNotEmpty()) onPlay(mix.songs, 0) }, Modifier.weight(1f), filled = true)
                    PillButton("Shuffle", { if (mix.songs.isNotEmpty()) onShuffle(mix.songs) }, Modifier.weight(1f))
                }
            }
        }
        item {
            Column(
                Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 18.dp)
                    .clip(cornerShape(22.dp))
                    .background(Palette.Card)
                    .padding(16.dp)
            ) {
                Text(if (mix.smart) "About this playlist" else "About this mix", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text(mix.about, color = Palette.Muted, fontSize = 13.5.sp, lineHeight = 19.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp))
                PillButton("Save as playlist", onSavePlaylist)
            }
        }
        itemsIndexed(mix.songs, key = { _, song -> song.id }) { index, song ->
            Row(
                Modifier
                    .fillMaxWidth()
                    .tapOrHold(onClick = { onPlay(mix.songs, index) }, onLongClick = { onSongMenu(song) })
                    .padding(horizontal = 16.dp, vertical = 7.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SongArtwork(song, size = 48.dp, corner = 10.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        color = if (song.id.toString() == currentMediaId) Palette.Accent else Palette.Text
                    )
                    Text(song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
            }
        }
    }
}
