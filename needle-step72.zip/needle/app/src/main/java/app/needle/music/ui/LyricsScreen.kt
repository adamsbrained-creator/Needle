package app.needle.music.ui

import android.content.Context
import android.content.Intent
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.gestures.scrollBy
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.BlendMode
import androidx.compose.ui.graphics.CompositingStrategy
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalView
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.LyricLine
import app.needle.music.data.LyricsTranslations
import app.needle.music.data.alignTranslation
import app.needle.music.data.FileAccess
import app.needle.music.data.LrcParser
import app.needle.music.data.LyricsPrefs
import app.needle.music.data.LyricsQuery
import app.needle.music.data.LyricsSource
import app.needle.music.data.LyricsViewModel
import app.needle.music.playback.PlayerViewModel
import kotlin.math.abs
import kotlin.math.exp

private val Dim = Color.White.copy(alpha = 0.35f)

/**
 * The lyrics page from the mockup: the current line big and serif, the others dimmed, tap a line to jump there,
 * a text-size slider on the right edge, keep-screen-on, share. Timed lyrics follow the song; plain lyrics scroll.
 */
@Composable
fun LyricsScreen(
    player: PlayerViewModel,
    lyricsVm: LyricsViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier,
    onEdit: () -> Unit = {}
) {
    val context = LocalContext.current
    val view = LocalView.current
    val state = lyricsVm.state
    val lyrics = state.lyrics
    val fileAccess by FileAccess.granted

    // The song that is playing right now decides which lyrics to show.
    val songId = player.currentMediaId?.toLongOrNull()
    LaunchedEffect(songId, player.title) {
        if (songId != null) {
            lyricsVm.load(LyricsQuery(songId, player.title.orEmpty(), player.artist.orEmpty(), player.album.orEmpty(), player.durationMs))
        }
    }
    // Coming back from the "all files access" settings page: look for .lrc files again.
    LaunchedEffect(fileAccess) { lyricsVm.reload() }
    // Position that moves on every frame while the song plays (see LivePosition.kt).
    val livePos = rememberLivePositionMs(player, poll = true)

    var locked by rememberSaveable { mutableStateOf(LyricsPrefs.keepScreenOn.value) }
    DisposableEffect(locked) {
        view.keepScreenOn = locked
        onDispose { view.keepScreenOn = false }
    }

    val scale = LyricsPrefs.scale.floatValue
    val canSearchOnline = LyricsPrefs.onlineSearch.value
    var showInfo by remember { mutableStateOf(false) }
    // The translation the person added for this song, and whether it is the one shown (Original | Translation).
    val translations by LyricsTranslations.map.collectAsState()
    val translation = songId?.let { translations[it] }
    var showTranslation by rememberSaveable(songId) { mutableStateOf(false) }
    var editingTranslation by remember { mutableStateOf(false) }
    val aligned = remember(lyrics, translation) { if (lyrics != null && translation != null) alignTranslation(lyrics.lines, translation) else null }
    // Per-song sync offset: positive shows the lines later, negative earlier.
    var offsetMs by remember(songId) { mutableIntStateOf(LyricsPrefs.offsetMs(songId ?: -1L)) }

    Box(modifier.fillMaxSize().safeDrawingPadding()) {
        // ---- lyrics (or the empty state) ----
        Box(Modifier.fillMaxSize().padding(top = 72.dp, bottom = 84.dp)) {
            when {
                state.loading -> CircularProgressIndicator(Modifier.align(Alignment.Center), color = Color.White)
                lyrics != null -> LyricsList(
                    lines = if (showTranslation && aligned != null) lyrics.lines.mapIndexed { i, l -> LyricLine(l.timeMs, aligned[i] ?: l.text) } else lyrics.lines,
                    synced = lyrics.synced,
                    positionMs = { livePos.value + LYRICS_LEAD_MS - offsetMs },
                    scale = scale,
                    onSeek = { player.seekTo(it) }
                )
                else -> EmptyState(
                    searching = state.searching,
                    message = state.message,
                    fileAccess = fileAccess && LyricsPrefs.useLrcFiles.value,
                    canSearch = canSearchOnline,
                    onSearch = { lyricsVm.searchOnline() },
                    onWrite = onEdit,
                    onAllowFiles = { FileAccess.openSettings(context) }
                )
            }
        }

        // ---- header ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RoundIconButton(NeedleIcon.CHEVRON_DOWN, onClose, size = 42.dp, iconSize = 22.dp)
            Column(Modifier.weight(1f)) {
                Text(player.title.orEmpty(), color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
                Text(player.artist.orEmpty(), color = Color(0xFFB9BDD0), fontSize = 11.5.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis)
            }
            RoundIconButton(
                if (locked) NeedleIcon.LOCK else NeedleIcon.UNLOCK, { locked = !locked },
                size = 42.dp, iconSize = 21.dp, active = locked
            )
            RoundIconButton(NeedleIcon.INFO, { showInfo = true }, size = 42.dp, iconSize = 21.dp)
        }

        // ---- text size slider ----
        if (lyrics != null) {
            val fraction = ((1.5f - scale) / 0.7f).coerceIn(0f, 1f)
            TextSizeSlider(
                fraction = fraction,
                onFraction = { LyricsPrefs.scale.floatValue = 1.5f - 0.7f * it },
                onDone = { LyricsPrefs.saveScale() },
                modifier = Modifier.align(Alignment.CenterEnd).padding(end = 12.dp)
            )
        }

        // ---- bottom bar ----
        if (!state.loading) {
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 16.dp, vertical = 22.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    Modifier
                        .height(42.dp)
                        .glass(cornerShape(99.dp))
                        .clickable(onClick = onEdit)
                        .padding(horizontal = 18.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeedleIconView(NeedleIcon.PENCIL, Color.White, size = 18.dp)
                    Spacer(Modifier.width(8.dp))
                    Text(if (lyrics == null) "Write lyrics" else "Edit lyrics", color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                if (lyrics != null) {
                    if (translation == null) {
                        Row(
                            Modifier.height(42.dp).glass(cornerShape(99.dp)).clickable { editingTranslation = true }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) { Text("Add translation", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold) }
                    } else {
                        // Original | Translation. Press and hold to change or remove the translation.
                        Row(
                            Modifier.height(42.dp).glass(cornerShape(99.dp)).tapOrHold({ showTranslation = !showTranslation }, { editingTranslation = true }).padding(horizontal = 4.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            listOf("Original" to false, "Translation" to true).forEach { (label, tr) ->
                                Text(
                                    label,
                                    color = if (showTranslation == tr) Color(0xFF111111) else Color.White,
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    modifier = Modifier
                                        .clip(CircleShape)
                                        .background(if (showTranslation == tr) Color.White else Color.Transparent)
                                        .padding(horizontal = 12.dp, vertical = 7.dp)
                                )
                            }
                        }
                    }
                    RoundIconButton(
                        NeedleIcon.SHARE,
                        {
                            val text = "${player.title.orEmpty()} - ${player.artist.orEmpty()}\n\n${lyrics.plainText()}"
                            val send = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
                            context.startActivity(Intent.createChooser(send, "Share lyrics"))
                        },
                        size = 42.dp, iconSize = 21.dp
                    )
                }
            }
        }
    }

    if (editingTranslation && songId != null) {
        LyricsTranslationDialog(
            songTitle = player.title.orEmpty(),
            existing = translation,
            onSave = { t ->
                LyricsTranslations.set(songId, t)
                showTranslation = t.isNotBlank()
                editingTranslation = false
            },
            onDismiss = { editingTranslation = false }
        )
    }

    if (showInfo) {
        AlertDialog(
            shape = cornerShape(28.dp),
            onDismissRequest = { showInfo = false },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted,
            title = { Text("Lyrics") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        if (lyrics == null) "No lyrics found for this song yet."
                        else "From ${lyrics.source.label}. ${if (lyrics.synced) "Timed lyrics: they follow the song." else "Plain text: no timing, so no highlight."}"
                    )
                    if (lyrics?.synced == true) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text("Sync offset", color = Palette.Text)
                                Text("+ shows the lines later, − earlier", fontSize = 11.5.sp)
                            }
                            TextButton(onClick = {
                                offsetMs -= 100
                                songId?.let { LyricsPrefs.setOffsetMs(it, offsetMs) }
                            }) { Text("−0.1", color = Palette.Accent) }
                            Text(
                                if (offsetMs == 0) "0.0 s" else "%+.1f s".format(offsetMs / 1000f),
                                color = Palette.Text, modifier = Modifier.width(52.dp), textAlign = TextAlign.Center
                            )
                            TextButton(onClick = {
                                offsetMs += 100
                                songId?.let { LyricsPrefs.setOffsetMs(it, offsetMs) }
                            }) { Text("+0.1", color = Palette.Accent) }
                        }
                    }
                    if (LyricsPrefs.useLrcFiles.value) {
                        Text(
                            if (fileAccess) "Needle can read .lrc files next to your songs."
                            else "Needle can't read .lrc files next to your songs yet. Allow access to all files to use them."
                        )
                        if (!fileAccess) {
                            TextButton(onClick = { FileAccess.openSettings(context) }) { Text("Allow access to files", color = Palette.Accent) }
                        }
                    }
                    if (canSearchOnline) {
                        TextButton(onClick = { lyricsVm.searchOnline(); showInfo = false }) { Text("Search online again", color = Palette.Accent) }
                    }
                    if (lyrics?.source == LyricsSource.SAVED) {
                        TextButton(onClick = { lyricsVm.forgetSaved(); showInfo = false }) { Text("Forget the saved lyrics", color = Palette.Accent) }
                    }
                }
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Close", color = Palette.Accent) } }
        )
    }
}

@Composable
private fun LyricsList(
    lines: List<app.needle.music.data.LyricLine>,
    synced: Boolean,
    positionMs: () -> Long,
    scale: Float,
    onSeek: (Long) -> Unit
) {
    val listState = rememberLazyListState()
    // One font for every line (chosen in Settings -> Lyrics), so a line never changes typeface while it grows.
    val font = LyricsFont.byId(LyricsPrefs.font.value)
    val active by remember(lines, synced) {
        derivedStateOf { if (synced) LrcParser.activeIndex(lines, positionMs()) else -1 }
    }

    // Keep the line being sung a little above the middle. Instead of one jumpy "animate to item",
    // the list glides toward that spot on every frame, so it follows the lines while they grow and shrink.
    // If the person is scrolling by hand, it leaves them alone until the next line.
    LaunchedEffect(active, lines) {
        if (!synced || active < 0 || listState.isScrollInProgress) return@LaunchedEffect
        val startNs = withFrameNanos { it }
        var lastNs = startNs
        while (true) {
            val nowNs = withFrameNanos { it }
            if (listState.isScrollInProgress) break
            val dt = ((nowNs - lastNs) / 1_000_000_000f).coerceIn(0f, 0.1f)
            lastNs = nowNs
            val elapsedMs = (nowNs - startNs) / 1_000_000L

            val info = listState.layoutInfo
            val target = info.viewportSize.height * 0.22f
            val item = info.visibleItemsInfo.firstOrNull { it.index == active }
            if (item == null) {
                // Far away (just opened mid-song, or a big jump): go straight there.
                listState.scrollToItem(active, -target.toInt())
                continue
            }
            val err = item.offset - target
            if (elapsedMs > 1500 || (elapsedMs > 450 && abs(err) < 0.5f)) break
            if (abs(err) >= 0.5f) listState.scrollBy(err * (1f - exp(-dt / 0.12f)))
        }
    }

    LazyColumn(
        state = listState,
        contentPadding = PaddingValues(start = 22.dp, end = 52.dp, top = 40.dp, bottom = 220.dp),
        modifier = Modifier
            .fillMaxSize()
            .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
            .drawWithContent {
                drawContent()
                drawRect(
                    Brush.verticalGradient(0f to Color.Transparent, 0.06f to Color.Black, 0.88f to Color.Black, 1f to Color.Transparent),
                    blendMode = BlendMode.DstIn
                )
            }
    ) {
        itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
            if (line.text.isEmpty()) {
                Spacer(Modifier.height(if (synced) 14.dp else 18.dp))
            } else if (synced) {
                // One 0..1 value drives size, color and line height together; the text-size slider still applies at once.
                val t by animateFloatAsState(
                    if (i == active) 1f else 0f,
                    animationSpec = tween(320, easing = FastOutSlowInEasing),
                    label = "lineActive"
                )
                val size = (21f + 9f * t) * scale
                Text(
                    line.text,
                    color = lerp(Dim, Color.White, t),
                    fontSize = size.sp,
                    lineHeight = (size * (1.25f - 0.10f * t)).sp,
                    fontFamily = font.family,
                    fontWeight = font.weight,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null) { onSeek(line.timeMs) }
                        .padding(bottom = 18.dp)
                )
            } else {
                Text(
                    line.text,
                    color = Color(0xFFF2F3F8),
                    fontSize = (19f * scale).sp,
                    lineHeight = (19f * scale * 1.5f).sp,
                    fontFamily = font.family,
                    fontWeight = font.weight,
                    modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)
                )
            }
        }
    }
}

@Composable
private fun EmptyState(
    searching: Boolean,
    message: String?,
    fileAccess: Boolean,
    canSearch: Boolean,
    onSearch: () -> Unit,
    onWrite: () -> Unit,
    onAllowFiles: () -> Unit
) {
    Column(
        Modifier.fillMaxSize().padding(horizontal = 32.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            "No lyrics yet", color = Color.White, fontSize = 28.sp, textAlign = TextAlign.Center,
            fontFamily = LyricsFont.byId(LyricsPrefs.font.value).family, fontWeight = LyricsFont.byId(LyricsPrefs.font.value).weight
        )
        Spacer(Modifier.height(8.dp))
        Text(
            message ?: "Needle looks for a .lrc file next to the song, then for the Lyrics tag.${if (canSearch) " You can also search online." else ""}",
            color = Color(0xFFD6D8E4), fontSize = 14.sp, lineHeight = 20.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(20.dp))
        if (searching) {
            CircularProgressIndicator(Modifier.size(28.dp), color = Color.White, strokeWidth = 2.5.dp)
        } else if (canSearch) {
            PillButton("Search online", onSearch, filled = true)
        }
        if (!searching) {
            Spacer(Modifier.height(10.dp))
            PillButton("Write lyrics", onWrite, filled = !canSearch)
        }
        if (!fileAccess) {
            Spacer(Modifier.height(24.dp))
            Column(
                Modifier.fillMaxWidth().glass(cornerShape(22.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    ".lrc files next to your songs can only be read if you allow access to all files.",
                    color = Color(0xFFD6D8E4), fontSize = 13.sp, lineHeight = 18.sp, textAlign = TextAlign.Center
                )
                Spacer(Modifier.height(12.dp))
                PillButton("Allow access to files", onAllowFiles)
            }
        }
    }
}

/** The vertical slider on the right edge: drag or tap anywhere on it. Top is the biggest text. */
@Composable
private fun TextSizeSlider(fraction: Float, onFraction: (Float) -> Unit, onDone: () -> Unit, modifier: Modifier = Modifier) {
    BoxWithConstraints(
        modifier
            .width(30.dp)
            .height(250.dp)
            .pointerInput(Unit) {
                detectVerticalDragGestures(
                    onDragStart = { onFraction((it.y / size.height).coerceIn(0f, 1f)) },
                    onDragEnd = onDone,
                    onDragCancel = onDone,
                    onVerticalDrag = { change, _ -> onFraction((change.position.y / size.height).coerceIn(0f, 1f)) }
                )
            }
            .pointerInput(Unit) {
                detectTapGestures { onFraction((it.y / size.height).coerceIn(0f, 1f)); onDone() }
            }
    ) {
        Box(
            Modifier
                .align(Alignment.Center)
                .width(8.dp)
                .fillMaxHeight()
                .clip(cornerShape(9.dp))
                .background(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.55f), Color.White.copy(alpha = 0.06f))))
        )
        Box(
            Modifier
                .align(Alignment.TopCenter)
                .offset(y = maxHeight * fraction - 11.dp)
                .size(22.dp)
                .clip(CircleShape)
                .background(Color.White)
        )
    }
}
