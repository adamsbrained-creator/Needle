package app.needle.music.ui

import android.graphics.Bitmap
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import app.needle.music.data.CoverStore
import app.needle.music.data.ExtraTags
import app.needle.music.data.FieldDef
import app.needle.music.data.FieldGroup
import app.needle.music.data.FieldKind
import app.needle.music.data.TagFields
import app.needle.music.data.Song
import app.needle.music.data.TagChanges
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** The text boxes of the editor, as typed. */
private data class TagForm(
    val title: String = "",
    val artist: String = "",
    val album: String = "",
    val genre: String = "",
    val year: String = "",
    val track: String = ""
)

private fun clean(value: String, placeholder: String) = if (value == placeholder) "" else value

/** What the boxes start with: a value shared by all the songs, or empty when they differ. */
private fun formOf(songs: List<Song>): TagForm {
    fun shared(pick: (Song) -> String): String = songs.map(pick).distinct().singleOrNull() ?: ""
    return TagForm(
        title = shared { clean(it.title, "Unknown title") },
        artist = shared { clean(it.artist, "Unknown artist") },
        album = shared { clean(it.album, "Unknown album") },
        genre = shared { it.genre },
        year = shared { if (it.year > 0) it.year.toString() else "" },
        track = shared { if (it.trackNumber > 0) it.trackNumber.toString() else "" }
    )
}

private fun differs(songs: List<Song>, pick: (Song) -> String) = songs.map(pick).distinct().size > 1

/** Only the boxes the person actually changed. */
private fun changesBetween(start: TagForm, now: TagForm) = TagChanges(
    title = now.title.takeIf { it != start.title },
    artist = now.artist.takeIf { it != start.artist },
    album = now.album.takeIf { it != start.album },
    genre = now.genre.takeIf { it != start.genre },
    year = now.year.takeIf { it != start.year },
    track = now.track.takeIf { it != start.track }
)

/**
 * Many files are named "Artist - Title" or "01 - Title" with no tags. Fills the empty boxes from that.
 */
private fun guessFromTitle(form: TagForm): TagForm {
    var title = form.title.trim()
    var artist = form.artist
    var track = form.track
    Regex("^(\\d{1,2})\\s*[-.]\\s+(.+)$").find(title)?.let { m ->
        if (track.isBlank()) track = m.groupValues[1].toInt().toString()
        title = m.groupValues[2].trim()
    }
    val dash = title.indexOf(" - ")
    if (dash > 0 && artist.isBlank()) {
        artist = title.substring(0, dash).trim()
        title = title.substring(dash + 3).trim()
    }
    return form.copy(title = title, artist = artist, track = track)
}

/**
 * Tag editor from the mockup. One song: all six boxes. Several songs (an album): the shared ones
 * (artist, album, genre, year), applied to all of them.
 * [trackTotal] is how many songs the album has, for "1 of 9". The lyrics button waits for the lyrics editor.
 */
@Composable
fun TagEditorScreen(
    songs: List<Song>,
    extras: ExtraTags,
    trackTotal: Int,
    writeToFiles: Boolean,
    onClose: () -> Unit,
    onSave: (TagChanges, Bitmap?) -> Unit,
    modifier: Modifier = Modifier
) {
    if (songs.isEmpty()) return
    val context = LocalContext.current
    val single = songs.size == 1
    val start = remember(songs) { formOf(songs) }
    var form by remember(songs) { mutableStateOf(start) }

    // The other tags: which ones are shown, what they hold, and which the person removed.
    val startExtras = remember(songs, extras) { extrasFormOf(songs, extras) }
    var extraKeys by remember(songs, extras) { mutableStateOf(TagFields.sortKeys(startExtras.keys)) }
    var extraValues by remember(songs, extras) { mutableStateOf(startExtras) }
    var removedKeys by remember(songs, extras) { mutableStateOf(emptySet<String>()) }
    var showPicker by remember { mutableStateOf(false) }

    // A cover picked from the phone, shown right away and saved with the tags.
    var pickedUri by remember { mutableStateOf<Uri?>(null) }
    var pickedCover by remember { mutableStateOf<Bitmap?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) pickedUri = uri
    }
    LaunchedEffect(pickedUri) {
        val uri = pickedUri ?: return@LaunchedEffect
        pickedCover = withContext(Dispatchers.IO) { CoverStore.decode(context, uri) }
    }

    val artistShown = form.artist.ifBlank { songs.first().artist.takeIf { single } ?: "" }
    val heroTitle = if (single) form.title.ifBlank { songs.first().title } else form.album.ifBlank { songs.first().album }
    val heroSub = buildString {
        append(artistShown.ifBlank { "Various artists" })
        append(" · ")
        append(if (single && trackTotal < 2) "Single" else tracksText(trackTotal))
    }

    Column(
        modifier
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 14.dp, vertical = 6.dp)
    ) {
        // ---- cover card ------------------------------------------------------------------
        Box(Modifier.fillMaxWidth().height(290.dp).clip(cornerShape(30.dp)).background(Palette.Card)) {
            val picked = pickedCover
            if (picked != null) {
                Image(picked.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                HeroCover(songs.first(), Modifier.fillMaxSize())
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.62f))
                )
            )
            Row(
                Modifier.fillMaxWidth().padding(14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                RoundIconButton(NeedleIcon.BACK, onClose, size = 40.dp, iconSize = 22.dp, scrim = true, tint = Color.White)
                Spacer(Modifier.weight(1f))
                // Kept small: the cover button below does the same thing.
                Row(
                    Modifier
                        .height(30.dp)
                        .clip(CircleShape)
                        .background(Color.White)
                        .clickable { picker.launch("image/*") }
                        .padding(horizontal = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(5.dp)
                ) {
                    NeedleIconView(NeedleIcon.IMAGE, Color(0xFF111111), size = 14.dp)
                    Text("Change cover", color = Color(0xFF111111), fontSize = 11.5.sp, fontWeight = FontWeight.SemiBold)
                }
            }
            Column(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(start = 16.dp, end = 16.dp, bottom = 22.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    heroTitle, color = Color.White, fontFamily = Palette.TitleFont, fontSize = 38.sp, lineHeight = 40.sp,
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    heroSub, color = Color(0xFFE6E6EA), fontSize = 13.sp, textAlign = TextAlign.Center,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp)
                )
            }
        }

        // ---- edit panel --------------------------------------------------------------------
        Column(
            Modifier
                .padding(top = 10.dp)
                .fillMaxWidth()
                .clip(cornerShape(26.dp))
                .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.07f), Palette.Accent.copy(alpha = 0.42f))))
                .border(1.dp, Color.White.copy(alpha = 0.1f), cornerShape(26.dp))
                .padding(14.dp)
        ) {
            Row(Modifier.fillMaxWidth().padding(bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(
                    if (single) "Edit tags" else "Edit tags · ${songs.size} songs",
                    color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.weight(1f)
                )
                Box(Modifier.size(32.dp).clip(CircleShape).clickable(onClick = onClose), contentAlignment = Alignment.Center) {
                    NeedleIconView(NeedleIcon.CLOSE, Color.White, size = 18.dp)
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                if (single) {
                    FieldRow(
                        TagField("Title", form.title, { form = form.copy(title = it) }),
                        TagField("Artist", form.artist, { form = form.copy(artist = it) }, hint = "Unknown")
                    )
                    FieldRow(
                        TagField("Album", form.album, { form = form.copy(album = it) }, hint = "Unknown"),
                        TagField("Genre", form.genre, { form = form.copy(genre = it) }, hint = "Add genre")
                    )
                    FieldRow(
                        TagField("Year", form.year, { form = form.copy(year = it.filter(Char::isDigit).take(4)) }, number = true, hint = "Year"),
                        TagField(
                            "Track", form.track, { form = form.copy(track = it.filter(Char::isDigit).take(3)) },
                            number = true, hint = "No.", suffix = if (trackTotal > 1) "of $trackTotal" else null
                        )
                    )
                } else {
                    // An empty box says "Different" when the songs disagree, otherwise "Add".
                    fun hintFor(pick: (Song) -> String) = if (differs(songs, pick)) "Different" else "Add"
                    FieldRow(
                        TagField("Artist", form.artist, { form = form.copy(artist = it) }, hint = hintFor { it.artist }),
                        TagField("Album", form.album, { form = form.copy(album = it) }, hint = hintFor { it.album })
                    )
                    FieldRow(
                        TagField("Genre", form.genre, { form = form.copy(genre = it) }, hint = hintFor { it.genre }),
                        TagField(
                            "Year", form.year, { form = form.copy(year = it.filter(Char::isDigit).take(4)) },
                            number = true, hint = hintFor { it.year.toString() }
                        )
                    )
                }
            }

            if (extraKeys.isNotEmpty()) {
                Column(Modifier.padding(top = 8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    extraKeys.forEach { key ->
                        val def = TagFields.find(key)
                        val mixed = songs.map { extras[it.id]?.get(key).orEmpty() }.distinct().size > 1
                        ExtraFieldBox(
                            label = def?.label ?: key,
                            kind = def?.kind ?: FieldKind.TEXT,
                            value = extraValues[key].orEmpty(),
                            hint = if (mixed) "Different" else def?.hint?.ifBlank { "Add" } ?: "Add",
                            onChange = { extraValues = extraValues + (key to it) },
                            onRemove = {
                                extraKeys = extraKeys - key
                                removedKeys = removedKeys + key
                            }
                        )
                    }
                }
            }

            Row(
                Modifier.fillMaxWidth().padding(top = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                RoundAction(NeedleIcon.IMAGE, onClick = { picker.launch("image/*") })
                // Fills empty boxes from a file name like "Artist - Title". Only for a single song.
                if (single) RoundAction(NeedleIcon.TAG, onClick = { form = guessFromTitle(form) })
                // Opens the list of all the other tags.
                Row(
                    Modifier
                        .height(40.dp)
                        .clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.14f))
                        .clickable { showPicker = true }
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NeedleIconView(NeedleIcon.PLUS, Color.White, size = 16.dp)
                    Text("Add field", color = Color.White, fontSize = 12.5.sp)
                }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color.White)
                        .clickable {
                            val changed = LinkedHashMap<String, String>()
                            removedKeys.forEach { changed[it] = "" }
                            extraKeys.forEach { key ->
                                val now = extraValues[key].orEmpty()
                                if (now != startExtras[key].orEmpty()) changed[key] = now
                            }
                            onSave(changesBetween(start, form).copy(extras = changed), pickedCover)
                        },
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 20.dp) }
            }
            // What saving does (Settings > Library > Write tags into the files)
            Text(
                if (writeToFiles) "Saves in Needle and writes into the audio file" else "Saves in Needle only",
                color = Color.White.copy(alpha = 0.5f), fontSize = 11.5.sp,
                modifier = Modifier.padding(top = 10.dp)
            )
        }
    }

    if (showPicker) {
        FieldPicker(
            taken = extraKeys.toSet(),
            onPick = { key ->
                extraKeys = TagFields.sortKeys(extraKeys + key)
                if (key !in extraValues) extraValues = extraValues + (key to "")
                removedKeys = removedKeys - key
                showPicker = false
            },
            onDismiss = { showPicker = false }
        )
    }
}

/** For each other tag the songs have: the value they share, or empty when they differ. */
private fun extrasFormOf(songs: List<Song>, extras: ExtraTags): Map<String, String> {
    val keys = songs.flatMap { extras[it.id]?.keys.orEmpty() }.toSet()
    return keys.associateWith { key ->
        songs.map { extras[it.id]?.get(key).orEmpty() }.distinct().singleOrNull() ?: ""
    }
}

private class TagField(
    val label: String,
    val value: String,
    val onChange: (String) -> Unit,
    val number: Boolean = false,
    val hint: String = "",
    val suffix: String? = null
)

@Composable
private fun FieldRow(left: TagField, right: TagField) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        FieldBox(left, Modifier.weight(1f))
        FieldBox(right, Modifier.weight(1f))
    }
}

@Composable
private fun FieldBox(field: TagField, modifier: Modifier) {
    Column(
        modifier
            .clip(cornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.11f))
            .padding(horizontal = 12.dp, vertical = 8.dp)
    ) {
        Text(field.label, color = Palette.Muted, fontSize = 10.5.sp)
        Row(verticalAlignment = Alignment.CenterVertically) {
            // With a suffix ("of 9") the number box is narrow; otherwise it takes the whole row.
            Box(if (field.suffix == null) Modifier.weight(1f) else Modifier.width(36.dp)) {
                BasicTextField(
                    value = field.value,
                    onValueChange = field.onChange,
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(keyboardType = if (field.number) KeyboardType.Number else KeyboardType.Text),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                if (field.value.isEmpty()) {
                    Text(
                        field.hint, color = Color.White.copy(alpha = 0.35f), fontSize = 13.5.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
            if (field.suffix != null) {
                Spacer(Modifier.width(4.dp))
                Text(field.suffix, color = Color.White.copy(alpha = 0.7f), fontSize = 13.5.sp, maxLines = 1)
            }
        }
    }
}

@Composable
private fun RoundAction(icon: NeedleIcon, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.14f)).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) { NeedleIconView(icon, Color.White, size = 20.dp) }
}


/** A full-width box for one of the other tags, with a small x to take the tag away again. */
@Composable
private fun ExtraFieldBox(
    label: String,
    kind: FieldKind,
    value: String,
    hint: String,
    onChange: (String) -> Unit,
    onRemove: () -> Unit
) {
    Column(
        Modifier
            .fillMaxWidth()
            .clip(cornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.11f))
            .padding(start = 12.dp, end = 6.dp, top = 8.dp, bottom = 8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                label, color = Palette.Muted, fontSize = 10.5.sp, maxLines = 1,
                overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
            )
            Box(
                Modifier.size(24.dp).clip(CircleShape).clickable(onClick = onRemove),
                contentAlignment = Alignment.Center
            ) { NeedleIconView(NeedleIcon.CLOSE, Palette.Muted, size = 13.dp) }
        }
        if (kind == FieldKind.FLAG) {
            val on = value == "1"
            Text(
                if (on) "Yes" else "No",
                color = if (on) Color.White else Color.White.copy(alpha = 0.6f),
                fontSize = 13.sp,
                modifier = Modifier
                    .padding(top = 4.dp, bottom = 2.dp)
                    .clip(CircleShape)
                    .background(if (on) Palette.Accent else Color.White.copy(alpha = 0.12f))
                    .clickable { onChange(if (on) "" else "1") }
                    .padding(horizontal = 14.dp, vertical = 4.dp)
            )
        } else {
            val long = kind == FieldKind.LONG_TEXT
            Box(Modifier.padding(end = 6.dp)) {
                BasicTextField(
                    value = value,
                    onValueChange = { onChange(if (kind == FieldKind.NUMBER) it.filter(Char::isDigit).take(6) else it) },
                    singleLine = !long,
                    minLines = if (long) 2 else 1,
                    textStyle = TextStyle(color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Medium),
                    cursorBrush = SolidColor(Color.White),
                    keyboardOptions = KeyboardOptions(
                        keyboardType = if (kind == FieldKind.NUMBER) KeyboardType.Number else KeyboardType.Text
                    ),
                    modifier = Modifier.fillMaxWidth().padding(vertical = 2.dp)
                )
                if (value.isEmpty()) {
                    Text(
                        hint, color = Color.White.copy(alpha = 0.35f), fontSize = 13.5.sp,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

/** The list of every other tag, with a search box. A name that is not in the list can be added as your own field. */
@Composable
private fun FieldPicker(taken: Set<String>, onPick: (String) -> Unit, onDismiss: () -> Unit) {
    var query by remember { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    val q = query.trim()
    val available = TagFields.all.filter { it.key !in taken }
    val matches: List<FieldDef> =
        if (q.isEmpty()) available else available.filter { it.label.contains(q, true) || it.key.contains(q, true) }
    val canAddCustom = q.isNotEmpty() && q.length <= 40 &&
        TagFields.all.none { it.key.equals(q, true) || it.label.equals(q, true) } &&
        taken.none { it.equals(q, true) }

    Dialog(onDismissRequest = onDismiss, properties = DialogProperties(usePlatformDefaultWidth = false)) {
        Column(
            Modifier
                .fillMaxWidth(0.92f)
                .clip(cornerShape(26.dp))
                .background(Color(0xFF26232B))
                .padding(14.dp)
        ) {
            Text("Add field", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Box(
                Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth()
                    .clip(cornerShape(14.dp))
                    .background(Color.White.copy(alpha = 0.11f))
                    .padding(horizontal = 12.dp, vertical = 10.dp)
            ) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 14.sp),
                    cursorBrush = SolidColor(Color.White),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus)
                )
                if (query.isEmpty()) {
                    Text("Search, or type your own name", color = Color.White.copy(alpha = 0.35f), fontSize = 14.sp)
                }
            }

            LazyColumn(Modifier.padding(top = 6.dp).heightIn(max = 420.dp)) {
                if (canAddCustom) {
                    item { PickerRow("Add \u201c$q\u201d as your own field", "Custom") { onPick(q) } }
                }
                if (q.isEmpty()) {
                    FieldGroup.entries.forEach { group ->
                        val inGroup = matches.filter { it.group == group }
                        if (inGroup.isNotEmpty()) {
                            item(key = "group-${group.name}") {
                                Text(
                                    group.label.uppercase(), color = Palette.Muted, fontSize = 11.sp,
                                    modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 2.dp)
                                )
                            }
                            items(inGroup, key = { it.key }) { def -> PickerRow(def.label, null) { onPick(def.key) } }
                        }
                    }
                } else {
                    items(matches, key = { it.key }) { def -> PickerRow(def.label, def.group.label) { onPick(def.key) } }
                }
            }
        }
    }
}

@Composable
private fun PickerRow(title: String, note: String?, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clip(cornerShape(10.dp)).clickable(onClick = onClick).padding(horizontal = 6.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color.White, fontSize = 14.5.sp, modifier = Modifier.weight(1f), maxLines = 1, overflow = TextOverflow.Ellipsis)
        if (note != null) Text(note, color = Palette.Muted, fontSize = 11.5.sp)
    }
}
