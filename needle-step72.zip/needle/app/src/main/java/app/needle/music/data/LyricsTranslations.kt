package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONObject
import kotlin.math.abs

/**
 * Translations of lyrics that the person pasted or imported (Needle has no translation service, so nothing is sent
 * anywhere). One text per song: plain lines in the same order as the lyrics, or a timed .lrc file. Remembered.
 */
object LyricsTranslations {
    private var prefs: SharedPreferences? = null

    val map = MutableStateFlow<Map<Long, String>>(emptyMap())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_lyrics_translations", Context.MODE_PRIVATE)
        prefs = p
        map.value = parse(p.getString("all", null))
    }

    private fun parse(json: String?): Map<Long, String> {
        if (json.isNullOrBlank()) return emptyMap()
        return try {
            val o = JSONObject(json)
            o.keys().asSequence().mapNotNull { k -> k.toLongOrNull()?.let { it to o.optString(k) } }.filter { it.second.isNotBlank() }.toMap()
        } catch (_: Exception) {
            emptyMap()
        }
    }

    fun toJson(): JSONObject = JSONObject().also { o -> map.value.forEach { (id, text) -> o.put(id.toString(), text) } }

    /** Saves the translation of a song; empty text removes it. */
    fun set(songId: Long, text: String) {
        val clean = text.trim()
        save(if (clean.isEmpty()) map.value - songId else map.value + (songId to clean))
    }

    fun merge(json: JSONObject) = save(parse(json.toString()) + map.value)

    private fun save(m: Map<Long, String>) {
        map.value = m
        prefs?.edit()?.putString("all", toJson().toString())?.apply()
    }
}

/**
 * Lines the translation gives for each line of the lyrics (null = none for that line).
 *  - A timed translation (.lrc) is matched by time: the translated line nearest to the original line, within 1.5 seconds.
 *  - A plain translation is matched in order: its non-empty lines go to the non-empty lines of the lyrics.
 */
fun alignTranslation(lines: List<LyricLine>, raw: String): List<String?> {
    val timed = LrcParser.parse(raw, LyricsSource.TAGS)
    if (timed != null && timed.synced) {
        val tr = timed.lines.filter { it.text.isNotEmpty() }
        return lines.map { line ->
            if (line.text.isEmpty() || line.timeMs < 0) null
            else tr.minByOrNull { abs(it.timeMs - line.timeMs) }?.takeIf { abs(it.timeMs - line.timeMs) <= 1500 }?.text
        }
    }
    val words = raw.replace("\r\n", "\n").replace('\r', '\n').split('\n').map { it.trim() }.filter { it.isNotEmpty() }
    var next = 0
    return lines.map { line ->
        if (line.text.isEmpty()) null else words.getOrNull(next++)
    }
}
