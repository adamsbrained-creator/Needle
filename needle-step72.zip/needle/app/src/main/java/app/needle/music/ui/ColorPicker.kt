package app.needle.music.ui

import android.graphics.Color as AndroidColor
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog

private fun hexOf(c: Color): String = "#%06X".format(c.toArgb() and 0xFFFFFF)

private fun parseHex(text: String): Color? {
    val t = text.trim().removePrefix("#")
    if (t.length != 6) return null
    val v = t.toLongOrNull(16) ?: return null
    return Color((0xFF000000L or v).toInt())
}

/**
 * A slider with a colored track, used for hue, saturation, brightness and opacity.
 * [value] runs from 0 to 1. Tap or drag.
 */
@Composable
internal fun NeedleSlider(label: String, value: Float, brush: Brush, onChange: (Float) -> Unit) {
    val latest by rememberUpdatedState(onChange)
    Text(label, color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp, start = 2.dp))
    Box(
        Modifier
            .fillMaxWidth()
            .height(34.dp)
            .pointerInput(Unit) {
                detectTapGestures { o -> latest((o.x / size.width).coerceIn(0f, 1f)) }
            }
            .pointerInput(Unit) {
                detectHorizontalDragGestures { change, _ ->
                    change.consume()
                    latest((change.position.x / size.width).coerceIn(0f, 1f))
                }
            }
    ) {
        Box(Modifier.align(Alignment.Center).fillMaxWidth().height(14.dp).clip(CircleShape).background(brush))
        Canvas(Modifier.fillMaxSize()) {
            val r = 12.dp.toPx()
            val x = (value.coerceIn(0f, 1f) * size.width).coerceIn(r, size.width - r)
            drawCircle(Color.White, r, Offset(x, size.height / 2f))
            drawCircle(Color(0x66000000), r, Offset(x, size.height / 2f), style = Stroke(width = 1.5.dp.toPx()))
        }
    }
}

private val presets = listOf(
    Color(0xFFAF65F5), Color(0xFFEF42B8), Color(0xFF5B8DEF), Color(0xFF2DD4BF),
    Color(0xFF6FCF97), Color(0xFFF2994A), Color(0xFFEB5757), Color(0xFFF2C94C),
    Color.White, Color(0xFF8E8E93), Color(0xFF333335), Color(0xFF101012)
)

/**
 * Pick any color: three sliders, a hex box and a row of quick colors. Changes apply live while you drag.
 * [maxBrightness] keeps backgrounds dark enough for the light text on top of them.
 */
@Composable
fun ColorPickerDialog(
    title: String,
    initial: Color,
    onChange: (Color) -> Unit,
    onReset: (() -> Unit)?,
    onDismiss: () -> Unit,
    maxBrightness: Float = 1f
) {
    val start = remember { FloatArray(3).also { AndroidColor.colorToHSV(initial.toArgb(), it) } }
    var hue by remember { mutableFloatStateOf(start[0]) }
    var sat by remember { mutableFloatStateOf(start[1]) }
    var bright by remember { mutableFloatStateOf(start[2].coerceAtMost(maxBrightness)) }
    var hex by remember { mutableStateOf(hexOf(Color.hsv(start[0], start[1], start[2].coerceAtMost(maxBrightness)))) }

    fun current() = Color.hsv(hue, sat, bright)
    fun push() {
        val c = current()
        hex = hexOf(c)
        onChange(c)
    }
    fun setFrom(c: Color) {
        val a = FloatArray(3)
        AndroidColor.colorToHSV(c.toArgb(), a)
        hue = a[0]; sat = a[1]; bright = a[2].coerceAtMost(maxBrightness)
        push()
    }

    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.clip(cornerShape(26.dp)).background(Palette.Surface).padding(20.dp)) {
            Text(title, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 24.sp)
            Spacer(Modifier.height(12.dp))
            Box(
                Modifier.fillMaxWidth().height(56.dp).clip(cornerShape(16.dp)).background(current())
                    .border(1.dp, Color.White.copy(alpha = 0.25f), cornerShape(16.dp))
            )

            NeedleSlider("Hue", hue / 360f, Brush.horizontalGradient(List(7) { Color.hsv(it * 60f, 1f, 1f) })) {
                hue = it * 360f; push()
            }
            NeedleSlider("Saturation", sat, Brush.horizontalGradient(listOf(Color.hsv(hue, 0f, bright), Color.hsv(hue, 1f, bright)))) {
                sat = it; push()
            }
            NeedleSlider("Brightness", bright / maxBrightness.coerceAtLeast(0.01f),
                Brush.horizontalGradient(listOf(Color.Black, Color.hsv(hue, sat, maxBrightness)))) {
                bright = it * maxBrightness; push()
            }

            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Hex", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.width(34.dp))
                Box(Modifier.weight(1f).clip(cornerShape(14.dp)).background(Color.White.copy(alpha = 0.08f)).padding(horizontal = 14.dp, vertical = 11.dp)) {
                    BasicTextField(
                        value = hex,
                        onValueChange = { t ->
                            hex = t.take(7)
                            parseHex(hex)?.let { setFrom(it).also { hex = t.take(7) } }
                        },
                        singleLine = true,
                        textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium),
                        cursorBrush = SolidColor(Color.White),
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                presets.take(6).forEach { c -> Swatch(c) { setFrom(c) } }
            }
            Spacer(Modifier.height(6.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                presets.drop(6).forEach { c -> Swatch(c) { setFrom(c) } }
            }

            Spacer(Modifier.height(18.dp))
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (onReset != null) {
                    Text(
                        "Reset to default", color = Palette.Muted, fontSize = 14.sp,
                        modifier = Modifier.clip(CircleShape).clickable {
                            onReset()
                            onDismiss()
                        }.padding(horizontal = 6.dp, vertical = 8.dp)
                    )
                }
                Spacer(Modifier.weight(1f))
                PillButton("Done", onClick = onDismiss, filled = true)
            }
        }
    }
}

@Composable
private fun Swatch(color: Color, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).clip(CircleShape).background(color)
            .border(1.dp, Color.White.copy(alpha = 0.3f), CircleShape).clickable(onClick = onClick)
    )
}
