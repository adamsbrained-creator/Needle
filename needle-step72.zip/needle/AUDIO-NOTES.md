# Speed & pitch, Volume levelling, Crossfade (Step 66, built on Step 65)

## New files
- playback/SpeedPrefs.kt   the speed / pitch settings, for everything and per song, remembered
- playback/Loudness.kt     Volume levelling: the gain logic and the audio processor that measures and applies it

## Speed & pitch (the mockup's dialog)
- Speed 0.5x to 2x with a slider, end labels and quick chips 0.75x / 1.0x / 1.25x / 1.5x.
- Pitch in semitones, -6 to +6 (it used to be a second 0.5x-2x ratio slider).
- "Keep pitch when changing speed" (on by default): off gives the tape effect, where faster also means higher.
- "Remember for this song": on, the setting belongs to the song that is playing and comes back whenever it plays;
  off, it is the one setting for every song. Turning it off makes the current values the common ones.
- "Reset to normal" (speed 1.0x, pitch 0) for whichever of the two is active.
- It is remembered between runs (before, it was lost when the app closed). The Player controls tile shows
  "1.25x · +2 st" when the pitch is changed. Not while casting, as before.

## Volume levelling (Settings > Playback, and "Loudness normalization" in the equalizer: one switch)
Songs end up about equally loud (target about -18 LUFS, the ReplayGain level). The gain is limited to -12 .. +6 dB,
and a boost goes through a soft limiter so it cannot crackle.
- A song with a ReplayGain tag (track gain, else album gain; the track peak keeps a boost from clipping) is levelled
  right away. Needle can now read these tags: ReplayGain track/album gain and peak are new tag fields, also shown in
  the tag editor. Songs scanned before this update need Settings > Library > Read tags from files > Re-read once.
- Other songs: Needle measures how loud a song is while it plays and remembers it, so the song is levelled from its
  second play on. A song heard for the first time plays untouched (a gain changing mid-song would be heard as pumping).
- The gain moves smoothly (about a quarter of a second). It works on this phone's playback only, 16-bit and float
  sound (the same as the equalizer); a cast device gets the original.
- Backup: the switch is saved with the other settings. What Needle learned is not backed up (it relearns).

## Crossfade (Settings > Playback)
Off, 2, 4, 6, 8 or 12 seconds. The end of a song fades out and the next fades in, each over half the time, so the dip
lasts about the time chosen; a fade never takes more than a quarter of a song. Songs you pick by hand (tap, next,
previous) start at full volume. It stays out of the way of the sleep timer's fade and of casting.
IMPORTANT: this is a fade, not an overlap. The two songs do not play at the same time. A real overlapping crossfade
needs a second player running alongside the first; I did not start that, it touches the queue, casting and the
media session.

## Changed
- data/NeedleSettings.kt (volumeLevelling, crossfadeSec, in backups), data/TagFields.kt (ReplayGain fields)
- playback/PlayerViewModel.kt (speed state and per-song apply), playback/PlaybackService.kt (levelling, crossfade,
  tag lookup), playback/SleepTimer.kt (isFading)
- ui/PlayerControlsSheet.kt (the new dialog), ui/EqualizerScreen.kt (the switch works), ui/SettingsScreen.kt (Playback
  page and its search words), ui/NeedleApp.kt (dialog hookup)
- MainActivity.kt: loads the speed settings

## Not done
- Opus files use R128 gain tags, which are not read (they get the learned level instead).
- "Remember for this song" is not in backups.
- No compiler or device here: checked brace balance, imports and every name against Step 65. The audio part
  (levelling and fades) especially needs a listen on a real phone. Please build once.
