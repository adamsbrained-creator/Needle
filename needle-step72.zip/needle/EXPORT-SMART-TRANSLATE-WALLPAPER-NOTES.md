# Playlist export, smart playlists, lyrics translation, wallpaper (Step 72, built on Step 71)

## Playlist export (.m3u)
Playlist menu (press and hold a playlist) > "Export as .m3u". Android asks where to save it, then Needle writes an .m3u8
(UTF-8) with each song's duration, "Artist - Title" and its path relative to the phone's storage ("Music/Indie/Song.flac").
Needle's own import reads these files back, so a playlist can go phone -> computer -> phone. Hidden songs that are in the playlist are
written too. The toast says "Exported 41 of 48 songs" if some files could not be found in the media list.

## Smart playlists
Library > Playlists > New playlist (the last tile) > "Smart playlist". One rule, how many songs, and the order:
- Rules: Added recently (days), Played often (at least N times), Not played for a while (months), Never played, Genre, Artist.
- How many: 25, 50, 100 or All. Order: Newest first, Most played, A to Z, Shuffled daily.
They fill themselves from the library and your play history and change when those change. They show in Library under All and Mine with a
SMART badge, and open on the same page as a mix: Play, Shuffle, "About this playlist" (the rule in words), Save as playlist (turns the
current songs into a normal playlist) and Edit (change or delete the rule). Included in backups.
Not included as rules: rating, year, folder (the play history and library data they need are not in one place yet).

## Lyrics translation (Original | Translation)
Needle has no translation service and sends nothing anywhere, so the translation is yours: on the lyrics page, "Add translation" opens a
box where you paste it, take it from the clipboard, or open a text or .lrc file.
- Plain text: one line for each line of the lyrics, in the same order (blank lines are ignored).
- A timed .lrc: matched to the lyrics by time (within 1.5 seconds).
Once a song has one, the bottom bar shows "Original | Translation"; tap to switch (timed lyrics keep following the song in both). Press and hold
it to change or remove the translation. Saved on the phone, in backups.

## Wallpaper
Settings > Customization > Colors & themes > Wallpaper: choose a picture, how much it is darkened (Light, Medium, Strong), and Blur
(Android 12 and newer). It is drawn behind every page, cropped from the middle, under a dark veil so text stays readable. Now playing keeps the
glow from the cover. Needle keeps only the link to the picture (like a Moment photo); a backup keeps the darkening and blur, not the link.

## Not done
- Light theme. Needle's colors are dark everywhere: about 260 places use white directly (text, icons and glass over covers), and every
  sheet, the dock and Now playing are built dark on purpose. A Light theme that is not half broken needs a screen-by-screen pass with
  screenshots (which screens stay dark, which flip, what the pills and icons become). Doing it blind would give a mess, so I did not
  start it. The plan: Palette gets a light mode, Now playing, the lyrics, the sheets and the dock stay dark, and the pages turn light, a few
  screens at a time with your screenshots.
- A true overlapping crossfade. It needs two players running at once, handing over the queue, the equalizer chain, volume levelling,
  casting and the notification between them. That cannot be checked without a phone, and a mistake there stops the music, so the fade
  (out, then in) from Step 66 stays.
- No compiler here: brace and import checks only. Please build.

## Changed / new files
- data/SmartPlaylists.kt, data/LyricsTranslations.kt, ui/SmartPlaylistEditor.kt, ui/LyricsTranslationDialog.kt, ui/Wallpaper.kt
- data/PlaylistImport.kt (exportM3u), data/Mixes.kt (MixData.smart), data/HomeViewModel.kt (smartMixes), data/NeedleSettings.kt, data/Backup.kt
- ui/MixScreen.kt, ui/PlaylistScreens.kt, ui/LyricsScreen.kt, ui/GlowBackground.kt, ui/SettingsScreen.kt, ui/NeedleApp.kt, MainActivity.kt
