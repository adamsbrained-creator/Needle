# Latest Moments and the Navigation switch (Step 70, built on Step 69)

## New files
- data/Moments.kt        your notes and photos for songs (remembered), and which songs the Moments row shows
- ui/MomentsSection.kt   the "Latest Moments" shelf and the Add a moment dialog

## Latest Moments (a new shelf at the top of Home > Popular)
- Header "Latest Moments" with a "+" button, a row of round covers, and one big card for the chosen one.
- The row (up to 8): songs you gave a note or photo to (newest first), then what you played most recently, then what was
  added most recently, one song per album so it is not eight of the same cover.
- The card is one of three kinds, decided for you:
  - Photo or note moment: you added a note and/or a photo to the song. Your photo fills the card and the note sits on it.
  - Lyric moment: the song has lyrics on the phone (a .lrc file, the Lyrics tag, the lyrics inside the file, or ones
    saved earlier). A line from the middle of the song, in the serif title font, with the next line under it. The same line
    all day for a song. Needle does not go online for this.
  - Album moment: the cover, large.
- At the bottom of the card, in a glass panel: title and artist, an add-to-playlist button, and, if that song is playing,
  its progress ("1:23 ---- -1:51"). Tap the card to play it.
- "+" opens "Moment for <song>": a note (up to 140 characters), Add / Change / Remove photo, Save, Remove. The photo stays
  where it is on the phone (Needle keeps permission to read it); it is not copied or uploaded.
- It is a Home section like the others: Settings > Customization > Home layout can move or hide it. People who already
  saved a layout get it at the top. Notes are in backups (the photo links only work on the same phone).

## Navigation (Settings > Customization > Navigation)
- Pill + dock: the floating dock, as before (the player row and the four places).
- Pill only: one slim pill with the four places and, while a song is loaded, a round cover at the end with a ring that
  shows the song's progress. Tap the cover to open Now playing. The list gets less bottom space than with the dock.
- Classic bar: the flat bar with labels and the player as a card above it. This used to be only for the Black & Green skin.
- Without a choice the skin decides (Black & Green = Classic bar), so nobody's look changes after the update.

## Changed
- data/HomeLayout.kt (the new section), data/HomeViewModel.kt (moments), data/Backup.kt, data/NeedleSettings.kt (navStyle),
  MainActivity.kt, ui/HomeScreen.kt, ui/NeedleApp.kt, ui/Dock.kt, ui/Appearance.kt, ui/SettingsScreen.kt

## Not done
- The mockup's lyric moment shows a lyric picked for you; there is no way to pick a different line yet.
- Pill only has no play/pause button of its own (open the player for that).
- Home widgets are still not built (they need a widget receiver and remote views, which is a separate piece of work).
- Light theme and Wallpaper are still not built.
- No compiler or device here: checked brace balance and imports; please build once.
