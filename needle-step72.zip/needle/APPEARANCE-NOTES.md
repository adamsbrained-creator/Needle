# Needle-style menus, Surfaces, Corners, Cover shape, Reduce motion (Step 68, built on Step 67)

## Menus in Needle's style
The artist page's ⋯ button opened a stock Material dropdown (a plain dark rectangle). It now opens a Needle sheet, the same
look and slide-in as the album and song sheets: the artist's round picture and name with "N songs", the quick actions
Play next / Add to queue / Shuffle for all their songs, a line, and Pin artist / Unpin artist.
That was the only stock dropdown in the app. The dialogs I added earlier (New playlist > Create or import, Speed & pitch)
use the same dialog style as the rest of Needle's dialogs (Delete playlist, Name, Equalizer ...).

## New: ui/Appearance.kt
withCornerStyle() and coverClip(): the two helpers the options below go through.

## Settings > Customization (new block under the list entries)
- Surfaces: Glass | Flat. Flat swaps the frosted glass of cards, rows and round buttons for plain dark cards (the card color
  from Colors & themes). Black & Green is always flat.
- Corners: Sharp | Soft | Round. Round is Needle's look until now; Soft is about 60% of the corner, Sharp about a quarter.
  It applies to everything drawn as a glass card (settings rows, list cards, info cards, dialogs' cards ...).
- Cover shape: Square | Rounded | Squircle | Circle. Rounded is as before. Applies to song rows, album grids, New, Singles,
  Most played, playlists and mixes, the artist page's cards, Now playing's cover and Song info. Round artist pictures
  stay round whatever you pick.
- Reduce motion: stops the moving background and the animated covers (Now playing and artist headers).
- A small preview card shows the choices. All four are in backups.

## Not done (from the mockup's Appearance page)
- Navigation (Pill + dock / Pill only / Classic bar): Needle has the floating dock and, in the Black & Green skin, the flat
  bar. A separate switch for it is not built.
- Light theme and Wallpaper themes: Palette is dark-only (about 380 uses of Palette.Text/Surface), so Light is a big job on its
  own. A wallpaper background would need a picker and a readability layer; not started.
- Corners does not change sheets, the dock, the hero cards on New/Home, or buttons; those keep their shape. Their radii are
  written directly in each screen, so a second pass could bring them in one by one.
- Cover shape does not change the wide cards (Home hero cards, "From your library" tiles); a circle there would be an oval.
- No compiler here: checked brace balance, imports and names against Step 67. Please build once.

## Changed
- ui/SongMenu.kt (ArtistMenuSheet), ui/ArtistScreen.kt (⋯ now only asks for the sheet), ui/NeedleApp.kt (sheet, scrim, Back)
- ui/PlayOnScreen.kt (glass and glassCircle), ui/Components.kt (SongArtwork), ui/PlaylistScreens.kt, ui/SinglesScreen.kt,
  ui/NewScreen.kt, ui/AlbumsScreen.kt, ui/MostPlayedScreen.kt, ui/HomeScreen.kt, ui/NowPlayingScreen.kt, ui/SongInfoScreen.kt
  (covers), ui/GlowBackground.kt and ui/AnimatedCoverVideo.kt (reduce motion), ui/SettingsScreen.kt (the block + search words)
- data/NeedleSettings.kt (four settings, saved and in backups)


---

# Second pass (Step 69): Corners and Surfaces everywhere

In Step 68 Corners only reached the glass cards. Now every rounded shape in the app goes through the setting.

## What changed
- 141 places that drew a rounded dp shape (settings rows, list cards, the dock and mini player, Now playing and its cards,
  queue, lyrics, tag editor, equalizer, sleep timer, stats, mixes, folder switches, sheets ...) now use cornerShape(), so
  Sharp / Soft / Round reach them. Round is exactly the old look: nothing changes until you pick another one.
- Four-corner shapes (the tops of the bottom sheets) use cornerShapeOf().
- All 17 dialogs (Delete, Name, Equalizer, Speed & pitch ...) take the same corners.
- Surfaces > Flat now also covers: the bottom sheets (song, album, artist, playlist, player controls, rating), the floating
  dock, and the round buttons on the New hero cards. They become plain dark cards instead of tinted glass.
- Shapes that were written as a percentage (the fully round pill buttons) are left alone, so pills stay pills.
- The settings note under the preview now says so.

## Still not covered
- Cover shape and the wide hero cards (a circle there would be an oval).
- The small selected-state gradients on the Play on device cards keep their accent tint in Flat.
- Skins: Black & Green already used flat cards; its own shapes now follow Corners too.
- Navigation style, Light theme and Wallpaper (see above).
- No compiler here: checked brace balance and imports across the whole project (the one unbalanced report, OnlineArtwork.kt,
  is an old file my checker misreads; it is unchanged from Step 62). Please build once, and look at Sharp and Flat on a few
  screens: radii that were tuned to a pill (for example 26.dp on a 52.dp button) turn square in Sharp, as intended, but you
  may want some of them to stay round.
