# Widgets and polish (Step 71, built on Step 70)

## Home screen widgets (long-press the home screen > Widgets > Needle)
Four widgets, all resizable, from the mockup. Nothing new is needed to build them (classic Android app widgets).
- Needle player (4x2): the cover, title, artist, a progress bar, previous / play-pause / next.
- Needle cover (2x2): just the cover with a play button.
- Needle this week (3x2): listening time this week ("14 h 20 m"), plays, and a bar for each weekday (the busiest day is solid).
- Needle mini bar (4x1): a slim bar with the cover, the song and play.
Tapping a widget opens Needle; the buttons work without opening it (they connect to the player for a moment, so they also work
when Needle is closed). The covers, buttons and bars are drawn in code, so they follow your accent color, and covers get rounded
corners on every Android version. Sizes and wording are in res/xml/widget_*_info.xml and res/values/strings.xml.
How they stay current:
- The playback service redraws the player widgets when the song, the cover or play/pause changes, and every 15 seconds while
  music plays (for the progress bar). Pausing, closing Needle or a phone restart keeps the last song on them.
- The week widget uses the same numbers as Your stats; they are saved when Home calculates them, so the widget refreshes when
  you open Needle (and while Needle runs and you listen), not while Needle is completely closed.

## Polish
- Sharp and Soft corners: shapes that are already pills or circles (a corner of about half the shortest side) are left as they are, so
  buttons stay round and only cards and rows get sharper. (This was the biggest worry from Step 69.)
- Selection bar on the Songs page has a Hide button: hide several songs at once (undo in Settings > Library > Hidden songs).
- Pill only dock: press and hold the round cover to play or pause (a tap still opens Now playing).
- Backup: speed and pitch settings (the common one, "keep pitch", and each song's own) are now saved and merged on restore.

## Changed / new files
- widget/WidgetState.kt, widget/WidgetArt.kt, widget/NeedleWidgets.kt (providers, updater, button receiver)
- res/layout/widget_*.xml, res/xml/widget_*_info.xml, res/drawable/widget_bg.xml, res/values/strings.xml, AndroidManifest.xml
- playback/PlaybackService.kt (publishes to the widgets), data/HomeViewModel.kt (week numbers)
- ui/MediaLists.kt + ui/SongsScreen.kt (Hide), ui/Appearance.kt, ui/Dock.kt, playback/SpeedPrefs.kt, data/Backup.kt

## Not done
- The device test: I cannot build or run anything here. Everything from Step 57 on has only been checked by reading and by brace/import
  checks. Please build, then try: a song with a ReplayGain tag (volume levelling), crossfade, speed per song, the widgets (add all
  four, press the buttons with Needle closed), a restart with Pill only, and Sharp corners with Flat surfaces.
- Widget previews in the picker are the empty layouts (a real preview needs screenshots).
- The week widget does not refresh while Needle is fully closed.
- Still open: Light theme, Wallpaper themes, lyrics translation, playlist export, smart playlists, true overlapping crossfade.
