# Mixes and playlist import (Step 65, built on Step 64)

## New files
- data/Mixes.kt           the mixes of today, and the remembered Refresh presses
- data/PlaylistImport.kt  reads an .m3u / .m3u8 file and finds its songs in the library
- ui/MixScreen.kt         the "Mix" page from the mockup

## Mixes (Library > Playlists)
Library now has the "All | Mixes | Mine" row from the mockup. Mixes come first, with a small MIX badge and
"Auto · 30 songs". Two mixes are made from your library and play history (nothing goes online):
- New Music Mix: up to 24 songs added in the last 30 days plus a few you have not played for two months,
  30 in all (not shown until there are 5 new songs). Text from the mockup: "Songs added in the last 30 days,
  plus a few you haven't played in a while."
- Rediscover Mix: songs you played at least twice but not for two months, most played first with some luck,
  at most 3 per artist (not shown until there are 8 such songs). This one is mine; the mockup only shows New Music.
Both avoid the same artist twice in a row where they can, and take at most 4 (New) or 3 (Rediscover) songs per artist.

A mix is the same all day and new the next day. Refresh makes a new one right now. Playing a mix does not change it
(what counts as "not played in a while" only looks at plays from before the mix was made).

## The Mix page
Back and Refresh, the cover mosaic, "Mix", the name, "Updated today · 30 songs · 1 h 52 min", "4 of 30 played"
(songs of the mix played since it was made), Play and Shuffle, an "About this mix" card with Save as playlist, then
the songs (tap plays from there, press and hold for the song menu). Save as playlist asks for a name (it starts with
the mix name) and keeps you on the mix.

## New playlist > Create or import
The last tile now says "Create or import" and asks which: Create a playlist (as before) or Import from a file.
Import reads .m3u / .m3u8 and matches each line to a song of your library: by file name (using the folder when two
files share a name), else by the "Artist - Title" of its #EXTINF line, else by the title if only one song has it.
Web addresses and songs that are not on the phone are skipped. It makes a playlist named like the file, opens it, and
says "Imported 41 of 48 songs". Hidden songs are not matched.

## Changed
- data/HomeViewModel.kt (mixes flow), MainActivity.kt (loads the Refresh state)
- ui/PlaylistScreens.kt: Library filters, mix tiles, new-or-import dialog
- ui/NeedleApp.kt: mix page + Back, file picker, dialog, "closing pages" also closes the mix

## Choices I made where the mockup does not say
- "Updated today" always says today, because a mix is rebuilt each day or on Refresh.
- Mixes are not on Home and not in backups (they are rebuilt, and Refresh counts reset on a new install).
- Import only; Export as .m3u is not added yet.

## Not done
- No compiler here: checked brace balance, imports and names against Step 64. Please build once.
- Import matches by name, not by the full path, because the path in the file is from another device. A file with
  hundreds of songs is read quickly, but I could not test it with real files here.
