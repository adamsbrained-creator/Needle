package app.needle.music.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import java.util.concurrent.TimeUnit

/** Feeds the Home screen. Rebuilds whenever the library or the play history changes. */
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)

    /** null = still loading. */
    val home: StateFlow<HomeState?> =
        combine(db.songDao().observeAll(), db.playDao().observeAll()) { songs, plays ->
            val now = System.currentTimeMillis()
            buildHome(songs, plays, now, seed = now / TimeUnit.DAYS.toMillis(1))
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}
