package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.playback.PlayerViewModel

/** The four places in the bottom bar. Only HOME and SONGS exist so far. */
enum class Destination(val icon: NeedleIcon) {
    HOME(NeedleIcon.HOME),
    SONGS(NeedleIcon.SONGS),
    ALBUMS(NeedleIcon.ALBUMS),
    LIBRARY(NeedleIcon.LIBRARY)
}

/**
 * The floating dock from the mockup: the player row on top (only while something is loaded)
 * and the four navigation buttons underneath. Tap the player row to open Now Playing.
 * The expanded and small dock states from the mockup come later.
 */
@Composable
fun NeedleDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(32.dp)
    val glow = Palette.Accent.copy(alpha = 0.3f)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(20.dp, shape, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    0f to Color(0xF24E4068),
                    0.6f to Color(0xF52E2E32),
                    start = Offset.Zero,
                    end = Offset.Infinite
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
    ) {
        if (player.hasMedia) DockPlayerRow(player, onOpenPlayer)

        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Destination.entries.forEach { dest ->
                DockButton(dest, isSelected = dest == selected, onClick = { onSelect(dest) })
            }
        }
    }
}

@Composable
private fun DockPlayerRow(vm: PlayerViewModel, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))) {
            val art = vm.artwork
            if (art != null) {
                Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                ArtworkPlaceholder(Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                vm.title ?: "", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.artist ?: "", color = Palette.Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        PlayPauseButton(
            isPlaying = vm.isPlaying,
            enabled = true,
            onClick = vm::togglePlay,
            size = 40.dp,
            iconSize = 16.dp
        )
    }
}

@Composable
private fun DockButton(dest: Destination, isSelected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .size(48.dp)
            .then(
                if (isSelected) {
                    val halo = Color.White.copy(alpha = 0.35f)
                    Modifier.shadow(10.dp, CircleShape, ambientColor = halo, spotColor = halo)
                } else Modifier
            )
            .clip(CircleShape)
            .background(if (isSelected) Color.White else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        NeedleIconView(dest.icon, tint = if (isSelected) Color(0xFF111111) else Color(0xFFA9A9AE))
    }
}
