package app.needle.music.data

import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** An album as the Home screen sees it. [cover] is the song whose artwork represents it. */
data class HomeAlbum(
    val id: Long,
    val title: String,
    val artist: String,
    val songs: List<Song>,
    val heardTracks: Int,
    val lastPlayedAt: Long?
) {
    val cover: Song get() = songs.first()
}

/** A big card at the top of Home. Tapping "Play now" plays [songs]. */
data class HeroCard(val title: String, val subtitle: String, val songs: List<Song>) {
    val cover: Song get() = songs.first()
}

data class WeekStats(val listenedMs: Long, val plays: Int, val topArtist: String?)

data class HomeState(
    val heroes: List<HeroCard>,
    val yourAlbums: List<HomeAlbum>,
    val week: WeekStats,
    val rediscover: List<HomeAlbum>
)

private val DAY_MS = TimeUnit.DAYS.toMillis(1)

/**
 * Builds everything the Home screen shows from the library and the play history.
 * Pure function (no Android), so it is easy to test and to change later.
 * [seed] keeps the "random" picks steady for the whole day.
 */
fun buildHome(songs: List<Song>, plays: List<PlayEvent>, now: Long, seed: Long): HomeState {
    val songById = songs.associateBy { it.id }
    val rng = Random(seed)

    // Albums with at least two songs. Single files and "Unknown album" are not albums.
    val albums: List<List<Song>> = songs
        .groupBy { it.albumId }
        .values
        .filter { it.size >= 2 && it.first().album != "Unknown album" }
        .map { group -> group.sortedWith(compareBy({ it.trackNumber }, { it.title })) }

    val playsByAlbum: Map<Long, List<PlayEvent>> = plays
        .mapNotNull { event -> songById[event.songId]?.let { it.albumId to event } }
        .groupBy({ it.first }, { it.second })

    val homeAlbums = albums.map { group ->
        val events = playsByAlbum[group.first().albumId].orEmpty()
        HomeAlbum(
            id = group.first().albumId,
            title = group.first().album,
            artist = group.map { it.artist }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                ?: group.first().artist,
            songs = group,
            heardTracks = events.map { it.songId }.distinct().size,
            lastPlayedAt = events.maxOfOrNull { it.playedAt }
        )
    }

    // ---- Your albums: what you listened to most recently --------------------------------
    val yourAlbums = homeAlbums
        .filter { it.lastPlayedAt != null }
        .sortedByDescending { it.lastPlayedAt }
        .take(10)

    // ---- This week ----------------------------------------------------------------------
    val weekEvents = plays.filter { it.playedAt >= now - 7 * DAY_MS }
    val week = WeekStats(
        listenedMs = weekEvents.sumOf { it.listenedMs },
        plays = weekEvents.size,
        topArtist = weekEvents
            .mapNotNull { songById[it.songId]?.artist }
            .groupingBy { it }.eachCount()
            .maxByOrNull { it.value }?.key
    )

    // ---- Rediscover: not played for a month or more (or never) ----------------------------
    val rediscover = homeAlbums
        .filter { it.lastPlayedAt == null || it.lastPlayedAt < now - 30 * DAY_MS }
        .shuffled(rng)
        .take(10)

    // ---- Hero cards -----------------------------------------------------------------------
    val heroes = ArrayList<HeroCard>()

    val topArtistThisMonth = plays
        .filter { it.playedAt >= now - 30 * DAY_MS }
        .mapNotNull { songById[it.songId]?.artist }
        .groupingBy { it }.eachCount()
        .maxByOrNull { it.value }?.key
    val becauseAlbum = topArtistThisMonth?.let { artist ->
        homeAlbums.filter { a -> a.songs.any { it.artist == artist } }.shuffled(rng).firstOrNull()
    }
    val first = becauseAlbum ?: homeAlbums.maxByOrNull { a -> a.songs.maxOf { it.dateAdded } }
    if (first != null) {
        heroes += HeroCard(
            title = first.title,
            subtitle = if (becauseAlbum != null) "Because you play $topArtistThisMonth" else "New in your library",
            songs = first.songs
        )
    }
    val second = rediscover.firstOrNull { it.id != first?.id }
        ?: homeAlbums.filter { it.id != first?.id }.shuffled(rng).firstOrNull()
    if (second != null) {
        heroes += HeroCard(title = second.title, subtitle = "Rediscover", songs = second.songs)
    }

    return HomeState(heroes, yourAlbums, week, rediscover)
}

/** "Never played", "Not played in 6 d", "Not played in 5 mo". */
fun notPlayedLabel(lastPlayedAt: Long?, now: Long): String {
    if (lastPlayedAt == null) return "Never played"
    val days = ((now - lastPlayedAt) / DAY_MS).toInt().coerceAtLeast(0)
    return if (days < 60) "Not played in $days d" else "Not played in ${days / 30} mo"
}

/** "0 min", "35 min", "3.5 h", "14 h". */
fun formatListened(ms: Long): String {
    val minutes = ms / 60_000
    if (minutes < 60) return "$minutes min"
    val hours = ms / 3_600_000.0
    return if (hours < 10) "%.1f h".format(hours) else "${hours.toInt()} h"
}
