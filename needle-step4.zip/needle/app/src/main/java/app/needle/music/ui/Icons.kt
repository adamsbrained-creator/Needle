package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The line icons from the mockups, drawn with paths so no icon library is needed. */
enum class NeedleIcon { SEARCH, HOME, SONGS, ALBUMS, LIBRARY }

@Composable
fun NeedleIconView(icon: NeedleIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) { drawNeedleIcon(icon, tint) }
}

/** Coordinates below are the mockups' 24x24 icon grid. */
private fun DrawScope.drawNeedleIcon(icon: NeedleIcon, color: Color) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(color, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = 1.8f * k, cap = StrokeCap.Round)

    when (icon) {
        NeedleIcon.SEARCH -> {
            drawCircle(color, radius = 7f * k, center = Offset(11f * k, 11f * k), style = stroke)
            line(20f, 20f, 16.5f, 16.5f)
        }
        NeedleIcon.HOME -> {
            val p = Path().apply {
                moveTo(4f * k, 11f * k); lineTo(12f * k, 4f * k); lineTo(20f * k, 11f * k)
                lineTo(20f * k, 20f * k); lineTo(15f * k, 20f * k); lineTo(15f * k, 14f * k)
                lineTo(9f * k, 14f * k); lineTo(9f * k, 20f * k); lineTo(4f * k, 20f * k)
                close()
            }
            drawPath(p, color, style = stroke)
        }
        NeedleIcon.SONGS -> {
            val p = Path().apply {
                moveTo(9f * k, 18f * k); lineTo(9f * k, 5f * k); lineTo(20f * k, 3f * k); lineTo(20f * k, 16f * k)
            }
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(6.5f * k, 18f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(17.5f * k, 16f * k), style = stroke)
        }
        NeedleIcon.ALBUMS -> {
            drawCircle(color, radius = 9f * k, center = Offset(12f * k, 12f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(12f * k, 12f * k), style = stroke)
        }
        NeedleIcon.LIBRARY -> {
            line(4f, 7f, 16f, 7f)
            line(4f, 12f, 16f, 12f)
            line(4f, 17f, 12f, 17f)
            line(19f, 14f, 19f, 20f)
            val arrow = Path().apply {
                moveTo(16f * k, 17f * k); lineTo(19f * k, 14f * k); lineTo(22f * k, 17f * k)
            }
            drawPath(arrow, color, style = stroke)
        }
    }
}
