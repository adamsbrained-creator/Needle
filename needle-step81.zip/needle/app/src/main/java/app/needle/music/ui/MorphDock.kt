package app.needle.music.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.Crossfade
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.nestedscroll.NestedScrollConnection
import androidx.compose.ui.input.nestedscroll.NestedScrollSource
import androidx.compose.ui.input.nestedscroll.nestedScroll
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.NeedleSettings
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

/*
 * Morph dock (Settings > Customization > Skins/Appearance > Navigation > "Morph dock", the default).
 *
 * One floating glass capsule that changes shape for what you are doing, instead of a second bar appearing:
 *   Idle      a slim pill with the four places; the open one shows its name.
 *   Playing   the same pill grows upward into the player row.
 *   Scroll    scrolling down tucks it into a small capsule (cover ring, play, where you are, expand).
 *   Select    selecting songs turns it into "N selected, All" with Next / Queue / Playlist / Tags.
 *   Search    opening Search turns it into the search field, right above the keyboard.
 * Swipe the dock down to tuck it, up to open it again. Pages do not need to know about any of this: the scroll is
 * read once from the page area, and Select and Search pages hand the dock what it needs through [DockBus].
 */

/** The small amount of shared state between the Morph dock and the pages that use it. */
object DockBus {
    /** True after the page was scrolled down: the dock tucks into its capsule. */
    val collapsed = mutableStateOf(false)

    /** Set while songs are selected on a page (SelectionBar publishes it instead of drawing its own bar). */
    val selection = mutableStateOf<DockSelection?>(null)

    /** True while the Search page is open: the dock becomes the search field. */
    val searchOpen = mutableStateOf(false)

    /** What is typed in the dock's search field. The Search page reads it. */
    val query = mutableStateOf("")

    /** The Search page fills these in; the dock calls them. */
    var onVoice: (() -> Unit)? = null
    var onSubmit: (() -> Unit)? = null
    var onCloseSearch: (() -> Unit)? = null
}

/** What the dock shows and does while songs are selected. [onHide] is only there on pages that can hide songs. */
class DockSelection(
    val count: Int,
    val onAll: () -> Unit,
    val onNext: () -> Unit,
    val onQueue: () -> Unit,
    val onPlaylist: () -> Unit,
    val onTags: () -> Unit,
    val onClose: () -> Unit,
    val onHide: (() -> Unit)?
)

/** Called by [SelectionBar] when the Morph dock is in use: hands the selection to the dock and draws nothing itself. */
@Composable
internal fun PublishDockSelection(
    count: Int,
    onAll: () -> Unit,
    onNext: () -> Unit,
    onQueue: () -> Unit,
    onPlaylist: () -> Unit,
    onTags: () -> Unit,
    onClose: () -> Unit,
    onHide: (() -> Unit)?
) {
    SideEffect {
        DockBus.selection.value = DockSelection(count, onAll, onNext, onQueue, onPlaylist, onTags, onClose, onHide)
    }
    DisposableEffect(Unit) {
        onDispose { DockBus.selection.value = null }
    }
}

/**
 * Put on the area that holds the pages. Scrolling any list in it down tucks the dock; scrolling up, or pulling down
 * at the very top, opens it again. Nothing is consumed, so the pages scroll exactly as before.
 */
@Composable
fun Modifier.dockScrollAware(): Modifier {
    val density = LocalDensity.current
    val connection = remember(density) {
        object : NestedScrollConnection {
            private var streak = 0f
            private val tuckAt = with(density) { 44.dp.toPx() }
            private val openAt = with(density) { 24.dp.toPx() }

            override fun onPreScroll(available: Offset, source: NestedScrollSource): Offset {
                val dy = available.y
                if (dy == 0f) return Offset.Zero
                // A change of direction starts counting again.
                if (streak != 0f && (dy > 0f) != (streak > 0f)) streak = 0f
                streak += dy
                if (streak < -tuckAt) {
                    if (!DockBus.collapsed.value) DockBus.collapsed.value = true
                    streak = -tuckAt
                } else if (streak > openAt) {
                    if (DockBus.collapsed.value) DockBus.collapsed.value = false
                    streak = openAt
                }
                return Offset.Zero
            }

            override fun onPostScroll(consumed: Offset, available: Offset, source: NestedScrollSource): Offset {
                // Still pulling down with nothing left to scroll: the page is at its top, so show the whole dock.
                if (available.y > 0f && consumed.y == 0f && DockBus.collapsed.value) DockBus.collapsed.value = false
                return Offset.Zero
            }
        }
    }
    return this.nestedScroll(connection)
}

private enum class MorphScene { IDLE, PLAYING, SELECT, SEARCH, COMPACT }

private val MorphInk = Color(0xFF111111)
private val MorphDim = Color(0xFFA9A9AE)
private val MorphText = Color(0xFFF2F2F5)

/** The dock's size and shape spring a little past their goal, like the mockup; Reduce motion makes it a short fade. */
private fun <T> shapeSpec(reduce: Boolean): FiniteAnimationSpec<T> =
    if (reduce) tween(160) else spring(dampingRatio = 0.74f, stiffness = 340f)

/** A soft press: the thing shrinks a little under the finger and springs back. Put it before clip and background. */
@Composable
private fun Modifier.pressable(onClick: () -> Unit, pressedScale: Float = 0.92f): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val squeeze by animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "dockPress"
    )
    return this
        .graphicsLayer {
            scaleX = squeeze
            scaleY = squeeze
        }
        .clickable(interactionSource = source, indication = null, onClick = onClick)
}

private fun Modifier.said(text: String): Modifier = this.semantics { contentDescription = text }

private fun fractionOf(vm: PlayerViewModel, positionMs: Long): Float =
    if (vm.durationMs > 0L && !vm.isRadio) (positionMs.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f

@Composable
internal fun MorphDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    modifier: Modifier = Modifier,
    castName: String? = null
) {
    val reduce = NeedleSettings.reduceMotion.value
    val selection = DockBus.selection.value
    val searching = DockBus.searchOpen.value
    val tucked = DockBus.collapsed.value
    val hasMedia = player.hasMedia

    val scene = when {
        selection != null -> MorphScene.SELECT
        searching -> MorphScene.SEARCH
        tucked -> MorphScene.COMPACT
        hasMedia -> MorphScene.PLAYING
        else -> MorphScene.IDLE
    }

    // The selection layer fades out after the selection is gone: keep what it showed for those few frames.
    val lastSelection = remember { arrayOfNulls<DockSelection>(1) }
    if (selection != null) lastSelection[0] = selection
    val shownSelection = selection ?: lastSelection[0]

    // Going to another place always shows the whole dock.
    LaunchedEffect(selected) { DockBus.collapsed.value = false }

    BoxWithConstraints(modifier.fillMaxWidth()) {
        val wide = if (maxWidth > 420.dp) 420.dp else maxWidth
        val idleWidth = if (wide > 322.dp) 322.dp else wide
        val compactWidth = if (hasMedia) 262.dp else 196.dp

        val targetWidth = when (scene) {
            MorphScene.IDLE -> idleWidth
            MorphScene.PLAYING, MorphScene.SELECT, MorphScene.SEARCH -> wide
            MorphScene.COMPACT -> compactWidth
        }
        val targetHeight = when (scene) {
            MorphScene.IDLE -> 68.dp
            MorphScene.PLAYING, MorphScene.SELECT -> 136.dp
            MorphScene.SEARCH -> 66.dp
            MorphScene.COMPACT -> 64.dp
        }
        // The tall dock follows Settings > Corners; the slim shapes are always fully round.
        val tallRadius = when (NeedleSettings.cornerStyle.intValue) {
            0 -> 10.dp
            1 -> 20.dp
            else -> 32.dp
        }
        val targetRadius = if (scene == MorphScene.PLAYING || scene == MorphScene.SELECT) tallRadius else 34.dp

        val dockW by animateDpAsState(targetWidth, shapeSpec(reduce), label = "dockWidth")
        val dockH by animateDpAsState(targetHeight, shapeSpec(reduce), label = "dockHeight")
        val radius by animateDpAsState(targetRadius, shapeSpec(reduce), label = "dockRadius")

        val h = maxOf(dockH, 0.dp)
        val r = minOf(maxOf(radius, 0.dp), h / 2)
        val shape = RoundedCornerShape(r)
        val glow = Palette.Accent.copy(alpha = 0.28f)
        val tint = if (NeedleSettings.accentIndex.intValue == 0) Color(0xF24E4068)
        else lerp(Color(0xFF2A2A2E), Palette.Accent, 0.3f).copy(alpha = 0.95f)
        val surface = Brush.linearGradient(
            0f to tint,
            0.6f to Color(0xF52E2E32),
            start = Offset.Zero,
            end = Offset.Infinite
        ).flatOr(Palette.Card)

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .size(maxOf(dockW, 0.dp), h)
                .shadow(20.dp, shape, ambientColor = glow, spotColor = glow)
                .clip(shape)
                .background(surface)
                .border(1.dp, Color.White.copy(alpha = 0.13f), shape)
                // Swipe the dock down to tuck it, up to open it again.
                .pointerInput(scene) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragCancel = { total = 0f },
                        onDragEnd = {
                            if ((scene == MorphScene.PLAYING || scene == MorphScene.IDLE) && total > 36.dp.toPx()) {
                                DockBus.collapsed.value = true
                            } else if (scene == MorphScene.COMPACT && total < -20.dp.toPx()) {
                                DockBus.collapsed.value = false
                            }
                            total = 0f
                        },
                        onVerticalDrag = { _, dy -> total += dy }
                    )
                }
        ) {
            // The four places. Idle: alone. Playing: under the player row.
            DockLayer(
                visible = scene == MorphScene.IDLE || scene == MorphScene.PLAYING,
                reduce = reduce,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(66.dp)
            ) {
                MorphTabs(selected, onSelect, reduce)
            }

            // The player row, on top.
            DockLayer(
                visible = scene == MorphScene.PLAYING,
                reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(68.dp)
            ) {
                MorphPlayerRow(player, onOpenPlayer, castName)
            }

            // Selecting songs: the header on top, the actions underneath.
            DockLayer(
                visible = scene == MorphScene.SELECT,
                reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(68.dp)
            ) {
                if (shownSelection != null) MorphSelectionHeader(shownSelection)
            }
            DockLayer(
                visible = scene == MorphScene.SELECT,
                reduce = reduce,
                modifier = Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(66.dp)
            ) {
                if (shownSelection != null) MorphSelectionActions(shownSelection)
            }

            // Search: the dock is the field.
            DockLayer(
                visible = scene == MorphScene.SEARCH,
                reduce = reduce,
                modifier = Modifier.fillMaxSize()
            ) {
                MorphSearchField()
            }

            // Scrolled: a small capsule.
            DockLayer(
                visible = scene == MorphScene.COMPACT,
                reduce = reduce,
                modifier = Modifier.align(Alignment.Center).width(compactWidth).height(62.dp)
            ) {
                MorphCompact(selected, player, onOpenPlayer)
            }
        }
    }
}

/**
 * One layer of the dock. It fades and rises 10 dp into place a moment after the dock has started changing shape,
 * and fades out quickly, so two layers never fight over the same space. It is only composed while it is showing.
 */
@Composable
private fun DockLayer(
    visible: Boolean,
    reduce: Boolean,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    val shown by animateFloatAsState(
        targetValue = if (visible) 1f else 0f,
        animationSpec = if (visible) tween(if (reduce) 100 else 240, delayMillis = if (reduce) 0 else 140) else tween(140),
        label = "dockLayer"
    )
    if (shown > 0.001f || visible) {
        Box(
            modifier.graphicsLayer {
                alpha = shown
                translationY = (1f - shown) * 10.dp.toPx()
            }
        ) {
            content()
        }
    }
}

// ---- places ----------------------------------------------------------------------------------------------------------

@Composable
private fun MorphTabs(selected: Destination, onSelect: (Destination) -> Unit, reduce: Boolean) {
    Row(
        Modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.spacedBy(4.dp, Alignment.CenterHorizontally),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Destination.dock.forEach { dest ->
            MorphTab(dest, dest == selected.dockSlot, reduce) { onSelect(dest) }
        }
    }
}

@Composable
private fun MorphTab(dest: Destination, isSelected: Boolean, reduce: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val ms = if (reduce) 120 else 350
    val bg by animateColorAsState(if (isSelected) Color.White else Color.Transparent, tween(ms), label = "tabBg")
    val ink by animateColorAsState(if (isSelected) MorphInk else MorphDim, tween(ms), label = "tabInk")
    val padX by animateDpAsState(if (isSelected) 18.dp else 15.dp, tween(if (reduce) 120 else 450), label = "tabPad")
    Row(
        Modifier
            .height(50.dp)
            .widthIn(min = 52.dp)
            .said(dest.label)
            .pressable({
                if (!isSelected) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            })
            .clip(CircleShape)
            .background(bg)
            .padding(horizontal = padX),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(dest.icon, tint = ink)
        AnimatedVisibility(
            visible = isSelected,
            enter = expandHorizontally(tween(if (reduce) 120 else 450)) + fadeIn(tween(300)),
            exit = shrinkHorizontally(tween(if (reduce) 120 else 350)) + fadeOut(tween(150))
        ) {
            Text(
                dest.label, color = ink, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, softWrap = false, modifier = Modifier.padding(start = 8.dp)
            )
        }
    }
}

// ---- player ----------------------------------------------------------------------------------------------------------

@Composable
private fun MorphCover(vm: PlayerViewModel, modifier: Modifier = Modifier) {
    val art = vm.artwork
    if (art != null) Image(art, null, modifier, contentScale = ContentScale.Crop)
    else ArtworkPlaceholder(modifier)
}

@Composable
private fun MorphPlayerRow(vm: PlayerViewModel, onOpen: () -> Unit, castName: String?) {
    val position = rememberLivePositionMs(vm, poll = true)
    val accent = Palette.Accent
    Box(Modifier.fillMaxSize()) {
        Row(
            Modifier
                .fillMaxSize()
                .clickable(onClick = onOpen)
                .padding(start = 12.dp, end = 14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            MorphCover(vm, Modifier.size(44.dp).clip(coverClip(12.dp)))
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    vm.title ?: "", color = MorphText, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    if (castName != null) "Playing on $castName" else vm.artist ?: "",
                    color = if (castName != null) Color(0xFFC9B8EE) else Color(0xFFA9A9B4), fontSize = 12.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            Spacer(Modifier.width(12.dp))
            PlayPauseButton(
                isPlaying = vm.isPlaying,
                enabled = true,
                onClick = vm::togglePlay,
                size = 40.dp,
                iconSize = 16.dp
            )
        }
        // How far the song is: a thin line along the foot of the player row.
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(horizontal = 14.dp)
                .fillMaxWidth()
                .height(3.dp)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f))
                .drawBehind {
                    val f = fractionOf(vm, position.value)
                    if (f > 0f) drawRect(accent, size = Size(size.width * f, size.height))
                }
        )
    }
}

// ---- selecting songs ------------------------------------------------------------------------------------------------

@Composable
private fun MorphSelectionHeader(sel: DockSelection) {
    Row(
        Modifier.fillMaxSize().padding(start = 12.dp, end = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier
                .size(40.dp)
                .said("Cancel selection")
                .pressable(sel.onClose)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CLOSE, MorphText, size = 18.dp)
        }
        Spacer(Modifier.width(10.dp))
        AnimatedContent(
            targetState = sel.count,
            transitionSpec = {
                val up = targetState > initialState
                (slideInVertically { if (up) it / 2 else -it / 2 } + fadeIn(tween(160))) togetherWith
                    (slideOutVertically { if (up) -it / 2 else it / 2 } + fadeOut(tween(120)))
            },
            modifier = Modifier.weight(1f),
            label = "selectionCount"
        ) { n ->
            Text("$n selected", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
        Box(
            Modifier
                .height(34.dp)
                .said("Select all")
                .pressable(sel.onAll)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f))
                .padding(horizontal = 14.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("All", color = MorphText, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        }
    }
}

@Composable
private fun MorphSelectionActions(sel: DockSelection) {
    // Five buttons (with Hide) get a little narrower so they all fit.
    val actWidth = if (sel.onHide != null) 64.dp else 78.dp
    Row(
        Modifier.fillMaxSize().padding(horizontal = 8.dp),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        MorphAction(NeedleIcon.PLAY_NEXT, "Next", actWidth, false, sel.onNext)
        MorphAction(NeedleIcon.ADD_QUEUE, "Queue", actWidth, false, sel.onQueue)
        MorphAction(NeedleIcon.ADD_PLAYLIST, "Playlist", actWidth, true, sel.onPlaylist)
        MorphAction(NeedleIcon.TAG, "Tags", actWidth, false, sel.onTags)
        sel.onHide?.let { MorphAction(NeedleIcon.EYE_OFF, "Hide", actWidth, false, it) }
    }
}

@Composable
private fun MorphAction(
    icon: NeedleIcon,
    label: String,
    actWidth: Dp,
    primary: Boolean,
    onClick: () -> Unit
) {
    val ink = if (primary) MorphInk else Color(0xFFE9E9EF)
    Column(
        Modifier
            .size(actWidth, 54.dp)
            .said(label)
            .pressable(onClick, pressedScale = 0.9f)
            .clip(cornerShape(16.dp))
            .background(if (primary) Color.White else Color.Transparent),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp, Alignment.CenterVertically)
    ) {
        NeedleIconView(icon, tint = ink)
        Text(label, color = ink, fontSize = 11.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

// ---- search ----------------------------------------------------------------------------------------------------------

@Composable
private fun MorphSearchField() {
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val query = DockBus.query.value

    // Ready to type as soon as the dock has become the field; the keyboard goes away with it.
    LaunchedEffect(Unit) {
        delay(80)
        runCatching { focus.requestFocus() }
    }
    DisposableEffect(Unit) {
        onDispose { keyboard?.hide() }
    }

    Row(
        Modifier.fillMaxSize().padding(start = 20.dp, end = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(NeedleIcon.SEARCH, Color(0xFFA9A9B4), size = 22.dp)
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = query,
            onValueChange = { DockBus.query.value = it },
            singleLine = true,
            textStyle = TextStyle(color = Color.White, fontSize = 17.sp),
            cursorBrush = SolidColor(Palette.Accent),
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
            keyboardActions = KeyboardActions(onSearch = { DockBus.onSubmit?.invoke() }),
            modifier = Modifier.weight(1f).focusRequester(focus),
            decorationBox = { inner ->
                Box(contentAlignment = Alignment.CenterStart) {
                    if (query.isEmpty()) {
                        Text(
                            "Search your library",
                            color = Color(0xFF9A9AA6), fontSize = 17.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    inner()
                }
            }
        )
        // The mic, while nothing is typed (voice search, as on the Search page).
        if (query.isEmpty()) {
            Box(
                Modifier
                    .size(40.dp)
                    .said("Search by voice")
                    .pressable({ DockBus.onVoice?.invoke() })
                    .clip(CircleShape),
                contentAlignment = Alignment.Center
            ) {
                NeedleIconView(NeedleIcon.MIC, Color(0xFFC9C9D2), size = 19.dp)
            }
        }
        Spacer(Modifier.width(6.dp))
        Box(
            Modifier
                .size(40.dp)
                .said("Close search")
                .pressable({ DockBus.onCloseSearch?.invoke() })
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CLOSE, MorphText, size = 18.dp)
        }
    }
}

// ---- scrolled: the capsule -------------------------------------------------------------------------------------------

@Composable
private fun MorphCompact(selected: Destination, vm: PlayerViewModel, onOpenPlayer: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val open: () -> Unit = {
        haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        DockBus.collapsed.value = false
    }
    Row(
        Modifier.fillMaxSize().padding(horizontal = 7.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (vm.hasMedia) {
            MorphRing(vm, onOpenPlayer)
            PlayPauseButton(
                isPlaying = vm.isPlaying,
                enabled = true,
                onClick = vm::togglePlay,
                size = 44.dp,
                iconSize = 16.dp
            )
        }
        // Where you are. Tap to open the dock.
        Box(
            Modifier
                .weight(1f)
                .height(44.dp)
                .said("Open the dock")
                .pressable(open, pressedScale = 0.95f)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.14f)),
            contentAlignment = Alignment.Center
        ) {
            Crossfade(targetState = selected.dockSlot, label = "dockHere") { here ->
                Row(verticalAlignment = Alignment.CenterVertically) {
                    NeedleIconView(here.icon, Color.White, size = 20.dp)
                    Spacer(Modifier.width(7.dp))
                    Text(here.label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
                }
            }
        }
        Box(
            Modifier
                .size(34.dp, 44.dp)
                .said("Expand the dock")
                .pressable(open)
                .clip(CircleShape),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CHEVRON_DOWN, Color(0xFFC9C9D2), modifier = Modifier.rotate(180f), size = 20.dp)
        }
    }
}

/** The cover inside a ring that fills as the song plays. Tap opens Now playing. */
@Composable
private fun MorphRing(vm: PlayerViewModel, onOpenPlayer: () -> Unit) {
    val position = rememberLivePositionMs(vm, poll = true)
    val accent = Palette.Accent
    Box(
        Modifier
            .size(48.dp)
            .said("Open the player")
            .pressable(onOpenPlayer, pressedScale = 0.94f)
            .drawBehind {
                val stroke = 4.dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.18f), style = Stroke(stroke))
                val f = fractionOf(vm, position.value)
                if (f > 0f) {
                    drawArc(
                        accent, -90f, 360f * f, false,
                        topLeft = Offset(stroke / 2, stroke / 2),
                        size = Size(size.width - stroke, size.height - stroke),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            }
            .padding(5.dp)
            .clip(CircleShape)
    ) {
        MorphCover(vm, Modifier.fillMaxSize())
    }
}
