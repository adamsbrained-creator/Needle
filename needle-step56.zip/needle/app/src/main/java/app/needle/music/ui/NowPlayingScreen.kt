package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.animation.core.tween
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AnimatedCoverSources
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.LyricsViewModel
import app.needle.music.data.NeedleSettings
import app.needle.music.data.isKnownArtist
import app.needle.music.data.networkAllowsAnimatedCovers
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onClose: () -> Unit,
    onOpenQueue: () -> Unit,
    modifier: Modifier = Modifier,
    castActive: Boolean = false,
    onOpenPlayOn: () -> Unit = {},
    onOpenLyrics: () -> Unit = {},
    onOpenControls: () -> Unit = {},
    liked: Boolean = false,
    onToggleLike: () -> Unit = {},
    onRate: () -> Unit = {},
    lyricsVm: LyricsViewModel? = null,
    library: NowPlayingLibrary? = null,
    /** Name of the queue for the header (null = just "Now playing"). */
    queueSource: QueueSource? = null,
    gestures: NowPlayingGestures = currentGestures()
) {
    // While playing, refresh the progress bar a few times per second.
    LaunchedEffect(vm.isPlaying) {
        while (vm.isPlaying) {
            vm.refreshPosition()
            delay(250)
        }
    }

    // Animated cover: looked up when the song changes (and when the setting changes), only while allowed on this network.
    val context = LocalContext.current
    val animatedOn = NeedleSettings.animatedCovers.value
    val wifiOnly = NeedleSettings.animatedCoversWifiOnly.value
    var animatedUrl by remember { mutableStateOf<String?>(null) }
    LaunchedEffect(vm.currentMediaId, animatedOn, wifiOnly) {
        animatedUrl = null
        if (animatedOn && vm.hasMedia && networkAllowsAnimatedCovers(context, wifiOnly)) {
            animatedUrl = AnimatedCoverSources.find(vm.title.orEmpty(), vm.artist.orEmpty(), vm.album)
        }
    }

    // Full-page mode: the video fills the whole page behind everything; the cover stays until the first frame is ready.
    val fullPage = NeedleSettings.animatedFullPage.value
    var videoReady by remember(animatedUrl) { mutableStateOf(false) }
    val fullActive = fullPage && animatedUrl != null && videoReady
    val coverAlpha by animateFloatAsState(if (fullActive) 0f else 1f, tween(500), label = "coverAlpha")
    val scrimAlpha by animateFloatAsState(if (fullActive) 1f else 0f, tween(500), label = "scrimAlpha")

    val currentSong = remember(library?.songs, vm.currentMediaId) {
        library?.songs?.firstOrNull { it.id.toString() == vm.currentMediaId }
    }
    // When the player has no cover for this song, use the one found online (if that setting is on).
    val noArt = vm.artwork == null
    val fallbackArt by androidx.compose.runtime.produceState<ImageBitmap?>(null, currentSong?.id, noArt, NeedleSettings.fetchMissingCovers.value) {
        value = if (noArt && currentSong != null) ArtworkLoader.loadLarge(context, currentSong) else null
    }
    // One place that knows what each tap does, so the actions can be made configurable later.
    fun perform(action: NowPlayingAction) {
        when (action) {
            NowPlayingAction.NONE -> {}
            NowPlayingAction.OPEN_ALBUM -> currentSong?.let { library?.onOpenAlbum?.invoke(it) }
            NowPlayingAction.OPEN_ARTIST -> currentSong?.takeIf { isKnownArtist(it.artist) }?.let { library?.onOpenArtist?.invoke(it.artist) }
            NowPlayingAction.OPEN_QUEUE_SOURCE -> (queueSource?.open ?: onOpenQueue).invoke()
            NowPlayingAction.OPEN_QUEUE -> onOpenQueue()
        }
    }

    Box(modifier) {
    val fullUrl = animatedUrl
    if (fullPage && fullUrl != null) {
        AnimatedCoverVideo(fullUrl, vm.isPlaying, Modifier.fillMaxSize(), onReady = { videoReady = it })
        // Darker at the top and bottom so the buttons and text stay readable over the video.
        Box(
            Modifier.fillMaxSize().graphicsLayer { alpha = scrimAlpha }.background(
                Brush.verticalGradient(
                    0f to Color.Black.copy(alpha = 0.45f), 0.3f to Color.Black.copy(alpha = 0.10f),
                    0.6f to Color.Black.copy(alpha = 0.55f), 1f to Color.Black.copy(alpha = 0.88f)
                )
            )
        )
    }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChevronDownButton(onClose)
            // The name of the queue; a tap opens where it came from (album, artist, playlist) or the queue.
            Column(
                Modifier.weight(1f).padding(horizontal = 8.dp).clip(RoundedCornerShape(14.dp))
                    .clickable(enabled = gestures.onHeader != NowPlayingAction.NONE) { perform(gestures.onHeader) }
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                if (queueSource != null) {
                    Text("Playing from", color = Palette.Muted, fontSize = 11.sp)
                    Text(
                        queueSource.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center
                    )
                } else {
                    Text("Now playing", color = Palette.Muted, fontSize = 14.sp)
                }
            }
            // The Needle bars open the Player controls sheet; Play on (cast) sits under the playback controls.
            RoundIconButton(NeedleIcon.CONTROLS, onOpenControls, size = 44.dp, iconSize = 24.dp)
        }

        Spacer(Modifier.height(8.dp))
        Artwork(
            vm.artwork ?: fallbackArt, if (fullPage) null else animatedUrl, vm.isPlaying,
            Modifier.fillMaxWidth().aspectRatio(1f).graphicsLayer { alpha = coverAlpha }
        )
        Spacer(Modifier.height(28.dp))

        Text(
            text = vm.title ?: "Nothing playing",
            color = Palette.Text,
            fontFamily = Palette.TitleFont,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            lineHeight = 34.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center,
            modifier = Modifier.clip(RoundedCornerShape(12.dp))
                .clickable(enabled = currentSong != null && gestures.onTitle != NowPlayingAction.NONE) { perform(gestures.onTitle) }
                .padding(horizontal = 8.dp, vertical = 2.dp)
        )
        Spacer(Modifier.height(2.dp))
        Text(
            text = vm.artist ?: "",
            color = Palette.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.clip(RoundedCornerShape(10.dp))
                .clickable(enabled = currentSong != null && gestures.onArtist != NowPlayingAction.NONE) { perform(gestures.onArtist) }
                .padding(horizontal = 8.dp, vertical = 4.dp)
        )

        Spacer(Modifier.height(24.dp))

        val duration = vm.durationMs
        val progress = if (duration > 0) (vm.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
        NeedleProgressBar(
            progress = progress,
            enabled = vm.hasMedia && duration > 0,
            onSeek = vm::seekToFraction,
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(vm.positionMs), color = Palette.Muted, fontSize = 13.sp)
            Text(formatTime(duration), color = Palette.Muted, fontSize = 13.sp)
        }

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShuffleButton(active = vm.shuffleEnabled, onClick = vm::toggleShuffle)
            SkipButton(next = false, enabled = vm.hasMedia, onClick = vm::previous)
            PlayPauseButton(isPlaying = vm.isPlaying, enabled = vm.hasMedia, onClick = vm::togglePlay)
            SkipButton(next = true, enabled = vm.hasMedia, onClick = vm::next)
            RepeatButton(mode = vm.repeatMode, onClick = vm::cycleRepeat)
        }

        Spacer(Modifier.height(28.dp))

        // Up next on the left; the star (Liked songs) and Play on (cast) on the right. The lyrics are opened from the preview card below.
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PillButton("Up next · ${vm.queueSize}", onClick = onOpenQueue)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                // Purple and filled when the song is in Liked songs
                RoundIconButton(
                    if (liked) NeedleIcon.STAR_FILLED else NeedleIcon.STAR, onToggleLike,
                    size = 44.dp, iconSize = 24.dp, active = liked, onLongClick = onRate   // press and hold = rate the song
                )
                RoundIconButton(NeedleIcon.CAST, onOpenPlayOn, size = 44.dp, iconSize = 24.dp, active = castActive)
            }
        }

        Spacer(Modifier.height(32.dp))

        // Below the player, as in the mockup: scroll down for the lyrics preview.
        if (lyricsVm != null && vm.hasMedia) {
            LyricsPreviewCard(player = vm, lyricsVm = lyricsVm, onOpen = onOpenLyrics)
            Spacer(Modifier.height(14.dp))
        }

        // About the artist, Credits, File details, From your library (for the song that is playing).
        if (library != null && currentSong != null && vm.hasMedia) {
            NowPlayingInfoCards(currentSong, library)
        }
        Spacer(Modifier.height(32.dp))
    }
    }
}

@Composable
private fun Artwork(art: ImageBitmap?, animatedUrl: String?, playing: Boolean, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(28.dp))) {
        if (art != null) {
            Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtworkPlaceholder(Modifier.fillMaxSize())
        }
        // The video fades in over the normal cover once its first frame is ready; if it fails, the cover just stays.
        if (animatedUrl != null) AnimatedCoverVideo(animatedUrl, playing, Modifier.fillMaxSize())
    }
}
