package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.PlaylistData
import app.needle.music.data.Song
import app.needle.music.data.playlistDuration
import app.needle.music.data.songsText

/** What the name dialog is for. */
enum class NameKind { NEW, RENAME }

/**
 * A pending "name this playlist" question. NEW makes a playlist holding [songIds] (and opens it when [openAfter]),
 * RENAME renames [playlistId].
 */
class NameRequest(
    val kind: NameKind,
    val songIds: List<Long> = emptyList(),
    val playlistId: Long = 0,
    val initial: String = "",
    val openAfter: Boolean = false
)

// ============================================================================================
// Cover
// ============================================================================================

/**
 * The cover of a playlist: "Liked songs" is a star on the purple-to-pink gradient, an empty playlist is a plain
 * tile, and the others show up to four of their covers as a mosaic.
 */
@Composable
fun PlaylistCover(playlist: PlaylistData, modifier: Modifier = Modifier, corner: Dp = 20.dp, iconSize: Dp = 36.dp) {
    Box(modifier.clip(RoundedCornerShape(corner)).background(Palette.Card2)) {
        val covers = playlist.covers
        when {
            playlist.liked -> Box(
                Modifier.fillMaxSize().background(Brush.linearGradient(listOf(Palette.Accent, Palette.Pink))),
                contentAlignment = Alignment.Center
            ) { NeedleIconView(NeedleIcon.STAR_FILLED, Color.White, size = iconSize) }
            covers.isEmpty() -> Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                NeedleIconView(NeedleIcon.ADD_PLAYLIST, Palette.Muted, size = iconSize)
            }
            covers.size == 1 -> Cover(covers[0], Modifier.fillMaxSize())
            else -> Column(Modifier.fillMaxSize()) {
                for (row in 0..1) {
                    Row(Modifier.weight(1f).fillMaxWidth()) {
                        for (col in 0..1) Cover(covers[(row * 2 + col) % covers.size], Modifier.weight(1f).fillMaxHeight())
                    }
                }
            }
        }
    }
}

// ============================================================================================
// Library page
// ============================================================================================

/**
 * The Library page (the dock's fourth button): your playlists as covers, with the tabs from the mockup.
 * Songs and Albums are their own pages, Liked opens "Liked songs"; Artists and Folders are not built yet.
 */
@Composable
fun LibraryScreen(
    playlists: List<PlaylistData>,
    songCount: Int,
    albumCount: Int,
    artistCount: Int,
    bottomPadding: Dp,
    onOpenPlaylist: (PlaylistData) -> Unit,
    onPlaylistMenu: (PlaylistData) -> Unit,
    onNewPlaylist: () -> Unit,
    onSearch: () -> Unit,
    onSongs: () -> Unit,
    onAlbums: () -> Unit,
    onFolders: () -> Unit,
    onSoon: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Library", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                    Text(
                        "${"%,d".format(songCount)} songs · ${"%,d".format(albumCount)} albums · ${"%,d".format(artistCount)} artists",
                        color = Palette.Muted, fontSize = 13.sp
                    )
                }
                RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)
            }
        }
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                LibraryChip("Songs", false, onSongs)
                LibraryChip("Liked", false) { playlists.firstOrNull { it.liked }?.let(onOpenPlaylist) }
                LibraryChip("Playlists", true) {}
                LibraryChip("Albums", false, onAlbums)
                LibraryChip("Artists", false, onSoon)
                LibraryChip("Folders", false, onFolders)
            }
        }
        items(playlists, key = { it.id }) { playlist ->
            Column(Modifier.tapOrHold(onClick = { onOpenPlaylist(playlist) }, onLongClick = { onPlaylistMenu(playlist) })) {
                PlaylistCover(playlist, Modifier.fillMaxWidth().aspectRatio(1f))
                Text(
                    playlist.name, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
                )
                Text(songsText(playlist.songs.size), color = Palette.Muted, fontSize = 12.sp)
            }
        }
        item {
            Column(Modifier.clip(RoundedCornerShape(20.dp)).clickable(onClick = onNewPlaylist)) {
                Box(
                    Modifier.fillMaxWidth().aspectRatio(1f).glass(RoundedCornerShape(20.dp)),
                    contentAlignment = Alignment.Center
                ) {
                    Box(
                        Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) { NeedleIconView(NeedleIcon.PLUS, Palette.Text, size = 26.dp) }
                }
                Text("New playlist", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 8.dp))
                Text("Create a playlist", color = Palette.Muted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun LibraryChip(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = if (selected) Palette.Bg else Palette.Text)
    }
}

// ============================================================================================
// Playlist page
// ============================================================================================

/**
 * One playlist: cover, name, how many songs and how long, Play and Shuffle, then the songs with the sort chips
 * from the mockup. Tap a song to play from it, press and hold for the song menu, tap the right icon to take it out.
 */
@Composable
fun PlaylistScreen(
    playlist: PlaylistData,
    playCounts: Map<Long, Int>,
    ratings: Map<Long, Int>,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onMenu: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onRemove: (Song) -> Unit,
    onSongMenu: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var sort by rememberSaveable { mutableStateOf(0) }   // 0 recently added, 1 A to Z, 2 most played, 3 top rated
    val sorted = remember(playlist, sort, playCounts, ratings) {
        when (sort) {
            3 -> playlist.songs.sortedWith(
                compareByDescending<Song> { ratings[it.id] ?: 0 }.thenByDescending { playCounts[it.id] ?: 0 }
            )
            1 -> playlist.songs.sortedBy { it.title.lowercase() }
            2 -> playlist.songs.sortedWith(
                compareByDescending<Song> { playCounts[it.id] ?: 0 }.thenByDescending { playlist.addedAt[it.id] ?: 0L }
            )
            else -> playlist.songs.sortedByDescending { playlist.addedAt[it.id] ?: 0L }
        }
    }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item {
            Column(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
                    ListBackButton(onBack, size = 42.dp)
                    Spacer(Modifier.weight(1f))
                    RoundIconButton(NeedleIcon.MORE, onMenu, size = 42.dp, iconSize = 22.dp)
                }
                Spacer(Modifier.height(8.dp))
                PlaylistCover(playlist, Modifier.size(180.dp), corner = 26.dp, iconSize = 56.dp)
                Text("Playlist", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 16.dp))
                Text(
                    playlist.name, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 32.sp, lineHeight = 36.sp,
                    textAlign = TextAlign.Center, maxLines = 2, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${songsText(playlist.songs.size)} · ${playlistDuration(playlist.durationMs)}",
                    color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 2.dp)
                )
                Row(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", { if (sorted.isNotEmpty()) onPlay(sorted, 0) }, Modifier.weight(1f), filled = true)
                    PillButton("Shuffle", { if (sorted.isNotEmpty()) onShuffle(sorted) }, Modifier.weight(1f))
                }
            }
        }
        if (playlist.songs.isEmpty()) {
            item {
                Text(
                    "No songs yet. Add some from the song menu, or from Player controls.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
                )
            }
        } else {
            item {
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    listOf("Recently added", "A to Z", "Most played", "Top rated").forEachIndexed { i, label ->
                        LibraryChip(label, sort == i) { sort = i }
                    }
                }
            }
            itemsIndexed(sorted, key = { _, song -> song.id }) { index, song ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .tapOrHold(onClick = { onPlay(sorted, index) }, onLongClick = { onSongMenu(song) })
                        .padding(horizontal = 16.dp, vertical = 7.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SongArtwork(song, size = 48.dp, corner = 10.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            song.title, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis,
                            color = if (song.id.toString() == currentMediaId) Palette.Accent else Palette.Text
                        )
                        Text(song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    // Liked songs: the filled star (tap to unlike). Other playlists: a small x to take the song out.
                    Box(Modifier.size(38.dp).clip(CircleShape).clickable { onRemove(song) }, contentAlignment = Alignment.Center) {
                        if (playlist.liked) NeedleIconView(NeedleIcon.STAR_FILLED, Palette.Pink, size = 22.dp)
                        else NeedleIconView(NeedleIcon.CLOSE, Palette.Muted, size = 18.dp)
                    }
                }
            }
        }
    }
}

// ============================================================================================
// Add to playlist
// ============================================================================================

private val SheetShape = RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp)
private val SheetBrush = Brush.linearGradient(listOf(Color(0xF53C3256), Color(0xFA202024)), start = androidx.compose.ui.geometry.Offset(0f, 0f), end = androidx.compose.ui.geometry.Offset(1400f, 2400f))

@Composable
private fun SheetHandle() {
    Box(
        Modifier.width(44.dp).height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.4f))
    )
}

/**
 * The "Add to playlist" sheet: a list of your playlists with a check where the song(s) already are. Tapping a row
 * adds the songs, or takes them out again when they are all in already. The first row makes a new playlist.
 */
@Composable
fun AddToPlaylistSheet(
    songs: List<Song>,
    playlists: List<PlaylistData>,
    onToggle: (playlist: PlaylistData, allIn: Boolean) -> Unit,
    onNew: () -> Unit,
    onDone: () -> Unit,
    modifier: Modifier = Modifier
) {
    var query by remember { mutableStateOf("") }
    val shown = remember(playlists, query) {
        val q = query.trim().lowercase()
        if (q.isEmpty()) playlists else playlists.filter { it.name.lowercase().contains(q) }
    }
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.88f).dp

    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = maxHeight)
            .clip(SheetShape)
            .background(SheetBrush)
            .padding(start = 16.dp, end = 16.dp, top = 10.dp)
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SheetHandle() }
        Text(
            "Add to playlist", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 26.sp,
            modifier = Modifier.padding(top = 14.dp)
        )
        Text(
            if (songs.size == 1) songs[0].title else songsText(songs.size),
            color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
        )
        // search
        Box(
            Modifier.fillMaxWidth().padding(top = 12.dp).glass(RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 12.dp)
        ) {
            BasicTextField(
                value = query, onValueChange = { query = it }, singleLine = true,
                textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                cursorBrush = SolidColor(Palette.Accent),
                modifier = Modifier.fillMaxWidth(),
                decorationBox = { inner ->
                    if (query.isEmpty()) Text("Search playlists", color = Palette.Muted, fontSize = 15.sp)
                    inner()
                }
            )
        }
        LazyColumn(Modifier.weight(1f, fill = false).padding(top = 6.dp)) {
            item {
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable(onClick = onNew).padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        Modifier.size(46.dp).glass(RoundedCornerShape(10.dp)),
                        contentAlignment = Alignment.Center
                    ) { NeedleIconView(NeedleIcon.PLUS, Palette.Text, size = 22.dp) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("New playlist", color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
                        Text("Create and add", color = Palette.Muted, fontSize = 12.sp)
                    }
                }
            }
            items(shown, key = { it.id }) { p ->
                val allIn = songs.isNotEmpty() && songs.all { it.id in p.songIds }
                val some = !allIn && songs.any { it.id in p.songIds }
                Row(
                    Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).clickable { onToggle(p, allIn) }.padding(vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PlaylistCover(p, Modifier.size(46.dp), corner = 10.dp, iconSize = 22.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.name, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(songsText(p.songs.size), color = Palette.Muted, fontSize = 12.sp)
                    }
                    Box(
                        Modifier
                            .size(26.dp)
                            .clip(CircleShape)
                            .then(
                                if (allIn) Modifier.background(Palette.Accent)
                                else Modifier.border(1.5.dp, Color.White.copy(alpha = 0.35f), CircleShape)
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        if (allIn) NeedleIconView(NeedleIcon.CHECK, Color.White, size = 16.dp)
                        else if (some) NeedleIconView(NeedleIcon.MINUS, Palette.Accent, size = 16.dp)
                    }
                }
            }
        }
        PillButton(
            "Done", onDone, Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 16.dp).navigationBarsPadding(), filled = true
        )
    }
}

// ============================================================================================
// Playlist menu (press and hold a playlist, or the ... on its page)
// ============================================================================================

@Composable
fun PlaylistMenuSheet(
    playlist: PlaylistData,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onRename: () -> Unit,
    onDelete: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(SheetShape)
            .background(SheetBrush)
            .navigationBarsPadding()
            .padding(start = 16.dp, end = 16.dp, top = 10.dp, bottom = 16.dp)
    ) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { SheetHandle() }
        Row(Modifier.padding(top = 14.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            PlaylistCover(playlist, Modifier.size(56.dp), corner = 12.dp, iconSize = 26.dp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(playlist.name, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(songsText(playlist.songs.size), color = Palette.Muted, fontSize = 13.sp)
            }
        }
        val has = playlist.songs.isNotEmpty()
        MenuItem(NeedleIcon.PLAY, "Play", has, onPlay)
        MenuItem(NeedleIcon.SHUFFLE, "Shuffle", has, onShuffle)
        MenuItem(NeedleIcon.PLAY_NEXT, "Play next", has, onPlayNext)
        MenuItem(NeedleIcon.ADD_QUEUE, "Add to queue", has, onAddToQueue)
        if (!playlist.liked) {
            MenuItem(NeedleIcon.PENCIL, "Rename", true, onRename)
            MenuItem(NeedleIcon.TRASH, "Delete playlist", true, onDelete)
        }
    }
}

@Composable
private fun MenuItem(icon: NeedleIcon, label: String, enabled: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(enabled = enabled, onClick = onClick)
            .padding(horizontal = 6.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(icon, if (enabled) Palette.Text else Palette.Muted, size = 22.dp)
        Spacer(Modifier.width(16.dp))
        Text(label, color = if (enabled) Palette.Text else Palette.Muted, fontSize = 15.5.sp)
    }
}

// ============================================================================================
// Dialogs
// ============================================================================================

/** Asks for a playlist name (a new one, or a new name for an existing one). */
@Composable
fun PlaylistNameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text(title) },
        text = {
            Box(Modifier.fillMaxWidth().glass(RoundedCornerShape(16.dp)).padding(14.dp)) {
                BasicTextField(
                    value = text, onValueChange = { text = it }, singleLine = true,
                    textStyle = TextStyle(color = Color.White, fontSize = 16.sp),
                    cursorBrush = SolidColor(Palette.Accent),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 24.dp),
                    decorationBox = { inner ->
                        if (text.isEmpty()) Text("Playlist name", color = Palette.Muted, fontSize = 16.sp)
                        inner()
                    }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onConfirm(text) }) { Text(confirm, color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}

@Composable
fun DeletePlaylistDialog(name: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        textContentColor = Palette.Muted,
        title = { Text("Delete \"$name\"?") },
        text = { Text("The songs stay in your library. Only the playlist is removed.") },
        confirmButton = { TextButton(onClick = onConfirm) { Text("Delete", color = Palette.Pink) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}
