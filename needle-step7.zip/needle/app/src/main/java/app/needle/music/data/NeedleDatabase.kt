package app.needle.music.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SongDao {
    @Query("SELECT * FROM songs")
    abstract fun observeAll(): Flow<List<Song>>

    @Query("SELECT * FROM songs")
    abstract suspend fun getAllOnce(): List<Song>

    @Query("DELETE FROM songs")
    abstract suspend fun clear()

    @Insert
    abstract suspend fun insertAll(songs: List<Song>)

    /** Swap the whole library in one transaction, so the UI updates once. */
    @Transaction
    open suspend fun replaceAll(songs: List<Song>) {
        clear()
        insertAll(songs)
    }
}

@Database(entities = [Song::class, PlayEvent::class], version = 2, exportSchema = false)
abstract class NeedleDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao
    abstract fun playDao(): PlayDao

    companion object {
        /** v1 -> v2: adds play history, keeps the songs table as it is. */
        private val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL(
                    "CREATE TABLE IF NOT EXISTS `play_events` (" +
                        "`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, " +
                        "`songId` INTEGER NOT NULL, " +
                        "`playedAt` INTEGER NOT NULL, " +
                        "`listenedMs` INTEGER NOT NULL)"
                )
            }
        }

        @Volatile
        private var instance: NeedleDatabase? = null

        fun get(context: Context): NeedleDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    NeedleDatabase::class.java,
                    "needle.db"
                )
                    .addMigrations(MIGRATION_1_2)
                    // Play history now exists, so from here on every change needs a real migration.
                    .build()
                    .also { instance = it }
            }
    }
}
