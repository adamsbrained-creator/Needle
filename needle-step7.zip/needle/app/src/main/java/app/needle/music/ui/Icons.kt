package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The line icons from the mockups, drawn with paths so no icon library is needed. */
enum class NeedleIcon { SEARCH, HOME, SONGS, ALBUMS, LIBRARY, SHUFFLE, PLAY, BACK }

@Composable
fun NeedleIconView(icon: NeedleIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) { drawNeedleIcon(icon, tint) }
}

/** Coordinates below are the mockups' 24x24 icon grid. */
private fun DrawScope.drawNeedleIcon(icon: NeedleIcon, color: Color) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(color, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = 1.8f * k, cap = StrokeCap.Round)

    when (icon) {
        NeedleIcon.SEARCH -> {
            drawCircle(color, radius = 7f * k, center = Offset(11f * k, 11f * k), style = stroke)
            line(20f, 20f, 16.5f, 16.5f)
        }
        NeedleIcon.HOME -> {
            val p = Path().apply {
                moveTo(4f * k, 11f * k); lineTo(12f * k, 4f * k); lineTo(20f * k, 11f * k)
                lineTo(20f * k, 20f * k); lineTo(15f * k, 20f * k); lineTo(15f * k, 14f * k)
                lineTo(9f * k, 14f * k); lineTo(9f * k, 20f * k); lineTo(4f * k, 20f * k)
                close()
            }
            drawPath(p, color, style = stroke)
        }
        NeedleIcon.SONGS -> {
            val p = Path().apply {
                moveTo(9f * k, 18f * k); lineTo(9f * k, 5f * k); lineTo(20f * k, 3f * k); lineTo(20f * k, 16f * k)
            }
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(6.5f * k, 18f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(17.5f * k, 16f * k), style = stroke)
        }
        NeedleIcon.ALBUMS -> {
            drawCircle(color, radius = 9f * k, center = Offset(12f * k, 12f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(12f * k, 12f * k), style = stroke)
        }
        NeedleIcon.SHUFFLE -> {
            val top = Path().apply {
                moveTo(3f * k, 7f * k); lineTo(6f * k, 7f * k)
                cubicTo(11f * k, 7f * k, 12f * k, 17f * k, 17f * k, 17f * k)
                lineTo(21f * k, 17f * k)
            }
            val bottomLeft = Path().apply {
                moveTo(3f * k, 17f * k); lineTo(6f * k, 17f * k)
                cubicTo(7.6f * k, 17f * k, 8.7f * k, 16.1f * k, 9.6f * k, 14.8f * k)
            }
            val topRight = Path().apply {
                moveTo(14.4f * k, 9.2f * k)
                cubicTo(15.3f * k, 7.9f * k, 16.4f * k, 7f * k, 18f * k, 7f * k)
                lineTo(21f * k, 7f * k)
            }
            val headTop = Path().apply { moveTo(18f * k, 4f * k); lineTo(21f * k, 7f * k); lineTo(18f * k, 10f * k) }
            val headBottom = Path().apply { moveTo(18f * k, 14f * k); lineTo(21f * k, 17f * k); lineTo(18f * k, 20f * k) }
            for (p in listOf(top, bottomLeft, topRight, headTop, headBottom)) drawPath(p, color, style = stroke)
        }
        NeedleIcon.BACK -> {
            line(19f, 12f, 5f, 12f)
            val head = Path().apply { moveTo(11f * k, 6f * k); lineTo(5f * k, 12f * k); lineTo(11f * k, 18f * k) }
            drawPath(head, color, style = stroke)
        }
        NeedleIcon.PLAY -> {
            val p = Path().apply {
                moveTo(7f * k, 4f * k); lineTo(7f * k, 20f * k); lineTo(20f * k, 12f * k); close()
            }
            drawPath(p, color)
        }
        NeedleIcon.LIBRARY -> {
            line(4f, 7f, 16f, 7f)
            line(4f, 12f, 16f, 12f)
            line(4f, 17f, 12f, 17f)
            line(19f, 14f, 19f, 20f)
            val arrow = Path().apply {
                moveTo(16f * k, 17f * k); lineTo(19f * k, 14f * k); lineTo(22f * k, 17f * k)
            }
            drawPath(arrow, color, style = stroke)
        }
    }
}
