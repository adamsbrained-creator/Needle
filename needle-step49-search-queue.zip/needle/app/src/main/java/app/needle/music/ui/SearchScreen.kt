package app.needle.music.ui

import android.app.Activity
import android.content.ActivityNotFoundException
import android.content.Intent
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtistHit
import app.needle.music.data.ExtraTags
import app.needle.music.data.HomeAlbum
import app.needle.music.data.MIN_LYRICS_QUERY
import app.needle.music.data.NeedleDatabase
import app.needle.music.data.RecentSearches
import app.needle.music.data.SearchResults
import app.needle.music.data.Song
import app.needle.music.data.SongHit
import app.needle.music.data.TopHit
import app.needle.music.data.TopKind
import app.needle.music.data.buildLyricsIndex
import app.needle.music.data.searchLibrary
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

private enum class SearchTab(val label: String) {
    ALL("All"), SONGS("Songs"), ALBUMS("Albums"), ARTISTS("Artists"), LYRICS("Lyrics")
}

/** How many rows each section shows on the All tab before "See all". */
private const val PREVIEW_SONGS = 5
private const val PREVIEW_OTHERS = 3

/**
 * Search the whole library: songs, albums, artists and the words of lyrics.
 * Type, then filter with the pills. Tap a song to play it, an album or artist to open it,
 * press and hold a song for its menu. The mic fills the box by voice.
 */
@Composable
fun SearchScreen(
    songs: List<Song>,
    albums: List<HomeAlbum>,
    extras: ExtraTags,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onOpenAlbum: (HomeAlbum) -> Unit,
    onOpenArtist: (String) -> Unit,
    onEditTags: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    var tab by rememberSaveable { mutableStateOf(SearchTab.ALL) }
    val focus = remember { FocusRequester() }
    val keyboard = LocalSoftwareKeyboardController.current
    val context = LocalContext.current
    LaunchedEffect(Unit) { focus.requestFocus() }

    // The words of every song we have lyrics for, loaded once when the page opens.
    val lyricsIndex by produceState(emptyMap<Long, String>(), extras) {
        value = withContext(Dispatchers.Default) { buildLyricsIndex(NeedleDatabase.get(context), extras) }
    }

    // Searched off the main thread, a moment after the typing settles.
    val results by produceState(SearchResults.Empty, query, songs, albums, extras, lyricsIndex) {
        val typed = query.trim()
        if (typed.isEmpty()) {
            value = SearchResults.Empty
            return@produceState
        }
        delay(150)
        value = withContext(Dispatchers.Default) { searchLibrary(typed, songs, albums, extras, lyricsIndex) }
    }

    val recents by RecentSearches.items.collectAsState()
    val q = query.trim()
    val searching = q.isNotEmpty() && results.query != q
    val mark = lerp(Palette.Accent, Color.White, 0.35f)

    val voice = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val said = r.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (r.resultCode == Activity.RESULT_OK && !said.isNullOrBlank()) {
            query = said
            tab = SearchTab.ALL
        }
    }
    val startVoice: () -> Unit = {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_PROMPT, "Say a song, album or artist")
        try {
            voice.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "Voice search isn't available on this phone", Toast.LENGTH_SHORT).show()
        }
    }

    // A search is remembered once it led somewhere (a song played, an album or artist opened).
    val saveSearch: () -> Unit = { RecentSearches.add(query) }
    val playFrom: (List<Song>, Int) -> Unit = { list, index ->
        saveSearch()
        onPlay(list, index)
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 16.dp).height(52.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 38.dp, iconSize = 20.dp)
        }

        // The search box
        Row(
            Modifier
                .padding(horizontal = 16.dp)
                .fillMaxWidth()
                .height(50.dp)
                .glass(CircleShape),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Spacer(Modifier.width(16.dp))
            NeedleIconView(NeedleIcon.SEARCH, Palette.Muted, size = 20.dp)
            Spacer(Modifier.width(10.dp))
            BasicTextField(
                value = query,
                onValueChange = { query = it },
                singleLine = true,
                textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                cursorBrush = SolidColor(Palette.Accent),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                keyboardActions = KeyboardActions(onSearch = {
                    saveSearch()
                    keyboard?.hide()
                }),
                modifier = Modifier.weight(1f).focusRequester(focus),
                decorationBox = { inner ->
                    Box(contentAlignment = Alignment.CenterStart) {
                        if (query.isEmpty()) {
                            Text(
                                "Search songs, albums, artists",
                                color = Palette.Muted, fontSize = 15.sp,
                                maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                        }
                        inner()
                    }
                }
            )
            // Clear when there is text, otherwise the mic
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .clickable { if (query.isEmpty()) startVoice() else query = "" },
                contentAlignment = Alignment.Center
            ) {
                NeedleIconView(if (query.isEmpty()) NeedleIcon.MIC else NeedleIcon.CLOSE, Palette.Muted, size = 19.dp)
            }
        }

        // Filter pills
        Row(
            Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 16.dp, vertical = 14.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            SearchTab.values().forEach { t -> SearchPill(t.label, t == tab) { tab = t } }
        }

        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
        ) {
            when {
                q.isEmpty() -> {
                    if (recents.isEmpty()) {
                        item("hint") {
                            Text(
                                "Find songs, albums and artists, or the words of a song's lyrics.",
                                color = Palette.Muted, fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 2.dp, vertical = 12.dp)
                            )
                        }
                    } else {
                        item("recent_label") { SearchLabel("Recent searches", "Clear") { RecentSearches.clear() } }
                        item("recent_chips") {
                            Row(
                                Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                recents.forEach { text ->
                                    RecentChip(text, onClick = { query = text }, onRemove = { RecentSearches.remove(text) })
                                }
                            }
                        }
                    }
                }

                searching && results.isEmpty -> Unit // still working on it

                else -> {
                    val r = results
                    val tabEmpty = when (tab) {
                        SearchTab.ALL -> r.isEmpty
                        SearchTab.SONGS -> r.songs.isEmpty()
                        SearchTab.ALBUMS -> r.albums.isEmpty()
                        SearchTab.ARTISTS -> r.artists.isEmpty()
                        SearchTab.LYRICS -> r.lyrics.isEmpty()
                    }
                    if (tabEmpty) {
                        item("nothing") {
                            Text(
                                when {
                                    tab == SearchTab.LYRICS && q.length < MIN_LYRICS_QUERY ->
                                        "Type at least $MIN_LYRICS_QUERY letters to search lyrics."
                                    tab == SearchTab.LYRICS -> "No lyrics have \u201C$q\u201D in them."
                                    else -> "Nothing found for \u201C$q\u201D."
                                },
                                color = Palette.Muted, fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 2.dp, vertical = 20.dp)
                            )
                        }
                    } else when (tab) {
                        SearchTab.ALL -> {
                            val top = r.top
                            if (top != null) {
                                val playTop: () -> Unit = {
                                    saveSearch()
                                    when (top.kind) {
                                        TopKind.ALBUM -> onPlay(top.album!!.songs, 0)
                                        TopKind.ARTIST -> onPlay(artistPlayOrder(top.artist!!), 0)
                                        TopKind.SONG -> {
                                            val i = r.songs.indexOfFirst { it.song.id == top.song!!.id }
                                            if (i >= 0) onPlay(r.songs.map { it.song }, i) else onPlay(listOf(top.song!!), 0)
                                        }
                                    }
                                }
                                item("top_l") { SearchLabel("Top result") }
                                item("top") {
                                    TopResultCard(
                                        top, q, mark,
                                        onOpen = {
                                            when (top.kind) {
                                                TopKind.ALBUM -> { saveSearch(); onOpenAlbum(top.album!!) }
                                                TopKind.ARTIST -> { saveSearch(); onOpenArtist(top.artist!!.name) }
                                                TopKind.SONG -> playTop()
                                            }
                                        },
                                        onPlay = playTop
                                    )
                                }
                            }
                            if (r.songs.isNotEmpty()) {
                                item("songs_l") {
                                    SearchLabel("Songs", if (r.songs.size > PREVIEW_SONGS) "See all" else null) { tab = SearchTab.SONGS }
                                }
                                itemsIndexed(r.songs.take(PREVIEW_SONGS), key = { _, h -> "s${h.song.id}" }) { index, hit ->
                                    SearchSongRow(
                                        hit, q, mark, hit.song.id.toString() == currentMediaId,
                                        onClick = { playFrom(r.songs.map { it.song }, index) },
                                        onLongClick = { onEditTags(hit.song) }
                                    )
                                }
                            }
                            if (r.albums.isNotEmpty()) {
                                item("albums_l") {
                                    SearchLabel("Albums", if (r.albums.size > PREVIEW_OTHERS) "See all" else null) { tab = SearchTab.ALBUMS }
                                }
                                itemsIndexed(r.albums.take(PREVIEW_OTHERS), key = { _, a -> "a${a.id}" }) { _, album ->
                                    SearchAlbumRow(album, q, mark) { saveSearch(); onOpenAlbum(album) }
                                }
                            }
                            if (r.artists.isNotEmpty()) {
                                item("artists_l") {
                                    SearchLabel("Artists", if (r.artists.size > PREVIEW_OTHERS) "See all" else null) { tab = SearchTab.ARTISTS }
                                }
                                itemsIndexed(r.artists.take(PREVIEW_OTHERS), key = { _, a -> "r${a.name}" }) { _, artist ->
                                    SearchArtistRow(artist, q, mark) { saveSearch(); onOpenArtist(artist.name) }
                                }
                            }
                        }

                        SearchTab.SONGS -> itemsIndexed(r.songs, key = { _, h -> "s${h.song.id}" }) { index, hit ->
                            SearchSongRow(
                                hit, q, mark, hit.song.id.toString() == currentMediaId,
                                onClick = { playFrom(r.songs.map { it.song }, index) },
                                onLongClick = { onEditTags(hit.song) }
                            )
                        }

                        SearchTab.ALBUMS -> itemsIndexed(r.albums, key = { _, a -> "a${a.id}" }) { _, album ->
                            SearchAlbumRow(album, q, mark) { saveSearch(); onOpenAlbum(album) }
                        }

                        SearchTab.ARTISTS -> itemsIndexed(r.artists, key = { _, a -> "r${a.name}" }) { _, artist ->
                            SearchArtistRow(artist, q, mark) { saveSearch(); onOpenArtist(artist.name) }
                        }

                        SearchTab.LYRICS -> itemsIndexed(r.lyrics, key = { _, h -> "l${h.song.id}" }) { index, hit ->
                            SearchSongRow(
                                hit, q, mark, hit.song.id.toString() == currentMediaId,
                                onClick = { playFrom(r.lyrics.map { it.song }, index) },
                                onLongClick = { onEditTags(hit.song) }
                            )
                        }
                    }
                }
            }
        }
    }
}

/** An artist's songs in a sensible order for "play": by album, then track. */
private fun artistPlayOrder(artist: ArtistHit): List<Song> =
    artist.songs.sortedWith(compareBy<Song>({ it.album.lowercase() }, { it.trackNumber }, { it.title.lowercase() }))

private fun songCountText(n: Int) = if (n == 1) "1 song" else "$n songs"

// ---- pieces ------------------------------------------------------------------------------------------

@Composable
private fun SearchPill(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            label,
            color = if (selected) Color(0xFF111111) else Palette.Text,
            fontSize = 13.5.sp,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal
        )
    }
}

@Composable
private fun SearchLabel(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(
        Modifier.fillMaxWidth().padding(start = 2.dp, end = 2.dp, top = 16.dp, bottom = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(title, color = Palette.Muted, fontSize = 13.sp)
        if (action != null) {
            Text(action, color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.clickable(onClick = onAction))
        }
    }
}

@Composable
private fun RecentChip(text: String, onClick: () -> Unit, onRemove: () -> Unit) {
    Row(
        Modifier
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.10f))
            .clickable(onClick = onClick)
            .padding(start = 16.dp, end = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Palette.Text, fontSize = 13.5.sp, maxLines = 1)
        Box(
            Modifier.size(34.dp).clip(CircleShape).clickable(onClick = onRemove),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CLOSE, Palette.Muted, size = 14.dp)
        }
    }
}

@Composable
private fun TopResultCard(top: TopHit, q: String, mark: Color, onOpen: () -> Unit, onPlay: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    val album = top.album
    val artist = top.artist
    val song = top.song
    val title = album?.title ?: artist?.name ?: song?.title.orEmpty()
    val line = when (top.kind) {
        TopKind.ALBUM -> "Album \u00B7 ${album?.artist.orEmpty()} \u00B7 ${songCountText(album?.songs?.size ?: 0)}"
        TopKind.ARTIST -> "Artist \u00B7 ${songCountText(artist?.songs?.size ?: 0)}"
        TopKind.SONG -> "Song \u00B7 ${song?.artist.orEmpty()}"
    }
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Accent.copy(alpha = 0.40f), Color.White.copy(alpha = 0.06f))))
            .border(1.dp, Palette.Accent.copy(alpha = 0.50f), shape)
            .clickable(onClick = onOpen)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(top.cover, size = 72.dp, corner = if (top.kind == TopKind.ARTIST) 36.dp else 18.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                highlighted(title, q, mark),
                color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.Bold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(line, color = Color(0xFFD8CDF5), fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Spacer(Modifier.width(10.dp))
        Box(
            Modifier.size(40.dp).clip(CircleShape).background(Color.White).clickable(onClick = onPlay),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.PLAY, Color(0xFF111111), size = 17.dp)
        }
    }
}

@Composable
private fun SearchSongRow(hit: SongHit, q: String, mark: Color, isCurrent: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val song = hit.song
    val snippet = hit.snippet
    Row(
        Modifier
            .fillMaxWidth()
            .tapOrHold(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 2.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(song, size = 48.dp, corner = 13.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                highlighted(song.title, q, mark),
                color = if (isCurrent) Palette.Accent else Palette.Text,
                fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (snippet != null) lyricLine(song.artist, snippet, q, mark) else highlighted(song.artist, q, mark),
                color = Palette.Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(formatTime(song.durationMs), color = Color(0xFFDDDDDD), fontSize = 12.sp)
    }
}

@Composable
private fun SearchAlbumRow(album: HomeAlbum, q: String, mark: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(album.cover, size = 48.dp, corner = 13.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                highlighted(album.title, q, mark),
                color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "Album \u00B7 ${album.artist} \u00B7 ${songCountText(album.songs.size)}",
                color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
    }
}

@Composable
private fun SearchArtistRow(artist: ArtistHit, q: String, mark: Color, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(artist.songs.first(), size = 48.dp, corner = 24.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                highlighted(artist.name, q, mark),
                color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("Artist \u00B7 ${songCountText(artist.songs.size)}", color = Palette.Muted, fontSize = 12.sp, maxLines = 1)
        }
        NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
    }
}

// ---- lighting up the part that matched ---------------------------------------------------------------

private fun AnnotatedString.Builder.appendHighlighted(text: String, q: String, mark: Color) {
    if (q.isEmpty()) {
        append(text)
        return
    }
    var from = 0
    while (from < text.length) {
        val at = text.indexOf(q, from, ignoreCase = true)
        if (at < 0) {
            append(text.substring(from))
            break
        }
        append(text.substring(from, at))
        withStyle(SpanStyle(color = mark)) { append(text.substring(at, at + q.length)) }
        from = at + q.length
    }
}

private fun highlighted(text: String, q: String, mark: Color): AnnotatedString =
    buildAnnotatedString { appendHighlighted(text, q, mark) }

/** "Ines Calder · in lyrics: “hold the light… harbor”", with the match lit up. */
private fun lyricLine(artist: String, snippet: String, q: String, mark: Color): AnnotatedString =
    buildAnnotatedString {
        append("$artist \u00B7 in lyrics: \u201C")
        appendHighlighted(snippet, q, mark)
        append("\u201D")
    }
