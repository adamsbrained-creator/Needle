package app.needle.music.data

import android.content.Context
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.graphics.luminance
import org.json.JSONArray
import org.json.JSONObject

/**
 * A color theme: the mode, accent, background, glow and cards of Settings > Customization > Colors & themes, in one piece.
 * 0 in a color field means "the default" (the same meaning it has in NeedleSettings). Fields that are not in use
 * (your own accent when a ready-made one is picked, the card color while cards are on Auto) are kept 0, so two
 * looks that are the same compare as equal.
 */
data class ColorTheme(
    val name: String,
    val accent: Int = 0,            // index in AccentChoices; AccentChoices.size = your own color
    val customAccent: Int = 0,
    val amoled: Boolean = false,
    val bgColor: Int = 0,
    val glow1: Int = 0,
    val glow2: Int = 0,
    val glow3: Int = 0,
    val glowStrength: Float = 1f,
    val cardCustom: Boolean = false,
    val cardArgb: Int = 0
) {
    fun sameLook(o: ColorTheme): Boolean = copy(name = "") == o.copy(name = "")

    /** Makes this the look of the app, right away. */
    fun apply() {
        NeedleSettings.setAmoled(amoled)
        NeedleSettings.setBgColor(bgColor)
        if (accent >= AccentChoices.size && customAccent != 0) NeedleSettings.setCustomAccent(customAccent)
        NeedleSettings.setAccent(accent.coerceIn(0, AccentChoices.size))
        NeedleSettings.setGlow(1, glow1)
        NeedleSettings.setGlow(2, glow2)
        NeedleSettings.setGlow(3, glow3)
        NeedleSettings.setGlowStrength(glowStrength.coerceIn(0f, 1f))
        NeedleSettings.setCardCustom(cardCustom)
        if (cardCustom && cardArgb != 0) NeedleSettings.setCardArgb(cardArgb)
    }

    fun toJson(): JSONObject = JSONObject()
        .put("needleTheme", 1)
        .put("name", name)
        .put("accent", accent)
        .put("customAccent", customAccent)
        .put("amoled", amoled)
        .put("bgColor", bgColor)
        .put("glow1", glow1)
        .put("glow2", glow2)
        .put("glow3", glow3)
        .put("glowStrength", glowStrength.toDouble())
        .put("cardCustom", cardCustom)
        .put("cardArgb", cardArgb)

    companion object {
        /** The look the app has right now, under [name]. */
        fun current(name: String): ColorTheme {
            val accent = NeedleSettings.accentIndex.intValue
            val cards = NeedleSettings.cardCustom.value
            return ColorTheme(
                name = name,
                accent = accent,
                customAccent = if (accent >= AccentChoices.size) NeedleSettings.customAccent.intValue else 0,
                amoled = NeedleSettings.amoled.value,
                bgColor = NeedleSettings.bgColor.intValue,
                glow1 = NeedleSettings.glow1.intValue,
                glow2 = NeedleSettings.glow2.intValue,
                glow3 = NeedleSettings.glow3.intValue,
                glowStrength = NeedleSettings.glowStrength.floatValue,
                cardCustom = cards,
                cardArgb = if (cards) NeedleSettings.cardArgb.intValue else 0
            )
        }

        /** null when the JSON is not a theme (no name). */
        fun fromJson(o: JSONObject): ColorTheme? {
            val name = o.optString("name", "").trim()
            if (name.isEmpty()) return null
            val accent = o.optInt("accent", 0).coerceIn(0, AccentChoices.size)
            val cards = o.optBoolean("cardCustom", false)
            return ColorTheme(
                name = name.take(40),
                accent = accent,
                customAccent = if (accent >= AccentChoices.size) o.optInt("customAccent", 0) else 0,
                amoled = o.optBoolean("amoled", false),
                bgColor = o.optInt("bgColor", 0),
                glow1 = o.optInt("glow1", 0),
                glow2 = o.optInt("glow2", 0),
                glow3 = o.optInt("glow3", 0),
                glowStrength = o.optDouble("glowStrength", 1.0).toFloat().coerceIn(0f, 1f),
                cardCustom = cards,
                cardArgb = if (cards) o.optInt("cardArgb", 0) else 0
            )
        }
    }
}

/** The ready-made themes. The first one is Needle's own look. Backgrounds stay dark, so the light text on top stays readable. */
object ColorThemes {
    private fun c(v: Long): Int = v.toInt()

    val builtIn: List<ColorTheme> = listOf(
        ColorTheme("Needle"),
        ColorTheme(
            "Midnight", accent = 2, amoled = true,
            glow1 = c(0xFF5B8DEF), glow2 = c(0xFF7B5BEF), glow3 = c(0xFF2DD4BF), glowStrength = 0.9f
        ),
        ColorTheme(
            "Sunset", accent = 5, bgColor = c(0xFF1A1210),
            glow1 = c(0xFFF2994A), glow2 = c(0xFFEB5757), glow3 = c(0xFFF2C94C)
        ),
        ColorTheme(
            "Forest", accent = 4, bgColor = c(0xFF0F1511),
            glow1 = c(0xFF6FCF97), glow2 = c(0xFF2DD4BF), glow3 = c(0xFF8FBF8F), glowStrength = 0.85f
        ),
        ColorTheme(
            "Rose", accent = 1, bgColor = c(0xFF171016),
            glow1 = c(0xFFEF42B8), glow2 = c(0xFFAF65F5), glow3 = c(0xFFF2994A)
        ),
        ColorTheme(
            "Mono", accent = AccentChoices.size, customAccent = c(0xFFE6E6EA), amoled = true,
            glow1 = c(0xFF8A8A92), glow2 = c(0xFF5A5A62), glow3 = c(0xFFB0B0B8), glowStrength = 0.6f
        )
    )

    fun isBuiltIn(name: String): Boolean = builtIn.any { it.name.equals(name, ignoreCase = true) }

    /** The name of the theme that matches the app's look right now, or null when it is your own mix. */
    fun nameOfCurrent(saved: List<ColorTheme>): String? {
        val now = ColorTheme.current("")
        return (builtIn + saved).firstOrNull { it.sameLook(now) }?.name
    }
}

/** The themes you saved or imported. Kept on the phone, and included in backups. */
object ThemeStore {
    val saved = mutableStateListOf<ColorTheme>()
    private var loaded = false

    private fun prefs(context: Context) =
        context.applicationContext.getSharedPreferences("needle_themes", Context.MODE_PRIVATE)

    fun ensureLoaded(context: Context) {
        if (loaded) return
        loaded = true
        val arr = runCatching { JSONArray(prefs(context).getString("list", "[]")) }.getOrNull() ?: return
        for (i in 0 until arr.length()) {
            arr.optJSONObject(i)?.let { ColorTheme.fromJson(it) }?.let { saved.add(it) }
        }
    }

    fun toJsonArray(): JSONArray = JSONArray().also { arr -> saved.forEach { arr.put(it.toJson()) } }

    private fun persist(context: Context) {
        prefs(context).edit().putString("list", toJsonArray().toString()).apply()
    }

    /** A name that is free: the ready-made names are taken, and so are your own (unless [replace]). */
    fun freeName(wanted: String, replace: Boolean = false): String {
        val base = wanted.trim().ifEmpty { "My theme" }.take(40)
        fun taken(n: String) = ColorThemes.isBuiltIn(n) || (!replace && saved.any { it.name.equals(n, ignoreCase = true) })
        if (!taken(base)) return base
        var i = 2
        while (taken("$base $i")) i++
        return "$base $i"
    }

    /** Saves the theme; one of yours with the same name is replaced. Returns the name it was saved under. */
    fun save(context: Context, theme: ColorTheme): String {
        ensureLoaded(context)
        val name = freeName(theme.name, replace = true)
        val fixed = theme.copy(name = name)
        val at = saved.indexOfFirst { it.name.equals(name, ignoreCase = true) }
        if (at >= 0) saved[at] = fixed else saved.add(fixed)
        persist(context)
        return name
    }

    fun delete(context: Context, name: String) {
        ensureLoaded(context)
        saved.removeAll { it.name == name }
        persist(context)
    }

    /** Themes from backups: the ones whose look you already have are skipped. */
    fun importAll(context: Context, arr: JSONArray): Int {
        ensureLoaded(context)
        var n = 0
        for (i in 0 until arr.length()) {
            val t = arr.optJSONObject(i)?.let { ColorTheme.fromJson(it) } ?: continue
            if ((ColorThemes.builtIn + saved).any { it.sameLook(t) }) continue
            val name = freeName(t.name)
            saved.add(t.copy(name = name))
            n++
        }
        if (n > 0) persist(context)
        return n
    }

    /** Reads shared text: one theme or a list of them. Anything else gives an empty list. */
    fun parse(text: String): List<ColorTheme> {
        val t = text.trim()
        if (t.isEmpty()) return emptyList()
        return runCatching {
            if (t.startsWith("[")) {
                val arr = JSONArray(t)
                (0 until arr.length()).mapNotNull { arr.optJSONObject(it)?.takeIf { o -> o.has("needleTheme") }?.let { o -> ColorTheme.fromJson(o) } }
            } else {
                val o = JSONObject(t)
                if (o.has("needleTheme")) listOfNotNull(ColorTheme.fromJson(o)) else emptyList()
            }
        }.getOrDefault(emptyList())
    }
}

// ---- readability ---------------------------------------------------------------------------

/** WCAG contrast between two colors: 1 (the same) to 21 (black on white). A see-through [top] is first laid over [under]. */
fun contrastRatio(top: Color, under: Color): Double {
    val base = under.copy(alpha = 1f)
    val a = top.compositeOver(base).luminance().toDouble()
    val b = base.luminance().toDouble()
    return (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)
}

/** "AAA" (7 or more), "AA" (4.5), "Large text only" (3), otherwise "Low". */
fun contrastGrade(ratio: Double): String = when {
    ratio >= 7.0 -> "AAA"
    ratio >= 4.5 -> "AA"
    ratio >= 3.0 -> "Large text only"
    else -> "Low"
}
