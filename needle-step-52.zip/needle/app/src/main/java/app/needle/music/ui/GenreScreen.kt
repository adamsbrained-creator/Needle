package app.needle.music.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song
import app.needle.music.data.genresOf

/** The songs of one genre. Upper and lower case count as the same genre; "Rock; Pop" counts for both. */
fun songsOfGenre(songs: List<Song>, genre: String): List<Song> {
    val key = genre.trim().lowercase()
    return songs.filter { s -> genresOf(s).any { it.lowercase() == key } }
}

/** The page "Go to genre" opens: the genre's name, Play and Shuffle, and every song that has it. */
@Composable
fun GenreScreen(
    genre: String,
    songs: List<Song>,
    currentMediaId: String?,
    ratings: Map<Long, Int>,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onMenu: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val inGenre = remember(songs, genre) { songsOfGenre(songs, genre).sortedBy { it.title.lowercase() } }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item {
            Column(Modifier.padding(horizontal = 16.dp)) {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(NeedleIcon.BACK, onBack, size = 40.dp, iconSize = 22.dp)
                }
                Text(
                    genre, color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    "${inGenre.size} ${if (inGenre.size == 1) "song" else "songs"}", color = Palette.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                Row(Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", onClick = { if (inGenre.isNotEmpty()) onPlay(inGenre, 0) }, filled = true)
                    PillButton("Shuffle", onClick = { onShuffle(inGenre) })
                }
            }
        }
        if (inGenre.isEmpty()) {
            item {
                Text(
                    "No songs with this genre.", color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp)
                )
            }
        }
        itemsIndexed(inGenre, key = { _, s -> s.id }) { index, song ->
            SongRow(
                song, isCurrent = song.id.toString() == currentMediaId,
                onClick = { onPlay(inGenre, index) }, onLongClick = { onMenu(song) },
                rating = ratings[song.id] ?: 0
            )
        }
    }
}
