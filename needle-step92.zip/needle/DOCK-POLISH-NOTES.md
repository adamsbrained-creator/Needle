# Step 91, built on Step 90: dock polish, first pass (+ Glass material)

Done in the order of the polish list: material, then motion, then gestures, then adaptability.

## Material (all floating docks: Island, Morph, Pill + dock, Pill only)
New file ui/DockStyle.kt holds what the docks are made of, so it is tuned in one place.
- A lit edge: bright on top, fading toward the foot (replaces the flat 13% outline), plus a faint second line just inside.
- A body with depth: a soft light from above, a little darkening toward the foot, a faint wash of the cover's color.
- A layered shadow (wide and soft + the system's contact shadow) and, under the dock, a light in the cover's main color.
  The Island's light brightens while a card is open.
- A dark fade at the foot of the pages behind the dock, so list text no longer runs up to (and under) it. (Not for the Classic bar.)
- Settings > Customization > Navigation, three new rows:
  - Dock material: Solid / Glass. Glass is see-through and frosted, with a brighter edge and a slanted highlight.
    It is NOT a real blur of the page behind it (Compose has no built-in backdrop blur); the fade behind the dock keeps text out of it.
  - Dock feel: Soft (the original springs) / Snappy / Bouncy. Affects the Island and the Morph dock.
  - Dock glow: Off / Soft / Strong.
  - "Try the Island": four buttons that show each card on the dock (only while the Island is the navigation).

## Island: motion
- One progress drives width, corners, light and content; the height follows a little later, so it squashes into place.
- Card parts arrive one after another (icon, then text, then button), rising 10 dp; they leave the same way.
- The selected place's white circle slides from place to place (with a small overshoot) instead of each tab fading.
- Tabs are 48 dp (were 44), so the capsule is a little bigger and easier to hit.
- Sizes are set while measuring, and radius / light while drawing, so the springs no longer recompose the dock.

## Island: gestures
- Swipe the open capsule down: it follows your finger and springs back if you let go early; a long or fast swipe puts it away.
- A finger on the open capsule stops its time (Undo cannot vanish under your thumb). The Queue card's line stands still too.
- Press and hold the cover: a ring grows and the cover lights up while you hold, a tick when it toggles.
- Swipe the cover or the "Now playing" card sideways: left = next, right = previous.

## Island: events and adaptability
- Priority: Queue > Cast > Timer > Track. A lesser event never wipes a more important one; it waits and shows right after.
- Cards scale with the system font size (the open capsule grows taller instead of clipping text).
- Reduce motion: the Cast card's rings no longer run in the background.
- New cards are announced by TalkBack as one phrase (buttons stay separate).
- Light tick when something is queued or casting starts.

## Not in this pass (next on the list)
Shared-element cover flight, richer cards (cover thumbnails, volume), rolling timer digits, scroll tuck for the Island, baseline profile, real backdrop blur for Glass.

## Icons
Your icon work in ui/Icons.kt (steps 84-88) is untouched; the docks use it as it is.

## Files
New: ui/DockStyle.kt. Rewritten: ui/IslandDock.kt. Changed: ui/MorphDock.kt (shapeSpec follows Dock feel; body uses dockBody),
ui/Dock.kt (Pill / Pill + dock bodies), ui/NeedleApp.kt (the fade), ui/SettingsScreen.kt, data/NeedleSettings.kt (3 settings, saved / exported / restored).

Not compiled here (no Android SDK on my side); an independent read-through found no compile errors. If the build fails, send the log.
Numbers to tune by feel are all in DockStyle.kt (springs, shadow, fade strength, edge and body alphas).
