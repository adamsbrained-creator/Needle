package app.needle.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * "Find info online": album facts (genres, tags, description, label, dates ...) from a web service.
 * Nothing here saves anything. The person searches by hand, picks an album from the answers and then
 * chooses what to keep (see ui/AlbumInfoScreen.kt).
 */
enum class InfoSource(val label: String) {
    MUSICBRAINZ("MusicBrainz"),
    LASTFM("Last.fm"),
    DISCOGS("Discogs");

    /** MusicBrainz needs nothing; the other two need the person's own key (Settings). */
    fun isReady(): Boolean = when (this) {
        MUSICBRAINZ -> true
        LASTFM -> NeedleSettings.lastFmKey.value.isNotBlank()
        DISCOGS -> NeedleSettings.discogsToken.value.isNotBlank()
    }

    fun keyHint(): String? = when (this) {
        MUSICBRAINZ -> null
        LASTFM -> "Add your Last.fm API key first (Settings, next to the Fanart.tv key)."
        DISCOGS -> "Add your Discogs personal token first (Settings, next to the Fanart.tv key)."
    }
}

/** A message that is fit to show to the person as it is. */
class InfoException(message: String) : Exception(message)

/** One album a search found. [id] is what the service needs to look it up again. */
data class InfoCandidate(
    val source: InfoSource,
    val id: String,
    val title: String,
    val artist: String,
    val year: String = "",
    /** A short line to tell look-alikes apart: type, format, label, country. */
    val note: String = ""
) {
    val key: String get() = "${source.name}|$id|$title|$artist"
}

/** Everything found for the album that was picked. Empty text = the service has nothing for it. */
data class InfoDetails(
    val source: InfoSource,
    val title: String = "",
    val artist: String = "",
    val year: String = "",
    val releaseDate: String = "",
    val label: String = "",
    val catalogNumber: String = "",
    val barcode: String = "",
    /** Genres as the service names them. */
    val genres: List<String> = emptyList(),
    /** Looser words: Last.fm tags, MusicBrainz tags, Discogs styles. */
    val tags: List<String> = emptyList(),
    val description: String = "",
    /** Where the description comes from, for the label on screen ("Wikipedia, linked from MusicBrainz"). */
    val descriptionFrom: String = "",
    val musicBrainzGroupId: String = ""
)

object OnlineInfo {

    suspend fun search(source: InfoSource, artist: String, album: String): List<InfoCandidate> =
        withContext(Dispatchers.IO) {
            val a = artist.trim()
            val b = album.trim()
            if (a.isEmpty() && b.isEmpty()) throw InfoException("Type an album or an artist to search for.")
            if (!source.isReady()) throw InfoException(source.keyHint() ?: "This source is not ready.")
            val found = when (source) {
                InfoSource.MUSICBRAINZ -> mbSearch(a, b)
                InfoSource.LASTFM -> lfSearch(a, b)
                InfoSource.DISCOGS -> dgSearch(a, b)
            }
            if (found.isEmpty()) throw InfoException("${source.label} found nothing for that. Try fewer words, or another source.")
            found
        }

    suspend fun details(c: InfoCandidate): InfoDetails = withContext(Dispatchers.IO) {
        when (c.source) {
            InfoSource.MUSICBRAINZ -> mbDetails(c)
            InfoSource.LASTFM -> lfDetails(c)
            InfoSource.DISCOGS -> dgDetails(c)
        }
    }

    // ---- shared helpers -------------------------------------------------------------------

    private fun getJson(url: String, service: String, headers: Map<String, String> = emptyMap()): JSONObject {
        val r = httpGet(url, headers)
        when {
            r.code == -1 -> throw InfoException("Could not reach $service. Check the connection.")
            r.code == 401 || r.code == 403 -> throw InfoException("$service did not accept the key. Check it in Settings.")
            r.code == 404 -> throw InfoException("$service has nothing for that.")
            r.code == 429 || r.code == 503 -> throw InfoException("$service is busy. Wait a moment and try again.")
            r.code != 200 -> throw InfoException("$service answered with an error (${r.code}).")
        }
        val body = r.body ?: throw InfoException("$service sent an empty answer.")
        return try {
            JSONObject(String(body, Charsets.UTF_8))
        } catch (e: Exception) {
            throw InfoException("$service sent an answer Needle could not read.")
        }
    }

    /** Text of a key, "" when it is missing or null (org.json would say "null"). */
    private fun JSONObject.s(key: String): String = if (isNull(key)) "" else optString(key, "").trim()

    private fun JSONArray?.objects(): List<JSONObject> {
        if (this == null) return emptyList()
        return (0 until length()).mapNotNull { optJSONObject(it) }
    }

    private fun JSONArray?.strings(): List<String> {
        if (this == null) return emptyList()
        return (0 until length()).map { optString(it, "").trim() }.filter { it.isNotEmpty() && it != "null" }
    }

    private fun cap(s: String): String = s.trim().replaceFirstChar { it.uppercase() }

    /** Drops repeats (any case) and anything in [other], keeps the order. */
    private fun cleanWords(words: List<String>, other: List<String> = emptyList()): List<String> {
        val seen = other.map { it.lowercase() }.toMutableSet()
        val out = ArrayList<String>()
        for (w in words) {
            val t = cap(w)
            if (t.isNotEmpty() && seen.add(t.lowercase())) out.add(t)
        }
        return out
    }

    /** "2013-05-00" -> "2013-05", "2013-00-00" -> "2013". Anything that is not a date -> "". */
    private fun cleanDate(raw: String): String {
        val m = Regex("""^(\d{4})(?:-(\d{2}))?(?:-(\d{2}))?""").find(raw.trim()) ?: return ""
        val y = m.groupValues[1]
        val mo = m.groupValues[2].takeIf { it.isNotEmpty() && it != "00" } ?: return y
        val d = m.groupValues[3].takeIf { it.isNotEmpty() && it != "00" } ?: return "$y-$mo"
        return "$y-$mo-$d"
    }

    private fun htmlToText(html: String): String {
        var t = html
            .replace(Regex("""(?i)<br\s*/?>"""), "\n")
            .replace(Regex("""(?i)</p>"""), "\n\n")
            .replace(Regex("""<[^>]+>"""), "")
        t = t.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&apos;", "'")
            .replace("&lt;", "<").replace("&gt;", ">").replace("&nbsp;", " ")
        return t.replace(Regex("""[ \t]+\n"""), "\n").replace(Regex("""\n{3,}"""), "\n\n").trim()
    }

    private fun lucene(s: String) = s.replace(Regex("""["\\]"""), " ").trim()

    // ---- MusicBrainz (no key; asks for one request a second) ---------------------------------

    private const val MB = "https://musicbrainz.org/ws/2"

    private fun mbCredit(credit: JSONArray?): String =
        credit.objects().joinToString("") { c ->
            (c.s("name").ifEmpty { c.optJSONObject("artist")?.s("name").orEmpty() }) + (if (c.isNull("joinphrase")) "" else c.optString("joinphrase", ""))
        }.trim()

    private suspend fun mbSearch(artist: String, album: String): List<InfoCandidate> {
        val queries = ArrayList<String>()
        if (album.isNotEmpty() && artist.isNotEmpty()) queries.add("""releasegroup:"${lucene(album)}" AND artist:"${lucene(artist)}"""")
        if (album.isNotEmpty()) queries.add("""releasegroup:"${lucene(album)}"""")
        if (album.isEmpty()) queries.add("""artist:"${lucene(artist)}"""")
        for ((i, q) in queries.withIndex()) {
            if (i > 0) delay(1100)
            val json = getJson("$MB/release-group/?query=${enc(q)}&fmt=json&limit=12", "MusicBrainz")
            val list = json.optJSONArray("release-groups").objects().map { g ->
                val types = listOf(g.s("primary-type")) + g.optJSONArray("secondary-types").strings()
                val date = g.s("first-release-date")
                InfoCandidate(
                    source = InfoSource.MUSICBRAINZ,
                    id = g.s("id"),
                    title = g.s("title"),
                    artist = mbCredit(g.optJSONArray("artist-credit")),
                    year = date.take(4),
                    note = (types + date).filter { it.isNotEmpty() }.joinToString(" · ")
                )
            }.filter { it.id.isNotEmpty() }
            if (list.isNotEmpty()) return list
        }
        return emptyList()
    }

    private suspend fun mbDetails(c: InfoCandidate): InfoDetails {
        val g = getJson("$MB/release-group/${c.id}?inc=genres+tags+annotation+url-rels+artist-credits&fmt=json", "MusicBrainz")
        val genreNames = g.optJSONArray("genres").objects().sortedByDescending { it.optInt("count", 0) }.map { it.s("name") }
        val tagNames = g.optJSONArray("tags").objects().sortedByDescending { it.optInt("count", 0) }.map { it.s("name") }
        val genres = cleanWords(genreNames).take(12)
        val tags = cleanWords(tagNames, genres).take(15)
        val firstDate = g.s("first-release-date")

        // The label, catalog number and barcode belong to a release, not to the album as a whole:
        // take the earliest official release that has them.
        var label = ""; var catno = ""; var barcode = ""; var date = firstDate
        try {
            delay(1100)
            val rels = getJson("$MB/release?release-group=${c.id}&inc=labels&status=official&fmt=json&limit=40", "MusicBrainz")
                .optJSONArray("releases").objects()
            val dated = rels.filter { it.s("date").isNotEmpty() }.sortedBy { it.s("date") }
            val pick = dated.firstOrNull { r -> r.optJSONArray("label-info").objects().any { it.optJSONObject("label") != null } }
                ?: dated.firstOrNull() ?: rels.firstOrNull()
            if (pick != null) {
                val li = pick.optJSONArray("label-info").objects().firstOrNull { it.optJSONObject("label") != null }
                    ?: pick.optJSONArray("label-info").objects().firstOrNull()
                label = li?.optJSONObject("label")?.s("name").orEmpty()
                catno = li?.s("catalog-number").orEmpty()
                barcode = pick.s("barcode")
                if (date.isEmpty()) date = pick.s("date")
            }
        } catch (e: InfoException) {
            // The rest is still useful without it.
        }

        // A description: MusicBrainz's own note, else the Wikipedia page they link to.
        var description = g.s("annotation")
        var from = if (description.isNotEmpty()) "MusicBrainz note" else ""
        if (description.isEmpty()) {
            val rels = g.optJSONArray("relations").objects()
            val wiki = rels.firstOrNull { it.s("type") == "wikipedia" }?.optJSONObject("url")?.s("resource").orEmpty()
            val wikidata = rels.firstOrNull { it.s("type") == "wikidata" }?.optJSONObject("url")?.s("resource").orEmpty()
            val extract = try { wikipediaSummary(wiki, wikidata) } catch (e: InfoException) { "" }
            if (extract.isNotEmpty()) { description = extract; from = "Wikipedia, linked from MusicBrainz" }
        }

        return InfoDetails(
            source = InfoSource.MUSICBRAINZ,
            title = g.s("title").ifEmpty { c.title },
            artist = mbCredit(g.optJSONArray("artist-credit")).ifEmpty { c.artist },
            year = firstDate.take(4),
            releaseDate = cleanDate(date),
            label = label, catalogNumber = catno, barcode = barcode,
            genres = genres, tags = tags,
            description = description, descriptionFrom = from,
            musicBrainzGroupId = c.id
        )
    }

    private fun wikipediaSummary(wikipediaUrl: String, wikidataUrl: String): String {
        var lang = "en"
        var title = ""
        if (wikipediaUrl.isNotEmpty()) {
            val m = Regex("""^https?://([a-z\-]+)\.wikipedia\.org/wiki/([^?#]+)""").find(wikipediaUrl)
            if (m != null) { lang = m.groupValues[1]; title = m.groupValues[2] }
        }
        if (title.isEmpty() && wikidataUrl.isNotEmpty()) {
            val qid = wikidataUrl.substringAfterLast('/').substringBefore('?')
            if (!Regex("""Q\d+""").matches(qid)) return ""
            val e = getJson(
                "https://www.wikidata.org/w/api.php?action=wbgetentities&ids=$qid&props=sitelinks&sitefilter=enwiki&format=json",
                "Wikidata"
            )
            val name = e.optJSONObject("entities")?.optJSONObject(qid)?.optJSONObject("sitelinks")?.optJSONObject("enwiki")?.s("title").orEmpty()
            if (name.isEmpty()) return ""
            title = enc(name.replace(' ', '_')).replace("+", "%20")
        }
        if (title.isEmpty()) return ""
        val j = getJson("https://$lang.wikipedia.org/api/rest_v1/page/summary/$title", "Wikipedia")
        return j.s("extract")
    }

    // ---- Last.fm (own API key) -----------------------------------------------------------------

    private const val LF = "https://ws.audioscrobbler.com/2.0/"

    private fun lfSearch(artist: String, album: String): List<InfoCandidate> {
        val key = NeedleSettings.lastFmKey.value.trim()
        // Last.fm's search takes one text; the artist only helps to put the right ones first.
        val text = album.ifEmpty { artist }
        val json = getJson("$LF?method=album.search&album=${enc(text)}&api_key=${enc(key)}&format=json&limit=30", "Last.fm")
        if (json.has("error")) throw InfoException(json.s("message").ifEmpty { "Last.fm refused the search." })
        val matches = json.optJSONObject("results")?.optJSONObject("albummatches")
        val arr = matches?.optJSONArray("album")
        val list = (arr.objects().ifEmpty { listOfNotNull(matches?.optJSONObject("album")) }).map { a ->
            InfoCandidate(InfoSource.LASTFM, a.s("mbid"), a.s("name"), a.s("artist"))
        }.filter { it.title.isNotEmpty() }
        return if (artist.isEmpty() || album.isEmpty()) list
        else list.sortedBy { if (sameish(it.artist, artist)) 0 else 1 }
    }

    private fun lfDetails(c: InfoCandidate): InfoDetails {
        val key = NeedleSettings.lastFmKey.value.trim()
        val json = getJson(
            "$LF?method=album.getinfo&artist=${enc(c.artist)}&album=${enc(c.title)}&autocorrect=1&api_key=${enc(key)}&format=json",
            "Last.fm"
        )
        if (json.has("error")) throw InfoException(json.s("message").ifEmpty { "Last.fm has nothing for that album." })
        val a = json.optJSONObject("album") ?: throw InfoException("Last.fm has nothing for that album.")
        val tags = cleanWords(a.optJSONObject("tags")?.optJSONArray("tag").objects().map { it.s("name") }).take(15)
        val wiki = a.optJSONObject("wiki")
        var text = htmlToText(wiki?.s("content").orEmpty().ifEmpty { wiki?.s("summary").orEmpty() })
        // The text ends with a link back to Last.fm and a licence line. Neither belongs in a tag.
        text = text.replace(Regex("""(?i)read more on last\.fm.*$"""), "")
            .replace(Regex("""(?i)user-contributed text is available under.*$"""), "").trim()
        return InfoDetails(
            source = InfoSource.LASTFM,
            title = a.s("name").ifEmpty { c.title },
            artist = a.s("artist").ifEmpty { c.artist },
            tags = tags,
            description = text,
            descriptionFrom = if (text.isNotEmpty()) "Last.fm wiki" else ""
        )
    }

    // ---- Discogs (own personal token) -----------------------------------------------------------

    private const val DG = "https://api.discogs.com"

    private fun dgHeaders() = mapOf("Authorization" to "Discogs token=${NeedleSettings.discogsToken.value.trim()}")

    private fun dgPersonName(raw: String) = raw.replace(Regex("""\s\(\d+\)$"""), "").trim()

    private fun dgSearch(artist: String, album: String): List<InfoCandidate> {
        fun fetch(params: String, type: String): List<InfoCandidate> {
            val json = getJson("$DG/database/search?$params&type=$type&per_page=12", "Discogs", dgHeaders())
            return json.optJSONArray("results").objects().mapNotNull { r ->
                val full = r.s("title")
                val dash = full.indexOf(" - ")
                val who = if (dash > 0) dgPersonName(full.substring(0, dash)) else ""
                val what = if (dash > 0) full.substring(dash + 3).trim() else full
                val id = r.opt("id")?.toString().orEmpty()
                if (id.isEmpty() || id == "null") return@mapNotNull null
                val extra = if (type == "master") listOf("Master release")
                else listOf(r.optJSONArray("format").strings().joinToString(", "), r.optJSONArray("label").strings().firstOrNull().orEmpty(), r.s("country"))
                InfoCandidate(
                    InfoSource.DISCOGS,
                    (if (type == "master") "m:" else "r:") + id,
                    what, who, r.s("year"),
                    (extra + r.s("year")).filter { it.isNotEmpty() }.joinToString(" · ")
                )
            }
        }
        val structured = buildString {
            if (artist.isNotEmpty()) append("artist=${enc(artist)}&")
            if (album.isNotEmpty()) append("release_title=${enc(album)}&")
        }.trimEnd('&')
        // One entry per album (the "master") first, then single releases, which show the label and format.
        var out = fetch(structured, "master")
        if (out.size < 6) out = out + fetch(structured, "release")
        if (out.isEmpty()) {
            val q = "q=${enc("$artist $album".trim())}"
            out = fetch(q, "master") + fetch(q, "release")
        }
        return out.take(16)
    }

    private fun dgDetails(c: InfoCandidate): InfoDetails {
        val isMaster = c.id.startsWith("m:")
        val id = c.id.substringAfter(':')
        val h = dgHeaders()
        var title = c.title; var artist = c.artist; var year = c.year
        var genres = emptyList<String>(); var styles = emptyList<String>()
        var releaseId = if (isMaster) "" else id

        if (isMaster) {
            val m = getJson("$DG/masters/$id", "Discogs", h)
            title = m.s("title").ifEmpty { title }
            artist = m.optJSONArray("artists").objects().joinToString(", ") { dgPersonName(it.s("name")) }.ifEmpty { artist }
            year = m.s("year").takeIf { it != "0" }.orEmpty().ifEmpty { year }
            genres = m.optJSONArray("genres").strings()
            styles = m.optJSONArray("styles").strings()
            releaseId = m.opt("main_release")?.toString().orEmpty().takeIf { it != "null" }.orEmpty()
        }

        var label = ""; var catno = ""; var barcode = ""; var date = ""; var notes = ""
        if (releaseId.isNotEmpty()) {
            try {
                val r = getJson("$DG/releases/$releaseId", "Discogs", h)
                if (!isMaster) {
                    title = r.s("title").ifEmpty { title }
                    artist = r.optJSONArray("artists").objects().joinToString(", ") { dgPersonName(it.s("name")) }.ifEmpty { artist }
                    year = r.s("year").takeIf { it != "0" }.orEmpty().ifEmpty { year }
                    genres = r.optJSONArray("genres").strings()
                    styles = r.optJSONArray("styles").strings()
                }
                val l = r.optJSONArray("labels").objects().firstOrNull()
                label = l?.s("name").orEmpty().let { dgPersonName(it) }
                catno = l?.s("catno").orEmpty().takeIf { !it.equals("none", true) }.orEmpty()
                date = cleanDate(r.s("released"))
                barcode = r.optJSONArray("identifiers").objects()
                    .firstOrNull { it.s("type").equals("Barcode", true) }?.s("value").orEmpty().replace(" ", "")
                notes = dgNotes(r.s("notes"))
            } catch (e: InfoException) {
                // Master facts are still useful without the release.
            }
        }

        val g = cleanWords(genres)
        return InfoDetails(
            source = InfoSource.DISCOGS,
            title = title, artist = artist, year = year.take(4),
            releaseDate = date, label = label, catalogNumber = catno, barcode = barcode,
            genres = g, tags = cleanWords(styles, g),
            description = notes,
            descriptionFrom = if (notes.isNotEmpty()) "Discogs release notes" else ""
        )
    }

    /** Discogs notes use their own markup: [a=Artist], [l=Label], [m123], [b]bold[/b], [url=...]text[/url]. */
    private fun dgNotes(raw: String): String {
        if (raw.isBlank()) return ""
        return raw
            .replace(Regex("""\[url=[^\]]*]"""), "").replace("[/url]", "")
            .replace(Regex("""\[[arlm]=([^\]]+)]"""), "$1")
            .replace(Regex("""\[[arlm]\d+]"""), "")
            .replace(Regex("""\[/?[biu]]"""), "")
            .replace("\r\n", "\n")
            .replace(Regex("""\n{3,}"""), "\n\n")
            .trim()
    }
}
