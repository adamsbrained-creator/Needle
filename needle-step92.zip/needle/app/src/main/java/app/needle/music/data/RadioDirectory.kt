package app.needle.music.data

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray

/** One search result of the public station directory. */
data class DirectoryStation(
    val name: String,
    val url: String,
    val thumbUrl: String,
    val tags: List<String>,
    val country: String,
    val codec: String,
    val bitrate: Int
) {
    /** "US · AAC 64k · jazz, lounge" */
    val line: String
        get() {
            val parts = ArrayList<String>()
            if (country.isNotBlank()) parts += country
            if (codec.isNotBlank()) parts += codec.uppercase() + (if (bitrate > 0) " ${bitrate}k" else "")
            else if (bitrate > 0) parts += "${bitrate}k"
            if (tags.isNotEmpty()) parts += tags.take(3).joinToString(", ")
            return parts.joinToString(" · ")
        }
}

/**
 * Looks stations up in the free Radio Browser directory (a community list of internet radio stations, no account or
 * key needed). It is only used while the person searches on the Find stations page; the stations they add are
 * copied into their own list and keep working without it.
 *
 * The directory has several servers; they are tried one after the other until one answers.
 */
object RadioDirectory {
    private val servers = listOf(
        "https://de1.api.radio-browser.info",
        "https://de2.api.radio-browser.info",
        "https://nl1.api.radio-browser.info",
        "https://at1.api.radio-browser.info"
    )

    /** The stations that match [query] by name or tag, most popular first. Null when no server could be reached. */
    suspend fun search(query: String, minBitrate: Int = 0, limit: Int = 40): List<DirectoryStation>? =
        withContext(Dispatchers.IO) {
            val q = query.trim()
            if (q.isEmpty()) return@withContext emptyList()
            val bitrate = if (minBitrate > 0) "&bitrateMin=$minBitrate" else ""
            val common = "&limit=$limit&hidebroken=true&order=clickcount&reverse=true$bitrate"
            val byName = fetch("/json/stations/search?name=${enc(q)}$common") ?: return@withContext null
            val result = ArrayList(byName)
            if (result.size < 10) {
                // Not many names match: look at the tags too ("jazz" is a tag more than a name).
                fetch("/json/stations/search?tag=${enc(q.lowercase())}$common")?.forEach { s ->
                    if (result.none { it.url.equals(s.url, ignoreCase = true) }) result += s
                }
            }
            result.take(limit)
        }

    private fun fetch(path: String): List<DirectoryStation>? {
        for (server in servers) {
            val reply = runCatching { httpGet(server + path, mapOf("Accept" to "application/json")) }.getOrNull() ?: continue
            val body = reply.body ?: continue
            if (reply.code != 200) continue
            val parsed = runCatching { parse(String(body, Charsets.UTF_8)) }.getOrNull() ?: continue
            return parsed
        }
        return null
    }

    private fun parse(text: String): List<DirectoryStation> {
        val arr = JSONArray(text)
        val out = ArrayList<DirectoryStation>()
        for (i in 0 until arr.length()) {
            val o = arr.getJSONObject(i)
            val url = o.optString("url_resolved").ifBlank { o.optString("url") }
            val name = o.optString("name").trim()
            if (url.isBlank() || name.isBlank()) continue
            out += DirectoryStation(
                name = name,
                url = url,
                thumbUrl = o.optString("favicon"),
                tags = RadioStations.splitTags(o.optString("tags")),
                country = o.optString("countrycode"),
                codec = o.optString("codec"),
                bitrate = o.optInt("bitrate", 0)
            )
        }
        return out
    }
}
