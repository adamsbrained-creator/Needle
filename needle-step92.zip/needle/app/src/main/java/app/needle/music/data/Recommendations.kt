package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/** An artist Needle thinks you may like, with the newest album it found for them. */
data class Suggestion(
    val artist: String,
    val pictureUrl: String,
    /** Artists of your library this one is related to ("Because you play ..."). */
    val because: List<String>,
    val albumTitle: String,
    val albumCover: String,
    val year: String
)

/** An album or artist kept on the wishlist. */
data class WishItem(val artist: String, val album: String, val cover: String, val at: Long)

/**
 * Recommendations. Needle stays an offline player: your music is analysed on the phone, and only the names of a few
 * of your most played artists are sent to Deezer's free public API (no account, no key) to ask "who is related?".
 * Nothing else leaves the phone. It is off until the person turns it on, it can be limited to Wi-Fi, the answers are
 * kept on the phone and refreshed at most once a week.
 */
object Recommendations {
    private var prefs: SharedPreferences? = null
    private const val WEEK_MS = 7L * 24 * 60 * 60 * 1000

    val enabled = MutableStateFlow(false)
    val wifiOnly = MutableStateFlow(true)
    val suggestions = MutableStateFlow<List<Suggestion>>(emptyList())
    val wishlist = MutableStateFlow<List<WishItem>>(emptyList())
    val updatedAt = MutableStateFlow(0L)
    val loading = MutableStateFlow(false)
    val failed = MutableStateFlow(false)

    // Listening history kept somewhere else (ListenBrainz or Last.fm), used as extra starting points.
    /** "" (none), "lb" (ListenBrainz) or "lfm" (Last.fm). */
    val extSource = MutableStateFlow("")
    val extUser = MutableStateFlow("")
    /** Last.fm needs the person's own free API key; ListenBrainz needs none for a public profile. */
    val extKey = MutableStateFlow("")
    val extArtists = MutableStateFlow<List<String>>(emptyList())
    val extStatus = MutableStateFlow("")
    private var extUpdated = 0L

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_recs", Context.MODE_PRIVATE)
        prefs = p
        enabled.value = p.getBoolean("enabled", false)
        wifiOnly.value = p.getBoolean("wifiOnly", true)
        updatedAt.value = p.getLong("updated", 0L)
        suggestions.value = runCatching { parseSuggestions(p.getString("suggestions", "[]").orEmpty()) }.getOrDefault(emptyList())
        wishlist.value = runCatching { parseWishes(p.getString("wishlist", "[]").orEmpty()) }.getOrDefault(emptyList())
        extSource.value = p.getString("extSource", "").orEmpty()
        extUser.value = p.getString("extUser", "").orEmpty()
        extKey.value = p.getString("extKey", "").orEmpty()
        extArtists.value = p.getString("extArtists", "").orEmpty().split('\n').filter { it.isNotBlank() }
        extUpdated = p.getLong("extUpdated", 0L)
    }

    /** Remembers where the listening history lives. An empty [user] removes it. */
    fun setExternal(source: String, user: String, key: String) {
        val clean = user.trim()
        extSource.value = if (clean.isEmpty()) "" else source
        extUser.value = clean
        extKey.value = key.trim()
        extArtists.value = emptyList()
        extStatus.value = ""
        extUpdated = 0L
        prefs?.edit()?.putString("extSource", extSource.value)?.putString("extUser", clean)?.putString("extKey", extKey.value)
            ?.putString("extArtists", "")?.putLong("extUpdated", 0L)?.apply()
    }

    /**
     * Loads the most played artists of the saved profile (about 30). Same rules as the suggestions: only when switched
     * on, and not on mobile data when Wi-Fi only is on. Without [force] it is done at most once a week.
     */
    suspend fun importExternal(context: Context, force: Boolean) {
        val source = extSource.value
        val user = extUser.value
        if (!enabled.value || source.isEmpty() || user.isEmpty()) return
        if (!force && extArtists.value.isNotEmpty() && System.currentTimeMillis() - extUpdated < WEEK_MS) return
        if (wifiOnly.value && isMetered(context)) {
            extStatus.value = "Waiting for Wi-Fi"
            return
        }
        extStatus.value = "Loading..."
        val names = withContext(Dispatchers.IO) { runCatching { fetchExternal(source, user, extKey.value) }.getOrNull() }
        if (names == null) {
            extStatus.value = "Could not load it. Check the name" + if (source == "lfm") " and the API key." else "."
            return
        }
        extArtists.value = names
        extUpdated = System.currentTimeMillis()
        extStatus.value = if (names.isEmpty()) "Nothing found on that profile yet." else "${names.size} artists loaded"
        prefs?.edit()?.putString("extArtists", names.joinToString("\n"))?.putLong("extUpdated", extUpdated)?.apply()
    }

    /** Null when the service could not be reached or does not know the name. */
    private fun fetchExternal(source: String, user: String, key: String): List<String>? {
        val u = enc(user)
        val names = ArrayList<String>()
        if (source == "lb") {
            val r = httpGet("https://api.listenbrainz.org/1/stats/user/$u/artists?range=all_time&count=30")
            if (r.code == 204) return emptyList()
            val body = r.body ?: return null
            val arr = JSONObject(String(body)).optJSONObject("payload")?.optJSONArray("artists") ?: return null
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("artist_name")?.takeIf { it.isNotBlank() }?.let { names += it }
        } else {
            if (key.isBlank()) return null
            val r = httpGet("https://ws.audioscrobbler.com/2.0/?method=user.gettopartists&user=$u&api_key=${enc(key)}&format=json&period=overall&limit=30")
            val body = r.body ?: return null
            val arr = JSONObject(String(body)).optJSONObject("topartists")?.optJSONArray("artist") ?: return null
            for (i in 0 until arr.length()) arr.optJSONObject(i)?.optString("name")?.takeIf { it.isNotBlank() }?.let { names += it }
        }
        return names
    }

    fun setEnabled(on: Boolean) {
        enabled.value = on
        prefs?.edit()?.putBoolean("enabled", on)?.apply()
    }

    fun setWifiOnly(on: Boolean) {
        wifiOnly.value = on
        prefs?.edit()?.putBoolean("wifiOnly", on)?.apply()
    }

    fun isWished(artist: String, album: String) = wishlist.value.any { it.artist == artist && it.album == album }

    fun toggleWish(s: Suggestion) {
        val now = if (isWished(s.artist, s.albumTitle)) wishlist.value.filterNot { it.artist == s.artist && it.album == s.albumTitle }
        else listOf(WishItem(s.artist, s.albumTitle, s.albumCover, System.currentTimeMillis())) + wishlist.value
        saveWishes(now)
    }

    fun removeWish(item: WishItem) = saveWishes(wishlist.value.filterNot { it.artist == item.artist && it.album == item.album })

    /**
     * Asks for new suggestions. [seeds] are the names of your most played artists, [libraryKeys] the artistKey of every
     * artist you already have (they are never suggested). Does nothing when it is switched off, when the phone is on
     * mobile data and Wi-Fi only is on, or when the saved answer is less than a week old (unless [force]).
     */
    suspend fun refresh(context: Context, seeds: List<String>, libraryKeys: Set<String>, force: Boolean) {
        if (!enabled.value || seeds.isEmpty() || loading.value) return
        if (!force && suggestions.value.isNotEmpty() && System.currentTimeMillis() - updatedAt.value < WEEK_MS) return
        if (wifiOnly.value && isMetered(context)) return
        loading.value = true
        failed.value = false
        val found = withContext(Dispatchers.IO) { runCatching { fetch(seeds.take(6), libraryKeys) }.getOrNull() }
        loading.value = false
        if (found == null) {
            failed.value = true
            return
        }
        suggestions.value = found
        updatedAt.value = System.currentTimeMillis()
        prefs?.edit()?.putString("suggestions", suggestionsJson(found))?.putLong("updated", updatedAt.value)?.apply()
    }

    private fun isMetered(context: Context): Boolean {
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        return runCatching { cm?.isActiveNetworkMetered == true }.getOrDefault(false)
    }

    // ---- Deezer ---------------------------------------------------------------------

    private fun json(url: String): JSONObject? {
        val body = httpGet(url).body ?: return null
        return runCatching { JSONObject(String(body)) }.getOrNull()
    }

    private class Candidate(val name: String, val id: Long, val picture: String, val because: MutableList<String> = ArrayList())

    /** Null when nothing could be reached at all. */
    private fun fetch(seeds: List<String>, libraryKeys: Set<String>): List<Suggestion>? {
        val candidates = LinkedHashMap<Long, Candidate>()
        var reached = false
        for (seed in seeds) {
            val hit = json("https://api.deezer.com/search/artist?q=${enc(seed)}&limit=1")?.optJSONArray("data")?.optJSONObject(0) ?: continue
            reached = true
            val seedId = hit.optLong("id")
            if (seedId == 0L) continue
            val related = json("https://api.deezer.com/artist/$seedId/related?limit=12")?.optJSONArray("data") ?: continue
            for (i in 0 until related.length()) {
                val a = related.optJSONObject(i) ?: continue
                val name = a.optString("name")
                val id = a.optLong("id")
                if (name.isBlank() || id == 0L || artistKey(name) in libraryKeys) continue
                val c = candidates.getOrPut(id) { Candidate(name, id, a.optString("picture_medium")) }
                if (seed !in c.because) c.because += seed
            }
        }
        if (!reached) return null
        // Artists related to several of your artists come first, then the ones Deezer lists first.
        val top = candidates.values.withIndex().sortedWith(compareByDescending<IndexedValue<Candidate>> { it.value.because.size }.thenBy { it.index })
            .map { it.value }.take(14)
        return top.map { c ->
            var title = ""; var cover = ""; var year = ""
            val albums = json("https://api.deezer.com/artist/${c.id}/albums?limit=25")?.optJSONArray("data")
            if (albums != null) {
                var bestDate = ""
                for (i in 0 until albums.length()) {
                    val a = albums.optJSONObject(i) ?: continue
                    if (a.optString("record_type") != "album") continue
                    val date = a.optString("release_date")
                    if (title.isEmpty() || date > bestDate) {
                        bestDate = date
                        title = a.optString("title")
                        cover = a.optString("cover_medium")
                        year = date.take(4)
                    }
                }
            }
            Suggestion(c.name, c.picture, c.because.toList(), title, cover, year)
        }
    }

    // ---- saving ---------------------------------------------------------------------

    private fun saveWishes(list: List<WishItem>) {
        wishlist.value = list
        val arr = JSONArray()
        list.forEach { arr.put(JSONObject().put("artist", it.artist).put("album", it.album).put("cover", it.cover).put("at", it.at)) }
        prefs?.edit()?.putString("wishlist", arr.toString())?.apply()
    }

    private fun suggestionsJson(list: List<Suggestion>): String {
        val arr = JSONArray()
        list.forEach {
            arr.put(
                JSONObject().put("artist", it.artist).put("pic", it.pictureUrl).put("because", it.because.joinToString("\n"))
                    .put("album", it.albumTitle).put("cover", it.albumCover).put("year", it.year)
            )
        }
        return arr.toString()
    }

    private fun parseSuggestions(text: String): List<Suggestion> {
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            Suggestion(
                o.optString("artist"), o.optString("pic"), o.optString("because").split('\n').filter { it.isNotBlank() },
                o.optString("album"), o.optString("cover"), o.optString("year")
            )
        }
    }

    private fun parseWishes(text: String): List<WishItem> {
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            WishItem(o.optString("artist"), o.optString("album"), o.optString("cover"), o.optLong("at"))
        }
    }
}
