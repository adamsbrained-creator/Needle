package app.needle.music.ui

import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.RoundRect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.ClipOp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import app.needle.music.data.NeedleSettings

/*
 * What every floating dock (Morph, Island, Pill) is made of and how it moves, in one place so the polish is done once.
 *
 *   Material  Solid: a dark body with a soft top sheen, a lit edge (bright on top, fading down), a layered shadow and a little
 *             light under it in the cover's color. Glass: the same shape, but see-through and frosted, with a stronger edge and a
 *             slanted highlight. (It is not a real blur of what is behind it: a fade behind the dock keeps text out of the glass.)
 *   Feel      Soft / Snappy / Bouncy springs for size and corners.
 *   Glow      Off / Soft / Strong light under the dock.
 * All three are in Settings > Customization > Navigation.
 */
internal object DockStyle {
    val glass: Boolean get() = NeedleSettings.dockMaterial.intValue == 1

    /** How strong the light under a dock is: 0 = off, 1 = Strong. */
    val glowStrength: Float
        get() = when (NeedleSettings.dockGlow.intValue) {
            0 -> 0f
            1 -> 0.6f
            else -> 1f
        }

    private val damping: Float
        get() = when (NeedleSettings.dockFeel.intValue) {
            1 -> 0.9f
            2 -> 0.55f
            else -> 0.74f
        }

    private val stiffness: Float
        get() = when (NeedleSettings.dockFeel.intValue) {
            1 -> 600f
            2 -> 360f
            else -> 340f
        }

    /**
     * The spring for sizes and corners; Reduce motion makes it a short fade. [lag] = a softer, slower spring: used for the height,
     * so the capsule is a little behind in height than in width and squashes into place instead of scaling evenly.
     */
    fun <T> spec(reduce: Boolean, lag: Boolean = false): FiniteAnimationSpec<T> =
        if (reduce) tween(160)
        else if (lag) spring(dampingRatio = (damping - 0.1f).coerceAtLeast(0.4f), stiffness = stiffness * 0.8f)
        else spring(dampingRatio = damping, stiffness = stiffness)

    /** The corner of a tall dock: follows Settings > Corners (Sharp / Soft / Round). */
    fun tallRadius(): Dp = when (NeedleSettings.cornerStyle.intValue) {
        0 -> 10.dp
        1 -> 20.dp
        else -> 32.dp
    }

    /** How tall the fade behind the dock is: enough to cover the dock and the song row above it. */
    fun fadeHeight(navStyle: Int, hasMedia: Boolean): Dp = when (navStyle) {
        4, 1 -> 130.dp
        else -> if (hasMedia) 210.dp else 140.dp
    }
}

/**
 * A soft dark fade at the foot of the pages, behind the dock. It stops list text from running right up to (and under) the dock,
 * so the dock sits on something instead of floating in the middle of the list. It takes no touches.
 */
@Composable
internal fun DockFade(height: Dp, modifier: Modifier = Modifier) {
    val top = if (DockStyle.glass) 0.62f else 0.5f
    Box(
        modifier
            .fillMaxWidth()
            .height(height)
            .background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = top))))
    )
}

/**
 * Gives a dock its body. Put it right after the size is set; draw the content after it.
 * [radius] is read while drawing (so animating it never recomposes), and is never more than half the height.
 * [glow] 0..1 = how lit the dock is (an event is open). [tint] = the color of the light (the cover's, or the accent).
 * [solid] = the body of the Solid material, for a dock that has its own colors (the Morph dock's violet); Glass ignores it.
 */
internal fun Modifier.dockBody(
    radius: () -> Dp,
    glow: () -> Float = { 0f },
    tint: () -> Color = { Palette.Accent },
    solid: Brush? = null
): Modifier {
    val glass = DockStyle.glass
    val strength = DockStyle.glowStrength
    return this
        // Outside the body: the wide shadow and the light under it.
        .drawBehind { drawDockOuter(radius().toPx(), glow(), tint(), strength, glass) }
        // The shape, the contact shadow (the system's) and the clip.
        .graphicsLayer {
            shape = RoundedCornerShape(minOf(radius().toPx(), size.height / 2f))
            clip = true
            val g = glow()
            shadowElevation = (10f + 8f * g).dp.toPx()
            ambientShadowColor = Color.Black.copy(alpha = 0.55f)
            spotShadowColor = lerp(Color.Black.copy(alpha = 0.7f), tint().copy(alpha = 0.55f), 0.45f * g * strength)
        }
        // The body itself.
        .drawBehind { drawDockBody(tint(), glow(), solid, glass) }
        // The lit edge, over the content.
        .drawWithContent {
            drawContent()
            drawDockEdge(radius().toPx(), tint(), glow(), glass)
        }
}

private fun DrawScope.drawDockOuter(radiusPx: Float, glow: Float, tint: Color, strength: Float, glass: Boolean) {
    val r = minOf(radiusPx, size.height / 2f)
    // Everything here is kept out of the body, so a see-through dock is not darkened from behind.
    val hole = Path().apply {
        addRoundRect(RoundRect(0f, 0f, size.width, size.height, CornerRadius(r)))
    }
    clipPath(hole, ClipOp.Difference) {
        // A wide, soft shadow: rounded outlines growing outward, each a little fainter.
        val steps = 7
        val grow = 3.dp.toPx()
        val drop = 9.dp.toPx()
        val a = if (glass) 0.05f else 0.07f
        for (i in 1..steps) {
            val g = grow * i
            drawRoundRect(
                color = Color.Black.copy(alpha = a * (1f - (i - 1) / steps.toFloat())),
                topLeft = Offset(-g, -g + drop),
                size = Size(size.width + 2f * g, size.height + 2f * g),
                cornerRadius = CornerRadius(r + g)
            )
        }
        // A little light under it, in the cover's color; brighter while an event is open.
        val light = strength * (0.16f + 0.34f * glow)
        if (light > 0.001f) {
            val c = Offset(size.width / 2f, size.height * 0.9f)
            val rad = size.width * 0.62f
            drawCircle(
                brush = Brush.radialGradient(colors = listOf(tint.copy(alpha = light), Color.Transparent), center = c, radius = rad),
                radius = rad,
                center = c
            )
        }
    }
}

private fun DrawScope.drawDockBody(tint: Color, glow: Float, solid: Brush?, glass: Boolean) {
    if (glass) {
        // See-through and frosted: a dark veil, a soft white wash from the top, a slanted highlight and a wash of the cover's color.
        drawRect(Color(0xFF0D0E15).copy(alpha = 0.5f))
        drawRect(Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.04f))))
        drawRect(
            Brush.linearGradient(
                0f to Color.White.copy(alpha = 0.2f),
                0.4f to Color.Transparent,
                start = Offset.Zero,
                end = Offset(size.width, size.height)
            )
        )
        drawRect(tint.copy(alpha = 0.1f + 0.12f * glow))
    } else {
        drawRect(solid ?: Brush.verticalGradient(listOf(Color(0xFF1C1C21), Color(0xFF0B0B0D))))
        // A faint wash of the cover's color from the top middle.
        drawRect(
            Brush.radialGradient(
                colors = listOf(tint.copy(alpha = 0.07f + 0.12f * glow), Color.Transparent),
                center = Offset(size.width * 0.5f, 0f),
                radius = size.width * 0.7f
            )
        )
    }
    // Light from above on the top part; the solid body also darkens a little toward the foot.
    drawRect(
        Brush.verticalGradient(
            colors = listOf(Color.White.copy(alpha = 0.09f), Color.Transparent),
            startY = 0f,
            endY = size.height * 0.45f
        )
    )
    if (!glass) {
        drawRect(
            Brush.verticalGradient(
                colors = listOf(Color.Transparent, Color.Black.copy(alpha = 0.28f)),
                startY = size.height * 0.6f,
                endY = size.height
            )
        )
    }
}

private fun DrawScope.drawDockEdge(radiusPx: Float, tint: Color, glow: Float, glass: Boolean) {
    val r = minOf(radiusPx, size.height / 2f)
    val w = 1.dp.toPx()
    val top = lerp(Color.White, tint, 0.35f * glow).copy(alpha = if (glass) 0.55f else 0.3f)
    val mid = Color.White.copy(alpha = if (glass) 0.16f else 0.09f)
    val foot = Color.White.copy(alpha = if (glass) 0.08f else 0.04f)
    drawRoundRect(
        brush = Brush.verticalGradient(listOf(top, mid, foot)),
        topLeft = Offset(w / 2f, w / 2f),
        size = Size(size.width - w, size.height - w),
        cornerRadius = CornerRadius((r - w / 2f).coerceAtLeast(0f)),
        style = Stroke(w)
    )
    if (!glass) {
        // A second, fainter line just inside gives the edge some thickness.
        val inset = 2.dp.toPx()
        drawRoundRect(
            brush = Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.06f), Color.Transparent)),
            topLeft = Offset(inset, inset),
            size = Size(size.width - 2f * inset, size.height - 2f * inset),
            cornerRadius = CornerRadius((r - inset).coerceAtLeast(0f)),
            style = Stroke(w)
        )
    }
}
