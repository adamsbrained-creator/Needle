package app.needle.music.ui

import android.content.Context
import androidx.annotation.OptIn
import androidx.media3.common.util.UnstableApi
import androidx.media3.database.StandaloneDatabaseProvider
import androidx.media3.datasource.cache.LeastRecentlyUsedCacheEvictor
import androidx.media3.datasource.cache.SimpleCache
import java.io.File

/** One disk cache for the animated cover videos, shared by every player (a cache folder may only be opened once). */
@OptIn(UnstableApi::class)
object AnimatedCoverCache {
    private const val MAX_BYTES = 300L * 1024 * 1024
    private var cache: SimpleCache? = null

    /** Opens the cache. Call it off the main thread ahead of time: the first opening reads the cache folder and can take a while. */
    fun warm(context: Context) { get(context) }

    @Synchronized
    fun get(context: Context): SimpleCache = cache ?: SimpleCache(
        File(context.applicationContext.cacheDir, "animated_covers"),
        LeastRecentlyUsedCacheEvictor(MAX_BYTES),
        StandaloneDatabaseProvider(context.applicationContext)
    ).also { cache = it }
}
