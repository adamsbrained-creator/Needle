package app.needle.music.data

import android.content.Context
import android.graphics.BitmapFactory
import android.util.LruCache
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.security.MessageDigest

/**
 * The little logo of a radio station, from its Thumbnail URL. The picture is kept in memory while the app runs and
 * in a folder of the app's cache, so a station's logo is downloaded once. A station without a picture (or a link
 * that does not work) shows a colored tile with its initials instead.
 */
object RadioArt {
    private val memory = LruCache<String, ImageBitmap>(48)
    private val failed = HashSet<String>()

    fun peek(url: String): ImageBitmap? = if (url.isBlank()) null else memory.get(url)

    suspend fun load(context: Context, url: String): ImageBitmap? = withContext(Dispatchers.IO) {
        if (url.isBlank() || !url.startsWith("http")) return@withContext null
        memory.get(url)?.let { return@withContext it }
        synchronized(failed) { if (url in failed) return@withContext null }
        val dir = File(context.cacheDir, "radio_logos").apply { mkdirs() }
        val file = File(dir, hash(url))
        var bytes: ByteArray? = if (file.exists()) runCatching { file.readBytes() }.getOrNull() else null
        if (bytes == null) {
            val reply = runCatching { httpGet(url) }.getOrNull()
            bytes = reply?.body
            if (bytes != null) runCatching { file.writeBytes(bytes) }
        }
        val bitmap = bytes?.let { runCatching { BitmapFactory.decodeByteArray(it, 0, it.size) }.getOrNull() }
        if (bitmap == null) {
            synchronized(failed) { failed += url }
            return@withContext null
        }
        val image = bitmap.asImageBitmap()
        memory.put(url, image)
        image
    }

    private fun hash(s: String): String =
        MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
