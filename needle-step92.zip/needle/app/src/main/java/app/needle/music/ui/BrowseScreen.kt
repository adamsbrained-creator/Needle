package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtistRow
import app.needle.music.data.HomeAlbum
import app.needle.music.data.HomeState
import app.needle.music.data.MostRange
import app.needle.music.data.PlayedSong
import app.needle.music.data.RadioStation
import app.needle.music.data.Song
import app.needle.music.data.StatsData
import app.needle.music.data.artistKey

/**
 * Browse: a front page made from your own music. A row of shortcuts, then covers you played lately, the artists you
 * play most, songs you keep coming back to, albums to rediscover and your radio stations. It is all worked out on the
 * phone from the library and the play history, so it works offline.
 */
@Composable
fun BrowseScreen(
    home: HomeState?,
    artistRows: List<ArtistRow>?,
    stats: Map<MostRange, StatsData>?,
    mostPlayed: Map<MostRange, List<PlayedSong>>?,
    stations: List<RadioStation>,
    playingStationId: String?,
    bottomPadding: Dp,
    onSearch: () -> Unit,
    onOpenAlbum: (HomeAlbum) -> Unit,
    onOpenArtist: (String) -> Unit,
    onOpenArtists: () -> Unit,
    onPlaySongs: (List<Song>, Int) -> Unit,
    onSongMenu: (Song) -> Unit,
    onStats: () -> Unit,
    onMostPlayed: () -> Unit,
    onSingles: () -> Unit,
    onRadio: () -> Unit,
    onForYou: () -> Unit,
    onPlayStation: (RadioStation) -> Unit,
    modifier: Modifier = Modifier
) {
    // The artists you play most this month first, then the ones with the most songs.
    val artists = remember(stats, artistRows) {
        val rows = artistRows.orEmpty()
        val byKey = rows.associateBy { artistKey(it.name) }
        val played = stats?.get(MostRange.MONTH)?.topArtists.orEmpty().mapNotNull { byKey[artistKey(it.name)] }
        (played + rows.sortedByDescending { it.songs }).distinctBy { it.key }.take(10)
    }
    val topSongs = remember(mostPlayed) {
        val month = mostPlayed?.get(MostRange.MONTH).orEmpty()
        (if (month.isNotEmpty()) month else mostPlayed?.get(MostRange.ALL).orEmpty()).take(4)
    }
    val topList = remember(topSongs) { topSongs.map { it.song } }

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 16.dp, top = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Browse", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp, modifier = Modifier.weight(1f))
                RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 40.dp, iconSize = 20.dp)
            }
        }
        item {
            Row(
                Modifier.horizontalScroll(rememberScrollState()).padding(horizontal = 16.dp, vertical = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                ShortcutPill("For you", NeedleIcon.SPARK, onForYou)
                ShortcutPill("Your stats", NeedleIcon.CHART, onStats)
                ShortcutPill("Radio", NeedleIcon.RADIO, onRadio)
                ShortcutPill("Most played", NeedleIcon.STAR, onMostPlayed)
                ShortcutPill("Singles", NeedleIcon.PLAY_NEXT, onSingles)
            }
        }

        if (home == null) return@LazyColumn

        if (home.yourAlbums.isNotEmpty()) {
            item { SectionHeader("Jump back in", "", null) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.yourAlbums.take(12), key = { it.id }) { a -> AlbumTile(a, onOpenAlbum) }
                }
            }
        }

        if (artists.isNotEmpty()) {
            item { SectionHeader("Your artists", "See all", onOpenArtists) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(artists, key = { it.key }) { a ->
                        Column(
                            Modifier.width(82.dp).clip(cornerShape(12.dp)).clickable { onOpenArtist(a.name) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            SongArtwork(a.cover, size = 78.dp, corner = 39.dp)
                            Text(
                                a.name, color = Palette.Text, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                                textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }

        if (topSongs.isNotEmpty()) {
            item { SectionHeader("You keep coming back to", "See all", onMostPlayed) }
            items(topSongs.size) { i ->
                val p = topSongs[i]
                Row(
                    Modifier.fillMaxWidth().tapOrHold({ onPlaySongs(topList, i) }, { onSongMenu(p.song) }).padding(horizontal = 18.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    SongArtwork(p.song, size = 48.dp, corner = 12.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(p.song.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(p.song.artist, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(if (p.plays == 1) "1 play" else "${p.plays} plays", color = Palette.Muted, fontSize = 12.5.sp)
                }
            }
        }

        if (home.rediscover.isNotEmpty()) {
            item { SectionHeader("Rediscover", "", null) }
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(home.rediscover.take(12), key = { it.id }) { a -> AlbumTile(a, onOpenAlbum) }
                }
            }
        }

        item { SectionHeader("Radio", if (stations.isEmpty()) "" else "See all", if (stations.isEmpty()) null else onRadio) }
        if (stations.isEmpty()) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(horizontal = 16.dp).glass(cornerShape(20.dp)).clickable(onClick = onRadio).padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NeedleIconView(NeedleIcon.RADIO, Palette.Accent, size = 24.dp)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Add your first radio station", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text("Type in a stream address or search a directory.", color = Palette.Muted, fontSize = 12.5.sp)
                    }
                    NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
                }
            }
        } else {
            item {
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                    items(stations.sortedByDescending { it.favorite }.take(12), key = { it.id }) { s ->
                        Column(
                            Modifier.width(78.dp).clip(cornerShape(12.dp)).clickable { onPlayStation(s) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            StationLogo(s, 72.dp, corner = 18.dp)
                            Text(
                                s.name, color = if (s.id == playingStationId) Palette.Accent else Palette.Text, fontSize = 12.5.sp, maxLines = 1,
                                overflow = TextOverflow.Ellipsis, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 6.dp)
                            )
                        }
                    }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun ShortcutPill(text: String, icon: NeedleIcon, onClick: () -> Unit) {
    Row(
        Modifier.clip(CircleShape).background(Palette.Card).clickable(onClick = onClick).height(40.dp).padding(start = 12.dp, end = 16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(icon, Palette.Accent, size = 20.dp)
        Spacer(Modifier.width(8.dp))
        Text(text, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.Medium, maxLines = 1)
    }
}

@Composable
private fun AlbumTile(album: HomeAlbum, onOpen: (HomeAlbum) -> Unit) {
    Column(Modifier.width(116.dp).clip(cornerShape(14.dp)).clickable { onOpen(album) }) {
        SongArtwork(album.cover, size = 116.dp, corner = 14.dp)
        Text(album.title, color = Palette.Text, fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
        Text(album.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}
