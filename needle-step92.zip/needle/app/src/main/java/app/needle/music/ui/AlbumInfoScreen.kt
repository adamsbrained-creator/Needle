package app.needle.music.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ExtraTags
import app.needle.music.data.InfoCandidate
import app.needle.music.data.InfoDetails
import app.needle.music.data.InfoException
import app.needle.music.data.InfoSource
import app.needle.music.data.OnlineInfo
import app.needle.music.data.Song
import app.needle.music.data.TagChanges
import app.needle.music.data.genresOf
import app.needle.music.data.isKnownArtist
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch

// The keys the ticked fields are kept under. Most are Needle's tag names; YEAR is the core Year box.
private const val K_YEAR = "YEAR"
private const val K_DATE = "RELEASETIME"
private const val K_LABEL = "PUBLISHER"
private const val K_CATNO = "CATALOGNUMBER"
private const val K_BARCODE = "BARCODE"
private const val K_MBID = "MUSICBRAINZ_RELEASEGROUPID"
private const val K_DESC = "DESCRIPTION"

/**
 * "Find info online": the person searches a service by hand, picks the right album from the answers, and chooses
 * which of the fields it found to keep (genres one by one, the description, label, dates). Every box starts
 * unticked, every text can be edited before it is kept, and nothing is saved here: [onApply] gets only the
 * ticked fields and the tag editor puts them into its boxes, where the person still has to press save.
 */
@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AlbumInfoScreen(
    songs: List<Song>,
    extras: ExtraTags,
    onClose: () -> Unit,
    onApply: (TagChanges) -> Unit,
    modifier: Modifier = Modifier
) {
    val first = songs.firstOrNull()
    val scope = rememberCoroutineScope()
    var source by remember { mutableStateOf(InfoSource.MUSICBRAINZ) }
    var artist by remember {
        mutableStateOf(
            first?.let { s -> extras[s.id]?.get("ALBUMARTIST")?.takeIf { it.isNotBlank() } ?: s.artist.takeIf { isKnownArtist(it) } }.orEmpty()
        )
    }
    var album by remember { mutableStateOf(first?.album?.takeIf { it.isNotBlank() && it != "Unknown album" }.orEmpty()) }

    var results by remember { mutableStateOf<List<InfoCandidate>?>(null) }
    var searching by remember { mutableStateOf(false) }
    var loadingKey by remember { mutableStateOf<String?>(null) }
    var error by remember { mutableStateOf<String?>(null) }

    var details by remember { mutableStateOf<InfoDetails?>(null) }
    var values by remember { mutableStateOf(mapOf<String, String>()) }
    var ticked by remember { mutableStateOf(setOf<String>()) }
    var chosenGenres by remember { mutableStateOf(listOf<String>()) }
    var replaceGenres by remember { mutableStateOf(false) }

    val currentGenres = remember(songs) { songs.flatMap { genresOf(it) }.distinctBy { it.lowercase() } }

    BackHandler { if (details != null) details = null else onClose() }

    fun search() {
        if (searching) return
        if (!source.isReady()) { error = source.keyHint(); return }
        searching = true; error = null; results = null
        val src = source
        scope.launch {
            try {
                results = OnlineInfo.search(src, artist, album)
            } catch (e: CancellationException) {
                throw e
            } catch (e: InfoException) {
                error = e.message
            } catch (e: Exception) {
                error = "Something went wrong. Try again."
            } finally {
                searching = false
            }
        }
    }

    fun pick(c: InfoCandidate) {
        if (loadingKey != null) return
        loadingKey = c.key; error = null
        scope.launch {
            try {
                val d = OnlineInfo.details(c)
                values = mapOf(
                    K_YEAR to d.year, K_DATE to d.releaseDate, K_LABEL to d.label, K_CATNO to d.catalogNumber,
                    K_BARCODE to d.barcode, K_MBID to d.musicBrainzGroupId, K_DESC to d.description
                )
                ticked = emptySet()
                chosenGenres = emptyList()
                details = d
            } catch (e: CancellationException) {
                throw e
            } catch (e: InfoException) {
                error = e.message
            } catch (e: Exception) {
                error = "Something went wrong. Try again."
            } finally {
                loadingKey = null
            }
        }
    }

    fun toggle(key: String) { ticked = if (key in ticked) ticked - key else ticked + key }
    fun edit(key: String, text: String) { values = values + (key to text); ticked = ticked + key }

    fun buildChanges(): TagChanges {
        if (details == null) return TagChanges()
        val picks = chosenGenres.map { it.trim() }.filter { it.isNotEmpty() }
        val genre = if (picks.isEmpty()) null else {
            val base = if (replaceGenres) emptyList() else currentGenres
            (base + picks).distinctBy { it.lowercase() }.joinToString("; ")
        }
        fun v(k: String) = values[k].orEmpty().trim()
        val year = if (K_YEAR in ticked) v(K_YEAR).filter(Char::isDigit).take(4).takeIf { it.length == 4 } else null
        val ex = LinkedHashMap<String, String>()
        for (k in listOf(K_DATE, K_LABEL, K_CATNO, K_BARCODE, K_MBID, K_DESC)) {
            if (k in ticked && v(k).isNotEmpty()) ex[k] = v(k)
        }
        return TagChanges(genre = genre, year = year, extras = ex)
    }

    val pending = buildChanges()
    val pendingCount = (if (pending.genre != null) 1 else 0) + (if (pending.year != null) 1 else 0) + pending.extras.size

    Column(modifier.safeDrawingPadding()) {
        // ---- header --------------------------------------------------------------------------
        Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(
                NeedleIcon.BACK, { if (details != null) details = null else onClose() },
                size = 40.dp, iconSize = 22.dp, scrim = true, tint = Color.White
            )
            Text(
                if (details == null) "Find info online" else "Pick what to keep",
                color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 24.sp,
                modifier = Modifier.padding(start = 12.dp).weight(1f)
            )
        }

        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(horizontal = 14.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            val d = details
            if (d == null) {
                // ---- stage 1: search -------------------------------------------------------------
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    InfoSource.values().forEach { s ->
                        PickPill(s.label, selected = s == source) {
                            if (s != source) { source = s; results = null; error = null }
                        }
                    }
                }
                if (!source.isReady()) {
                    InfoNote(source.keyHint().orEmpty())
                } else {
                    InfoNote("Search by hand, then pick the album that matches. Nothing is filled in until you tick it.")
                }
                InfoBox(album, { album = it }, "Album", ImeAction.Search) { search() }
                InfoBox(artist, { artist = it }, "Artist", ImeAction.Search) { search() }
                val canSearch = !searching && source.isReady() && (album.isNotBlank() || artist.isNotBlank())
                Box(
                    Modifier.fillMaxWidth().height(46.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = if (canSearch) 1f else 0.35f))
                        .clickable(enabled = canSearch) { search() },
                    contentAlignment = Alignment.Center
                ) {
                    Text(if (searching) "Searching…" else "Search ${source.label}", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                }
                error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp)) }

                results?.let { list ->
                    Text("${list.size} found. Tap the right one.", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(start = 4.dp, top = 4.dp))
                    list.forEach { c ->
                        Column(
                            Modifier.fillMaxWidth().glass(cornerShape(20.dp)).clickable { pick(c) }.padding(horizontal = 16.dp, vertical = 12.dp)
                        ) {
                            Text(c.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                            if (c.artist.isNotBlank()) Text(c.artist, color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            val line = if (loadingKey == c.key) "Loading…" else c.note
                            if (line.isNotBlank()) Text(line, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }
                }
                Spacer(Modifier.height(16.dp))
            } else {
                // ---- stage 2: choose what to keep ----------------------------------------------------
                Column(Modifier.fillMaxWidth().glass(cornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 12.dp)) {
                    Text(d.title, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    Text(
                        listOf(d.artist, d.source.label).filter { it.isNotBlank() }.joinToString(" · "),
                        color = Palette.Muted, fontSize = 13.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text("Wrong album? Press back to see the list again.", color = Palette.Muted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 4.dp))
                }
                error?.let { Text(it, color = Color(0xFFFF8A80), fontSize = 13.sp, modifier = Modifier.padding(horizontal = 4.dp)) }

                // genres and tags
                val genres = d.genres.distinctBy { it.lowercase() }
                val tags = d.tags.distinctBy { it.lowercase() }
                InfoSection("Genres and tags")
                if (genres.isEmpty() && tags.isEmpty()) {
                    InfoNote("${d.source.label} has no genres or tags for this album.")
                } else {
                    Column(Modifier.fillMaxWidth().glass(cornerShape(20.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text(
                            if (currentGenres.isEmpty()) "Genre now: none" else "Genre now: ${currentGenres.joinToString("; ")}",
                            color = Palette.Muted, fontSize = 12.sp
                        )
                        if (genres.isNotEmpty()) {
                            Text("Genres", color = Palette.Muted, fontSize = 12.sp)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                genres.forEach { g ->
                                    PickChip(g, g in chosenGenres) { chosenGenres = if (g in chosenGenres) chosenGenres - g else chosenGenres + g }
                                }
                            }
                        }
                        if (tags.isNotEmpty()) {
                            Text(if (d.source == InfoSource.DISCOGS) "Styles" else "Tags", color = Palette.Muted, fontSize = 12.sp)
                            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                tags.forEach { g ->
                                    PickChip(g, g in chosenGenres) { chosenGenres = if (g in chosenGenres) chosenGenres - g else chosenGenres + g }
                                }
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            PickPill("Add to current", selected = !replaceGenres) { replaceGenres = false }
                            PickPill("Replace current", selected = replaceGenres) { replaceGenres = true }
                        }
                        Text(
                            if (chosenGenres.isEmpty()) "Tap the ones you want. Needle keeps them in the Genre box, separated by ;"
                            else "${chosenGenres.size} chosen",
                            color = Palette.Muted, fontSize = 11.5.sp
                        )
                    }
                }

                // other facts
                val facts = listOf(
                    Triple(K_YEAR, "Year", d.year),
                    Triple(K_DATE, "Release date", d.releaseDate),
                    Triple(K_LABEL, "Label", d.label),
                    Triple(K_CATNO, "Catalog number", d.catalogNumber),
                    Triple(K_BARCODE, "Barcode", d.barcode),
                    Triple(K_MBID, "MusicBrainz release group ID", d.musicBrainzGroupId)
                ).filter { it.third.isNotBlank() }
                InfoSection("Details")
                if (facts.isEmpty()) {
                    InfoNote("No year, label or dates found.")
                } else {
                    facts.forEach { (key, label, _) ->
                        FactRow(label, values[key].orEmpty(), key in ticked, { toggle(key) }, { edit(key, it) }, number = key == K_YEAR)
                    }
                }

                // description
                InfoSection("Description")
                if (d.description.isBlank()) {
                    InfoNote("No description found.")
                } else {
                    FactRow(
                        label = if (d.descriptionFrom.isBlank()) "Description" else "Description · ${d.descriptionFrom}",
                        value = values[K_DESC].orEmpty(),
                        checked = K_DESC in ticked,
                        onCheck = { toggle(K_DESC) },
                        onValue = { edit(K_DESC, it) },
                        multiline = true
                    )
                    Row(
                        Modifier.padding(start = 4.dp).clip(CircleShape).clickable { values = values + (K_DESC to ""); ticked = ticked - K_DESC }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) { Text("Clear the text", color = Palette.Muted, fontSize = 12.sp) }
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        // ---- bottom bar (only when there is something to choose) ------------------------------------
        if (details != null) {
            Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp)) {
                val ok = pendingCount > 0
                Box(
                    Modifier.fillMaxWidth().height(48.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = if (ok) 1f else 0.35f))
                        .clickable(enabled = ok) { onApply(pending) },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        if (ok) "Use $pendingCount selected" else "Nothing selected yet",
                        color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold
                    )
                }
                Text(
                    "This only fills the boxes in the tag editor. Nothing is saved until you press the check mark there.",
                    color = Palette.Muted, fontSize = 11.5.sp, modifier = Modifier.padding(top = 8.dp, start = 4.dp)
                )
            }
        }
    }
}

// ---- small pieces --------------------------------------------------------------------------------

@Composable
private fun InfoSection(text: String) {
    Text(text, color = Palette.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(start = 4.dp, top = 6.dp))
}

@Composable
private fun InfoNote(text: String) {
    Text(text, color = Palette.Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp))
}

@Composable
private fun PickPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.height(36.dp).clip(CircleShape)
            .background(if (selected) Palette.Accent else Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(text, color = Color.White, fontSize = 13.sp, fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal)
    }
}

@Composable
private fun PickChip(text: String, selected: Boolean, onClick: () -> Unit) {
    Row(
        Modifier.clip(CircleShape)
            .background(if (selected) Palette.Accent else Color.White.copy(alpha = 0.12f))
            .border(1.dp, if (selected) Color.White.copy(alpha = 0.5f) else Color.Transparent, CircleShape)
            .clickable(onClick = onClick).padding(horizontal = 12.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        if (selected) NeedleIconView(NeedleIcon.CHECK, Color.White, size = 14.dp)
        Text(text, color = Color.White, fontSize = 13.sp)
    }
}

@Composable
private fun InfoBox(value: String, onValue: (String) -> Unit, hint: String, ime: ImeAction, onSearch: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().glass(cornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = value,
            onValueChange = onValue,
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Palette.Accent),
            keyboardOptions = KeyboardOptions(imeAction = ime),
            keyboardActions = KeyboardActions(onSearch = { onSearch() }),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (value.isEmpty()) Text(hint, color = Palette.Muted, fontSize = 15.sp)
                    inner()
                }
            }
        )
    }
}

/** A found value with a tick. The text can be changed first; changing it ticks it. */
@Composable
private fun FactRow(
    label: String,
    value: String,
    checked: Boolean,
    onCheck: () -> Unit,
    onValue: (String) -> Unit,
    multiline: Boolean = false,
    number: Boolean = false
) {
    Row(
        Modifier.fillMaxWidth().glass(cornerShape(20.dp)).padding(horizontal = 12.dp, vertical = 10.dp),
        verticalAlignment = Alignment.Top
    ) {
        Box(
            Modifier.padding(top = 2.dp).size(26.dp).clip(CircleShape)
                .background(if (checked) Palette.Accent else Color.Transparent)
                .border(1.5.dp, if (checked) Palette.Accent else Color.White.copy(alpha = 0.4f), CircleShape)
                .clickable(onClick = onCheck),
            contentAlignment = Alignment.Center
        ) {
            if (checked) NeedleIconView(NeedleIcon.CHECK, Color.White, size = 16.dp)
        }
        Column(Modifier.weight(1f).padding(start = 12.dp)) {
            Text(label, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            BasicTextField(
                value = value,
                onValueChange = onValue,
                singleLine = !multiline,
                textStyle = TextStyle(color = Palette.Text, fontSize = 14.sp, lineHeight = 20.sp),
                cursorBrush = SolidColor(Palette.Accent),
                keyboardOptions = if (number) KeyboardOptions(keyboardType = KeyboardType.Number) else KeyboardOptions.Default,
                modifier = Modifier.fillMaxWidth().padding(top = 2.dp).then(if (multiline) Modifier.heightIn(min = 90.dp) else Modifier)
            )
        }
    }
}
