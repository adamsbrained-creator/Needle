package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The line icons from the mockups, drawn with paths so no icon library is needed. */
enum class NeedleIcon { SEARCH, HOME, SONGS, ALBUMS, LIBRARY, SHUFFLE, PLAY, BACK, IMAGE, TAG, CHECK, CLOSE, PLUS,
    REFRESH, INFO, HELP, PHONE, TV, PC, SPEAKER, GEAR, EYE, EYE_OFF, CAST, MINUS,
    CHEVRON_DOWN, LOCK, UNLOCK, SHARE, PENCIL, FOLDER, PLAY_NEXT, ADD_QUEUE, CONTROLS, SPEED, LYRICS,
    ADD_PLAYLIST, EQUALIZER, TIMER, ARTIST, STAR, MORE, CHEVRON_RIGHT, PALETTE, BACKUP, HEART, HEART_FILLED, TRASH, STAR_FILLED,
    REPEAT, SORT, MIC, SMART_FLOW, MIX, GENRE, GLOBE,
    BROWSE, RADIO, SHELF, CHART, SPARK, BOOKMARK, HISTORY, CALENDAR, FLAME, LINK,
    PLAYLIST }

@Composable
fun NeedleIconView(icon: NeedleIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) {
        // Crisp line on top; closed shapes get a light frosted fill (no halo: it made small icons look muddy).
        drawNeedleIcon(icon, tint, 1f, GlassIcons.on)
    }
}

/** The glass icon look (frosted fill + halo). Flip [on] to false to get the plain line icons back. */
object GlassIcons {
    const val on = true
}

/** A frosted fill: the icon color, lighter at the top and fading toward the bottom. */
private fun glassBrush(color: Color, height: Float) =
    Brush.verticalGradient(listOf(color.copy(alpha = color.alpha * 0.16f), color.copy(alpha = color.alpha * 0.03f)), 0f, height)

/**
 * Coordinates below are the mockups' 24x24 icon grid. [wm] widens every line (the halo pass); [glass] adds the frosted
 * fill inside closed shapes.
 */
private fun DrawScope.drawNeedleIcon(icon: NeedleIcon, color: Color, wm: Float, glass: Boolean) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f * wm * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val fillBrush = glassBrush(color, size.height)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(color, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = 1.8f * wm * k, cap = StrokeCap.Round)

    when (icon) {
        NeedleIcon.SEARCH -> {
            drawCircle(color, radius = 7f * k, center = Offset(11f * k, 11f * k), style = stroke)
            line(20f, 20f, 16.5f, 16.5f)
        }
        NeedleIcon.SONGS -> {
            val p = Path().apply {
                moveTo(9f * k, 18f * k); lineTo(9f * k, 5f * k); lineTo(20f * k, 3f * k); lineTo(20f * k, 16f * k)
            }
            if (glass) {
                drawCircle(fillBrush, radius = 2.5f * k, center = Offset(6.5f * k, 18f * k))
                drawCircle(fillBrush, radius = 2.5f * k, center = Offset(17.5f * k, 16f * k))
            }
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(6.5f * k, 18f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(17.5f * k, 16f * k), style = stroke)
        }
        NeedleIcon.SHUFFLE -> {
            val top = Path().apply {
                moveTo(3f * k, 7f * k); lineTo(6f * k, 7f * k)
                cubicTo(11f * k, 7f * k, 12f * k, 17f * k, 17f * k, 17f * k)
                lineTo(21f * k, 17f * k)
            }
            val bottomLeft = Path().apply {
                moveTo(3f * k, 17f * k); lineTo(6f * k, 17f * k)
                cubicTo(7.6f * k, 17f * k, 8.7f * k, 16.1f * k, 9.6f * k, 14.8f * k)
            }
            val topRight = Path().apply {
                moveTo(14.4f * k, 9.2f * k)
                cubicTo(15.3f * k, 7.9f * k, 16.4f * k, 7f * k, 18f * k, 7f * k)
                lineTo(21f * k, 7f * k)
            }
            val headTop = Path().apply { moveTo(18f * k, 4f * k); lineTo(21f * k, 7f * k); lineTo(18f * k, 10f * k) }
            val headBottom = Path().apply { moveTo(18f * k, 14f * k); lineTo(21f * k, 17f * k); lineTo(18f * k, 20f * k) }
            for (p in listOf(top, bottomLeft, topRight, headTop, headBottom)) drawPath(p, color, style = stroke)
        }
        NeedleIcon.IMAGE -> {
            if (glass) drawRoundRect(fillBrush, topLeft = Offset(3f * k, 4f * k), size = Size(18f * k, 16f * k), cornerRadius = CornerRadius(3f * k))
            drawRoundRect(
                color, topLeft = Offset(3f * k, 4f * k), size = Size(18f * k, 16f * k),
                cornerRadius = CornerRadius(3f * k), style = stroke
            )
            drawCircle(color, radius = 1.6f * k, center = Offset(9f * k, 10f * k), style = stroke)
            val hills = Path().apply {
                moveTo(4f * k, 18f * k); lineTo(9f * k, 13f * k); lineTo(13f * k, 17f * k)
                lineTo(16f * k, 14f * k); lineTo(20f * k, 18f * k)
            }
            drawPath(hills, color, style = stroke)
        }
        NeedleIcon.TAG -> {
            val p = Path().apply {
                moveTo(3f * k, 12f * k); lineTo(3f * k, 4f * k); lineTo(11f * k, 4f * k)
                lineTo(21f * k, 14f * k); lineTo(13f * k, 22f * k)
                close()
            }
            if (glass) drawPath(p, fillBrush)
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 1f * k, center = Offset(7.5f * k, 8.5f * k), style = stroke)
        }
        NeedleIcon.CHECK -> {
            val p = Path().apply { moveTo(5f * k, 12.5f * k); lineTo(9.5f * k, 17f * k); lineTo(19f * k, 7.5f * k) }
            drawPath(p, color, style = Stroke(width = 2.4f * wm * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        NeedleIcon.PLUS -> {
            line(12f, 5f, 12f, 19f)
            line(5f, 12f, 19f, 12f)
        }
        NeedleIcon.CLOSE -> {
            line(6f, 6f, 18f, 18f)
            line(18f, 6f, 6f, 18f)
        }
        NeedleIcon.BACK -> {
            line(19f, 12f, 5f, 12f)
            val head = Path().apply { moveTo(11f * k, 6f * k); lineTo(5f * k, 12f * k); lineTo(11f * k, 18f * k) }
            drawPath(head, color, style = stroke)
        }
        NeedleIcon.PLAY -> {
            val p = Path().apply {
                moveTo(7.5f * k, 5f * k); lineTo(7.5f * k, 19f * k); lineTo(19f * k, 12f * k); close()
            }
            // Fill plus a round-joined outline: the triangle gets soft corners instead of sharp ones.
            drawPath(p, color)
            drawPath(p, color, style = Stroke(width = 2.4f * wm * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        NeedleIcon.LIBRARY -> {
            line(4f, 7f, 16f, 7f)
            line(4f, 12f, 16f, 12f)
            line(4f, 17f, 12f, 17f)
            line(19f, 14f, 19f, 20f)
            val arrow = Path().apply {
                moveTo(16f * k, 17f * k); lineTo(19f * k, 14f * k); lineTo(22f * k, 17f * k)
            }
            drawPath(arrow, color, style = stroke)
        }
        else -> drawSvgIcon(icon, color, wm, glass)
    }
}

private val svgPaths = HashMap<String, Path>()
private fun svgPath(d: String): Path = svgPaths.getOrPut(d) { PathParser().parsePathString(d).toPath() }

/** A gear with eight rounded teeth around a hole, on the 24x24 grid. */
private val gearPath: Path by lazy {
    Path().apply {
        val outer = 9.4f
        val inner = 7.0f
        for (i in 0 until 8) {
            val base = Math.toRadians(i * 45.0)
            fun pt(r: Float, deg: Double): Offset {
                val a = base + Math.toRadians(deg)
                return Offset(12f + r * Math.cos(a).toFloat(), 12f + r * Math.sin(a).toFloat())
            }
            val points = listOf(pt(inner, -15.0), pt(outer, -9.0), pt(outer, 9.0), pt(inner, 15.0))
            if (i == 0) moveTo(points[0].x, points[0].y) else lineTo(points[0].x, points[0].y)
            for (q in points.drop(1)) lineTo(q.x, q.y)
        }
        close()
    }
}

private const val EYE_PATH = "M2 12 s4 -7 10 -7 s10 7 10 7 s-4 7 -10 7 s-10 -7 -10 -7 z"

/** The casting icons, taken straight from the mockup's SVG shapes (24x24 grid). */
private fun DrawScope.drawSvgIcon(icon: NeedleIcon, color: Color, wm: Float, glass: Boolean) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f * wm, cap = StrokeCap.Round, join = StrokeJoin.Round)
    val fillBrush = glassBrush(color, 24f)
    scale(k, Offset.Zero) {
        fun p(d: String) = drawPath(svgPath(d), color, style = stroke)
        fun circle(cx: Float, cy: Float, r: Float) = drawCircle(color, r, Offset(cx, cy), style = stroke)
        fun dot(cx: Float, cy: Float, r: Float) = drawCircle(color, r, Offset(cx, cy))
        fun box(x: Float, y: Float, w: Float, h: Float, r: Float) =
            drawRoundRect(color, Offset(x, y), Size(w, h), CornerRadius(r, r), style = stroke)
        // Closed shapes with the frosted fill inside (only in the glass pass).
        fun pF(d: String) { if (glass) drawPath(svgPath(d), fillBrush); p(d) }
        fun circleF(cx: Float, cy: Float, r: Float) { if (glass) drawCircle(fillBrush, r, Offset(cx, cy)); circle(cx, cy, r) }
        fun boxF(x: Float, y: Float, w: Float, h: Float, r: Float) {
            if (glass) drawRoundRect(fillBrush, Offset(x, y), Size(w, h), CornerRadius(r, r))
            box(x, y, w, h, r)
        }
        /** A small solid shape (a play triangle, a needle): brighter than the frosted fill. */
        fun solid(d: String) { if (glass) drawPath(svgPath(d), color.copy(alpha = color.alpha * 0.55f)); p(d) }
        when (icon) {
            NeedleIcon.REFRESH -> p("M20 12 a8 8 0 1 1 -2.5 -5.8 M20 4 v5 h-5")
            NeedleIcon.INFO -> { circleF(12f, 12f, 9f); p("M12 11 v6 M12 7.5 v0.1") }
            NeedleIcon.HELP -> { circleF(12f, 12f, 9f); p("M9.5 9.5 a2.5 2.5 0 1 1 3.5 2.3 c-0.7 0.4 -1 0.9 -1 1.7 M12 17 v0.1") }
            NeedleIcon.PHONE -> { boxF(7f, 2.5f, 10f, 19f, 2.5f); p("M11 18.5 h2") }
            NeedleIcon.TV -> { boxF(3f, 4f, 18f, 12f, 2f); p("M8 20 h8 M12 16 v4") }
            NeedleIcon.PC -> { boxF(3f, 3f, 18f, 13f, 2f); p("M2 20 h20 M9 16 v4 M15 16 v4") }
            NeedleIcon.SPEAKER -> { boxF(6f, 2.5f, 12f, 19f, 3f); circle(12f, 14.5f, 3.5f); circle(12f, 7f, 0.6f) }
            NeedleIcon.GEAR -> {
                if (glass) drawPath(gearPath, fillBrush)
                drawPath(gearPath, color, style = stroke)
                circle(12f, 12f, 2.9f)
            }
            NeedleIcon.HOME -> { boxF(3.5f, 3.5f, 17f, 17f, 6f); p("M7.8 12 L12 8.2 L16.2 12 M9 11.2 V16 h6 V11.2") }
            // A record with one groove highlight, like the vinyl in the Needle name.
            NeedleIcon.ALBUMS -> {
                circleF(12f, 12f, 9f)
                circle(12f, 12f, 2.4f)
                p("M15 6.8 A6 6 0 0 1 17.9 10.96")
            }
            NeedleIcon.EYE -> { p(EYE_PATH); circle(12f, 12f, 3f) }
            NeedleIcon.EYE_OFF -> { p(EYE_PATH); p("M4 4 l16 16") }
            // Needle's cast ("Play on") icon: sound waves going out of both sides of a dot.
            NeedleIcon.CAST -> {
                dot(12f, 12f, 1.5f)
                p("M15.69 9.42 A4.5 4.5 0 0 1 15.69 14.58")
                p("M18.96 7.12 A8.5 8.5 0 0 1 18.96 16.88")
                p("M8.31 14.58 A4.5 4.5 0 0 1 8.31 9.42")
                p("M5.04 16.88 A8.5 8.5 0 0 1 5.04 7.12")
            }
            // Player controls: the five bars of the Needle app icon (centre bar tallest and brightest).
            NeedleIcon.CONTROLS -> {
                val bars = listOf(7.6f to 0.7f, 14.8f to 0.85f, 20f to 1f, 12f to 0.85f, 6f to 0.7f)
                bars.forEachIndexed { i, (h, a) ->
                    val x = 3.6f + i * 4.2f
                    // A round-capped line this long is a bar of height h.
                    drawLine(color.copy(alpha = color.alpha * a), Offset(x, 12f - h / 2f + 1.5f), Offset(x, 12f + h / 2f - 1.5f), 3f, StrokeCap.Round)
                }
            }
            // Speed & pitch: two sliders, as in the mockup.
            NeedleIcon.SPEED -> {
                p("M4 8h9M17 8h3M4 16h3M11 16h9")
                circle(15f, 8f, 2f)
                circle(9f, 16f, 2f)
            }
            NeedleIcon.LYRICS -> p("M4 6h16M4 11h10M4 16h16M4 21h8")
            NeedleIcon.ADD_PLAYLIST -> p("M4 7h11M4 12h11M4 17h6M18 14v6M15 17h6")
            NeedleIcon.HEART -> pF("M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z")
            NeedleIcon.HEART_FILLED -> {
                val heart = svgPath("M12 20s-7-4.4-7-10a4 4 0 0 1 7-2.6A4 4 0 0 1 19 10c0 5.6-7 10-7 10z")
                drawPath(heart, color)
                drawPath(heart, color, style = stroke)
            }
            NeedleIcon.TRASH -> p("M4 7h16M9 7V4h6v3M6 7l1 13h10l1-13")
            NeedleIcon.STAR_FILLED -> {
                val star = svgPath("m12 3 2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 17l-5.4 2.8 1.1-6.1L3.2 9.4l6.1-.8z")
                drawPath(star, color)
                drawPath(star, color, style = stroke)
            }
            NeedleIcon.STAR -> pF("m12 3 2.7 5.6 6.1.8-4.5 4.3 1.1 6.1L12 17l-5.4 2.8 1.1-6.1L3.2 9.4l6.1-.8z")
            NeedleIcon.MORE -> { dot(5f, 12f, 1.5f); dot(12f, 12f, 1.5f); dot(19f, 12f, 1.5f) }
            NeedleIcon.CHEVRON_RIGHT -> p("m9 5 7 7-7 7")
            NeedleIcon.EQUALIZER -> p("M6 6v12M10 9v6M14 4v16M18 8v8")
            NeedleIcon.TIMER -> {
                circleF(12f, 13f, 8f)
                p("M12 9v4l2.5 1.5M9 2h6")
            }
            NeedleIcon.ARTIST -> {
                circle(9f, 8f, 3.5f)
                p("M3 20c0-4 3-6 6-6s6 2 6 6M17 5v7M17 5l3 1")
            }
            NeedleIcon.MINUS -> p("M5 12 h14")
            NeedleIcon.CHEVRON_DOWN -> p("M6 9 l6 6 6 -6")
            NeedleIcon.LOCK -> { boxF(5f, 11f, 14f, 10f, 2f); p("M8 11 V8 a4 4 0 0 1 8 0 v3") }
            NeedleIcon.UNLOCK -> { boxF(5f, 11f, 14f, 10f, 2f); p("M8 11 V8 a4 4 0 0 1 7.5 -1.5") }
            NeedleIcon.PLAY_NEXT -> p("M4 7 h10 M4 12 h10 M4 17 h6 M16 13 l5 3.5 -5 3.5 z")
            NeedleIcon.ADD_QUEUE -> p("M4 7 h12 M4 12 h12 M4 17 h7 M18 14 v6 M15 17 h6")
            NeedleIcon.PALETTE -> { circleF(12f, 12f, 9f); circle(8f, 11f, 1f); circle(11f, 7.5f, 1f); circle(15.5f, 8.5f, 1f); circle(16f, 13.5f, 1f) }
            NeedleIcon.BACKUP -> p("M12 15 V4 M8 8 l4 -4 4 4 M4 15 v3 a2 2 0 0 0 2 2 h12 a2 2 0 0 0 2 -2 v-3")
            NeedleIcon.PENCIL -> pF("M4 20 h4 L19 9 l-4 -4 L4 16 z")
            NeedleIcon.FOLDER -> pF("M3 6 a2 2 0 0 1 2 -2 h4 l2 2 h8 a2 2 0 0 1 2 2 v10 a2 2 0 0 1 -2 2 H5 a2 2 0 0 1 -2 -2 z")
            NeedleIcon.REPEAT -> p("M17 3 l3 3 -3 3 M4 11 V9 a3 3 0 0 1 3 -3 h13 M7 21 l-3 -3 3 -3 M20 13 v2 a3 3 0 0 1 -3 3 H4")
            NeedleIcon.SORT -> p("M8 4 v16 M4 8 l4 -4 4 4 M16 20 V4 M12 16 l4 4 4 -4")
            NeedleIcon.MIC -> { boxF(9f, 3f, 6f, 12f, 3f); p("M5 11 a7 7 0 0 0 14 0 M12 18 v3") }
            // Smart flow: a loop with a play triangle. Instant mix: a glass and a note. Genre: stacked tags. Web: a globe.
            NeedleIcon.SMART_FLOW -> { p("M20 12 a8 8 0 1 1 -2.5 -5.8 M20 4 v5 h-5"); p("M10 9 l5 3 -5 3 z") }
            NeedleIcon.MIX -> { p("M5 4 h8 l-4 5.5 z M9 9.5 v5 M6 18 h6"); p("M17 17 v-8 l3 1"); circle(15.5f, 17f, 1.5f) }
            NeedleIcon.GENRE -> { boxF(5f, 7f, 14f, 13f, 2.5f); p("M8 4 h8") }
            NeedleIcon.GLOBE -> { circleF(12f, 12f, 9f); p("M3 12 h18 M12 3 c-3 3 -3 15 0 18 M12 3 c3 3 3 15 0 18") }
            // Browse: a compass. Radio: a set with an aerial. Shelf (the Library button): books on a shelf.
            NeedleIcon.BROWSE -> { circleF(12f, 12f, 9f); solid("M16 8 l-2.3 5.7 -5.7 2.3 2.3 -5.7 z"); dot(12f, 12f, 0.9f) }
            NeedleIcon.RADIO -> { boxF(3f, 8f, 18f, 12f, 3f); p("M8 8 L17 3.5"); circle(8.5f, 14f, 2f); p("M14 13 h4 M14 16 h4") }
            NeedleIcon.SHELF -> { boxF(3.5f, 3.5f, 17f, 17f, 6f); circleF(12f, 12f, 4.3f); dot(12f, 12f, 0.9f) }
            // Playlists: a rounded square with a note.
            NeedleIcon.PLAYLIST -> {
                boxF(3.5f, 3.5f, 17f, 17f, 6f)
                p("M10.5 15 V8.4 l5.5 -1.2 V13.6")
                circleF(8.9f, 15.2f, 1.7f)
                circleF(14.4f, 13.8f, 1.7f)
            }
            NeedleIcon.CHART -> p("M5 20 v-6 M12 20 V5 M19 20 V10")
            NeedleIcon.SPARK -> { pF("M11 3 l1.9 5.6 5.6 1.9 -5.6 1.9 L11 18 l-1.9 -5.6 -5.6 -1.9 5.6 -1.9 z"); p("M19 15 v5 M16.5 17.5 h5") }
            NeedleIcon.BOOKMARK -> pF("M6 4 h12 v17 l-6 -4 -6 4 z")
            NeedleIcon.HISTORY -> p("M3 12 a9 9 0 1 0 3 -6.7 L3 8 M3 3 v5 h5 M12 8 v4 l3 2")
            NeedleIcon.CALENDAR -> { boxF(4f, 5f, 16f, 15f, 2.5f); p("M4 10 h16 M9 3 v4 M15 3 v4") }
            NeedleIcon.FLAME -> pF("M12 3 c1 4 5 5 5 10 a5 5 0 0 1 -10 0 c0 -2 1 -3 2 -4 0 2 1 3 2 3 0 -3 -1 -5 1 -9 z")
            NeedleIcon.LINK -> p("M10 14 a4 4 0 0 0 5.7 0 l3 -3 a4 4 0 0 0 -5.7 -5.7 l-1 1 M14 10 a4 4 0 0 0 -5.7 0 l-3 3 a4 4 0 0 0 5.7 5.7 l1 -1")
            NeedleIcon.SHARE -> p("M12 3 v12 M7 8 l5 -5 5 5 M5 14 v5 a2 2 0 0 0 2 2 h10 a2 2 0 0 0 2 -2 v-5")
            else -> Unit
        }
    }
}
