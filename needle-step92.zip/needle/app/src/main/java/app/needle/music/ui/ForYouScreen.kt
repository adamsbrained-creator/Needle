package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Switch
import androidx.compose.material3.TextButton
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import android.content.ActivityNotFoundException
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import app.needle.music.data.artistKey
import app.needle.music.data.enc
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeAlbum
import app.needle.music.data.Recommendations
import app.needle.music.data.Suggestion
import app.needle.music.data.WishItem
import app.needle.music.data.sameish
import java.text.DateFormat
import java.util.Date

/**
 * For you: artists related to the ones you play most, with their newest album, and a wishlist. Off until the person
 * turns it on; what is sent and when is written on the page.
 */
@Composable
fun ForYouScreen(
    suggestions: List<Suggestion>,
    wishlist: List<WishItem>,
    enabled: Boolean,
    wifiOnly: Boolean,
    loading: Boolean,
    failed: Boolean,
    updatedAt: Long,
    /** Top artists from ListenBrainz / Last.fm, the saved profile, and the last status line. */
    external: List<String>,
    extSource: String,
    extUser: String,
    extKey: String,
    extStatus: String,
    ownArtistKeys: Set<String>,
    onSaveExternal: (source: String, user: String, key: String) -> Unit,
    libraryAlbums: List<HomeAlbum>,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onEnable: (Boolean) -> Unit,
    onWifiOnly: (Boolean) -> Unit,
    onRefresh: () -> Unit,
    onToggleWish: (Suggestion) -> Unit,
    onRemoveWish: (WishItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val inLibrary: (String, String) -> Boolean = { artist, album ->
        album.isNotBlank() && libraryAlbums.any { sameish(it.title, album) && sameish(it.artist, artist) }
    }
    var showSetup by remember { mutableStateOf(false) }
    if (showSetup) {
        ExternalDialog(extSource, extUser, extKey, onDismiss = { showSetup = false }, onSave = { a, b, c ->
            showSetup = false
            onSaveExternal(a, b, c)
        })
    }
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                ListBackButton(onBack)
                Spacer(Modifier.width(12.dp))
                Text("For you", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp, modifier = Modifier.weight(1f))
                if (enabled) RoundIconButton(NeedleIcon.REFRESH, onRefresh, size = 40.dp, iconSize = 20.dp)
            }
        }
        if (!enabled) {
            item {
                Column(Modifier.fillMaxWidth().padding(top = 12.dp).glass(cornerShape(22.dp)).padding(18.dp)) {
                    Text("New music, based on yours", color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "Needle stays an offline player. If you turn this on, it picks a few of the artists you play most and asks " +
                            "Deezer's free public service which artists are related to them, and what their newest album is.",
                        color = Palette.Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                    Text(
                        "Only artist names are sent: no songs, no files, no account. Answers are kept on the phone and refreshed once a week. " +
                            "You can limit it to Wi-Fi and turn it off any time.",
                        color = Palette.Muted, fontSize = 14.sp, modifier = Modifier.padding(top = 8.dp)
                    )
                    Box(
                        Modifier.padding(top = 16.dp).clip(CircleShape).background(Palette.Accent).clickable { onEnable(true) }
                            .padding(horizontal = 22.dp, vertical = 11.dp)
                    ) { Text("Turn on", color = Color(0xFF15101A), fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp) }
                }
            }
        } else {
            item {
                val status = when {
                    loading -> "Looking for new music..."
                    failed -> "Could not reach the service. Try again later."
                    suggestions.isEmpty() -> "Nothing yet. It needs Wi-Fi (or turn off Wi-Fi only below) and some played artists."
                    updatedAt > 0 -> "Updated " + DateFormat.getDateInstance(DateFormat.MEDIUM).format(Date(updatedAt))
                    else -> ""
                }
                Text(status, color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 4.dp))
            }
            item {
                Row(
                    Modifier.fillMaxWidth().padding(top = 6.dp).glass(cornerShape(20.dp)).clickable { showSetup = true }.padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Listening elsewhere", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
                        Text(
                            if (extUser.isEmpty()) "Add your ListenBrainz or Last.fm profile (it can hold what you play on Spotify or YouTube Music)"
                            else (if (extSource == "lb") "ListenBrainz: " else "Last.fm: ") + extUser + (if (extStatus.isNotEmpty()) " · $extStatus" else ""),
                            color = Palette.Muted, fontSize = 12.5.sp
                        )
                    }
                    NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
                }
            }
            val missing = external.filter { artistKey(it) !in ownArtistKeys }.take(8)
            if (missing.isNotEmpty()) {
                item { Header("From your history, not in your library") }
                items(missing, key = { "ext|" + it }) { name ->
                    var menu by remember { mutableStateOf(false) }
                    Box {
                        Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            RadioLogo(name, "", 44.dp, corner = 22.dp)
                            Spacer(Modifier.width(12.dp))
                            Text(name, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                            Text("Open in…", color = Palette.Muted, fontSize = 12.5.sp)
                        }
                        OpenInMenu(menu, { menu = false }, name)
                    }
                }
            }
            if (suggestions.isNotEmpty()) {
                item { Header("Artists you may like") }
                items(suggestions, key = { it.artist }) { s ->
                    val wished = Recommendations.isWished(s.artist, s.albumTitle)
                    var menu by remember { mutableStateOf(false) }
                    Box {
                    Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioLogo(s.artist, s.pictureUrl, 58.dp, corner = 29.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(s.artist, color = Palette.Text, fontSize = 15.5.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(
                                "Because you play " + s.because.take(2).joinToString(" and "),
                                color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis
                            )
                            if (s.albumTitle.isNotBlank()) {
                                val have = inLibrary(s.artist, s.albumTitle)
                                Text(
                                    (if (have) "In library: " else "Latest: ") + s.albumTitle + (if (s.year.isNotBlank()) " (${s.year})" else ""),
                                    color = if (have) Palette.Accent else Palette.Text.copy(alpha = 0.8f), fontSize = 12.5.sp,
                                    maxLines = 1, overflow = TextOverflow.Ellipsis
                                )
                            }
                        }
                        if (s.albumTitle.isNotBlank()) {
                            RoundIconButton(NeedleIcon.BOOKMARK, { onToggleWish(s) }, size = 38.dp, iconSize = 19.dp, active = wished)
                        }
                    }
                    OpenInMenu(menu, { menu = false }, s.artist + (if (s.albumTitle.isNotBlank()) " " + s.albumTitle else ""))
                    }
                }
            }
            if (wishlist.isNotEmpty()) {
                item { Header("Wishlist") }
                items(wishlist, key = { it.artist + "|" + it.album }) { w ->
                    val have = inLibrary(w.artist, w.album)
                    var menu by remember { mutableStateOf(false) }
                    Box {
                    Row(Modifier.fillMaxWidth().clickable { menu = true }.padding(vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioLogo(w.album, w.cover, 52.dp, corner = 12.dp)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text(w.album, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(w.artist, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                        if (have) Text("In library", color = Palette.Accent, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(end = 8.dp))
                        RoundIconButton(NeedleIcon.CLOSE, { onRemoveWish(w) }, size = 34.dp, iconSize = 16.dp)
                    }
                    OpenInMenu(menu, { menu = false }, w.artist + " " + w.album)
                    }
                }
            }
            item { Header("Settings") }
            item {
                Column(Modifier.fillMaxWidth().glass(cornerShape(22.dp))) {
                    SwitchRow("Wi-Fi only", "Never ask on mobile data", wifiOnly, onWifiOnly)
                    SwitchRow("Recommendations", "Turn off to stop asking altogether", true) { onEnable(it) }
                }
            }
        }
        item { Spacer(Modifier.height(8.dp)) }
    }
}

@Composable
private fun Header(text: String) {
    Text(text, color = Palette.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 6.dp))
}

@Composable
private fun SwitchRow(title: String, note: String, on: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.Text, fontSize = 15.5.sp, fontWeight = FontWeight.Medium)
            Text(note, color = Palette.Muted, fontSize = 12.5.sp)
        }
        Switch(checked = on, onCheckedChange = onChange)
    }
}

/** Opens a search for [query] in the streaming app the person picks. The phone hands the link to the app if it is installed. */
@Composable
private fun OpenInMenu(expanded: Boolean, onDismiss: () -> Unit, query: String) {
    val context = LocalContext.current
    fun open(url: String) {
        onDismiss()
        try {
            context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(context, "No app or browser could open it", Toast.LENGTH_SHORT).show()
        }
    }
    val q = enc(query.trim())
    DropdownMenu(expanded = expanded, onDismissRequest = onDismiss) {
        DropdownMenuItem(text = { Text("Open in Spotify") }, onClick = { open("https://open.spotify.com/search/$q") })
        DropdownMenuItem(text = { Text("Open in YouTube Music") }, onClick = { open("https://music.youtube.com/search?q=$q") })
        DropdownMenuItem(text = { Text("Open in Deezer") }, onClick = { open("https://www.deezer.com/search/$q") })
    }
}

/** Where the listening history lives: ListenBrainz (just the user name) or Last.fm (user name and the person's own API key). */
@Composable
private fun ExternalDialog(source: String, user: String, key: String, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var src by remember { mutableStateOf(if (source.isEmpty()) "lb" else source) }
    var name by remember { mutableStateOf(user) }
    var apiKey by remember { mutableStateOf(key) }
    AlertDialog(
        shape = cornerShape(28.dp),
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Listening elsewhere") },
        text = {
            Column {
                Text(
                    "Needle asks for your most played artists (public profile) and uses them as starting points. Only the user name" +
                        (if (src == "lfm") " and key are" else " is") + " sent.",
                    color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(bottom = 10.dp)
                )
                Row(Modifier.padding(bottom = 10.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RadioChip("ListenBrainz", src == "lb") { src = "lb" }
                    RadioChip("Last.fm", src == "lfm") { src = "lfm" }
                }
                FormField("User name", name, { name = it })
                if (src == "lfm") FormField("Last.fm API key (free, from last.fm/api)", apiKey, { apiKey = it })
            }
        },
        confirmButton = { TextButton(onClick = { onSave(src, name, apiKey) }) { Text(if (name.isBlank()) "Remove" else "Save", color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}
