package app.needle.music.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.InfiniteTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.StartOffsetType
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.withFrameNanos
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.PointerEventPass
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.NeedleSettings
import app.needle.music.data.Song
import app.needle.music.playback.PlayerViewModel
import app.needle.music.playback.SleepTimer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext

/*
 * Island dock (Settings > Customization > Navigation > "Island dock").
 *
 * At rest it is one small capsule: the four places as round icons and the cover with a ring that fills as the song plays
 * (tap = Now playing, press and hold = play or pause, swipe sideways = next / previous). It takes almost no screen.
 * When something happens it opens upward for a few seconds, says what, and settles back:
 *   Track   a new song starts: what it is, with a Next button (swipe the card sideways to skip).
 *   Queue   "Added to queue" / "Plays next", with Undo and a line that counts down.
 *   Timer   the sleep timer started or was extended: the time left, with +5 min.
 *   Cast    casting started: the device, with Switch (opens Play on).
 * Swipe the open capsule down to put it away early: it follows your finger and springs back if you let go early.
 * It waits while a finger is on it, so Undo cannot vanish under your thumb. An event that matters more (Queue, then Cast, Timer,
 * Track) is never wiped by a lesser one: the lesser one waits its turn.
 * Selecting songs and Search keep the pages' own bars and fields.
 * Navigation style 4 (see effectiveNavStyle / usesIslandDock in Appearance.kt); NeedleDock draws it.
 * The material (Solid / Glass), the feel (springs) and the glow come from DockStyle.
 */

/** One thing the Island has to tell. Track, Timer and Cast read their live values while shown; Queue carries what it needs for Undo. */
sealed class DockEvent(val id: Long, val lifeMs: Long, val priority: Int) {
    class Track(id: Long) : DockEvent(id, 3300L, 0)
    class Queued(id: Long, val songs: List<Song>, val next: Boolean, val onUndo: () -> Unit) : DockEvent(id, 3000L, 3)
    /** [demo] = the Settings preview: shows a made-up countdown instead of the real timer. */
    class Timer(id: Long, val demo: Boolean = false) : DockEvent(id, 3400L, 1)
    class Cast(id: Long, val device: String) : DockEvent(id, 3400L, 2)
}

/** Where events are posted. A newer event replaces the one being shown, unless the one being shown matters more: then it waits. */
object DockEvents {
    val current = mutableStateOf<DockEvent?>(null)

    /** The event waiting for a more important one to finish. */
    val pending = mutableStateOf<DockEvent?>(null)

    /** True while a finger is on the open capsule: its time stands still. */
    val held = mutableStateOf(false)

    /** How much of its time the shown event has left, 1 -> 0 (the Queue card's line). Read while drawing. */
    val lifeLeft = mutableFloatStateOf(1f)

    private var counter = 0L

    private fun newId(): Long = ++counter

    private fun post(e: DockEvent) {
        val cur = current.value
        if (cur != null && e.priority < cur.priority) {
            pending.value = e
        } else {
            current.value = e
            val waiting = pending.value
            if (waiting != null && waiting.priority <= e.priority) pending.value = null
        }
    }

    fun track() = post(DockEvent.Track(newId()))
    fun timer() = post(DockEvent.Timer(newId()))
    fun cast(device: String) = post(DockEvent.Cast(newId(), device))
    fun queued(songs: List<Song>, next: Boolean, onUndo: () -> Unit) = post(DockEvent.Queued(newId(), songs, next, onUndo))

    /** The waiting event takes its turn. */
    fun promote() {
        val p = pending.value ?: return
        pending.value = null
        current.value = p
    }

    fun dismiss() { current.value = null }

    /** For the Settings page: 0 Track, 1 Queue, 2 Timer, 3 Cast, with made-up content. */
    fun preview(kind: Int) {
        when (kind) {
            0 -> track()
            1 -> queued(emptyList(), true) {}
            2 -> post(DockEvent.Timer(newId(), demo = true))
            else -> cast("Living room TV")
        }
    }
}

/**
 * Adds [songs] to the queue (or right after the current song) and tells the person: the Island dock answers with its Queue card
 * and an Undo, every other navigation with the toast [toast].
 */
internal fun announceQueue(context: Context, player: PlayerViewModel, songs: List<Song>, next: Boolean, toast: String) {
    if (songs.isEmpty()) return
    if (next) player.playNext(songs) else player.addToQueue(songs)
    if (usesIslandDock()) {
        DockEvents.queued(songs, next) { player.undoAdd(songs, next) }
    } else {
        Toast.makeText(context, toast, Toast.LENGTH_SHORT).show()
    }
}

private val IslandInk = Color(0xFF111111)
private val IslandDim = Color(0xFFA9A9AE)
private val IslandSub = Color(0xFFA9A9B4)

private val TabSize = 48.dp
private val RestHeight = 62.dp
private val CardHeight = 62.dp

private fun mix(a: Dp, b: Dp, f: Float): Dp = a + (b - a) * f

/** Sets the size from two functions that are read while measuring, so the springs never recompose the dock. */
private fun Modifier.dockSize(width: () -> Dp, height: () -> Dp): Modifier = this.layout { measurable, _ ->
    val w = width().roundToPx().coerceAtLeast(0)
    val h = height().roundToPx().coerceAtLeast(0)
    val placeable = measurable.measure(Constraints.fixed(w, h))
    layout(w, h) { placeable.place(0, 0) }
}

/** Fades and rises 10 dp into place as the capsule opens: [start] (0..1) delays it, so the parts of a card arrive one after another. */
private fun Modifier.rise(reveal: () -> Float, start: Float): Modifier = this.graphicsLayer {
    val p = ((reveal() - start) / (1f - start)).coerceIn(0f, 1f)
    alpha = p
    translationY = (1f - p) * 10.dp.toPx()
}

@Composable
internal fun IslandDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    onOpenCast: () -> Unit,
    modifier: Modifier = Modifier,
    castName: String? = null
) {
    val reduce = NeedleSettings.reduceMotion.value
    val event = DockEvents.current.value
    val expanded = event != null
    val hasMedia = player.hasMedia
    val haptic = LocalHapticFeedback.current
    val density = LocalDensity.current

    // The card fades out after the event is gone: keep what it showed for those few frames.
    val lastEvent = remember { arrayOfNulls<DockEvent>(1) }
    if (event != null) lastEvent[0] = event
    val shown = event ?: lastEvent[0]

    // ---- what makes the Island speak -----------------------------------------------------------------------------

    // A new song. Not when the app opens, and not when a saved queue is just restored (paused).
    val mediaId = player.currentMediaId
    val trackSeen = remember { arrayOfNulls<String>(1) }
    val trackFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(mediaId) {
        val before = trackSeen[0]
        trackSeen[0] = mediaId
        if (trackFirst[0]) {
            trackFirst[0] = false
        } else if (mediaId != null && mediaId != before && (before != null || player.isPlaying)) {
            DockEvents.track()
        }
    }

    // Casting started.
    val castFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(castName) {
        if (castFirst[0]) castFirst[0] = false
        else if (castName != null) DockEvents.cast(castName)
    }

    // The sleep timer started or was extended, and again when a minute is left.
    val timerMode = SleepTimer.mode.value
    val timerTotal = SleepTimer.totalMs.longValue
    val timerFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(timerMode, timerTotal) {
        if (timerFirst[0]) timerFirst[0] = false
        else if (timerMode != SleepTimer.Mode.OFF) DockEvents.timer()
    }
    val lastMinute by remember {
        derivedStateOf {
            SleepTimer.mode.value == SleepTimer.Mode.TIME && !SleepTimer.finishing.value &&
                SleepTimer.remainingMs.longValue in 1L..60_000L
        }
    }
    LaunchedEffect(lastMinute) { if (lastMinute) DockEvents.timer() }

    // Leaving the screen (another navigation style, a page that hides the dock) drops what it was about to say.
    DisposableEffect(Unit) {
        onDispose {
            DockEvents.pending.value = null
            DockEvents.held.value = false
            DockEvents.dismiss()
        }
    }

    // It settles back by itself, after its time. Time stands still while a finger is on it.
    LaunchedEffect(event?.id) {
        val e = event ?: return@LaunchedEffect
        if (e is DockEvent.Queued || e is DockEvent.Cast) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
        DockEvents.lifeLeft.floatValue = 1f
        var left = e.lifeMs.toFloat()
        var last = withFrameNanos { it }
        while (left > 0f) {
            val now = withFrameNanos { it }
            val dt = (now - last) / 1_000_000f
            last = now
            if (!DockEvents.held.value) left -= dt
            DockEvents.lifeLeft.floatValue = (left / e.lifeMs).coerceIn(0f, 1f)
        }
        if (DockEvents.current.value?.id == e.id) DockEvents.dismiss()
    }

    // An event that had to wait takes its turn a moment after the one before it has gone.
    val waiting = DockEvents.pending.value
    LaunchedEffect(event == null, waiting?.id) {
        if (event == null && waiting != null) {
            delay(240)
            if (DockEvents.current.value == null) DockEvents.promote()
        }
    }

    // The light under the capsule is the cover's main color.
    val art = player.artwork
    val coverColor by produceState<Color?>(null, art) {
        value = if (art == null) null else withContext(Dispatchers.Default) { extractGlow(art, Palette.Bg)?.a }
    }
    val light = animateColorAsState(coverColor ?: Palette.Accent, tween(700), label = "islandLight")

    // ---- motion: one progress for width, corners, light and content; the height lags a little behind ------------------

    val openP = animateFloatAsState(if (expanded) 1f else 0f, DockStyle.spec(reduce), label = "islandOpen")
    val openH = animateFloatAsState(if (expanded) 1f else 0f, DockStyle.spec(reduce, lag = true), label = "islandOpenH")
    val slot = Destination.dock.indexOf(selected.dockSlot).coerceAtLeast(0)
    val indicator = animateFloatAsState(
        slot.toFloat(),
        if (reduce) tween<Float>(120) else spring<Float>(dampingRatio = 0.66f, stiffness = 420f),
        label = "islandSlot"
    )
    val drag = remember { mutableFloatStateOf(0f) }
    val dismissAfter = with(density) { 36.dp.toPx() }
    val dragState = rememberDraggableState { delta ->
        drag.floatValue = drag.floatValue + delta
    }
    val accent = Palette.Accent

    // ---- shape ---------------------------------------------------------------------------------------------------

    BoxWithConstraints(modifier.fillMaxWidth()) {
        val fontScale = density.fontScale.coerceIn(1f, 1.4f)
        val cardH = CardHeight * fontScale
        val restContent = 12.dp + TabSize * 4 + (if (hasMedia) 1.dp + TabSize else 0.dp)
        val restW = minOf(maxWidth, restContent + (if (hasMedia) 30.dp else 18.dp))
        val wideW = maxOf(minOf(maxWidth, 368.dp), restW)
        val openRadius = DockStyle.tallRadius()
        val reveal = { ((openP.value - 0.3f) / 0.7f).coerceIn(0f, 1f) }

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .dockSize(
                    { mix(restW, wideW, openP.value) },
                    { mix(RestHeight, RestHeight + cardH, openH.value) }
                )
                // Swipe down: it follows the finger (a little resistance up, none down).
                .graphicsLayer {
                    val v = drag.floatValue
                    translationY = if (v > 0f) v * 0.9f else v * 0.2f
                }
                .dockBody(
                    radius = { mix(RestHeight / 2, openRadius, openP.value.coerceIn(0f, 1f)) },
                    glow = { openP.value.coerceIn(0f, 1f) },
                    tint = { light.value }
                )
                .draggable(
                    state = dragState,
                    orientation = Orientation.Vertical,
                    enabled = expanded,
                    onDragStopped = { velocity ->
                        if (drag.floatValue > dismissAfter || velocity > 900f) DockEvents.dismiss()
                        animate(drag.floatValue, 0f, velocity, spring(dampingRatio = 0.8f, stiffness = 380f)) { v, _ -> drag.floatValue = v }
                    }
                )
                // Watches for a finger on the capsule without taking the touch.
                .pointerInput(Unit) {
                    awaitPointerEventScope {
                        while (true) {
                            val change = awaitPointerEvent(PointerEventPass.Initial)
                            val down = change.changes.any { it.pressed }
                            if (down != DockEvents.held.value) DockEvents.held.value = down
                        }
                    }
                }
        ) {
            val track = shown as? DockEvent.Track
            val queued = shown as? DockEvent.Queued
            val timer = shown as? DockEvent.Timer
            val cast = shown as? DockEvent.Cast
            val top = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(cardH)

            EventLayer(visible = expanded && track != null, reduce = reduce, openReveal = reveal, modifier = top) { r ->
                TrackCard(player, reduce, r, onOpenPlayer)
            }
            EventLayer(visible = expanded && queued != null, reduce = reduce, openReveal = reveal, modifier = top) { r ->
                if (queued != null) QueuedCard(queued, r)
            }
            EventLayer(visible = expanded && timer != null, reduce = reduce, openReveal = reveal, modifier = top) { r ->
                if (timer != null) TimerCard(timer, r)
            }
            EventLayer(visible = expanded && cast != null, reduce = reduce, openReveal = reveal, modifier = top) { r ->
                if (cast != null) CastCard(cast, reduce, r, onOpenCast)
            }

            // The four places and the cover ring: always there, at the foot of the capsule.
            // The white circle of the selected place slides from place to place (and overshoots a little).
            Row(
                Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .height(RestHeight)
                    .drawBehind {
                        val tab = TabSize.toPx()
                        val pad = 6.dp.toPx()
                        val items = if (hasMedia) 6 else 4
                        val widths = tab * (if (hasMedia) 5 else 4) + (if (hasMedia) 1.dp.toPx() else 0f)
                        val gap = ((this.size.width - 2f * pad - widths) / (items - 1)).coerceAtLeast(0f)
                        val center = Offset(pad + indicator.value * (tab + gap) + tab / 2f, this.size.height / 2f)
                        drawCircle(accent.copy(alpha = 0.2f), radius = tab / 2f + 3.dp.toPx(), center = center)
                        drawCircle(Color.White, radius = tab / 2f, center = center)
                    }
                    .padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Destination.dock.forEach { dest ->
                    IslandTab(dest, dest == selected.dockSlot, reduce) { onSelect(dest) }
                }
                if (hasMedia) {
                    Box(Modifier.width(1.dp).height(26.dp).background(Color.White.copy(alpha = 0.14f)))
                    IslandRing(player, casting = castName != null, reduce = reduce, onOpen = onOpenPlayer)
                }
            }
        }
    }
}

/** One card layer: composed while it shows or fades. [content] gets how far in it is (0..1) to stagger its parts. */
@Composable
private fun EventLayer(
    visible: Boolean,
    reduce: Boolean,
    openReveal: () -> Float,
    modifier: Modifier,
    content: @Composable (() -> Float) -> Unit
) {
    val vis = animateFloatAsState(if (visible) 1f else 0f, tween(if (reduce) 90 else 240), label = "islandLayer")
    if (visible || vis.value > 0.001f) {
        Box(modifier) {
            content({ minOf(openReveal(), vis.value) })
        }
    }
}

// ---- the places ------------------------------------------------------------------------------------------------------

@Composable
private fun IslandTab(dest: Destination, isSelected: Boolean, reduce: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val ink by animateColorAsState(
        if (isSelected) IslandInk else IslandDim,
        tween(if (reduce) 120 else 300),
        label = "islandTabInk"
    )
    Box(
        Modifier
            .size(TabSize)
            .said(dest.label)
            .pressable({
                if (!isSelected) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            }),
        contentAlignment = Alignment.Center
    ) {
        NeedleIconView(dest.icon, tint = ink, size = 24.dp)
    }
}

/** Tap and press-and-hold on one thing, with the same soft squeeze as the other buttons. [source] lets the caller see the press. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Modifier.pressableHold(source: MutableInteractionSource, onClick: () -> Unit, onLongClick: () -> Unit): Modifier {
    val pressed by source.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    val squeeze by animateFloatAsState(
        targetValue = if (pressed) 0.94f else 1f,
        animationSpec = spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "islandRingPress"
    )
    return this
        .graphicsLayer {
            scaleX = squeeze
            scaleY = squeeze
        }
        .combinedClickable(
            interactionSource = source,
            indication = null,
            onClick = onClick,
            onLongClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onLongClick()
            }
        )
}

/** A sideways swipe skips: left = next song, right = previous. */
@Composable
private fun Modifier.swipeSkip(vm: PlayerViewModel): Modifier {
    val haptic = LocalHapticFeedback.current
    return this.pointerInput(vm) {
        var total = 0f
        val limit = 40.dp.toPx()
        detectHorizontalDragGestures(
            onDragStart = { total = 0f },
            onDragCancel = { total = 0f },
            onDragEnd = {
                if (total < -limit) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    vm.next()
                } else if (total > limit) {
                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                    vm.previous()
                }
                total = 0f
            },
            onHorizontalDrag = { _, dx -> total += dx }
        )
    }
}

/**
 * The cover in a ring that fills as the song plays. Tap opens Now playing, press and hold plays or pauses (a ring grows and the
 * cover lights up while you hold, so you can see it is working), swipe sideways skips.
 * Paused shows a small pause mark on the cover; casting sends a soft pulse out of the ring.
 */
@Composable
private fun IslandRing(vm: PlayerViewModel, casting: Boolean, reduce: Boolean, onOpen: () -> Unit) {
    val position = rememberLivePositionMs(vm, poll = true)
    val accent = Palette.Accent
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    // The hold takes about as long as the long press: the ring grows that long, then springs back.
    val hold = animateFloatAsState(
        if (pressed) 1f else 0f,
        if (pressed && !reduce) tween<Float>(420, easing = LinearEasing) else spring<Float>(dampingRatio = 0.55f, stiffness = 500f),
        label = "islandHold"
    )
    val pulse: State<Float>? = if (casting && !reduce) {
        rememberInfiniteTransition(label = "islandCastPulse").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
            label = "pulse"
        )
    } else null
    val paused = !vm.isPlaying
    Box(
        Modifier
            .size(TabSize)
            .said(if (paused) "Open the player. Press and hold to play" else "Open the player. Press and hold to pause")
            .swipeSkip(vm)
            .pressableHold(source, onOpen) { vm.togglePlay() }
            .drawBehind {
                val stroke = 3.dp.toPx()
                val p = pulse?.value
                if (p != null) {
                    drawCircle(
                        accent.copy(alpha = 0.6f * (1f - p)),
                        radius = (this.size.minDimension / 2f) * (1f + 0.8f * p),
                        style = Stroke(2.dp.toPx())
                    )
                }
                val h = hold.value
                if (h > 0.01f) {
                    drawCircle(
                        accent.copy(alpha = 0.45f * h.coerceAtMost(1f)),
                        radius = (this.size.minDimension / 2f) * (1f + 0.3f * h),
                        style = Stroke(2.dp.toPx())
                    )
                }
                drawCircle(Color.White.copy(alpha = 0.16f), style = Stroke(stroke))
                val f = fractionOf(vm, position.value)
                if (f > 0f) {
                    drawArc(
                        accent, -90f, 360f * f, false,
                        topLeft = Offset(stroke / 2, stroke / 2),
                        size = Size(this.size.width - stroke, this.size.height - stroke),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            }
            .padding(5.dp)
            .clip(CircleShape)
    ) {
        MorphCover(vm, Modifier.fillMaxSize())
        if (paused) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.42f))
                    .drawBehind {
                        val bar = this.size.width * 0.12f
                        val tall = this.size.height * 0.36f
                        val top = (this.size.height - tall) / 2f
                        val gap = this.size.width * 0.09f
                        val left = this.size.width / 2f - gap - bar
                        val right = this.size.width / 2f + gap
                        drawRoundRect(Color.White, Offset(left, top), Size(bar, tall), CornerRadius(bar / 2f))
                        drawRoundRect(Color.White, Offset(right, top), Size(bar, tall), CornerRadius(bar / 2f))
                    }
            )
        }
        // The cover lights up while you hold.
        Box(Modifier.fillMaxSize().drawBehind { drawRect(Color.White.copy(alpha = 0.24f * hold.value.coerceIn(0f, 1f))) })
    }
}

// ---- the cards -------------------------------------------------------------------------------------------------------

@Composable
private fun CardRow(modifier: Modifier = Modifier, content: @Composable RowScope.() -> Unit) {
    Row(
        modifier
            .fillMaxSize()
            // A new card is announced to TalkBack as one phrase; its buttons stay separate.
            .semantics(mergeDescendants = true) { liveRegion = LiveRegionMode.Polite }
            .padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** A text pill on a card (Undo, +5 min, Switch). */
@Composable
private fun CardPill(label: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .height(36.dp)
            .said(label)
            .pressable(onClick, pressedScale = 0.94f)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun TrackCard(vm: PlayerViewModel, reduce: Boolean, reveal: () -> Float, onOpenPlayer: () -> Unit) {
    val accent = Palette.Accent
    CardRow(
        Modifier
            .swipeSkip(vm)
            .clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onOpenPlayer)
    ) {
        IslandEq(accent, still = reduce, modifier = Modifier.rise(reveal, 0f))
        Column(Modifier.weight(1f).rise(reveal, 0.15f)) {
            Text(
                "NOW PLAYING", color = accent, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.7.sp, lineHeight = 14.sp, maxLines = 1
            )
            Text(
                vm.title ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.artist ?: "", color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            Modifier
                .size(40.dp)
                .rise(reveal, 0.3f)
                .said("Next song")
                .pressable(vm::next)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            SkipGlyph(Color.White)
        }
    }
}

@Composable
private fun QueuedCard(ev: DockEvent.Queued, reveal: () -> Float) {
    val accent = Palette.Accent
    val first = ev.songs.firstOrNull()?.title.orEmpty()
    val title = if (ev.next) "Plays next" else "Added to queue"
    val line = when {
        ev.songs.isEmpty() -> if (ev.next) "A song plays after this song" else "A song is at the end of the queue"
        ev.songs.size == 1 && ev.next -> "$first plays after this song"
        ev.songs.size == 1 -> "$first is at the end of the queue"
        ev.next -> "${ev.songs.size} songs play after this song"
        else -> "${ev.songs.size} songs are at the end of the queue"
    }
    Box(Modifier.fillMaxSize()) {
        CardRow {
            Box(
                Modifier.size(38.dp).rise(reveal, 0f).clip(CircleShape).background(accent),
                contentAlignment = Alignment.Center
            ) {
                NeedleIconView(NeedleIcon.CHECK, IslandInk, size = 20.dp)
            }
            Column(Modifier.weight(1f).rise(reveal, 0.15f)) {
                Text(
                    title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    line, color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            CardPill("Undo", Modifier.rise(reveal, 0.3f)) {
                ev.onUndo()
                DockEvents.dismiss()
            }
        }
        // The line along the foot shrinks away while the card waits: that is how long Undo stays (and it stands still while held).
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 14.dp, end = 14.dp, bottom = 2.dp)
                .fillMaxWidth()
                .height(2.dp)
                .rise(reveal, 0.3f)
                .drawBehind { drawRect(accent, size = Size(this.size.width * DockEvents.lifeLeft.floatValue, this.size.height)) }
        )
    }
}

@Composable
private fun TimerCard(ev: DockEvent.Timer, reveal: () -> Float) {
    val accent = Palette.Accent
    val mode = if (ev.demo) SleepTimer.Mode.TIME else SleepTimer.mode.value
    val remaining = if (ev.demo) 14 * 60_000L + 58_000L else SleepTimer.remainingMs.longValue
    val total = if (ev.demo) 20 * 60_000L else SleepTimer.totalMs.longValue
    val finishing = !ev.demo && SleepTimer.finishing.value
    val fraction = if (mode == SleepTimer.Mode.TIME && total > 0L) (remaining.toFloat() / total).coerceIn(0f, 1f) else 1f
    val line = when (mode) {
        SleepTimer.Mode.TIME -> if (finishing) "Finishing this song" else "Music stops in ${SleepTimer.clock(remaining)}"
        SleepTimer.Mode.SONG -> "Music stops after this song"
        SleepTimer.Mode.ALBUM -> "Music stops after this album"
        SleepTimer.Mode.OFF -> "The timer is off"
    }
    CardRow {
        Box(Modifier.size(40.dp).rise(reveal, 0f), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(40.dp)) {
                val stroke = 3.dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.16f), radius = (this.size.minDimension - stroke) / 2f, style = Stroke(stroke))
                drawArc(
                    accent, -90f, 360f * fraction, false,
                    topLeft = Offset(stroke / 2, stroke / 2),
                    size = Size(this.size.width - stroke, this.size.height - stroke),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            NeedleIconView(NeedleIcon.TIMER, accent, size = 18.dp)
        }
        Column(Modifier.weight(1f).rise(reveal, 0.15f)) {
            Text(
                "Sleep timer", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1
            )
            Text(line, color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (mode == SleepTimer.Mode.TIME) {
            CardPill("+5 min", Modifier.rise(reveal, 0.3f)) { if (!ev.demo) SleepTimer.addMinutes(5) }
        }
    }
}

@Composable
private fun CastCard(ev: DockEvent.Cast, reduce: Boolean, reveal: () -> Float, onOpenCast: () -> Unit) {
    val accent = Palette.Accent
    // Two rings spread out of the icon, half a beat apart (not at all with Reduce motion).
    val transition = rememberInfiniteTransition(label = "castCard")
    val ringA: State<Float>? = if (!reduce) {
        transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "ringA")
    } else null
    val ringB: State<Float>? = if (!reduce) {
        transition.animateFloat(
            0f, 1f,
            infiniteRepeatable(tween(1800, easing = LinearEasing), initialStartOffset = StartOffset(900, StartOffsetType.FastForward)),
            label = "ringB"
        )
    } else null
    CardRow {
        Box(
            Modifier
                .size(38.dp)
                .rise(reveal, 0f)
                .drawBehind {
                    for (s in listOfNotNull(ringA, ringB)) {
                        val p = s.value
                        drawCircle(
                            accent.copy(alpha = 0.7f * (1f - p)),
                            radius = (this.size.minDimension / 2f) * (1f + 0.9f * p),
                            style = Stroke(2.dp.toPx())
                        )
                    }
                    drawCircle(accent.copy(alpha = 0.2f))
                },
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CAST, accent, size = 20.dp)
        }
        Column(Modifier.weight(1f).rise(reveal, 0.15f)) {
            Text(
                ev.device, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("Casting from this phone", color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 1)
        }
        CardPill("Switch", Modifier.rise(reveal, 0.3f), onOpenCast)
    }
}

// ---- small drawings --------------------------------------------------------------------------------------------------

@Composable
private fun islandBar(transition: InfiniteTransition, offsetMs: Int): State<Float> =
    transition.animateFloat(
        initialValue = 5f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            tween(800, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
            StartOffset(offsetMs, StartOffsetType.FastForward)
        ),
        label = "eqBar"
    )

/** Four bars that dance while the song starts. Still (and a little uneven) with Reduce motion. */
@Composable
private fun IslandEq(color: Color, still: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "islandEq")
    val a = islandBar(transition, 0)
    val b = islandBar(transition, 250)
    val c = islandBar(transition, 500)
    val d = islandBar(transition, 100)
    Canvas(modifier.size(28.dp, 26.dp)) {
        val heights = if (still) listOf(10f, 18f, 14f, 22f) else listOf(a.value, b.value, c.value, d.value)
        val barW = 4.dp.toPx()
        val gap = 3.dp.toPx()
        heights.forEachIndexed { i, hDp ->
            val hPx = hDp.dp.toPx()
            drawRoundRect(
                color,
                topLeft = Offset(i * (barW + gap), (this.size.height - hPx) / 2f),
                size = Size(barW, hPx),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

/** "Next song": a triangle with a bar, from the mockup's 24 x 24 grid. */
@Composable
private fun SkipGlyph(color: Color, glyph: Dp = 18.dp) {
    Canvas(Modifier.size(glyph)) {
        val k = this.size.width / 24f
        val tri = Path().apply {
            moveTo(6f * k, 5f * k)
            lineTo(6f * k, 19f * k)
            lineTo(15f * k, 12f * k)
            close()
        }
        drawPath(tri, color)
        drawLine(color, Offset(18.5f * k, 5f * k), Offset(18.5f * k, 19f * k), strokeWidth = 1.8f * k, cap = StrokeCap.Round)
    }
}
