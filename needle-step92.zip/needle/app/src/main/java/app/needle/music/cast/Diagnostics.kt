package app.needle.music.cast

import android.app.ActivityManager
import android.app.ApplicationExitInfo
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/*
 * Finding out what makes Needle stop responding while it casts. Both pieces write into the cast debug log
 * (Settings > Play on > a device > Copy debug log), so a stall can be sent without a computer.
 *
 *  - MainThreadWatchdog: while casting, notices when the main thread is stuck for more than a second and writes
 *    down what it is doing (its stack), then how long the stall lasted.
 *  - ExitReport: at the next start, reads why Android ended the previous run (not responding, crash, out of memory ...).
 *    For "not responding" it also writes the main thread's stack from Android's own report.
 */
object MainThreadWatchdog {
    private const val STALL_MS = 1000L
    private const val BEAT_MS = 500L

    @Volatile private var running = false
    @Volatile private var beat = 0L
    @Volatile private var pinged = false

    @Synchronized
    fun start() {
        if (running) return
        running = true
        val main = Looper.getMainLooper()
        val handler = Handler(main)
        val mainThread = main.thread
        Thread({
            val ping = Runnable { beat = SystemClock.elapsedRealtime(); pinged = false }
            beat = SystemClock.elapsedRealtime()
            pinged = false
            var reported = false
            var stallSince = 0L
            while (running) {
                if (!pinged) { pinged = true; handler.post(ping) }
                try { Thread.sleep(BEAT_MS) } catch (e: InterruptedException) { break }
                val now = SystemClock.elapsedRealtime()
                val late = now - beat
                if (late >= STALL_MS) {
                    if (stallSince == 0L) stallSince = beat
                    if (!reported) {
                        reported = true
                        CastHub.log("main thread blocked for ${late} ms, now in:\n" + stack(mainThread))
                    }
                } else if (stallSince != 0L) {
                    CastHub.log("main thread free again after ${now - stallSince} ms")
                    stallSince = 0L
                    reported = false
                }
            }
        }, "needle-watchdog").apply { isDaemon = true }.start()
    }

    @Synchronized
    fun stop() { running = false }

    private fun stack(t: Thread): String =
        t.stackTrace.take(22).joinToString("\n") { "    at $it" }
}

object ExitReport {
    private const val PREFS = "needle_diag"

    /** Call once at start-up. Does its reading on a background thread. */
    fun check(context: Context) {
        val app = context.applicationContext
        Thread({ runCatching { read(app) } }, "needle-exit-report").apply { isDaemon = true }.start()
    }

    private fun read(context: Context) {
        if (Build.VERSION.SDK_INT < 30) return // the system keeps no exit history before Android 11
        val am = context.getSystemService(ActivityManager::class.java) ?: return
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val seen = prefs.getLong("exitSeen", 0L)
        val clock = SimpleDateFormat("MMM d HH:mm:ss", Locale.US)
        var newest = seen
        // Oldest first, so the log reads in order.
        for (info in am.getHistoricalProcessExitReasons(context.packageName, 0, 8).sortedBy { it.timestamp }) {
            if (info.timestamp <= seen) continue
            newest = maxOf(newest, info.timestamp)
            val name = reasonName(info.reason)
            // The person closing the app or swiping it away is not a problem worth writing down.
            if (info.reason == ApplicationExitInfo.REASON_USER_REQUESTED || info.reason == ApplicationExitInfo.REASON_EXIT_SELF) continue
            val text = StringBuilder("previous run ended: $name at ${clock.format(Date(info.timestamp))}")
            if (!info.description.isNullOrBlank()) text.append(" (").append(info.description).append(')')
            text.append(", memory ").append(info.pss / 1024).append(" MB")
            if (info.reason == ApplicationExitInfo.REASON_ANR) {
                val trace = runCatching {
                    info.traceInputStream?.use { s ->
                        val out = java.io.ByteArrayOutputStream()
                        val chunk = ByteArray(8192)
                        while (out.size() < 600_000) {
                            val n = s.read(chunk)
                            if (n < 0) break
                            out.write(chunk, 0, n)
                        }
                        String(out.toByteArray())
                    }
                }.getOrNull()
                mainThreadOf(trace)?.let { text.append("\nmain thread:\n").append(it) }
            }
            CastHub.log(text.toString())
        }
        if (newest != seen) prefs.edit().putLong("exitSeen", newest).apply()
    }

    /** The "main" thread's block from Android's not-responding report: its first lines show where it was stuck. */
    private fun mainThreadOf(trace: String?): String? {
        if (trace.isNullOrBlank()) return null
        val start = trace.indexOf("\"main\" prio=")
        if (start < 0) return null
        val lines = trace.substring(start).lineSequence().takeWhile { it.isNotBlank() }.take(30).toList()
        return lines.joinToString("\n") { "    $it" }
    }

    private fun reasonName(r: Int) = when (r) {
        ApplicationExitInfo.REASON_ANR -> "not responding"
        ApplicationExitInfo.REASON_CRASH -> "crash"
        ApplicationExitInfo.REASON_CRASH_NATIVE -> "native crash"
        ApplicationExitInfo.REASON_LOW_MEMORY -> "killed for memory"
        ApplicationExitInfo.REASON_SIGNALED -> "killed by a signal"
        ApplicationExitInfo.REASON_INITIALIZATION_FAILURE -> "failed to start"
        ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE -> "too many resources used"
        ApplicationExitInfo.REASON_PERMISSION_CHANGE -> "permission changed"
        ApplicationExitInfo.REASON_DEPENDENCY_DIED -> "something it depends on died"
        ApplicationExitInfo.REASON_FREEZER -> "frozen by the system"
        ApplicationExitInfo.REASON_OTHER -> "other"
        else -> "reason $r"
    }
}
