# Find info online from the album page (Step 90, on Step 89)

The album page has a "Find info" chip (globe) at the end of the tag row, under the Play row. It shows even when the album
has no genre, label or description yet, so there is always a way in.

It opens the same "Find info online" screen as the tag editor (Step 77): pick a source, search, tap the album, tick what to keep.
The difference: from the album page "Use N selected" saves straight away, like a save in the tag editor (Needle's own copy, and the
audio files too when Settings > Library > Write tags into the files is on). From the tag editor it still only fills the boxes.

Files: AlbumScreen.kt (chip), NeedleApp.kt (overlay + save).
Not compiled here (no Android SDK in the sandbox): if the build log shows errors, send it.
