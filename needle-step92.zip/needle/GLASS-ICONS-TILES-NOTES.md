# Step 87, built on Step 86
- Library = rounded tile with a record (L5).
- Home, Playlists and Library tiles now share one corner radius (6 on the 24 grid); Playlists was 4.5 and looked squarer.
- Only ui/Icons.kt changed. Not compiled here.
