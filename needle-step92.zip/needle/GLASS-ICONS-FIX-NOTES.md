# Step 85, built on Step 84

- The dark, muddy look is fixed: the wide halo behind every icon is gone. Icons are a crisp line again, and closed shapes get a lighter, clearer frosted fill.
- Playlists icon is now P5 (a rounded square with a note).
- Home and Library go back to the original house and shelf shapes (now with the new fill for Home) until you pick new ones.
- Switch: `GlassIcons.on` in ui/Icons.kt (false = no fill at all, plain lines).
- Not compiled here. If the build fails, send the log.
