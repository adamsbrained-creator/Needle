# Step 86, built on Step 85
- Home = H5 (house in a rounded tile), Playlists = P5 (note in a rounded tile), Library = rounded tile with three book spines (a first try, easy to swap).
- Only ui/Icons.kt changed (HOME, SHELF). Not compiled here.
