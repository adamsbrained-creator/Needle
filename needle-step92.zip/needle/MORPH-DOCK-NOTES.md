# Morph dock, built on Step 80 (from the "A Morph" mockup)

Settings > Customization > Navigation now has four choices: **Morph dock** (new, the default), Pill + dock (the original, unchanged),
Pill only, Classic bar. Black & Green still starts with the Classic bar when nothing was chosen.

## What it does
One floating glass capsule that changes shape instead of a second bar appearing.
- Idle (nothing loaded): a slim pill with the four places. The open place shows its name; the name slides to the next tab when you change place.
- Playing: the same pill grows upward into the player row (cover, title, artist or "Playing on ...", play/pause, a thin accent line for the song's progress). Tap the row for Now playing.
- Scroll down: it tucks into a small capsule: cover with a progress ring (tap = Now playing), play/pause, where you are, and an expand arrow.
  Scroll up, pull down at the top, tap the capsule or swipe it up and it opens again. Swiping the open dock down tucks it. Changing place always opens it.
  With nothing loaded the capsule is just "where you are" and the arrow.
- Select songs (long-press): the dock turns into "N selected" + All + close, with Next, Queue, Playlist, Tags (and Hide on Songs). The count rolls up and down.
- Search: the dock becomes the search field (mic while empty, close button, keyboard Search key), riding above the keyboard.
  The Search page keeps its pills and results and shows a "Search" title where its own box was.
- Motion: size and corners spring a little past their goal, layers fade and rise 10 dp a moment after the shape starts to change, buttons squeeze under the finger,
  tabs have a soft tick. Reduce motion (Settings) turns the springs into short fades. Corners (Sharp/Soft/Round) shape the tall dock; the slim shapes stay fully round.

## New file
- ui/MorphDock.kt   MorphDock, DockBus (the little shared state), DockSelection, PublishDockSelection, dockScrollAware

## Changed
- ui/Dock.kt          navStyle 3 draws MorphDock; the other three are untouched
- ui/Appearance.kt    effectiveNavStyle: 0..3, default is 3 (2 on Black & Green); usesMorphDock()
- data/NeedleSettings.kt  navStyle may be 3 (saved, exported and restored with backups)
- ui/SettingsScreen.kt    the Navigation pills (Morph dock first) and its note
- ui/MediaLists.kt    SelectionBar hands its actions to the dock when Morph is on (Songs, Album and Genre pages all use it)
- ui/SearchScreen.kt  with Morph, the text lives in the dock's field; without it the page is exactly as before
- ui/NeedleApp.kt     one modifier, .dockScrollAware(), on the page area. It only watches scrolling and consumes nothing.

## Things to know
- Someone who already picked a Navigation style keeps it (it is saved). Pick "Morph dock" once to switch. New installs and anyone who never touched it get Morph.
- The dock's search placeholder says "Search your library" (the mockup's text did not leave room for the mic).
- Written without a compiler on hand: if the build reports an error, send the log. The likely places are ui/MorphDock.kt and ui/SearchScreen.kt.
