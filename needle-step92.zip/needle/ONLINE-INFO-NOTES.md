# Find info online (Step 77, on Step 76)

A globe button in the tag editor opens "Find info online". Everything is manual:
1. Pick a source (MusicBrainz, Last.fm, Discogs), check the Album/Artist boxes, press Search.
2. Tap the right album in the list.
3. Tick what to keep. Every box starts unticked. Genres and tags are chips (tap each one), "Add to current" / "Replace current"
   decides how they join the Genre box. Year, release date, label, catalog number, barcode and the description are rows with a tick;
   their text can be edited first (editing ticks it), and the description has "Clear the text".
4. "Use N selected" only fills the boxes of the tag editor. Nothing is saved until the check mark there is pressed.

Sources
- MusicBrainz: no key. Genres, tags, label/catalog/barcode/date from the earliest official release, description from MusicBrainz's
  own note, else the Wikipedia page they link to. Asks for one request a second, so a pick takes a couple of seconds.
- Last.fm: needs the person's own API key (Settings, Album info online). Tags and the album wiki text.
- Discogs: needs a personal token (same place). Genres, styles, label, catalog number, barcode, release notes.
  Masters (one entry per album) are listed first, then single releases.
Keys stay on the phone and are not part of backups (same as the Fanart.tv key).

Files: data/OnlineInfo.kt (fetchers), ui/AlbumInfoScreen.kt (screen), TagEditorScreen.kt (button + overlay),
NeedleSettings.kt + SettingsScreen.kt (the two key fields).
Not compiled here (no Android SDK in the sandbox): if the build log shows errors, send it.
