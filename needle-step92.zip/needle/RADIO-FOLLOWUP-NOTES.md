# Step 83, built on Step 82

- The playing radio station's logo now shows in the dock's cover (Morph, Island, Pill and Classic) instead of the empty placeholder. New RadioCover in ui/RadioScreens.kt; MorphCover and ui/Dock.kt use it while radio plays.
- Station initials skip brackets: "Guldkanalen (90-tal)" is now "G9" (was "G(").
- Radio player: a "Sleep timer" pill under the controls (opens the same timer page, returns to the player).
- Play on / casting is still not available for radio (the cast engine only handles library songs).
- Not compiled here. If the build fails, send the log.
