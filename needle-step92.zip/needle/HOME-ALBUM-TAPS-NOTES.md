# Home taps and album page tidy (Step 78, on Step 77)

- Home: tapping an album card (the big picks at the top, Your albums, Rediscover) now opens that album's page. Only the
  "Play now" buttons play. The Moments card with its own track is unchanged.
- Album page: the thin line under each side/disc heading is gone, and the "2 sides" tag under the buttons is gone (genre and label stay).
