# Step 88, built on Step 87
- Icon fills are much lighter (about half as strong, fading to almost nothing at the bottom), so dark icons on the white selected pill and grey icons on the dock no longer look muddy. The compass needle is lighter too.
- Only ui/Icons.kt changed (glassBrush alphas, `solid`). Not compiled here.
