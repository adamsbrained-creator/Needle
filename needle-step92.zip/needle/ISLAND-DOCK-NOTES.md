# Island dock, built on Step 81 (from the "C Island" mockup)

Settings > Customization > Navigation now has five choices: Morph dock (still the default), **Island dock** (new), Pill + dock, Pill only, Classic bar.
Nobody's saved choice changes; pick "Island dock" once to switch.

## What it does
At rest it is one small black capsule: the four places as round icons and the cover in a ring that fills as the song plays
(tap = Now playing, press and hold = play or pause; a small pause mark shows on the cover while paused). With nothing loaded it is just the four places.
When something happens it opens upward for a few seconds, says what, and settles back:
- **Track**  a new song starts: equalizer bars, "NOW PLAYING", title, artist and a Next button. Not shown when the app opens or when a saved queue is restored.
- **Queue**  "Added to queue" / "Plays next" with an Undo, and a line along the foot that shrinks while Undo is available.
  Every way of queuing uses it: swiping a song, the selection bar (Next / Queue), the song, album, artist and playlist menus, "Add latest" on Home.
- **Timer**  the sleep timer started or was extended (and again when one minute is left): a ring of the time left, "Music stops in 14:58", and +5 min.
- **Cast**  casting started: the device name, "Casting from this phone", two rings spreading out of the icon, and Switch (opens Play on).
Swipe the open capsule down to put it away early. A newer event replaces the one being shown. Reduce motion: springs become short fades, equalizer stands still, no rings.
Corners (Sharp/Soft/Round) shape the open capsule; the resting capsule is always fully round.
Select songs and Search keep the pages' own bars and fields (unlike the Morph dock, the Island takes nothing else over).

## New file
- ui/IslandDock.kt   IslandDock, DockEvent / DockEvents, announceQueue

## Changed
- ui/Appearance.kt        effectiveNavStyle accepts 0..4; usesIslandDock()
- data/NeedleSettings.kt  navStyle may be 4 (saved, exported and restored with backups)
- ui/Dock.kt              NeedleDock draws IslandDock for style 4; new `onOpenCast` parameter (default does nothing)
- ui/SettingsScreen.kt    the Navigation pills (five now) and its note
- ui/NeedleApp.kt         passes onOpenCast = open Play on; room under the pages is 100 dp for the Island (like Pill only);
                          all 13 "Playing next / Added to queue" places call announceQueue instead of a toast
- playback/PlayerViewModel.kt  undoAdd(songs, next): takes back what was just added (finds those songs where they were put)
- ui/MorphDock.kt         shapeSpec, pressable, said, fractionOf, DockLayer, MorphCover are `internal` (were private) so the Island reuses them. Nothing else changed.

## Things to know
- With any other Navigation, queuing still shows the toast exactly as before (announceQueue falls back to it).
- The Smart flow top-ups (songs added by itself) stay silent on purpose.
- Undo on a very first add (nothing was queued before) removes those songs again, which stops playback.
- Written without a compiler on hand: if the build reports an error, send the log. The likely places are ui/IslandDock.kt and playback/PlayerViewModel.kt (undoAdd).
