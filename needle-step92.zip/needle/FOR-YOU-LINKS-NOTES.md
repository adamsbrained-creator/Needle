# Step 89, built on Step 88: For you gets "Open in..." and outside listening history

## Open in...
Tap an artist (For you), a wishlist album, or an artist from your history: a small menu offers Spotify, YouTube Music or Deezer.
It opens a search for "artist album" with a normal web link; the phone hands it to the app if it is installed, else to the browser.
No account, no API, nothing is sent from Needle.

## Listening elsewhere (ListenBrainz / Last.fm)
- New row on For you: "Listening elsewhere". Choose ListenBrainz (user name only, public profile) or Last.fm (user name + your own free API key from last.fm/api).
- Needle loads your ~30 most played artists (all time), once a week or when you press refresh. Only the user name (and key) is sent.
- Up to 3 of them join the starting points for suggestions; artists from that list that are not in your library show under "From your history, not in your library".
- Same switches as the rest of For you: off until turned on, Wi-Fi only if set. The Last.fm key is kept in the app's private preferences (not encrypted).
- Spotify / YouTube Music users: scrobble to ListenBrainz or Last.fm with their own tools, then connect that profile here.

## Files
Changed: data/Recommendations.kt, ui/ForYouScreen.kt, ui/NeedleApp.kt, ui/RadioScreens.kt (FormField, RadioChip made internal)

## Not checked
The ListenBrainz and Last.fm calls (stats/user/<name>/artists and user.gettopartists) were written from memory of their docs and were not tested. Not compiled here: if the build fails, send the log.
