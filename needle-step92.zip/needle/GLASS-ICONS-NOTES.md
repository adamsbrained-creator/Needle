# Step 84, built on Step 83: glass icons

- Every icon (old and new sections) is now drawn in the glass style: a soft halo behind it, the line on top, and a frosted fill (lighter at the top) inside closed shapes (house, record, folder, heart, star, timer, phone, globe, calendar, tag, image, gear ...). Open line icons (chevrons, plus, sort ...) get the halo only.
- New dock icons: Home (house with an arched door), Playlists (new PLAYLIST icon: stacked cards with a play button), Browse (compass with a solid needle), Library (books on a shelf, one leaning).
- The Library page lists Playlists with the new Playlists icon. Songs keeps the note icon.
- Switch: `GlassIcons.on` in ui/Icons.kt. Set it to false to get the old plain line icons everywhere.
- Not compiled here. If the build fails, send the log (likely spot: ui/Icons.kt).
