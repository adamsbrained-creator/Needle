# Step 92 - Needle not responding while casting

Built on Step 91. I could not reproduce this (no device, no trace), so this step does two things:
makes the likely causes cheaper, and writes down what is blocking when it happens again.

## Makes it cheaper
- Animated covers are off while casting (new switch: Settings > Animated covers > While casting, default off).
  Covers Now playing and the artist videos. Turning casting off brings them back.
- Animated cover videos ask the stream for at most 720 x 720 (was: its biggest picture).
- The video cache is opened off the main thread (the first opening reads the whole cache folder).
- Cast sync: the phone's silent player is pulled to the device's position at most once every 5 s, and only
  while it is ready. A device that reports a stuck position could make it seek on every 1.2 s poll.
- Playback service: widget redraws are batched (400 ms) instead of one per play-state change, and the cover for
  the widgets is decoded at ~400 px instead of full size. Both ran on the main thread.

## Finds the cause if it still happens
- While casting, a watchdog writes to the cast debug log when the main thread is stuck for over a second:
  what it was doing (stack), and how long it lasted.
- On the next start, the log gets a line for how the previous run ended (not responding / crash / killed for
  memory), with the main thread's stack from Android's own report for "not responding".
- Read it: Settings > Play on > (device) > Copy debug log.
