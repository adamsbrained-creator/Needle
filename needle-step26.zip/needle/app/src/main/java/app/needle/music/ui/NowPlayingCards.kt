package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ExtraTags
import app.needle.music.data.LibraryTile
import app.needle.music.data.Song
import app.needle.music.data.SongInfoData
import app.needle.music.data.SongInfoLoader
import app.needle.music.data.artistKey
import app.needle.music.data.buildArtistStats
import app.needle.music.data.buildCredits
import app.needle.music.data.buildLibraryTiles
import app.needle.music.data.dayLabel
import app.needle.music.data.isKnownArtist
import app.needle.music.data.songsByArtist
import app.needle.music.data.splitAlbums

/** What the cards under the player need from the rest of the app. */
class NowPlayingLibrary(
    val songs: List<Song>,
    val extras: ExtraTags,
    val playedIds: Set<Long>,
    val artistNotes: Map<String, String>,
    val onSaveArtistNote: (artist: String, note: String) -> Unit,
    val onOpenArtist: (artist: String) -> Unit,
    val onEditTags: (Song) -> Unit,
    val onOpenInfo: (Song) -> Unit,
    val onPlayTile: (LibraryTile) -> Unit
)

private val CardShape = RoundedCornerShape(28.dp)
private val SoftText = Color(0xFFD8D8DE)

/**
 * The cards of the Now Playing mockup that come after the lyrics preview:
 * About the artist, Credits, File details and From your library.
 */
@Composable
fun NowPlayingInfoCards(song: Song, lib: NowPlayingLibrary, modifier: Modifier = Modifier) {
    val tags = lib.extras[song.id].orEmpty()

    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        if (isKnownArtist(song.artist)) {
            ArtistCard(song, lib)
        }
        CreditsCard(song, tags, onEditTags = { lib.onEditTags(song) })
        FileDetailsCard(song, onOpenInfo = { lib.onOpenInfo(song) })
        LibraryCard(song, lib)
    }
}

@Composable
private fun CardBox(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Column(modifier.fillMaxWidth().clip(CardShape).background(Palette.Card)) { content() }
}

@Composable
private fun CardHeader(title: String, action: String? = null, onAction: () -> Unit = {}) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        if (action != null) {
            Text(
                action, color = Palette.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onAction).padding(vertical = 4.dp, horizontal = 2.dp)
            )
        }
    }
}

// ---- About the artist ---------------------------------------------------------------------

@Composable
private fun ArtistCard(song: Song, lib: NowPlayingLibrary) {
    val artistSongs = remember(lib.songs, song.artist) { songsByArtist(lib.songs, song.artist) }
    val realAlbumIds = remember(lib.songs) { splitAlbums(lib.songs).first.map { it.first().albumId }.toSet() }
    val stats = remember(song.id, artistSongs, realAlbumIds, lib.playedIds) {
        buildArtistStats(song, artistSongs, realAlbumIds, lib.playedIds)
    }
    val note = lib.artistNotes[artistKey(song.artist)].orEmpty()
    var editing by remember { mutableStateOf(false) }

    CardBox {
        // Header: the covers of this artist's albums side by side, fading into the card.
        Box(Modifier.fillMaxWidth().height(210.dp)) {
            Row(Modifier.fillMaxSize().background(Palette.Card2)) {
                stats.covers.forEach { cover ->
                    Cover(cover, Modifier.weight(1f).fillMaxHeight())
                }
            }
            Box(
                Modifier.fillMaxSize().background(
                    Brush.verticalGradient(0f to Color.Black.copy(alpha = 0.6f), 0.45f to Color.Black.copy(alpha = 0.2f), 1f to Palette.Card)
                )
            )
            Text(
                "About the artist", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.align(Alignment.TopStart).padding(start = 18.dp, top = 16.dp)
            )
        }
        Column(Modifier.padding(start = 18.dp, end = 18.dp, bottom = 18.dp)) {
            // The name opens the artist page.
            Row(
                Modifier.clip(RoundedCornerShape(10.dp)).clickable { lib.onOpenArtist(song.artist) },
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    song.artist, color = Color.White, fontFamily = FontFamily.Serif, fontSize = 25.sp, lineHeight = 29.sp,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                )
                Spacer(Modifier.width(6.dp))
                NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
            }
            Text(stats.line, color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 6.dp))
            Box(
                Modifier
                    .padding(top = 14.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .background(Color.White.copy(alpha = 0.07f))
                    .clickable { editing = true }
                    .padding(12.dp)
            ) {
                Text(
                    if (note.isBlank()) "Your notes: add a note about this artist, like where you found them." else note,
                    color = if (note.isBlank()) SoftText.copy(alpha = 0.7f) else SoftText,
                    fontSize = 13.sp, lineHeight = 18.sp
                )
            }
        }
    }

    if (editing) {
        NoteDialog(
            artist = song.artist,
            initial = note,
            onSave = { lib.onSaveArtistNote(song.artist, it); editing = false },
            onDismiss = { editing = false }
        )
    }
}

@Composable
private fun NoteDialog(artist: String, initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Note about $artist", maxLines = 2, overflow = TextOverflow.Ellipsis) },
        text = {
            Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(16.dp)).background(Color.White.copy(alpha = 0.08f)).padding(14.dp)) {
                BasicTextField(
                    value = text,
                    onValueChange = { text = it },
                    textStyle = TextStyle(color = Color.White, fontSize = 15.sp, lineHeight = 21.sp),
                    cursorBrush = SolidColor(Palette.Accent),
                    modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 100.dp),
                    decorationBox = { inner ->
                        if (text.isEmpty()) Text("Where you found them, why you like them...", color = Palette.Muted, fontSize = 15.sp)
                        inner()
                    }
                )
            }
        },
        confirmButton = { TextButton(onClick = { onSave(text) }) { Text("Save", color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}

// ---- Credits ------------------------------------------------------------------------------

@Composable
private fun CreditsCard(song: Song, tags: Map<String, String>, onEditTags: () -> Unit) {
    val credits = remember(song.id, song.artist, tags) { buildCredits(song, tags) }
    var showAll by remember(song.id) { mutableStateOf(false) }
    val shown = if (showAll) credits else credits.take(5)

    CardBox {
        Column(Modifier.padding(18.dp)) {
            CardHeader("Credits", "Edit tags", onEditTags)
            Spacer(Modifier.height(6.dp))
            if (credits.isEmpty()) {
                Text("No credits in this song's tags yet.", color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(vertical = 8.dp))
            }
            shown.forEachIndexed { i, credit ->
                if (i > 0) Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
                Column(Modifier.fillMaxWidth().padding(vertical = 12.dp)) {
                    Text(credit.name, color = Color.White, fontSize = 15.5.sp, fontWeight = FontWeight.Medium, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    if (credit.roles.isNotEmpty()) {
                        Text(credit.roles.joinToString(" · "), color = Palette.Muted, fontSize = 12.5.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
            if (credits.size > 5) {
                Text(
                    if (showAll) "Show less" else "Show all ${credits.size}",
                    color = Palette.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable { showAll = !showAll }.padding(vertical = 6.dp, horizontal = 2.dp)
                )
            } else if (credits.size <= 1) {
                Text(
                    "Add composer, lyricist and more in the tag editor.",
                    color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 2.dp)
                )
            }
        }
    }
}

// ---- File details -------------------------------------------------------------------------

private fun fileSizeText(bytes: Long): String =
    if (bytes >= 1024L * 1024) "%.1f MB".format(bytes / 1048576.0) else "${bytes / 1024} KB"

@Composable
private fun FileDetailsCard(song: Song, onOpenInfo: () -> Unit) {
    val context = LocalContext.current
    val info by produceState<SongInfoData?>(null, song.id) { value = SongInfoLoader.load(context, song) }
    val now = System.currentTimeMillis()

    val i = info
    val first = listOf(
        "Format" to (i?.format ?: "–"),
        "Quality" to (i?.quality ?: "–"),
        "Size" to (i?.sizeBytes?.let { fileSizeText(it) } ?: "–")
    )
    val second = if (i == null) emptyList() else buildList {
        i.bitrateKbps?.let { add("Bitrate" to "%,d kbps".format(it)) }
        add("Plays" to i.plays.toString())
        i.lastPlayedAt?.let { add("Last played" to dayLabel(it / 1000, now)) }
    }

    CardBox {
        Column(Modifier.padding(18.dp)) {
            CardHeader("File details", "All info", onOpenInfo)
            DetailRow(first, Modifier.padding(top = 10.dp))
            if (second.isNotEmpty()) DetailRow(second, Modifier.padding(top = 16.dp))
        }
    }
}

@Composable
private fun DetailRow(items: List<Pair<String, String>>, modifier: Modifier = Modifier) {
    Row(modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        items.forEach { (label, value) ->
            Column {
                Text(label, color = Palette.Muted, fontSize = 11.5.sp)
                Text(value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Medium, modifier = Modifier.padding(top = 3.dp))
            }
        }
    }
}

// ---- From your library --------------------------------------------------------------------

@Composable
private fun LibraryCard(song: Song, lib: NowPlayingLibrary) {
    val tiles = remember(song.id, lib.songs) { buildLibraryTiles(song, lib.songs) }
    if (tiles.isEmpty()) return

    CardBox {
        Column(Modifier.padding(18.dp)) {
            CardHeader("From your library")
            Row(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                for (slot in 0 until 3) {
                    val tile = tiles.getOrNull(slot)
                    if (tile != null) {
                        LibraryTileView(tile, Modifier.weight(1f)) { lib.onPlayTile(tile) }
                    } else {
                        // Keep the tiles the same width when there are fewer than three.
                        Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun LibraryTileView(tile: LibraryTile, modifier: Modifier, onClick: () -> Unit) {
    Box(modifier.height(170.dp).clip(RoundedCornerShape(20.dp)).background(Palette.Card2).clickable(onClick = onClick)) {
        Cover(tile.cover, Modifier.fillMaxSize())
        Box(Modifier.fillMaxSize().background(Brush.verticalGradient(0.4f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.7f))))
        Column(Modifier.align(Alignment.BottomStart).padding(10.dp)) {
            Text(tile.label, color = Color.White, fontSize = 13.sp, lineHeight = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 3, overflow = TextOverflow.Ellipsis)
            Text(
                if (tile.songs.size == 1) "1 song" else "${tile.songs.size} songs",
                color = Color.White.copy(alpha = 0.7f), fontSize = 11.sp, modifier = Modifier.padding(top = 2.dp)
            )
        }
    }
}
