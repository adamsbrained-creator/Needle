package app.needle.music.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.music.cast.CastHub
import app.needle.music.cast.CastPhase
import app.needle.music.cast.CastSettings
import app.needle.music.data.isKnownArtist
import app.needle.music.data.buildArtistPage
import app.needle.music.playback.EqState
import app.needle.music.data.FileAccess
import app.needle.music.data.HomeViewModel
import app.needle.music.data.LyricsViewModel
import app.needle.music.data.LibraryViewModel
import app.needle.music.data.Song
import app.needle.music.data.TagsViewModel
import app.needle.music.data.WritePrefs
import app.needle.music.playback.PlayerViewModel

@Composable
fun NeedleApp() {
    val library: LibraryViewModel = viewModel()
    val homeVm: HomeViewModel = viewModel()
    val tagsVm: TagsViewModel = viewModel()
    val player: PlayerViewModel = viewModel()
    val lyricsVm: LyricsViewModel = viewModel()
    var destination by rememberSaveable { mutableStateOf(Destination.HOME) }
    var homeTab by rememberSaveable { mutableStateOf(HomeTab.POPULAR) }
    var showSingles by rememberSaveable { mutableStateOf(false) }
    var showPlayer by rememberSaveable { mutableStateOf(false) }
    var showQueue by rememberSaveable { mutableStateOf(false) }
    var showLyrics by rememberSaveable { mutableStateOf(false) }
    var showLyricsEditor by rememberSaveable { mutableStateOf(false) }
    var lyricsEditSongId by rememberSaveable { mutableStateOf(0L) }
    var showLyricsSettings by rememberSaveable { mutableStateOf(false) }
    // The song menu and the Song info page. The ids stay put while they slide away.
    var showMenu by rememberSaveable { mutableStateOf(false) }
    var menuSongId by rememberSaveable { mutableStateOf(0L) }
    var showInfo by rememberSaveable { mutableStateOf(false) }
    var infoSongId by rememberSaveable { mutableStateOf(0L) }
    // The menu of a whole album (press and hold on the Albums page)
    var showAlbumMenu by rememberSaveable { mutableStateOf(false) }
    // The Player controls sheet on Now Playing, and its Speed & pitch dialog
    var showControls by rememberSaveable { mutableStateOf(false) }
    var showSpeed by rememberSaveable { mutableStateOf(false) }
    var albumMenuId by rememberSaveable { mutableStateOf(0L) }
    var showSearch by rememberSaveable { mutableStateOf(false) }
    var openAlbumId by rememberSaveable { mutableStateOf<Long?>(null) }
    // The artist page that is open (the artist's name), and the color it paints behind the whole screen
    var openArtist by rememberSaveable { mutableStateOf<String?>(null) }
    // The Equalizer page, and where Back should go ("player", "settings" or "")
    var showEq by rememberSaveable { mutableStateOf(false) }
    var eqFrom by rememberSaveable { mutableStateOf("") }
    val artistChrome = remember { mutableStateOf<Color?>(null) }
    // The tag editor. The ids stay put while it slides away, so it does not go blank mid-animation.
    var showEditor by rememberSaveable { mutableStateOf(false) }
    var editorIds by rememberSaveable { mutableStateOf(longArrayOf()) }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        library.refreshPermission()
    }

    // ---- casting (DLNA / UPnP) ----
    val context = LocalContext.current
    var showPlayOn by rememberSaveable { mutableStateOf(false) }
    var showSettings by rememberSaveable { mutableStateOf(false) }
    var castSettingsUdn by rememberSaveable { mutableStateOf<String?>(null) }
    var lanDenied by rememberSaveable { mutableStateOf(false) }
    val castDevices by CastHub.devices.collectAsState()
    val castHidden by CastHub.hidden.collectAsState()
    val castScanning by CastHub.scanning.collectAsState()
    val castState by CastHub.state.collectAsState()
    val castSettingsMap by CastHub.settings.collectAsState()
    val lanGranted by CastHub.localNetworkGranted.collectAsState()
    val lanLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        CastHub.refreshPermission()
        lanDenied = !granted
        if (granted) CastHub.startScan()
    }
    val openAppSettings = {
        context.startActivity(
            Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
        )
    }
    // Opening "Play on" asks for local network access (Android 17+) and starts looking for devices.
    LaunchedEffect(showPlayOn, lanGranted) {
        if (showPlayOn) {
            if (lanGranted) CastHub.startScan()
            else if (!lanDenied) lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
        }
    }
    // Short messages from the casting engine ("Lost connection to ...", volume).
    LaunchedEffect(Unit) {
        var toast: Toast? = null
        CastHub.messages.collect { message ->
            toast?.cancel()
            toast = Toast.makeText(context, message, Toast.LENGTH_SHORT).also { it.show() }
        }
    }

    // Ask once on launch; scan whenever access becomes available.
    LaunchedEffect(Unit) {
        if (!library.hasPermission) permissionLauncher.launch(library.audioPermission)
    }
    LaunchedEffect(library.hasPermission) {
        if (library.hasPermission) library.scan()
    }

    val closeEq = {
        showEq = false
        when (eqFrom) {
            "player" -> showPlayer = true
            "settings" -> showSettings = true
        }
        eqFrom = ""
    }
    BackHandler(enabled = destination != Destination.HOME) { destination = Destination.HOME }
    BackHandler(enabled = showSingles) { showSingles = false }
    BackHandler(enabled = openArtist != null) { openArtist = null }
    BackHandler(enabled = openAlbumId != null) { openAlbumId = null }
    BackHandler(enabled = showSearch) { showSearch = false }
    BackHandler(enabled = showSettings) { showSettings = false }
    BackHandler(enabled = showLyricsSettings) { showLyricsSettings = false; showSettings = true }
    BackHandler(enabled = showEq) { closeEq() }
    BackHandler(enabled = showPlayOn) { showPlayOn = false }
    BackHandler(enabled = castSettingsUdn != null) { castSettingsUdn = null }
    BackHandler(enabled = showPlayer) { showPlayer = false }
    BackHandler(enabled = showInfo) { showInfo = false }
    BackHandler(enabled = showEditor) { showEditor = false }
    BackHandler(enabled = showQueue) { showQueue = false }
    BackHandler(enabled = showLyrics) { showLyrics = false }
    BackHandler(enabled = showAlbumMenu) { showAlbumMenu = false }
    BackHandler(enabled = showMenu) { showMenu = false }
    BackHandler(enabled = showControls) { showControls = false } // registered last, so it wins

    // The moving glow sits behind every page; pages that slide over it share the same clock.
    Box(Modifier.fillMaxSize()) {
        GlowLayer(Modifier.matchParentSize())
        // The artist page paints its color behind the status bar and the whole screen (cleared when it goes away).
        Box(Modifier.matchParentSize().drawBehind { artistChrome.value?.let { drawRect(it) } })
        if (!library.hasPermission) {
            PermissionScreen(onRequest = { permissionLauncher.launch(library.audioPermission) })
        } else {
            val songs by library.songs.collectAsState()
            val extras by library.extras.collectAsState()
            val playedIds by library.playedIds.collectAsState()
            val artistNotes by library.artistNotes.collectAsState()
            val playCounts by library.playCounts.collectAsState()
            val tagsRead by library.tagsReadCount.collectAsState()
            val sort by library.sort.collectAsState()
            val home by homeVm.home.collectAsState()
            val newState by homeVm.newState.collectAsState()
            val singlesState by homeVm.singles.collectAsState()
            val albums by homeVm.albums.collectAsState()
            // Look the open album up again each time, so it shows the latest tags. If an edit renamed it
            // into another album (it gets a new id), go back to the Albums grid.
            val albumToShow = openAlbumId?.let { id -> albums?.firstOrNull { it.id == id } }
            LaunchedEffect(albums, openAlbumId) {
                if (albums != null && openAlbumId != null && albumToShow == null) openAlbumId = null
            }

            val openEditor: (List<Song>) -> Unit = { list ->
                editorIds = list.map { it.id }.toLongArray()
                showEditor = true
            }

            // Pressing and holding a song opens its menu (edit tags, song info, share, go to album).
            val openMenu: (Song) -> Unit = { song ->
                menuSongId = song.id
                showMenu = true
            }

            // Singles opens as its own page; the other pills switch the Home page itself.
            val selectTab: (HomeTab) -> Unit = { tab ->
                if (tab == HomeTab.SINGLES) {
                    showSingles = true
                } else {
                    homeTab = tab
                }
            }

            // The dock floats over every screen: room to scroll past it (with / without the player row).
            val dockPadding = if (player.hasMedia) 160.dp else 100.dp

            val settingsUdn = castSettingsUdn

            Box(Modifier.fillMaxSize().safeDrawingPadding()) {
                when {
                    settingsUdn != null -> CastDeviceSettingsScreen(
                        device = castDevices.firstOrNull { it.udn == settingsUdn },
                        settings = castSettingsMap[settingsUdn] ?: CastSettings(),
                        connected = castState.phase == CastPhase.CONNECTED && castState.device?.udn == settingsUdn,
                        bottomPadding = dockPadding,
                        onBack = { castSettingsUdn = null },
                        onChange = { change -> CastHub.updateSettings(settingsUdn, change) },
                        onRestore = { CastHub.restoreDefaults(settingsUdn) },
                        modifier = Modifier.fillMaxSize()
                    )
                    showPlayOn -> PlayOnScreen(
                        devices = castDevices,
                        hidden = castHidden,
                        scanning = castScanning,
                        cast = castState,
                        isPlaying = player.isPlaying,
                        volumeStep = castState.device?.let { (castSettingsMap[it.udn] ?: CastSettings()).volumeStep } ?: 10,
                        permissionGranted = lanGranted,
                        permissionDenied = lanDenied,
                        bottomPadding = dockPadding,
                        onBack = { showPlayOn = false },
                        onRefresh = { CastHub.startScan(clear = true) },
                        onUsePhone = { CastHub.disconnect() },
                        onUseDevice = { CastHub.connect(it) },
                        onHide = { CastHub.hide(it.udn) },
                        onUnhide = { CastHub.unhide(it.udn) },
                        onSettings = { castSettingsUdn = it.udn },
                        onVolume = { CastHub.stepVolume(it) },
                        onRequestPermission = {
                            if (lanDenied) openAppSettings() else lanLauncher.launch(CastHub.LOCAL_NETWORK_PERMISSION)
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showEq -> EqualizerScreen(
                        casting = castState.phase == CastPhase.CONNECTED,
                        bottomPadding = dockPadding,
                        onBack = closeEq,
                        onSoon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() },
                        modifier = Modifier.fillMaxSize()
                    )
                    showLyricsSettings -> LyricsSettingsScreen(
                        savedCount = lyricsVm.savedCount,
                        onRefreshSaved = { lyricsVm.refreshSavedCount() },
                        onClearSaved = { lyricsVm.clearAllSaved() },
                        bottomPadding = dockPadding,
                        onBack = {
                            showLyricsSettings = false
                            showSettings = true
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSettings -> SettingsScreen(
                        glowOn = GlowSettings.enabled.value,
                        onGlowChange = { GlowSettings.set(it) },
                        onOpenLyricsSettings = {
                            showSettings = false
                            showLyricsSettings = true
                        },
                        onOpenEq = {
                            showSettings = false
                            eqFrom = "settings"
                            showEq = true
                        },
                        bottomPadding = dockPadding,
                        onBack = { showSettings = false },
                        onOpenCast = {
                            showSettings = false
                            showPlayOn = true
                        },
                        tagsRead = tagsRead,
                        songCount = songs?.size ?: 0,
                        tagProgress = library.tagProgress,
                        onRereadTags = { library.readTags(all = true) },
                        writeToFiles = WritePrefs.enabled.value,
                        onWriteToFilesChange = { on ->
                            WritePrefs.set(on)
                            if (on) {
                                FileAccess.refresh()
                                if (!FileAccess.granted.value) FileAccess.openSettings(context)
                            }
                        },
                        writeProgress = tagsVm.writeProgress,
                        onWriteAll = {
                            tagsVm.writeAll { message -> Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
                        },
                        modifier = Modifier.fillMaxSize()
                    )
                    showSearch -> SearchScreen(
                        songs = songs.orEmpty(),
                        extras = extras,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { showSearch = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onEditTags = openMenu
                    )
                    albumToShow != null -> AlbumScreen(
                        album = albumToShow,
                        extras = extras,
                        currentMediaId = player.currentMediaId,
                        bottomPadding = dockPadding,
                        onBack = { openAlbumId = null },
                        onTrack = { index -> player.playSongs(albumToShow.songs, index) },
                        onPlay = { player.playSongs(albumToShow.songs, 0, shuffle = false) },
                        onShuffle = { player.shuffleAll(albumToShow.songs) },
                        onPlayNext = {
                            player.playNext(albumToShow.songs)
                            Toast.makeText(context, "Album playing next", Toast.LENGTH_SHORT).show()
                        },
                        onAddToQueue = {
                            player.addToQueue(albumToShow.songs)
                            Toast.makeText(context, "Album added to queue", Toast.LENGTH_SHORT).show()
                        },
                        onEditTags = openEditor,
                        onEditTrack = openMenu
                    )
                    openArtist != null -> {
                        val name = openArtist.orEmpty()
                        val page = remember(name, songs, albums, playCounts) {
                            buildArtistPage(name, songs.orEmpty(), albums.orEmpty(), playCounts)
                        }
                        // If an edit renamed the artist away, there is nothing left to show.
                        LaunchedEffect(page.songs.isEmpty(), songs != null, albums != null) {
                            if (songs != null && albums != null && page.songs.isEmpty()) openArtist = null
                        }
                        ArtistScreen(
                            data = page,
                            currentMediaId = player.currentMediaId,
                            bottomPadding = dockPadding,
                            onBack = { openArtist = null },
                            onPlay = { player.playSongs(page.songs, 0, shuffle = false) },
                            onShuffle = { player.shuffleAll(page.songs) },
                            onPlayList = { list, index -> player.playSongs(list, index) },
                            onOpenAlbum = { openAlbumId = it.id },
                            onQueueLatest = {
                                page.latest?.let {
                                    player.addToQueue(it.songs)
                                    Toast.makeText(context, "Added to queue", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onSongMenu = openMenu,
                            onSoon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() },
                            onChrome = { artistChrome.value = it },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    showSingles -> SinglesScreen(
                        state = singlesState,
                        bottomPadding = dockPadding,
                        onBack = { showSingles = false },
                        onPlay = { list, index -> player.playSongs(list, index) },
                        onEditTags = openMenu
                    )
                    destination == Destination.SONGS -> SongsScreen(
                        songs = songs,
                        isScanning = library.isScanning,
                        currentMediaId = player.currentMediaId,
                        sort = sort,
                        bottomPadding = dockPadding,
                        onSongClick = { index -> songs?.let { player.playSongs(it, index) } },
                        onSongLongClick = openMenu,
                        onShuffleAll = { songs?.let { player.shuffleAll(it) } },
                        onSortSelected = library::setSort,
                        onRescan = library::scan
                    )
                    destination == Destination.ALBUMS -> AlbumsScreen(
                        albums = albums,
                        bottomPadding = dockPadding,
                        onOpenAlbum = { openAlbumId = it.id },
                        onSearch = { showSearch = true },
                        onEditTags = { album ->
                            albumMenuId = album.id
                            showAlbumMenu = true
                        }
                    )
                    else -> when (homeTab) {
                        HomeTab.NEW -> NewScreen(
                            state = newState,
                            bottomPadding = dockPadding,
                            onPlay = { list, index -> player.playSongs(list, index) },
                            onShuffle = { list -> player.shuffleAll(list) },
                            onEditTags = openEditor,
                            onSearch = { showSearch = true },
                            onProfile = { showSettings = true },
                            onTabSelected = selectTab
                        )
                        else -> HomeScreen(
                            home = home,
                            bottomPadding = dockPadding,
                            onPlay = { list -> player.playSongs(list, 0) },
                            onSearch = { showSearch = true },
                            onProfile = { showSettings = true },
                            onTabSelected = selectTab
                        )
                    }
                }
                NeedleDock(
                    selected = destination,
                    // Library has no page yet, so that button does nothing for now.
                    onSelect = {
                        if (it != Destination.LIBRARY) {
                            destination = it
                            showSingles = false
                            openAlbumId = null
                            openArtist = null
                            showEq = false
                            eqFrom = ""
                            showSearch = false
                            showPlayOn = false
                            showSettings = false
                            showLyricsSettings = false
                            castSettingsUdn = null
                        }
                    },
                    player = player,
                    onOpenPlayer = { showPlayer = true },
                    castName = castState.device?.name?.takeIf { castState.phase == CastPhase.CONNECTED },
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }

            AnimatedVisibility(
                visible = showPlayer,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                NowPlayingScreen(
                    vm = player,
                    onClose = { showPlayer = false },
                    onOpenQueue = { showQueue = true },
                    onOpenLyrics = { showLyrics = true },
                    onOpenControls = { showControls = true },
                    lyricsVm = lyricsVm,
                    library = NowPlayingLibrary(
                        songs = songs.orEmpty(),
                        extras = extras,
                        playedIds = playedIds,
                        artistNotes = artistNotes,
                        onSaveArtistNote = { artist, note -> library.saveArtistNote(artist, note) },
                        onOpenArtist = { name ->
                            showPlayer = false
                            showSearch = false
                            showSingles = false
                            openAlbumId = null
                            openArtist = name
                        },
                        onEditTags = { song -> openEditor(listOf(song)) },
                        onOpenInfo = { song ->
                            infoSongId = song.id
                            showInfo = true
                        },
                        onPlayTile = { tile ->
                            player.shuffleAll(tile.songs)
                            Toast.makeText(context, "Shuffling ${tile.label}", Toast.LENGTH_SHORT).show()
                        }
                    ),
                    castActive = castState.phase == CastPhase.CONNECTED,
                    onOpenPlayOn = {
                        showPlayer = false
                        showPlayOn = true
                    },
                    // swallow taps so they don't reach the list underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showInfo,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val infoSong = songs?.firstOrNull { it.id == infoSongId }
                if (infoSong != null) {
                    val trackCount = remember(songs, infoSong.albumId) { songs?.count { it.albumId == infoSong.albumId } ?: 0 }
                    GlowSurface(Modifier.fillMaxSize()) {
                        SongInfoScreen(
                            song = infoSong,
                            albumTrackCount = trackCount,
                            extras = extras[infoSong.id].orEmpty(),
                            onBack = { showInfo = false },
                            onEditTags = { openEditor(listOf(infoSong)) },
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showEditor,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val all = songs
                val ids = editorIds.toList()
                val editing = remember(all, editorIds) { all?.filter { it.id in ids }.orEmpty() }
                val trackTotal = remember(all, editing) {
                    editing.firstOrNull()?.let { first -> all?.count { it.albumId == first.albumId } } ?: 0
                }
                GlowSurface(Modifier.fillMaxSize()) {
                TagEditorScreen(
                    songs = editing,
                    extras = extras,
                    trackTotal = trackTotal,
                    onClose = { showEditor = false },
                    writeToFiles = WritePrefs.enabled.value,
                    onSave = { changes, cover ->
                        tagsVm.save(
                            ids, changes, cover, WritePrefs.enabled.value,
                            onSaved = { showEditor = false },
                            onWritten = { message -> Toast.makeText(context, message, Toast.LENGTH_LONG).show() }
                        )
                    },
                    // swallow taps so they don't reach the screen underneath
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showQueue,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                QueueScreen(
                    vm = player,
                    onClose = { showQueue = false },
                    modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                )
            }
            }

            AnimatedVisibility(
                visible = showLyrics,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                GlowSurface(Modifier.fillMaxSize()) {
                    LyricsScreen(
                        player = player,
                        lyricsVm = lyricsVm,
                        onClose = { showLyrics = false },
                        onEdit = {
                            val id = player.currentMediaId?.toLongOrNull()
                            if (id != null) {
                                lyricsEditSongId = id
                                showLyricsEditor = true
                            }
                        },
                        modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                    )
                }
            }

            AnimatedVisibility(
                visible = showLyricsEditor,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val editSong = songs?.firstOrNull { it.id == lyricsEditSongId }
                if (editSong != null) {
                    GlowSurface(Modifier.fillMaxSize()) {
                        LyricsEditorScreen(
                            song = editSong,
                            player = player,
                            lyricsVm = lyricsVm,
                            onClose = { showLyricsEditor = false },
                            modifier = Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }

            AnimatedVisibility(visible = showMenu || showAlbumMenu || showControls, enter = fadeIn(), exit = fadeOut()) {
                Box(
                    Modifier.fillMaxSize().background(Color.Black.copy(alpha = 0.55f))
                        .pointerInput(Unit) {
                            detectTapGestures {
                                showMenu = false
                                showAlbumMenu = false
                                showControls = false
                            }
                        }
                )
            }
            AnimatedVisibility(
                visible = showAlbumMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val menuAlbum = albums?.firstOrNull { it.id == albumMenuId }
                if (menuAlbum != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        AlbumMenuSheet(
                            album = menuAlbum,
                            onPlayNext = {
                                showAlbumMenu = false
                                player.playNext(menuAlbum.songs)
                                Toast.makeText(context, "Album playing next", Toast.LENGTH_SHORT).show()
                            },
                            onAddToQueue = {
                                showAlbumMenu = false
                                player.addToQueue(menuAlbum.songs)
                                Toast.makeText(context, "Album added to queue", Toast.LENGTH_SHORT).show()
                            },
                            onShuffle = {
                                showAlbumMenu = false
                                player.shuffleAll(menuAlbum.songs)
                            },
                            onEditTags = {
                                showAlbumMenu = false
                                openEditor(menuAlbum.songs)
                            },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
            AnimatedVisibility(
                visible = showControls,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                // The song that is playing. It is looked up here so the sheet always matches the player.
                val current = songs?.firstOrNull { it.id.toString() == player.currentMediaId }
                if (current != null) {
                    val casting = castState.phase == CastPhase.CONNECTED
                    val lyricsReady = lyricsVm.state.songId == current.id && lyricsVm.state.lyrics != null
                    val soon = { Toast.makeText(context, "Coming soon", Toast.LENGTH_SHORT).show() }
                    val onAlbum = albums?.any { it.id == current.albumId } == true
                    // The tiles in the mockup's order. The ones whose feature is not built yet are placeholders.
                    val tiles = listOf(
                        ControlTile(NeedleIcon.ADD_PLAYLIST, "Add to playlist", onClick = soon),
                        ControlTile(
                            NeedleIcon.SPEED, "Speed & pitch",
                            if (casting) "Not while casting" else speedText(player.speed)
                        ) {
                            if (casting) {
                                Toast.makeText(context, "Speed and pitch work on this phone only", Toast.LENGTH_SHORT).show()
                            } else {
                                showControls = false
                                showSpeed = true
                            }
                        },
                        ControlTile(NeedleIcon.EQUALIZER, "Equalizer", EqState.summary) {
                            showControls = false
                            showPlayer = false
                            eqFrom = "player"
                            showEq = true
                        },
                        ControlTile(NeedleIcon.TIMER, "Sleep timer", "Off", onClick = soon),
                        ControlTile(NeedleIcon.LYRICS, "Edit lyrics", if (lyricsReady) "Has lyrics" else "No lyrics yet") {
                            showControls = false
                            lyricsEditSongId = current.id
                            showLyricsEditor = true
                        },
                        ControlTile(NeedleIcon.TAG, "Edit tags") {
                            showControls = false
                            openEditor(listOf(current))
                        },
                        ControlTile(NeedleIcon.ALBUMS, "Go to album", enabled = onAlbum) {
                            if (onAlbum) {
                                showControls = false
                                showPlayer = false
                                showSearch = false
                                showSingles = false
                                destination = Destination.ALBUMS
                                openAlbumId = current.albumId
                            } else {
                                Toast.makeText(context, "This song is not on an album", Toast.LENGTH_SHORT).show()
                            }
                        },
                        ControlTile(NeedleIcon.ARTIST, "Go to artist", enabled = isKnownArtist(current.artist)) {
                            if (isKnownArtist(current.artist)) {
                                showControls = false
                                showPlayer = false
                                showSearch = false
                                showSingles = false
                                openAlbumId = null
                                openArtist = current.artist
                            } else {
                                Toast.makeText(context, "This song has no artist", Toast.LENGTH_SHORT).show()
                            }
                        },
                        ControlTile(NeedleIcon.CAST, "Play on", castState.device?.name?.takeIf { casting } ?: "This phone") {
                            showControls = false
                            showPlayer = false
                            showPlayOn = true
                        },
                        ControlTile(NeedleIcon.INFO, "Song info") {
                            showControls = false
                            infoSongId = current.id
                            showInfo = true
                        },
                        ControlTile(NeedleIcon.SHARE, "Share file") {
                            showControls = false
                            shareSong(context, current)
                        },
                        ControlTile(NeedleIcon.PENCIL, "Edit controls", onClick = soon)
                    )
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        PlayerControlsSheet(tiles, Modifier.pointerInput(Unit) { detectTapGestures { } })
                    }
                }
            }
            if (showSpeed) {
                SpeedPitchDialog(
                    speed = player.speed,
                    pitch = player.pitch,
                    onChange = { sp, pi -> player.setSpeedPitch(sp, pi) },
                    onDismiss = { showSpeed = false }
                )
            }
            AnimatedVisibility(
                visible = showMenu,
                enter = slideInVertically(initialOffsetY = { it }),
                exit = slideOutVertically(targetOffsetY = { it })
            ) {
                val menuSong = songs?.firstOrNull { it.id == menuSongId }
                if (menuSong != null) {
                    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.BottomCenter) {
                        SongMenuSheet(
                            song = menuSong,
                            canGoToAlbum = albums?.any { it.id == menuSong.albumId } == true,
                            canGoToArtist = isKnownArtist(menuSong.artist),
                            onGoToArtist = {
                                showMenu = false
                                showSearch = false
                                showSingles = false
                                openAlbumId = null
                                openArtist = menuSong.artist
                            },
                            onPlayNext = {
                                showMenu = false
                                player.playNext(listOf(menuSong))
                                Toast.makeText(context, "Playing next", Toast.LENGTH_SHORT).show()
                            },
                            onAddToQueue = {
                                showMenu = false
                                player.addToQueue(listOf(menuSong))
                                Toast.makeText(context, "Added to queue", Toast.LENGTH_SHORT).show()
                            },
                            onGoToAlbum = {
                                showMenu = false
                                showSearch = false
                                showSingles = false
                                destination = Destination.ALBUMS
                                openAlbumId = menuSong.albumId
                            },
                            onEditTags = {
                                showMenu = false
                                openEditor(listOf(menuSong))
                            },
                            onEditLyrics = {
                                showMenu = false
                                lyricsEditSongId = menuSong.id
                                showLyricsEditor = true
                            },
                            onInfo = {
                                showMenu = false
                                infoSongId = menuSong.id
                                showInfo = true
                            },
                            onShare = {
                                showMenu = false
                                shareSong(context, menuSong)
                            },
                            modifier = Modifier.pointerInput(Unit) { detectTapGestures { } }
                        )
                    }
                }
            }
        }
    }
}
