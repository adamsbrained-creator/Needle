package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * One tile of the Player controls sheet. [sub] is the small line under the label ("1.0x", "This phone" ...).
 * [enabled] = false dims it (the thing it does is not possible for this song).
 */
class ControlTile(
    val icon: NeedleIcon,
    val label: String,
    val sub: String? = null,
    val enabled: Boolean = true,
    val onClick: () -> Unit
)

/**
 * The "Player controls" sheet from the mockup: all twelve tiles, in the mockup's order.
 * Tiles for features that are not built yet are placeholders (they show a "coming soon" note when tapped).
 */
@Composable
fun PlayerControlsSheet(tiles: List<ControlTile>, modifier: Modifier = Modifier) {
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.9f).dp
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = maxHeight)
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(Brush.linearGradient(listOf(Color(0xF53C3256), Color(0xFA202024)), start = Offset(0f, 0f), end = Offset(1400f, 2400f)))
            .padding(start = 14.dp, end = 14.dp, top = 10.dp)
    ) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(5.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.4f))
        )
        Text(
            "Player controls", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 30.sp,
            modifier = Modifier.padding(start = 4.dp, top = 14.dp)
        )
        // Twelve tiles can be taller than a small screen, so the grid scrolls.
        Column(
            Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(top = 12.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            tiles.chunked(2).forEach { row ->
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    row.forEach { tile -> ControlTileView(tile, Modifier.weight(1f)) }
                    if (row.size == 1) Spacer(Modifier.weight(1f))
                }
            }
        }
    }
}

@Composable
private fun ControlTileView(tile: ControlTile, modifier: Modifier) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier
            .alpha(if (tile.enabled) 1f else 0.45f)
            .height(78.dp)
            .clip(shape)
            .background(Color.White.copy(alpha = 0.07f))
            .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
            .clickable(onClick = tile.onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
            NeedleIconView(tile.icon, Palette.Text, size = 16.dp)
        }
        Column {
            Text(tile.label, color = Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (tile.sub != null) {
                Text(tile.sub, color = Palette.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** "1.0x", "1.25x", "1.5x" */
fun speedText(v: Float): String {
    val t = "%.2f".format(v).trimEnd('0')
    return (if (t.endsWith(".")) t + "0" else t) + "x"
}

/** Speed and pitch of this phone's player, 0.5x to 2x in steps of 0.05. */
@Composable
fun SpeedPitchDialog(speed: Float, pitch: Float, onChange: (speed: Float, pitch: Float) -> Unit, onDismiss: () -> Unit) {
    var s by remember { mutableFloatStateOf(speed) }
    var p by remember { mutableFloatStateOf(pitch) }
    fun snap(v: Float) = (v * 20f).roundToInt() / 20f

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Speed & pitch") },
        text = {
            Column {
                SliderRow("Speed", speedText(s), s) { s = snap(it); onChange(s, p) }
                Spacer(Modifier.height(8.dp))
                SliderRow("Pitch", speedText(p), p) { p = snap(it); onChange(s, p) }
                Text(
                    "Applies to this phone's playback.",
                    color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 10.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Palette.Accent) } },
        dismissButton = {
            TextButton(onClick = { s = 1f; p = 1f; onChange(1f, 1f) }) { Text("Reset", color = Palette.Muted) }
        }
    )
}

@Composable
private fun SliderRow(label: String, value: String, current: Float, onChange: (Float) -> Unit) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Palette.Text, fontSize = 15.sp)
            Text(value, color = Palette.Muted, fontSize = 15.sp)
        }
        Slider(
            value = current,
            onValueChange = onChange,
            valueRange = 0.5f..2f,
            steps = 29,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Palette.Accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
    }
}
