package app.needle.music.ui

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.InfiniteTransition
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.StartOffsetType
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.NeedleSettings
import app.needle.music.data.Song
import app.needle.music.playback.PlayerViewModel
import app.needle.music.playback.SleepTimer
import kotlinx.coroutines.delay

/*
 * Island dock (Settings > Customization > Navigation > "Island dock").
 *
 * At rest it is one small black capsule: the four places as round icons and the cover with a ring that fills as the song plays
 * (tap = Now playing, press and hold = play or pause). It takes almost no screen.
 * When something happens it opens upward for a few seconds, says what, and settles back:
 *   Track   a new song starts: what it is, with a Next button.
 *   Queue   "Added to queue" / "Plays next", with Undo and a line that counts down.
 *   Timer   the sleep timer started or was extended: the time left, with +5 min.
 *   Cast    casting started: the device, with Switch (opens Play on).
 * Swipe the open capsule down to put it away early. Selecting songs and Search keep the pages' own bars and fields.
 * Navigation style 4 (see effectiveNavStyle / usesIslandDock in Appearance.kt); NeedleDock draws it.
 */

/** One thing the Island has to tell. Track, Timer and Cast read their live values while shown; Queue carries what it needs for Undo. */
sealed class DockEvent(val id: Long, val lifeMs: Long) {
    class Track(id: Long) : DockEvent(id, 3300L)
    class Queued(id: Long, val songs: List<Song>, val next: Boolean, val onUndo: () -> Unit) : DockEvent(id, 2900L)
    class Timer(id: Long) : DockEvent(id, 3400L)
    class Cast(id: Long, val device: String) : DockEvent(id, 3400L)
}

/** Where events are posted. The newest one replaces the one being shown. */
object DockEvents {
    val current = mutableStateOf<DockEvent?>(null)
    private var counter = 0L

    private fun newId(): Long = ++counter

    fun track() { current.value = DockEvent.Track(newId()) }
    fun timer() { current.value = DockEvent.Timer(newId()) }
    fun cast(device: String) { current.value = DockEvent.Cast(newId(), device) }
    fun queued(songs: List<Song>, next: Boolean, onUndo: () -> Unit) {
        current.value = DockEvent.Queued(newId(), songs, next, onUndo)
    }
    fun dismiss() { current.value = null }
}

/**
 * Adds [songs] to the queue (or right after the current song) and tells the person: the Island dock answers with its Queue card
 * and an Undo, every other navigation with the toast [toast].
 */
internal fun announceQueue(context: Context, player: PlayerViewModel, songs: List<Song>, next: Boolean, toast: String) {
    if (songs.isEmpty()) return
    if (next) player.playNext(songs) else player.addToQueue(songs)
    if (usesIslandDock()) {
        DockEvents.queued(songs, next) { player.undoAdd(songs, next) }
    } else {
        Toast.makeText(context, toast, Toast.LENGTH_SHORT).show()
    }
}

private val IslandBlack = Color(0xFF0B0B0D)
private val IslandInk = Color(0xFF111111)
private val IslandDim = Color(0xFFA9A9AE)
private val IslandSub = Color(0xFFA9A9B4)

@Composable
internal fun IslandDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    onOpenCast: () -> Unit,
    modifier: Modifier = Modifier,
    castName: String? = null
) {
    val reduce = NeedleSettings.reduceMotion.value
    val event = DockEvents.current.value
    val expanded = event != null
    val hasMedia = player.hasMedia

    // The card fades out after the event is gone: keep what it showed for those few frames.
    val lastEvent = remember { arrayOfNulls<DockEvent>(1) }
    if (event != null) lastEvent[0] = event
    val shown = event ?: lastEvent[0]

    // ---- what makes the Island speak -----------------------------------------------------------------------------

    // A new song. Not when the app opens, and not when a saved queue is just restored (paused).
    val mediaId = player.currentMediaId
    val trackSeen = remember { arrayOfNulls<String>(1) }
    val trackFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(mediaId) {
        val before = trackSeen[0]
        trackSeen[0] = mediaId
        if (trackFirst[0]) {
            trackFirst[0] = false
        } else if (mediaId != null && mediaId != before && (before != null || player.isPlaying)) {
            DockEvents.track()
        }
    }

    // Casting started.
    val castFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(castName) {
        if (castFirst[0]) castFirst[0] = false
        else if (castName != null) DockEvents.cast(castName)
    }

    // The sleep timer started or was extended, and again when a minute is left.
    val timerMode = SleepTimer.mode.value
    val timerTotal = SleepTimer.totalMs.longValue
    val timerFirst = remember { booleanArrayOf(true) }
    LaunchedEffect(timerMode, timerTotal) {
        if (timerFirst[0]) timerFirst[0] = false
        else if (timerMode != SleepTimer.Mode.OFF) DockEvents.timer()
    }
    val lastMinute by remember {
        derivedStateOf {
            SleepTimer.mode.value == SleepTimer.Mode.TIME && !SleepTimer.finishing.value &&
                SleepTimer.remainingMs.longValue in 1L..60_000L
        }
    }
    LaunchedEffect(lastMinute) { if (lastMinute) DockEvents.timer() }

    // Leaving the screen (another navigation style, a page that hides the dock) drops what it was about to say.
    DisposableEffect(Unit) { onDispose { DockEvents.dismiss() } }

    // It settles back by itself.
    LaunchedEffect(event?.id) {
        val e = event ?: return@LaunchedEffect
        delay(e.lifeMs)
        if (DockEvents.current.value?.id == e.id) DockEvents.dismiss()
    }

    // ---- shape ---------------------------------------------------------------------------------------------------

    BoxWithConstraints(modifier.fillMaxWidth()) {
        val wide = if (maxWidth > 362.dp) 362.dp else maxWidth
        val restWidth = if (hasMedia) (if (maxWidth > 262.dp) 262.dp else maxWidth) else 206.dp
        val targetWidth = if (expanded) wide else restWidth
        val targetHeight = if (expanded) 122.dp else 60.dp
        val openRadius = when (NeedleSettings.cornerStyle.intValue) {
            0 -> 10.dp
            1 -> 20.dp
            else -> 30.dp
        }
        val targetRadius = if (expanded) openRadius else 30.dp

        // A touch more spring than the Morph dock: the capsule pops open.
        val dockW by animateDpAsState(targetWidth, shapeSpec(reduce), label = "islandWidth")
        val dockH by animateDpAsState(targetHeight, shapeSpec(reduce), label = "islandHeight")
        val radius by animateDpAsState(targetRadius, shapeSpec(reduce), label = "islandRadius")
        val glow by animateFloatAsState(if (expanded) 1f else 0f, tween(600), label = "islandGlow")

        val h = maxOf(dockH, 0.dp)
        val r = minOf(maxOf(radius, 0.dp), h / 2)
        val shape = RoundedCornerShape(r)
        val shadowColor = lerp(Color.Black.copy(alpha = 0.6f), Palette.Accent.copy(alpha = 0.34f), glow)

        Box(
            Modifier
                .align(Alignment.BottomCenter)
                .size(maxOf(dockW, 0.dp), h)
                .shadow((14f + 8f * glow).dp, shape, ambientColor = shadowColor, spotColor = shadowColor)
                .clip(shape)
                .background(IslandBlack)
                .border(1.dp, Color.White.copy(alpha = 0.13f), shape)
                // Swipe the open capsule down to put it away.
                .pointerInput(expanded) {
                    var total = 0f
                    detectVerticalDragGestures(
                        onDragStart = { total = 0f },
                        onDragCancel = { total = 0f },
                        onDragEnd = {
                            if (expanded && total > 22.dp.toPx()) DockEvents.dismiss()
                            total = 0f
                        },
                        onVerticalDrag = { _, dy -> total += dy }
                    )
                }
        ) {
            val track = shown as? DockEvent.Track
            val queued = shown as? DockEvent.Queued
            val timer = shown as? DockEvent.Timer
            val cast = shown as? DockEvent.Cast

            DockLayer(
                visible = expanded && track != null, reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(62.dp)
            ) { TrackCard(player, reduce, onOpenPlayer) }

            DockLayer(
                visible = expanded && queued != null, reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(62.dp)
            ) { if (queued != null) QueuedCard(queued) }

            DockLayer(
                visible = expanded && timer != null, reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(62.dp)
            ) { TimerCard() }

            DockLayer(
                visible = expanded && cast != null, reduce = reduce,
                modifier = Modifier.align(Alignment.TopCenter).fillMaxWidth().height(62.dp)
            ) { if (cast != null) CastCard(cast, reduce, onOpenCast) }

            // The four places and the cover ring: always there, at the foot of the capsule.
            Row(
                Modifier.align(Alignment.BottomCenter).fillMaxWidth().height(58.dp).padding(horizontal = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Destination.dock.forEach { dest ->
                    IslandTab(dest, dest == selected.dockSlot, reduce) { onSelect(dest) }
                }
                if (hasMedia) {
                    Box(Modifier.width(1.dp).height(26.dp).background(Color.White.copy(alpha = 0.14f)))
                    IslandRing(player, casting = castName != null, reduce = reduce, onOpen = onOpenPlayer)
                }
            }
        }
    }
}

// ---- the places ------------------------------------------------------------------------------------------------------

@Composable
private fun IslandTab(dest: Destination, isSelected: Boolean, reduce: Boolean, onClick: () -> Unit) {
    val haptic = LocalHapticFeedback.current
    val ms = if (reduce) 120 else 350
    val bg by animateColorAsState(if (isSelected) Color.White else Color.Transparent, tween(ms), label = "islandTabBg")
    val ink by animateColorAsState(if (isSelected) IslandInk else IslandDim, tween(ms), label = "islandTabInk")
    Box(
        Modifier
            .size(44.dp)
            .said(dest.label)
            .pressable({
                if (!isSelected) haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                onClick()
            })
            .clip(CircleShape)
            .background(bg),
        contentAlignment = Alignment.Center
    ) {
        NeedleIconView(dest.icon, tint = ink)
    }
}

/** Tap and press-and-hold on one thing, with the same soft squeeze as the other buttons. */
@OptIn(ExperimentalFoundationApi::class)
@Composable
private fun Modifier.pressableHold(onClick: () -> Unit, onLongClick: () -> Unit): Modifier {
    val source = remember { MutableInteractionSource() }
    val pressed by source.collectIsPressedAsState()
    val haptic = LocalHapticFeedback.current
    val squeeze by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = androidx.compose.animation.core.spring(dampingRatio = 0.55f, stiffness = 500f),
        label = "islandRingPress"
    )
    return this
        .graphicsLayer {
            scaleX = squeeze
            scaleY = squeeze
        }
        .combinedClickable(
            interactionSource = source,
            indication = null,
            onClick = onClick,
            onLongClick = {
                haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                onLongClick()
            }
        )
}

/**
 * The cover in a ring that fills as the song plays. Tap opens Now playing, press and hold plays or pauses.
 * Paused shows a small pause mark on the cover; casting sends a soft pulse out of the ring.
 */
@Composable
private fun IslandRing(vm: PlayerViewModel, casting: Boolean, reduce: Boolean, onOpen: () -> Unit) {
    val position = rememberLivePositionMs(vm, poll = true)
    val accent = Palette.Accent
    val pulse: State<Float>? = if (casting && !reduce) {
        rememberInfiniteTransition(label = "islandCastPulse").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(1800, easing = LinearEasing)),
            label = "pulse"
        )
    } else null
    val paused = !vm.isPlaying
    Box(
        Modifier
            .size(44.dp)
            .said(if (paused) "Open the player. Press and hold to play" else "Open the player. Press and hold to pause")
            .pressableHold(onOpen) { vm.togglePlay() }
            .drawBehind {
                val stroke = 3.dp.toPx()
                val p = pulse?.value
                if (p != null) {
                    drawCircle(
                        accent.copy(alpha = 0.6f * (1f - p)),
                        radius = (this.size.minDimension / 2f) * (1f + 0.8f * p),
                        style = Stroke(2.dp.toPx())
                    )
                }
                drawCircle(Color.White.copy(alpha = 0.16f), style = Stroke(stroke))
                val f = fractionOf(vm, position.value)
                if (f > 0f) {
                    drawArc(
                        accent, -90f, 360f * f, false,
                        topLeft = Offset(stroke / 2, stroke / 2),
                        size = Size(this.size.width - stroke, this.size.height - stroke),
                        style = Stroke(stroke, cap = StrokeCap.Round)
                    )
                }
            }
            .padding(5.dp)
            .clip(CircleShape)
    ) {
        MorphCover(vm, Modifier.fillMaxSize())
        if (paused) {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Color.Black.copy(alpha = 0.42f))
                    .drawBehind {
                        val bar = this.size.width * 0.12f
                        val tall = this.size.height * 0.36f
                        val top = (this.size.height - tall) / 2f
                        val gap = this.size.width * 0.09f
                        val left = this.size.width / 2f - gap - bar
                        val right = this.size.width / 2f + gap
                        drawRoundRect(Color.White, Offset(left, top), Size(bar, tall), CornerRadius(bar / 2f))
                        drawRoundRect(Color.White, Offset(right, top), Size(bar, tall), CornerRadius(bar / 2f))
                    }
            )
        }
    }
}

// ---- the cards -------------------------------------------------------------------------------------------------------

@Composable
private fun CardRow(modifier: Modifier = Modifier, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        modifier.fillMaxSize().padding(horizontal = 14.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** A round button on a card: white-on-grey circle (Next) or a text pill (Undo, +5 min, Switch). */
@Composable
private fun CardPill(label: String, onClick: () -> Unit) {
    Box(
        Modifier
            .height(36.dp)
            .said(label)
            .pressable(onClick, pressedScale = 0.94f)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.14f))
            .padding(horizontal = 15.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = Color.White, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, softWrap = false)
    }
}

@Composable
private fun TrackCard(vm: PlayerViewModel, reduce: Boolean, onOpenPlayer: () -> Unit) {
    val accent = Palette.Accent
    CardRow(
        Modifier.clickable(interactionSource = remember { MutableInteractionSource() }, indication = null, onClick = onOpenPlayer)
    ) {
        IslandEq(accent, still = reduce)
        Column(Modifier.weight(1f)) {
            Text(
                "NOW PLAYING", color = accent, fontSize = 10.5.sp, fontWeight = FontWeight.SemiBold,
                letterSpacing = 0.7.sp, lineHeight = 14.sp, maxLines = 1
            )
            Text(
                vm.title ?: "", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.artist ?: "", color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Box(
            Modifier
                .size(40.dp)
                .said("Next song")
                .pressable(vm::next)
                .clip(CircleShape)
                .background(Color.White.copy(alpha = 0.12f)),
            contentAlignment = Alignment.Center
        ) {
            SkipGlyph(Color.White)
        }
    }
}

@Composable
private fun QueuedCard(ev: DockEvent.Queued) {
    val accent = Palette.Accent
    val first = ev.songs.firstOrNull()?.title.orEmpty()
    val title = if (ev.next) "Plays next" else "Added to queue"
    val line = when {
        ev.songs.size == 1 && ev.next -> "$first plays after this song"
        ev.songs.size == 1 -> "$first is at the end of the queue"
        ev.next -> "${ev.songs.size} songs play after this song"
        else -> "${ev.songs.size} songs are at the end of the queue"
    }
    // The line along the foot shrinks away while the card waits: that is how long Undo stays.
    val left = remember(ev.id) { Animatable(1f) }
    LaunchedEffect(ev.id) {
        left.snapTo(1f)
        delay(300)
        left.animateTo(0f, tween(2600, easing = LinearEasing))
    }
    Box(Modifier.fillMaxSize()) {
        CardRow {
            Box(
                Modifier.size(38.dp).clip(CircleShape).background(accent),
                contentAlignment = Alignment.Center
            ) {
                NeedleIconView(NeedleIcon.CHECK, IslandInk, size = 20.dp)
            }
            Column(Modifier.weight(1f)) {
                Text(
                    title, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    line, color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            CardPill("Undo") {
                ev.onUndo()
                DockEvents.dismiss()
            }
        }
        Box(
            Modifier
                .align(Alignment.BottomStart)
                .padding(start = 14.dp, end = 14.dp, bottom = 2.dp)
                .fillMaxWidth()
                .height(2.dp)
                .drawBehind { drawRect(accent, size = Size(this.size.width * left.value, this.size.height)) }
        )
    }
}

@Composable
private fun TimerCard() {
    val accent = Palette.Accent
    val mode = SleepTimer.mode.value
    val remaining = SleepTimer.remainingMs.longValue
    val total = SleepTimer.totalMs.longValue
    val fraction = if (mode == SleepTimer.Mode.TIME && total > 0L) (remaining.toFloat() / total).coerceIn(0f, 1f) else 1f
    val line = when (mode) {
        SleepTimer.Mode.TIME -> if (SleepTimer.finishing.value) "Finishing this song" else "Music stops in ${SleepTimer.clock(remaining)}"
        SleepTimer.Mode.SONG -> "Music stops after this song"
        SleepTimer.Mode.ALBUM -> "Music stops after this album"
        SleepTimer.Mode.OFF -> "The timer is off"
    }
    CardRow {
        Box(Modifier.size(40.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(40.dp)) {
                val stroke = 3.dp.toPx()
                drawCircle(Color.White.copy(alpha = 0.16f), radius = (this.size.minDimension - stroke) / 2f, style = Stroke(stroke))
                drawArc(
                    accent, -90f, 360f * fraction, false,
                    topLeft = Offset(stroke / 2, stroke / 2),
                    size = Size(this.size.width - stroke, this.size.height - stroke),
                    style = Stroke(stroke, cap = StrokeCap.Round)
                )
            }
            NeedleIconView(NeedleIcon.TIMER, accent, size = 18.dp)
        }
        Column(Modifier.weight(1f)) {
            Text(
                "Sleep timer", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1
            )
            Text(line, color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (mode == SleepTimer.Mode.TIME) CardPill("+5 min") { SleepTimer.addMinutes(5) }
    }
}

@Composable
private fun CastCard(ev: DockEvent.Cast, reduce: Boolean, onOpenCast: () -> Unit) {
    val accent = Palette.Accent
    // Two rings spread out of the icon, half a beat apart.
    val transition = rememberInfiniteTransition(label = "castCard")
    val ringA = transition.animateFloat(0f, 1f, infiniteRepeatable(tween(1800, easing = LinearEasing)), label = "ringA")
    val ringB = transition.animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(1800, easing = LinearEasing), initialStartOffset = StartOffset(900, StartOffsetType.FastForward)),
        label = "ringB"
    )
    CardRow {
        Box(
            Modifier
                .size(38.dp)
                .drawBehind {
                    if (!reduce) {
                        for (p in listOf(ringA.value, ringB.value)) {
                            drawCircle(
                                accent.copy(alpha = 0.7f * (1f - p)),
                                radius = (this.size.minDimension / 2f) * (1f + 0.9f * p),
                                style = Stroke(2.dp.toPx())
                            )
                        }
                    }
                    drawCircle(accent.copy(alpha = 0.2f))
                },
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(NeedleIcon.CAST, accent, size = 20.dp)
        }
        Column(Modifier.weight(1f)) {
            Text(
                ev.device, color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, lineHeight = 20.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text("Casting from this phone", color = IslandSub, fontSize = 12.sp, lineHeight = 16.sp, maxLines = 1)
        }
        CardPill("Switch", onOpenCast)
    }
}

// ---- small drawings --------------------------------------------------------------------------------------------------

@Composable
private fun islandBar(transition: InfiniteTransition, offsetMs: Int): State<Float> =
    transition.animateFloat(
        initialValue = 5f,
        targetValue = 24f,
        animationSpec = infiniteRepeatable(
            tween(800, easing = FastOutSlowInEasing),
            RepeatMode.Reverse,
            StartOffset(offsetMs, StartOffsetType.FastForward)
        ),
        label = "eqBar"
    )

/** Four bars that dance while the song starts. Still (and a little uneven) with Reduce motion. */
@Composable
private fun IslandEq(color: Color, still: Boolean) {
    val transition = rememberInfiniteTransition(label = "islandEq")
    val a = islandBar(transition, 0)
    val b = islandBar(transition, 250)
    val c = islandBar(transition, 500)
    val d = islandBar(transition, 100)
    Canvas(Modifier.size(28.dp, 26.dp)) {
        val heights = if (still) listOf(10f, 18f, 14f, 22f) else listOf(a.value, b.value, c.value, d.value)
        val barW = 4.dp.toPx()
        val gap = 3.dp.toPx()
        heights.forEachIndexed { i, hDp ->
            val hPx = hDp.dp.toPx()
            drawRoundRect(
                color,
                topLeft = Offset(i * (barW + gap), (this.size.height - hPx) / 2f),
                size = Size(barW, hPx),
                cornerRadius = CornerRadius(barW / 2f)
            )
        }
    }
}

/** "Next song": a triangle with a bar, from the mockup's 24 x 24 grid. */
@Composable
private fun SkipGlyph(color: Color, glyph: Dp = 18.dp) {
    Canvas(Modifier.size(glyph)) {
        val k = this.size.width / 24f
        val tri = Path().apply {
            moveTo(6f * k, 5f * k)
            lineTo(6f * k, 19f * k)
            lineTo(15f * k, 12f * k)
            close()
        }
        drawPath(tri, color)
        drawLine(color, Offset(18.5f * k, 5f * k), Offset(18.5f * k, 19f * k), strokeWidth = 1.8f * k, cap = StrokeCap.Round)
    }
}
