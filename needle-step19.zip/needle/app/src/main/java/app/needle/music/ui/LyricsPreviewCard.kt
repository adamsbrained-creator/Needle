package app.needle.music.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.SizeTransform
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.LrcParser
import app.needle.music.data.LyricsPrefs
import app.needle.music.data.LyricsQuery
import app.needle.music.data.LyricsViewModel
import app.needle.music.playback.PlayerViewModel

private val CardTop = Color(0xFF4B3A72)
private val CardBottom = Color(0xFF34304A)
private val DimLine = Color.White.copy(alpha = 0.5f)

/**
 * The "Lyrics preview" card from the Now Playing mockup: three lines (the two before the one being sung, then the
 * one being sung, big and serif) and a "Show lyrics" button. Tapping the card opens the full Lyrics page.
 * It uses the same [LyricsViewModel] as the Lyrics page, so both always show the same lyrics.
 */
@Composable
fun LyricsPreviewCard(
    player: PlayerViewModel,
    lyricsVm: LyricsViewModel,
    onOpen: () -> Unit,
    modifier: Modifier = Modifier
) {
    val songId = player.currentMediaId?.toLongOrNull()
    // The song that is playing decides which lyrics to load (does nothing if they are already loaded).
    LaunchedEffect(songId, player.title) {
        if (songId != null) {
            lyricsVm.load(LyricsQuery(songId, player.title.orEmpty(), player.artist.orEmpty(), player.album.orEmpty(), player.durationMs))
        }
    }

    val state = lyricsVm.state
    // For one frame after a song change the state can still belong to the previous song.
    val ready = songId != null && state.songId == songId && !state.loading
    val lyrics = if (ready) state.lyrics else null

    // Only the lines with words; the blank separators between verses are not shown in a 3-line preview.
    val lines = remember(lyrics) { lyrics?.lines?.filter { it.text.isNotEmpty() }.orEmpty() }
    val synced = lyrics?.synced == true
    // Moves on every frame (Now Playing already polls the player; this fills in between).
    val livePos = rememberLivePositionMs(player, poll = false)
    val active by remember(lines, synced, songId) {
        derivedStateOf {
            if (synced) LrcParser.activeIndex(lines, livePos.value + LYRICS_LEAD_MS - LyricsPrefs.offsetMs(songId ?: -1L)) else -1
        }
    }

    Column(
        modifier
            .fillMaxWidth()
            .animateContentSize()
            .clip(RoundedCornerShape(28.dp))
            .background(Brush.linearGradient(0f to CardTop, 0.7f to CardBottom, 1f to CardBottom))
            .clickable(onClick = onOpen)
            .padding(18.dp)
    ) {
        Text("Lyrics preview", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)

        when {
            !ready -> Text(
                "Looking for lyrics…",
                color = DimLine, fontSize = 15.sp, modifier = Modifier.padding(top = 14.dp, bottom = 8.dp)
            )
            lines.isEmpty() -> {
                Text(
                    "No lyrics yet",
                    color = Color.White, fontFamily = FontFamily.Serif, fontSize = 24.sp,
                    modifier = Modifier.padding(top = 18.dp)
                )
                Text(
                    if (state.searching) "Searching online…"
                    else if (LyricsPrefs.onlineSearch.value) "Open Lyrics to search online or write your own."
                    else "Open Lyrics to write your own.",
                    color = DimLine, fontSize = 13.sp, lineHeight = 18.sp,
                    modifier = Modifier.padding(top = 6.dp, bottom = 8.dp)
                )
            }
            else -> AnimatedContent(
                targetState = active,
                // Old and new lines move together (no blank moment in between), like the lyrics page scrolling.
                transitionSpec = {
                    (slideInVertically(tween(280, easing = FastOutSlowInEasing)) { it / 4 } + fadeIn(tween(220))) togetherWith
                        (slideOutVertically(tween(280, easing = FastOutSlowInEasing)) { -it / 4 } + fadeOut(tween(160))) using
                        SizeTransform(clip = false)
                },
                label = "lyricsPreview"
            ) { a ->
                // Show the two lines before the current one. At the very start there are none, so the first lines show.
                // (coerceIn keeps this safe while an old song's lines are still fading out.)
                val start = (if (a >= 0) a - 2 else 0).coerceIn(0, maxOf(0, lines.size - 1))
                val shown = lines.subList(start, minOf(start + 3, lines.size))
                Column {
                    shown.forEachIndexed { i, line ->
                        val on = synced && start + i == a
                        when {
                            on -> Text(
                                line.text,
                                color = Color.White, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium,
                                fontSize = 27.sp, lineHeight = 31.sp,
                                maxLines = 3, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(vertical = 22.dp)
                            )
                            synced -> Text(
                                line.text,
                                color = DimLine, fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium,
                                fontSize = 19.sp, lineHeight = 24.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 14.dp)
                            )
                            // Plain lyrics have no timing, so nothing is highlighted.
                            else -> Text(
                                line.text,
                                color = Color.White.copy(alpha = 0.85f), fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium,
                                fontSize = 19.sp, lineHeight = 24.sp,
                                maxLines = 2, overflow = TextOverflow.Ellipsis,
                                modifier = Modifier.padding(top = 14.dp)
                            )
                        }
                    }
                }
            }
        }

        Box(
            Modifier
                .padding(top = 6.dp)
                .height(42.dp)
                .clip(CircleShape)
                .background(Color.White)
                .clickable(onClick = onOpen)
                .padding(horizontal = 20.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                if (ready && lines.isEmpty()) "Find lyrics" else "Show lyrics",
                color = Color(0xFF111111), fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold
            )
        }
    }
}
