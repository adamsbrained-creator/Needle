plugins {
    alias(libs.plugins.android.application) apply false
    alias(libs.plugins.kotlin.compose) apply false
    alias(libs.plugins.ksp) apply false
    // kotlin.android is NOT applied: AGP 9+ has built-in Kotlin support.
}
