# Reference implementation of the file-tag reader (the Kotlin version is a line-by-line port of this).
import struct, re, sys, json

FIELDS = ["ALBUMARTIST","COMPOSER","CONDUCTOR","LYRICIST","MIXARTIST","ORIGARTIST","ORIGLYRICIST","NARRATOR","INVOLVEDPEOPLE","MUSICIANCREDITS",
 "TITLESORT","ARTISTSORT","ALBUMSORT","ALBUMARTISTSORT","COMPOSERSORT","DISCNUMBER","SUBTITLE","SETSUBTITLE","GROUPING","CONTENTGROUP","COMPILATION","WORK","MOVEMENTNAME","MOVEMENT","MOVEMENTTOTAL",
 "RELEASETIME","ORIGYEAR","ORIGALBUM","COMMENT","DESCRIPTION","MOOD","BPM","INITIALKEY","LANGUAGE","UNSYNCEDLYRICS","RATING","PUBLISHER","COPYRIGHT","CATALOGNUMBER","BARCODE","ISRC","MEDIATYPE",
 "ACOUSTID_ID","ACOUSTID_FINGERPRINT","MUSICBRAINZ_ALBUMARTISTID","MUSICBRAINZ_ALBUMID","MUSICBRAINZ_ALBUMRELEASECOUNTRY","MUSICBRAINZ_ALBUMSTATUS","MUSICBRAINZ_ALBUMTYPE","MUSICBRAINZ_ARTISTID","MUSICBRAINZ_DISCID","MUSICBRAINZ_ORIGINALALBUMID","MUSICBRAINZ_ORIGINALARTISTID","MUSICBRAINZ_RELEASEGROUPID","MUSICBRAINZ_RELEASETRACKID","MUSICBRAINZ_TRACKID","MUSICBRAINZ_TRMID","MUSICBRAINZ_WORKID","UNIQUEFILEID",
 "ITUNESALBUMID","ITUNESARTISTID","ITUNESCATALOGID","ITUNESCOMPOSERID","ITUNESCOUNTRYID","ITUNESGENREID",
 "WWW","WWWARTIST","WWWAUDIOFILE","WWWAUDIOSOURCE","WWWCOMMERCIALINFO","WWWCOPYRIGHT","WWWPAYMENT","WWWPUBLISHER","WWWRADIOPAGE"]
def norm(s): return ''.join(c for c in s.upper() if c.isalnum())
BY_NORM = {norm(k): k for k in FIELDS}
ALIASES = {"REMIXER":"MIXARTIST","MIXARTIST":"MIXARTIST","ORIGINALARTIST":"ORIGARTIST","ORIGINALLYRICIST":"ORIGLYRICIST","DISCSUBTITLE":"SETSUBTITLE",
 "LYRICS":"UNSYNCEDLYRICS","UNSYNCEDLYRICS":"UNSYNCEDLYRICS","ORGANIZATION":"PUBLISHER","LABEL":"PUBLISHER","RELEASEDATE":"RELEASETIME",
 "ORIGINALDATE":"ORIGYEAR","ORIGINALYEAR":"ORIGYEAR","ORIGINALALBUM":"ORIGALBUM","KEY":"INITIALKEY","TEMPO":"BPM","MEDIA":"MEDIATYPE","CATALOG":"CATALOGNUMBER","LABELNO":"CATALOGNUMBER",
 "PERFORMER":None}
def map_named(name):
    n = norm(name)
    if n in ALIASES: return ALIASES[n]
    return BY_NORM.get(n)

def clean(key, value):
    value = value.strip().strip('\x00')
    if not value: return None
    if key == "ORIGYEAR":
        m = re.match(r'\d{4}', value); return m.group(0) if m else None
    if key == "RATING":
        try: r = int(value)
        except: return None
        if r <= 0: return None
        return str(r) if r <= 5 else str(min(5, max(1, round(r/20))))
    return value

# ---------------------------------------------------------------- ID3v2
def synchsafe(b): return (b[0]<<21)|(b[1]<<14)|(b[2]<<7)|b[3]
def unsync(b): return b.replace(b'\xff\x00', b'\xff')
def decode_text(enc, b):
    if enc == 0: return b.decode('latin-1')
    if enc == 1:
        if b[:2] == b'\xff\xfe': return b[2:].decode('utf-16-le', 'replace')
        if b[:2] == b'\xfe\xff': return b[2:].decode('utf-16-be', 'replace')
        return b.decode('utf-16-le','replace')
    if enc == 2: return b.decode('utf-16-be', 'replace')
    return b.decode('utf-8', 'replace')
def split_terminated(enc, b):
    """split b at the first terminator for the encoding -> (before, after)"""
    if enc in (1, 2):
        i = 0
        while i + 1 < len(b):
            if b[i] == 0 and b[i+1] == 0 and i % 2 == 0: return b[:i], b[i+2:]
            i += 1
        return b, b''
    i = b.find(b'\x00')
    return (b, b'') if i < 0 else (b[:i], b[i+1:])
def split_values(enc, b):
    """all null-separated strings"""
    out = []; rest = b
    while True:
        s, rest2 = split_terminated(enc, rest)
        out.append(decode_text(enc, s))
        if len(rest2) == 0 or rest2 is rest: break
        rest = rest2
    return [x for x in out if x != '']
TEXT = {"TPE2":"ALBUMARTIST","TCOM":"COMPOSER","TPE3":"CONDUCTOR","TEXT":"LYRICIST","TPE4":"MIXARTIST","TOPE":"ORIGARTIST","TOLY":"ORIGLYRICIST",
 "TSOT":"TITLESORT","TSOP":"ARTISTSORT","TSOA":"ALBUMSORT","TSO2":"ALBUMARTISTSORT","TSOC":"COMPOSERSORT","TPOS":"DISCNUMBER","TIT3":"SUBTITLE","TSST":"SETSUBTITLE",
 "GRP1":"GROUPING","TIT1":"CONTENTGROUP","TCMP":"COMPILATION","MVNM":"MOVEMENTNAME","TDRL":"RELEASETIME","TOAL":"ORIGALBUM","TMOO":"MOOD","TBPM":"BPM","TKEY":"INITIALKEY",
 "TLAN":"LANGUAGE","TPUB":"PUBLISHER","TCOP":"COPYRIGHT","TSRC":"ISRC","TMED":"MEDIATYPE","TORY":"ORIGYEAR","TDOR":"ORIGYEAR"}
URLS = {"WOAR":"WWWARTIST","WOAF":"WWWAUDIOFILE","WOAS":"WWWAUDIOSOURCE","WCOM":"WWWCOMMERCIALINFO","WCOP":"WWWCOPYRIGHT","WPAY":"WWWPAYMENT","WPUB":"WWWPUBLISHER","WORS":"WWWRADIOPAGE"}

def popm_rating(r):
    if r == 0: return None
    return 1 if r <= 31 else 2 if r <= 95 else 3 if r <= 159 else 4 if r <= 223 else 5

def read_id3(f):
    head = f.read(10)
    if len(head) < 10 or head[:3] != b'ID3': return {}
    ver = head[3]; flags = head[5]; size = synchsafe(head[6:10])
    if ver not in (3, 4) or size > 16*1024*1024: return {}
    body = f.read(size)
    if len(body) < size: body = body
    if ver == 3 and flags & 0x80: body = unsync(body)
    pos = 0
    if flags & 0x40:  # extended header
        if len(body) < 4: return {}
        ext = synchsafe(body[:4]) if ver == 4 else struct.unpack('>I', body[:4])[0] + 4
        pos = ext
    out = {}
    def put(k, v, first_wins=True):
        v = clean(k, v)
        if v is None: return
        if k in out and first_wins: return
        out[k] = v
    while pos + 10 <= len(body):
        fid = body[pos:pos+4]
        if fid[0] == 0: break
        try: fid_s = fid.decode('ascii')
        except: break
        if ver == 4: fsize = synchsafe(body[pos+4:pos+8])
        else: fsize = struct.unpack('>I', body[pos+4:pos+8])[0]
        fflags = body[pos+8:pos+10]
        pos += 10
        if fsize <= 0 or pos + fsize > len(body): break
        data = body[pos:pos+fsize]; pos += fsize
        if ver == 4:
            f_unsync = bool(fflags[1] & 0x02) or bool(flags & 0x80)
            has_dli = bool(fflags[1] & 0x01)
            compressed = bool(fflags[1] & 0x08); encrypted = bool(fflags[1] & 0x04)
            if compressed or encrypted: continue
            if has_dli: data = data[4:]
            if f_unsync: data = unsync(data)
        else:
            if fflags[1] & 0xC0: continue   # compressed / encrypted
            if fflags[1] & 0x20: data = data[1:]  # grouping id byte
        if not data: continue
        if fid_s in TEXT:
            enc = data[0]; vals = split_values(enc, data[1:])
            key = TEXT[fid_s]
            if not vals: continue
            if key == "ORIGYEAR": put(key, vals[0])
            else: put(key, '; '.join(vals))
        elif fid_s == "MVIN":
            enc = data[0]; vals = split_values(enc, data[1:])
            if vals:
                a, _, b = vals[0].partition('/')
                put("MOVEMENT", a); put("MOVEMENTTOTAL", b)
        elif fid_s in ("TIPL", "TMCL", "IPLS"):
            enc = data[0]; vals = split_values(enc, data[1:])
            pairs = []
            for i in range(0, len(vals) - 1, 2): pairs.append(vals[i] + ':' + vals[i+1])
            put("MUSICIANCREDITS" if fid_s == "TMCL" else "INVOLVEDPEOPLE", ';'.join(pairs))
        elif fid_s == "TXXX":
            enc = data[0]; d, rest = split_terminated(enc, data[1:])
            key = map_named(decode_text(enc, d))
            if key: put(key, '; '.join(split_values(enc, rest)))
        elif fid_s == "COMM":
            if len(data) < 5: continue
            enc = data[0]; d, rest = split_terminated(enc, data[4:])
            if decode_text(enc, d) == '': put("COMMENT", decode_text(enc, rest))
        elif fid_s == "USLT":
            if len(data) < 5: continue
            enc = data[0]; _, rest = split_terminated(enc, data[4:])
            put("UNSYNCEDLYRICS", decode_text(enc, rest))
        elif fid_s == "POPM":
            _, rest = split_terminated(0, data)
            if rest: 
                r = popm_rating(rest[0])
                if r: put("RATING", str(r))
        elif fid_s in URLS:
            put(URLS[fid_s], data.split(b'\x00')[0].decode('latin-1'))
        elif fid_s == "WXXX":
            enc = data[0]; _, rest = split_terminated(enc, data[1:])
            put("WWW", rest.split(b'\x00')[0].decode('latin-1'))
        elif fid_s == "UFID":
            owner, rest = split_terminated(0, data)
            if owner.decode('latin-1') == "http://musicbrainz.org": put("MUSICBRAINZ_TRACKID", rest.decode('latin-1'))
    return out

# ---------------------------------------------------------------- Vorbis comments
def parse_vorbis_comments(b):
    out = {}
    if len(b) < 8: return out
    p = 0
    vlen = struct.unpack('<I', b[p:p+4])[0]; p += 4 + vlen
    if p + 4 > len(b): return out
    n = struct.unpack('<I', b[p:p+4])[0]; p += 4
    for _ in range(n):
        if p + 4 > len(b): break
        l = struct.unpack('<I', b[p:p+4])[0]; p += 4
        if l > len(b) - p: break
        item = b[p:p+l].decode('utf-8', 'replace'); p += l
        k, eq, v = item.partition('=')
        if not eq: continue
        key = map_named(k)
        if not key: continue
        v = clean(key, v)
        if v is None: continue
        out[key] = out[key] + '; ' + v if key in out else v
    return out

def read_flac(f):
    if f.read(4) != b'fLaC': return {}
    while True:
        h = f.read(4)
        if len(h) < 4: return {}
        last = h[0] & 0x80; typ = h[0] & 0x7f; ln = (h[1]<<16)|(h[2]<<8)|h[3]
        if typ == 4:
            if ln > 16*1024*1024: return {}
            return parse_vorbis_comments(f.read(ln))
        f.seek(ln, 1)
        if last: return {}

def read_ogg(f):
    packets = []; cur = bytearray(); total = 0
    while len(packets) < 2:
        hdr = f.read(27)
        if len(hdr) < 27 or hdr[:4] != b'OggS': return {}
        nseg = hdr[26]; segs = f.read(nseg)
        if len(segs) < nseg: return {}
        for s in segs:
            chunk = f.read(s); total += s
            cur += chunk
            if s < 255: packets.append(bytes(cur)); cur = bytearray()
            if len(packets) >= 2: break
        if total > 8*1024*1024: return {}
    c = packets[1]
    if c[:7] == b'\x03vorbis': return parse_vorbis_comments(c[7:])
    if c[:8] == b'OpusTags': return parse_vorbis_comments(c[8:])
    return {}

# ---------------------------------------------------------------- MP4
MP4_TEXT = {"aART":"ALBUMARTIST","\u00a9wrt":"COMPOSER","\u00a9grp":"GROUPING","\u00a9cmt":"COMMENT","desc":"DESCRIPTION","\u00a9lyr":"UNSYNCEDLYRICS","cprt":"COPYRIGHT",
 "soal":"ALBUMSORT","soaa":"ALBUMARTISTSORT","soar":"ARTISTSORT","sonm":"TITLESORT","soco":"COMPOSERSORT","\u00a9mvn":"MOVEMENTNAME","\u00a9wrk":"WORK"}
def be(b):
    return int.from_bytes(b, 'big')
def read_box_header(f, end):
    pos = f.tell()
    if pos + 8 > end: return None
    h = f.read(8)
    if len(h) < 8: return None
    size = struct.unpack('>I', h[:4])[0]; typ = h[4:8].decode('latin-1'); hl = 8
    if size == 1:
        size = struct.unpack('>Q', f.read(8))[0]; hl = 16
    elif size == 0: size = end - pos
    if size < hl or pos + size > end: return None
    return typ, pos + hl, pos + size
def find_child(f, start, end, want):
    f.seek(start)
    while f.tell() < end:
        h = read_box_header(f, end)
        if h is None: return None
        typ, ds, de = h
        if typ == want: return ds, de
        f.seek(de)
    return None
def read_mp4(f):
    f.seek(0, 2); fsize = f.tell(); f.seek(0)
    h = f.read(12)
    if len(h) < 12 or h[4:8] != b'ftyp': return {}
    moov = find_child(f, 0, fsize, "moov")
    if not moov: return {}
    udta = find_child(f, moov[0], moov[1], "udta")
    if not udta: return {}
    meta = find_child(f, udta[0], udta[1], "meta")
    if not meta: return {}
    ilst = find_child(f, meta[0] + 4, meta[1], "ilst")   # meta is a full box: 4 bytes version/flags
    if not ilst: return {}
    out = {}
    def put(k, v):
        v = clean(k, v)
        if v is not None and k not in out: out[k] = v
    f.seek(ilst[0])
    while f.tell() < ilst[1]:
        h = read_box_header(f, ilst[1])
        if h is None: break
        typ, ds, de = h
        if typ == "covr": f.seek(de); continue
        if de - ds > 8*1024*1024: f.seek(de); continue
        mean = name = None; datas = []
        f.seek(ds)
        while f.tell() < de:
            ch = read_box_header(f, de)
            if ch is None: break
            ct, cs, ce = ch
            payload = f.read(ce - cs)
            if ct == "mean": mean = payload[4:].decode('utf-8', 'replace')
            elif ct == "name": name = payload[4:].decode('utf-8', 'replace')
            elif ct == "data": datas.append((be(payload[0:4]) & 0xFFFFFF, payload[8:]))
            f.seek(ce)
        f.seek(de)
        if not datas: continue
        flags, val = datas[0]
        def text(): return val.decode('utf-8', 'replace')
        if typ in MP4_TEXT: put(MP4_TEXT[typ], text())
        elif typ == "cpil": put("COMPILATION", "1" if val and val[-1] else "")
        elif typ == "tmpo" and val: put("BPM", str(be(val[-2:] if len(val) >= 2 else val)))
        elif typ == "disk" and len(val) >= 6:
            d = be(val[2:4]); t = be(val[4:6])
            if d > 0: put("DISCNUMBER", f"{d}/{t}" if t > 0 else str(d))
        elif typ == "\u00a9mvi" and val: put("MOVEMENT", str(be(val)))
        elif typ == "\u00a9mvc" and val: put("MOVEMENTTOTAL", str(be(val)))
        elif typ == "----" and name:
            key = map_named(name)
            if key: put(key, text())
    return out

def read_tags(path):
    with open(path, 'rb') as f:
        magic = f.read(12); f.seek(0)
        if magic[:3] == b'ID3': return read_id3(f)
        if magic[:4] == b'fLaC': return read_flac(f)
        if magic[:4] == b'OggS': return read_ogg(f)
        if magic[4:8] == b'ftyp': return read_mp4(f)
    return {}

if __name__ == '__main__':
    for p in sys.argv[1:]:
        print(p, json.dumps(read_tags(p), ensure_ascii=False, indent=1, sort_keys=True))
