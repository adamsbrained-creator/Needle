#!/bin/bash
set -e
SINE=(-loglevel error -f lavfi -i "sine=frequency=440:duration=1")
META=(-metadata title="Test Title é" -metadata artist="The Artist" -metadata album="The Album" -metadata album_artist="Album Artist Ü" -metadata composer="Comp One" -metadata genre="Rock" -metadata date="2021-05-04" -metadata track="3/9" -metadata disc="1/2" -metadata comment="A comment here" -metadata lyrics="Line one
Line two" -metadata performer="Conductor Name" -metadata publisher="Label X" -metadata copyright="(c) 2021" -metadata TBPM=128 -metadata TMOO=Happy -metadata TKEY=Am -metadata TSRC=USRC17607839 -metadata TSOP="Artist, The" -metadata TSOT="Title Sort" -metadata TSOA="Album Sort" -metadata TLAN=eng)
ffmpeg "${SINE[@]}" "${META[@]}" -id3v2_version 3 -write_id3v1 1 t23.mp3
ffmpeg "${SINE[@]}" "${META[@]}" -id3v2_version 4 t24.mp3
ffmpeg "${SINE[@]}" -metadata title="Test Title é" -metadata artist="The Artist" -metadata album="The Album" -metadata ALBUMARTIST="Album Artist Ü" -metadata COMPOSER="Comp One" -metadata CONDUCTOR="Conductor Name" -metadata MOOD=Happy -metadata BPM=128 -metadata MUSICBRAINZ_ALBUMID=abc-123 -metadata ISRC=USRC17607839 -metadata COMMENT="A comment here" -metadata LYRICS="Line one
Line two" -metadata DISCNUMBER="1/2" -metadata COMPILATION=1 -metadata ARTISTSORT="Artist, The" t.flac
ffmpeg "${SINE[@]}" -c:a libvorbis -metadata title="Test Title é" -metadata artist="The Artist" -metadata ALBUMARTIST="Album Artist Ü" -metadata COMPOSER="Comp One" -metadata MOOD=Happy t.ogg || echo NO_VORBIS
ffmpeg "${SINE[@]}" -c:a libopus -metadata title="Test Title é" -metadata ALBUMARTIST="Album Artist Ü" -metadata COMPOSER="Comp One" -metadata MOOD=Happy t.opus || echo NO_OPUS
ffmpeg "${SINE[@]}" -c:a aac -movflags use_metadata_tags -metadata title="Test Title é" -metadata artist="The Artist" -metadata album="The Album" -metadata album_artist="Album Artist Ü" -metadata composer="Comp One" -metadata genre="Rock" -metadata date="2021" -metadata track="3/9" -metadata disc="1/2" -metadata comment="A comment here" -metadata lyrics="Line one" -metadata grouping="Group G" -metadata copyright="(c) 2021" -metadata MOOD=Happy -metadata CONDUCTOR="Conductor Name" -metadata MUSICBRAINZ_ALBUMID=abc-123 t.m4a
ffmpeg "${SINE[@]}" -c:a aac -metadata title="Plain" -metadata album_artist="AA" -metadata composer="CC" -metadata disc="2/3" t2.m4a
