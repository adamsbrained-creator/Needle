import subprocess, json, sys, os
from refwrite import write_file
from ref import read_tags

def md5(path):
    r = subprocess.run(['ffmpeg','-v','error','-i',path,'-map','0:a:0','-c','copy','-f','md5','-'],capture_output=True,text=True)
    return r.stdout.strip() or ('ERR '+r.stderr.strip()[:200])
def decode_ok(path):
    r = subprocess.run(['ffmpeg','-v','error','-i',path,'-f','null','-'],capture_output=True,text=True)
    return r.stderr.strip()
def probe(path):
    r = subprocess.run(['ffprobe','-v','error','-show_entries','format_tags','-of','json',path],capture_output=True,text=True)
    try: return json.loads(r.stdout).get('format',{}).get('tags',{})
    except Exception: return {'ERR': r.stderr[:200]}
def streams(path):
    r = subprocess.run(['ffprobe','-v','error','-show_entries','stream=codec_type,codec_name','-of','csv=p=0',path],capture_output=True,text=True)
    return r.stdout.split()

cover = open('cover.jpg','rb').read()
CORE = {"TITLE":"New Title é","ARTIST":"New Artist","ALBUM":"New Album","GENRE":"Jazz","YEAR":"1999","TRACK":"7"}
EXTRAS = {"ALBUMARTIST":"AA Ünïcode","COMPOSER":"Comp Z","COMMENT":"Hello\nworld","UNSYNCEDLYRICS":"[00:01.00]Line","BPM":"99","MOOD":"Calm","RATING":"4",
 "DISCNUMBER":"2/3","COMPILATION":"1","MUSICBRAINZ_ALBUMID":"mb-1","CATALOGNUMBER":"CAT-1","TITLESORT":"Sort Title","WWWARTIST":"http://a.example","INVOLVEDPEOPLE":"producer:Bob;engineer:Al",
 "MOVEMENT":"2","MOVEMENTTOTAL":"4","MYCUSTOM":"custom value","DESCRIPTION":"An album description","ORIGYEAR":"1977","LANGUAGE":"eng"}
files = sys.argv[1:] or ['t23.mp3','t24.mp3','b24.mp3','b23u.mp3','t.flac','pic.flac','t2.m4a','hand.m4a']
bad = 0
for f in files:
    out = 'w_' + f
    try:
        write_file(f, out, CORE, EXTRAS, cover)
    except Exception as e:
        print(f, 'WRITE ERROR', repr(e)); bad += 1; continue
    a, b = md5(f), md5(out)
    dec = decode_ok(out)
    got = read_tags(out)
    p = probe(out)
    missing = {k: v for k, v in EXTRAS.items() if k in ("ALBUMARTIST","COMPOSER","COMMENT","BPM","MOOD","DISCNUMBER","COMPILATION","MUSICBRAINZ_ALBUMID","TITLESORT","WWWARTIST","DESCRIPTION","ORIGYEAR","LANGUAGE","UNSYNCEDLYRICS","CATALOGNUMBER","INVOLVEDPEOPLE","MOVEMENT","MOVEMENTTOTAL") and got.get(k) != v}
    st = streams(out)
    print(f"{f:10} audio_md5_same={a==b} decode_errors={'none' if not dec else dec[:120]!r} streams={st}")
    print("   ffprobe title/artist/album/genre/date/track:", {k: p.get(k) or p.get(k.upper()) for k in ('title','artist','album','genre','date','track')})
    print("   reader mismatches:", missing)
    if a != b or dec or missing: bad += 1
print("PROBLEMS:", bad)
