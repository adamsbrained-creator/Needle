import struct, subprocess, json
from ref import read_tags

def ss(n): return bytes([(n>>21)&0x7f,(n>>14)&0x7f,(n>>7)&0x7f,n&0x7f])
def unsync_enc(b):
    out = bytearray()
    for i, c in enumerate(b):
        out.append(c)
        if c == 0xFF and (i + 1 == len(b) or b[i+1] >= 0xE0 or b[i+1] == 0): out.append(0)
    return bytes(out)
def t(enc, s):
    if enc == 0: return bytes([0]) + s.encode('latin-1')
    if enc == 1: return bytes([1]) + b'\xff\xfe' + s.encode('utf-16-le')
    if enc == 3: return bytes([3]) + s.encode('utf-8')
def term(enc): return b'\x00\x00' if enc == 1 else b'\x00'
def frame(ver, fid, data, fflags=b'\x00\x00'):
    size = ss(len(data)) if ver == 4 else struct.pack('>I', len(data))
    return fid.encode() + size + fflags + data
def tag(ver, frames, hflags=0, ext=None):
    body = b''.join(frames)
    if ext: body = ext + body
    return b'ID3' + bytes([ver, 0, hflags]) + ss(len(body)) + body + b'\x00' * 20

def write(name, data): open(name, 'wb').write(data + b'\xff\xfb\x90\x00' * 8)

# ---- v2.4, UTF-8 / UTF-16, many frame kinds
f = []
v=4
f.append(frame(v,'COMM', bytes([3])+b'eng'+b'\x00'+'Nice song ✓'.encode()))
f.append(frame(v,'COMM', bytes([3])+b'eng'+b'iTunNORM\x00'+b' 000001AB'))
f.append(frame(v,'USLT', bytes([1])+b'eng'+b'\xff\xfe\x00\x00'+b'\xff\xfe'+'Zeile eins\nZeile zwei é'.encode('utf-16-le')))
f.append(frame(v,'POPM', b'user@x\x00'+bytes([196])+b'\x00\x00\x00\x05'))
f.append(frame(v,'TIPL', bytes([3])+b'producer\x00Bob\x00engineer\x00Alice\x00'))
f.append(frame(v,'TMCL', bytes([3])+b'drums\x00Dan\x00bass\x00Ben\x00'))
f.append(frame(v,'WXXX', bytes([0])+b'\x00http://example.com/a'))
f.append(frame(v,'WOAR', b'http://artist.example'))
f.append(frame(v,'UFID', b'http://musicbrainz.org\x00abcd-1234'))
f.append(frame(v,'MVIN', t(3,'2/5')))
f.append(frame(v,'MVNM', t(3,'Allegro')))
f.append(frame(v,'TXXX', bytes([3])+b'MusicBrainz Album Id\x00'+b'mb-album-1'))
f.append(frame(v,'TXXX', bytes([3])+b'Acoustid Id\x00'+b'acoust-1'))
f.append(frame(v,'TXXX', bytes([3])+b'SOMETHING ELSE\x00'+b'ignored'))
f.append(frame(v,'TXXX', bytes([3])+b'LABEL\x00'+b'Indie Label'))
f.append(frame(v,'TCMP', t(3,'1')))
f.append(frame(v,'TDOR', t(3,'1999-03-04')))
f.append(frame(v,'TPE2', bytes([3])+b'Alpha\x00Beta\x00'))
f.append(frame(v,'GRP1', t(3,'My Group')))
f.append(frame(v,'TIT1', t(3,'Content Group')))
write('b24.mp3', tag(4, f))

# ---- v2.3 whole-tag unsync (FF FE BOM in UTF-16 text gets a 00 inserted)
f = []
v=3
f.append(frame(v,'TPE2', t(1,'Ünsynced Artist')))
f.append(frame(v,'TCOM', t(1,'Çomposer')))
f.append(frame(v,'COMM', bytes([1])+b'eng'+b'\xff\xfe\x00\x00'+b'\xff\xfe'+'unsynced comment'.encode('utf-16-le')))
f.append(frame(v,'IPLS', bytes([0])+b'mixer\x00Zed\x00'))
f.append(frame(v,'TORY', t(0,'1987')))
f.append(frame(v,'TBPM', t(0,'96')))
body = b''.join(f)
data = b'ID3' + bytes([3,0,0x80]) + ss(len(unsync_enc(body))) + unsync_enc(body) + b'\x00'*10
write('b23u.mp3', data)

# ---- v2.3 with extended header (size 6, flags 2 bytes, padding 4 bytes)
f = [frame(3,'TPE2', t(0,'Ext Header Artist')), frame(3,'TCOM', t(0,'Ext Comp'))]
ext = struct.pack('>I', 6) + b'\x00\x00' + struct.pack('>I', 0)
write('b23e.mp3', tag(3, f, hflags=0x40, ext=ext))

# ---- v2.4 per-frame unsync + data length indicator
txt = bytes([1]) + b'\xff\xfe' + 'Frame Unsync Åuthor'.encode('utf-16-le')
raw = unsync_enc(txt)
dli = ss(len(txt))
fr = frame(4, 'TPE2', dli + raw, fflags=b'\x00\x03')   # unsync + data length indicator
write('b24u.mp3', tag(4, [fr, frame(4,'TCOM', t(3,'After Frame'))]))

# ---- ogg/opus with a huge comment (spans many pages)
big = 'L' * 100000
for codec, ext_ in (('libvorbis','ogg'),('libopus','opus')):
    subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi','-i','sine=frequency=440:duration=1','-c:a',codec,'-metadata','COMPOSER=Big Comp','-metadata','LYRICS='+big,'-metadata','MOOD=After Big',f'big.{ext_}'],check=True)
# ---- flac with a picture block before the comments
subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi','-i','color=c=red:s=64x64:d=1','-frames:v','1','cover.png'],check=True)
subprocess.run(['ffmpeg','-loglevel','error','-y','-f','lavfi','-i','sine=frequency=440:duration=1','-i','cover.png','-map','0','-map','1','-c:a','flac','-c:v','copy','-disposition:v','attached_pic','-metadata','COMPOSER=Pic Comp','-metadata','ALBUMARTIST=Pic AA','pic.flac'],check=True)

# ---- MP4 (iTunes style) built by hand: freeform atoms, covr, disk, cpil, tmpo; moov AFTER mdat
def box(typ, payload): return struct.pack('>I', len(payload)+8) + typ + payload
def data_box(flags, val): return box(b'data', struct.pack('>I', flags) + b'\x00\x00\x00\x00' + val)
def item(typ, flags, val): return box(typ, data_box(flags, val))
def free(mean, name, val):
    return box(b'----', box(b'mean', b'\x00\x00\x00\x00'+mean.encode()) + box(b'name', b'\x00\x00\x00\x00'+name.encode()) + data_box(1, val.encode()))
ilst = b''.join([
  item(b'\xa9nam',1,'Song'.encode()), item(b'aART',1,'MP4 Album Artist ñ'.encode()), item(b'\xa9wrt',1,'MP4 Composer'.encode()),
  item(b'covr',13,b'\xff\xd8'+b'J'*50000), item(b'disk',0,b'\x00\x00\x00\x02\x00\x04\x00\x00'),
  item(b'cpil',21,b'\x01'), item(b'tmpo',21,struct.pack('>H',140)), item(b'\xa9cmt',1,'mp4 comment'.encode()),
  item(b'\xa9lyr',1,'la la la'.encode()), item(b'soar',1,'Sort, Artist'.encode()),
  free('com.apple.iTunes','MusicBrainz Album Id','mb-mp4-1'), free('com.apple.iTunes','CONDUCTOR','Maestro'), free('com.apple.iTunes','MOOD','Calm'),
  free('com.apple.iTunes','iTunNORM','000'),
  item(b'\xa9mvi',21,b'\x03'), item(b'\xa9mvn',1,'Largo'.encode()), item(b'\xa9wrk',1,'Opus 1'.encode())])
meta = box(b'meta', b'\x00\x00\x00\x00' + box(b'hdlr', b'\x00'*8 + b'mdir' + b'\x00'*13) + box(b'ilst', ilst))
moov = box(b'moov', box(b'mvhd', b'\x00'*100) + box(b'trak', b'\x00'*3000) + box(b'udta', meta))
ftyp = box(b'ftyp', b'M4A \x00\x00\x00\x00M4A mp42isom')
mdat = box(b'mdat', b'\x00' * 20000)
open('hand.m4a','wb').write(ftyp + mdat + moov)

for n in ['b24.mp3','b23u.mp3','b23e.mp3','b24u.mp3','big.ogg','big.opus','pic.flac','hand.m4a']:
    r = read_tags(n)
    if 'UNSYNCEDLYRICS' in r and len(r['UNSYNCEDLYRICS'])>100: r['UNSYNCEDLYRICS'] = f"<{len(r['UNSYNCEDLYRICS'])} chars>"
    print(n, json.dumps(r, ensure_ascii=False, sort_keys=True))
