#!/bin/bash
set -e
S=(-loglevel error -y -f lavfi -i "sine=frequency=440:duration=3")
ffmpeg "${S[@]}" -c:a aac -movflags +faststart -metadata title="Fast" -metadata artist="Fa" -metadata comment="old comment" f_fast.m4a
ffmpeg "${S[@]}" -i cover.jpg -map 0 -map 1 -c:a aac -c:v copy -disposition:v attached_pic -metadata title="Covered" -metadata album="Alb" c_cover.m4a
ffmpeg "${S[@]}" -i cover.jpg -map 0 -map 1 -c:a aac -c:v copy -disposition:v attached_pic -movflags +faststart -metadata title="FastCover" fc_cover.m4a
ffmpeg "${S[@]}" -write_id3v2 0 -write_id3v1 0 -c:a libmp3lame notag.mp3
ffmpeg "${S[@]}" -i cover.jpg -map 0 -map 1 -c:a libmp3lame -c:v copy -id3v2_version 3 -metadata title="Has Cover" -metadata artist="Old A" apic23.mp3
ffmpeg "${S[@]}" -i cover.jpg -map 0 -map 1 -c:a libmp3lame -c:v copy -id3v2_version 4 -metadata title="Has Cover4" apic24.mp3
ffmpeg "${S[@]}" -c:a flac -metadata title="Plain flac" -metadata artist="Fl" -metadata TRACKNUMBER=5 -metadata TRACKTOTAL=12 plain.flac
