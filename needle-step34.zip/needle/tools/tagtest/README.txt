Test tools for the tag reader and writer (not part of the app build).
ref.py        reference tag reader (FileTagReader.kt is a port of it)
refwrite.py   reference tag writer for MP3, FLAC and M4A (FileTagWriter.kt is a port of it)
gen.sh, gen2.sh, build_tests.py   make test files with ffmpeg and by hand
test_write.py writes tags into the test files, then checks with ffmpeg that the audio is byte for byte the same,
              the file still decodes, and the tags read back.
Run: bash gen.sh && bash gen2.sh && python3 build_tests.py && python3 test_write.py
