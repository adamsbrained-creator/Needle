# Reference implementation of the tag writers (MP3/ID3v2, FLAC, M4A). The Kotlin version is a port of this.
import struct, re
from ref import FIELDS, norm, BY_NORM

# ---- shared ------------------------------------------------------------------------------
PRETTY = {  # names Picard / Mp3tag use for TXXX descriptions and iTunes freeform names
 "MUSICBRAINZ_ALBUMARTISTID":"MusicBrainz Album Artist Id","MUSICBRAINZ_ALBUMID":"MusicBrainz Album Id",
 "MUSICBRAINZ_ALBUMRELEASECOUNTRY":"MusicBrainz Album Release Country","MUSICBRAINZ_ALBUMSTATUS":"MusicBrainz Album Status",
 "MUSICBRAINZ_ALBUMTYPE":"MusicBrainz Album Type","MUSICBRAINZ_ARTISTID":"MusicBrainz Artist Id","MUSICBRAINZ_DISCID":"MusicBrainz Disc Id",
 "MUSICBRAINZ_ORIGINALALBUMID":"MusicBrainz Original Album Id","MUSICBRAINZ_ORIGINALARTISTID":"MusicBrainz Original Artist Id",
 "MUSICBRAINZ_RELEASEGROUPID":"MusicBrainz Release Group Id","MUSICBRAINZ_RELEASETRACKID":"MusicBrainz Release Track Id",
 "MUSICBRAINZ_TRMID":"MusicBrainz TRM Id","MUSICBRAINZ_WORKID":"MusicBrainz Work Id","ACOUSTID_ID":"Acoustid Id","ACOUSTID_FINGERPRINT":"Acoustid Fingerprint"}
def ss(n): return bytes([(n>>21)&0x7f,(n>>14)&0x7f,(n>>7)&0x7f,n&0x7f])
def unss(b): return (b[0]<<21)|(b[1]<<14)|(b[2]<<7)|b[3]
def unsync(b): return b.replace(b'\xff\x00', b'\xff')

# ================================================================ ID3v2
ID3_TEXT = {"ALBUMARTIST":"TPE2","COMPOSER":"TCOM","CONDUCTOR":"TPE3","LYRICIST":"TEXT","MIXARTIST":"TPE4","ORIGARTIST":"TOPE","ORIGLYRICIST":"TOLY",
 "TITLESORT":"TSOT","ARTISTSORT":"TSOP","ALBUMSORT":"TSOA","ALBUMARTISTSORT":"TSO2","COMPOSERSORT":"TSOC","DISCNUMBER":"TPOS","SUBTITLE":"TIT3","SETSUBTITLE":"TSST",
 "GROUPING":"GRP1","CONTENTGROUP":"TIT1","COMPILATION":"TCMP","MOVEMENTNAME":"MVNM","ORIGALBUM":"TOAL","MOOD":"TMOO","BPM":"TBPM","INITIALKEY":"TKEY",
 "LANGUAGE":"TLAN","PUBLISHER":"TPUB","COPYRIGHT":"TCOP","ISRC":"TSRC","MEDIATYPE":"TMED"}
ID3_URL = {"WWWARTIST":"WOAR","WWWAUDIOFILE":"WOAF","WWWAUDIOSOURCE":"WOAS","WWWCOMMERCIALINFO":"WCOM","WWWCOPYRIGHT":"WCOP","WWWPAYMENT":"WPAY","WWWPUBLISHER":"WPUB","WWWRADIOPAGE":"WORS"}
V23_ONLY_UNSUPPORTED = {"RELEASETIME"}   # TDRL does not exist in 2.3

def parse_id3(data):
    """-> (version, [ [id, flags(2 bytes), data] ... ], audio_start). No tag: (None, [], 0)."""
    if data[:3] != b'ID3': return None, [], 0
    ver = data[3]; flags = data[5]; size = unss(data[6:10])
    if ver not in (3, 4): raise ValueError("unsupported ID3v2.%d" % ver)
    audio = 10 + size + (10 if ver == 4 and flags & 0x10 else 0)
    body = data[10:10+size]
    if ver == 3 and flags & 0x80: body = unsync(body)
    pos = 0
    if flags & 0x40:
        pos = unss(body[:4]) if ver == 4 else struct.unpack('>I', body[:4])[0] + 4
    frames = []
    while pos + 10 <= len(body) and body[pos] != 0:
        fid = body[pos:pos+4].decode('latin-1')
        fsz = unss(body[pos+4:pos+8]) if ver == 4 else struct.unpack('>I', body[pos+4:pos+8])[0]
        fl = bytearray(body[pos+8:pos+10]); pos += 10
        if fsz <= 0 or pos + fsz > len(body): break
        d = body[pos:pos+fsz]; pos += fsz
        if ver == 4 and not (fl[1] & 0x0C):          # normalise 2.4 frames: drop unsync / length indicator
            if fl[1] & 0x01: d = d[4:]
            if fl[1] & 0x02 or flags & 0x80: d = unsync(d)
            fl[1] &= ~0x03
        frames.append([fid, bytes(fl), d])
    return ver, frames, audio

def enc_text(ver, s):
    """-> (encoding byte, bytes)"""
    if ver == 4: return 3, s.encode('utf-8')
    try: return 0, s.encode('latin-1')
    except UnicodeEncodeError: return 1, b'\xff\xfe' + s.encode('utf-16-le')
def term(e): return b'\x00\x00' if e == 1 else b'\x00'
def text_frame(ver, s):
    e, b = enc_text(ver, s); return bytes([e]) + b
def desc_frame(ver, lang, desc, text, fid=None):
    # encoding must be the same for desc and text
    e = 0 if ver == 3 else 3
    if ver == 3:
        try: desc.encode('latin-1'); text.encode('latin-1')
        except UnicodeEncodeError: e = 1
    def enc(s):
        if e == 0: return s.encode('latin-1')
        if e == 3: return s.encode('utf-8')
        return b'\xff\xfe' + s.encode('utf-16-le')
    return e, enc(desc), enc(text)
def comm_like(ver, desc, text):
    e, d, t = desc_frame(ver, None, desc, text)
    return bytes([e]) + b'eng' + d + term(e) + t
def txxx(ver, desc, text):
    e, d, t = desc_frame(ver, None, desc, text)
    return bytes([e]) + d + term(e) + t
def wxxx(ver, url):
    return bytes([0]) + b'\x00' + url.encode('latin-1', 'replace')
def list_frame(ver, items):
    if ver == 4: return bytes([3]) + b'\x00'.join(i.encode('utf-8') for i in items)
    try:
        return bytes([0]) + b'\x00'.join(i.encode('latin-1') for i in items)
    except UnicodeEncodeError:
        return bytes([1]) + b'\x00\x00'.join(b'\xff\xfe' + i.encode('utf-16-le') for i in items)
def popm(stars):
    b = {1:1, 2:64, 3:128, 4:196, 5:255}[stars]
    return b'Windows Media Player 9 Series\x00' + bytes([b]) + b'\x00\x00\x00\x00'
def apic(jpeg):
    return b'\x00' + b'image/jpeg\x00' + b'\x03' + b'\x00' + jpeg

def write_id3(data, core, extras, cover):
    ver, frames, audio = parse_id3(data)
    new_tag = ver is None
    if new_tag: ver = 4
    def drop(*ids): 
        frames[:] = [f for f in frames if f[0] not in ids]
    def put(fid, payload): frames.append([fid, b'\x00\x00', payload])
    def old_text(fid):
        for f in frames:
            if f[0] == fid and f[2]:
                e = f[2][0]; b = f[2][1:]
                try:
                    if e == 0: return b.decode('latin-1')
                    if e == 3: return b.decode('utf-8')
                    if e == 1: return b[2:].decode('utf-16-le') if b[:2] == b'\xff\xfe' else b[2:].decode('utf-16-be')
                    return b.decode('utf-16-be')
                except Exception: return ''
        return ''
    # ---- core
    for k, fid in (("TITLE","TIT2"),("ARTIST","TPE1"),("ALBUM","TALB"),("GENRE","TCON")):
        if k in core: drop(fid); put(fid, text_frame(ver, core[k]))
    if "YEAR" in core:
        fid = "TDRC" if ver == 4 else "TYER"
        drop("TDRC","TYER","TDAT","TIME","TRDA"); put(fid, text_frame(ver, core["YEAR"]))
    if "TRACK" in core:
        total = old_text("TRCK").partition('/')[2]
        drop("TRCK"); put("TRCK", text_frame(ver, core["TRACK"] + ('/' + total if total else '')))
    # ---- extras
    mvn = {}
    for key, val in extras.items():
        if key not in ("MUSICBRAINZ_TRACKID",):
            # a leftover TXXX that means the same thing would win over our new frame when reading
            frames[:] = [f for f in frames if not (f[0] == "TXXX" and BY_NORM.get(norm(desc_of(f[2], True))) == key
                                                    and key not in PRETTY)]
        if key in ID3_TEXT:
            fid = ID3_TEXT[key]; drop(fid); put(fid, text_frame(ver, val))
        elif key in ("ORIGYEAR",):
            drop("TORY","TDOR"); put("TDOR" if ver == 4 else "TORY", text_frame(ver, val))
        elif key == "RELEASETIME" and ver == 4:
            drop("TDRL"); put("TDRL", text_frame(ver, val))
        elif key == "COMMENT":
            frames[:] = [f for f in frames if not (f[0] == "COMM" and desc_of(f[2]) == '')]
            put("COMM", comm_like(ver, '', val))
        elif key == "UNSYNCEDLYRICS":
            frames[:] = [f for f in frames if not (f[0] == "USLT" and desc_of(f[2]) == '')]
            put("USLT", comm_like(ver, '', val))
        elif key == "RATING":
            drop("POPM"); put("POPM", popm(int(val)))
        elif key in ID3_URL:
            drop(ID3_URL[key]); put(ID3_URL[key], val.encode('latin-1', 'replace'))
        elif key == "WWW":
            frames[:] = [f for f in frames if not (f[0] == "WXXX" and desc_of(f[2]) == '')]
            put("WXXX", wxxx(ver, val))
        elif key in ("MOVEMENT", "MOVEMENTTOTAL"):
            mvn[key] = val
        elif key in ("INVOLVEDPEOPLE", "MUSICIANCREDITS"):
            items = []
            for pair in val.split(';'):
                if ':' in pair:
                    r, _, p = pair.partition(':'); items += [r.strip(), p.strip()]
            if key == "INVOLVEDPEOPLE":
                drop("TIPL","IPLS"); put("TIPL" if ver == 4 else "IPLS", list_frame(ver, items))
            elif ver == 4:
                drop("TMCL"); put("TMCL", list_frame(ver, items))
            else:
                put_txxx(frames, ver, key, val)
        elif key == "MUSICBRAINZ_TRACKID":
            frames[:] = [f for f in frames if not (f[0] == "UFID" and f[2].startswith(b'http://musicbrainz.org\x00'))]
            put("UFID", b'http://musicbrainz.org\x00' + val.encode('latin-1', 'replace'))
        else:
            put_txxx(frames, ver, PRETTY.get(key, key), val)
    if mvn:
        old = old_text("MVIN").partition('/')
        n = mvn.get("MOVEMENT", old[0]); t = mvn.get("MOVEMENTTOTAL", old[2])
        drop("MVIN"); put("MVIN", text_frame(ver, n + ('/' + t if t else '')))
    if cover:
        frames[:] = [f for f in frames if not (f[0] == "APIC" and apic_type(f[2]) in (0, 3))]   # the front cover (or an untyped picture)
        put("APIC", apic(cover))
    # ---- serialise
    body = b''
    for fid, fl, d in frames:
        size = ss(len(d)) if ver == 4 else struct.pack('>I', len(d))
        body += fid.encode('latin-1') + size + fl + d
    body += b'\x00' * 1024
    tag = b'ID3' + bytes([ver, 0, 0]) + ss(len(body)) + body
    return tag + data[audio:]

def put_txxx(frames, ver, desc, val):
    frames[:] = [f for f in frames if not (f[0] == "TXXX" and norm(desc_of(f[2])) == norm(desc))]
    frames.append(["TXXX", b'\x00\x00', txxx(ver, desc, val)])

def desc_of(payload):
    """the description string of COMM/USLT/TXXX/WXXX style payload"""
    if not payload: return ''
    e = payload[0]
    rest = payload[4:] if len(payload) > 4 else b''   # COMM/USLT have a 3 byte language
    return _first_string(e, rest)
def _first_string(e, b):
    if e in (1, 2):
        i = 0
        while i + 1 < len(b):
            if b[i] == 0 and b[i+1] == 0: s = b[:i]; break
            i += 2
        else: s = b
        if s[:2] == b'\xff\xfe': return s[2:].decode('utf-16-le', 'replace')
        if s[:2] == b'\xfe\xff': return s[2:].decode('utf-16-be', 'replace')
        return s.decode('utf-16-le', 'replace') if e == 1 else s.decode('utf-16-be', 'replace')
    s = b.split(b'\x00')[0]
    return s.decode('latin-1' if e == 0 else 'utf-8', 'replace')
def apic_type(payload):
    e = payload[0]; rest = payload[1:]
    i = rest.find(b'\x00')
    return rest[i+1] if i >= 0 and i + 1 < len(rest) else -1

# NOTE: COMM/USLT payloads have the language bytes, TXXX/WXXX do not. desc_of() assumes the COMM layout,
# so TXXX descriptions are read with desc_of_txxx():
_old_desc_of = desc_of
def desc_of(payload, _txxx=False):
    if not payload: return ''
    e = payload[0]
    rest = payload[1:] if _txxx else payload[4:]
    return _first_string(e, rest)
def put_txxx(frames, ver, desc, val):
    frames[:] = [f for f in frames if not (f[0] == "TXXX" and norm(desc_of(f[2], True)) == norm(desc))]
    frames.append(["TXXX", b'\x00\x00', txxx(ver, desc, val)])

# ================================================================ FLAC
FLAC_NAME = {"MIXARTIST":"REMIXER","ORIGARTIST":"ORIGINALARTIST","ORIGLYRICIST":"ORIGINALLYRICIST","SETSUBTITLE":"DISCSUBTITLE","UNSYNCEDLYRICS":"LYRICS",
 "PUBLISHER":"LABEL","RELEASETIME":"RELEASEDATE","ORIGYEAR":"ORIGINALDATE","ORIGALBUM":"ORIGINALALBUM","INITIALKEY":"INITIALKEY","MEDIATYPE":"MEDIA"}
FLAC_ALIASES = {"UNSYNCEDLYRICS":["LYRICS","UNSYNCEDLYRICS"],"PUBLISHER":["LABEL","ORGANIZATION","PUBLISHER"],"MIXARTIST":["REMIXER","MIXARTIST"],
 "ORIGYEAR":["ORIGINALDATE","ORIGINALYEAR","ORIGYEAR"],"RELEASETIME":["RELEASEDATE","RELEASETIME"],"INITIALKEY":["INITIALKEY","KEY"],"BPM":["BPM","TEMPO"]}
def flac_names(key):
    primary = FLAC_NAME.get(key, key)
    return primary, [n.upper() for n in FLAC_ALIASES.get(key, [primary])] + [primary]
def valid_vorbis_key(k): return bool(k) and all(0x20 <= ord(c) <= 0x7d and c != '=' for c in k)

def parse_vorbis_raw(b):
    p = 0; vl = struct.unpack('<I', b[p:p+4])[0]; vendor = b[p+4:p+4+vl]; p += 4 + vl
    n = struct.unpack('<I', b[p:p+4])[0]; p += 4; items = []
    for _ in range(n):
        l = struct.unpack('<I', b[p:p+4])[0]; p += 4
        items.append(b[p:p+l].decode('utf-8', 'replace')); p += l
    return vendor, items
def build_vorbis(vendor, items):
    out = struct.pack('<I', len(vendor)) + vendor + struct.pack('<I', len(items))
    for it in items:
        e = it.encode('utf-8'); out += struct.pack('<I', len(e)) + e
    return out
def jpeg_size(b):
    i = 2
    while i < len(b):
        if b[i] != 0xFF: i += 1; continue
        m = b[i+1]
        if m in (0xC0,0xC1,0xC2): return struct.unpack('>HH', b[i+5:i+9])[::-1]
        i += 2 + struct.unpack('>H', b[i+2:i+4])[0]
    return (0, 0)
def flac_picture(jpeg):
    w, h = jpeg_size(jpeg)
    mime = b'image/jpeg'
    return struct.pack('>I', 3) + struct.pack('>I', len(mime)) + mime + struct.pack('>I', 0) + struct.pack('>IIII', w, h, 24, 0) + struct.pack('>I', len(jpeg)) + jpeg

def write_flac(data, core, extras, cover):
    if data[:4] != b'fLaC': raise ValueError("not flac")
    pos = 4; blocks = []
    while True:
        h = data[pos]; last = h & 0x80; typ = h & 0x7f; ln = int.from_bytes(data[pos+1:pos+4], 'big')
        blocks.append((typ, data[pos+4:pos+4+ln])); pos += 4 + ln
        if last: break
    audio = pos
    vendor = b'Needle'; items = []
    for typ, d in blocks:
        if typ == 4: vendor, items = parse_vorbis_raw(d)
    def setkey(names, value):
        items[:] = [i for i in items if i.split('=', 1)[0].upper() not in names]
        if value: items.append(names[-1] + '=' + value)
    for k, name in (("TITLE","TITLE"),("ARTIST","ARTIST"),("ALBUM","ALBUM"),("GENRE","GENRE"),("YEAR","DATE"),("TRACK","TRACKNUMBER")):
        if k in core: setkey([name], core[k])
    for key, val in extras.items():
        primary, names = flac_names(key)
        if not valid_vorbis_key(primary): continue
        setkey(names, val)
    out_blocks = []
    for typ, d in blocks:
        if typ in (4, 1): continue                                  # old comments, old padding
        if typ == 6 and cover and int.from_bytes(d[:4], 'big') in (0, 3): continue   # old front cover (or untyped picture)
        out_blocks.append((typ, d))
    out_blocks.append((4, build_vorbis(vendor, items)))
    if cover: out_blocks.append((6, flac_picture(cover)))
    out_blocks.append((1, b'\x00' * 4096))
    out = b'fLaC'
    for i, (typ, d) in enumerate(out_blocks):
        out += bytes([(0x80 if i == len(out_blocks) - 1 else 0) | typ]) + len(d).to_bytes(3, 'big') + d
    return out + data[audio:]

# ================================================================ MP4 / M4A
MP4_TEXT = {"ALBUMARTIST":"aART","COMPOSER":"\u00a9wrt","GROUPING":"\u00a9grp","COMMENT":"\u00a9cmt","DESCRIPTION":"desc","UNSYNCEDLYRICS":"\u00a9lyr","COPYRIGHT":"cprt",
 "ALBUMSORT":"soal","ALBUMARTISTSORT":"soaa","ARTISTSORT":"soar","TITLESORT":"sonm","COMPOSERSORT":"soco","MOVEMENTNAME":"\u00a9mvn","WORK":"\u00a9wrk"}
MP4_CORE = {"TITLE":"\u00a9nam","ARTIST":"\u00a9ART","ALBUM":"\u00a9alb","GENRE":"\u00a9gen","YEAR":"\u00a9day"}
def box(t, payload): return struct.pack('>I', len(payload) + 8) + t.encode('latin-1') + payload
def data_box(flags, val): return box('data', struct.pack('>I', flags) + b'\x00\x00\x00\x00' + val)
def item_text(t, s): return box(t, data_box(1, s.encode('utf-8')))
def item_free(name, s):
    return box('----', box('mean', b'\x00\x00\x00\x00' + b'com.apple.iTunes') + box('name', b'\x00\x00\x00\x00' + name.encode('utf-8')) + data_box(1, s.encode('utf-8')))

def read_boxes(b, start=0, end=None):
    """-> [(type, offset, size)] of the boxes between start and end"""
    end = len(b) if end is None else end; out = []; p = start
    while p + 8 <= end:
        size = struct.unpack('>I', b[p:p+4])[0]; t = b[p+4:p+8].decode('latin-1'); hl = 8
        if size == 1: size = struct.unpack('>Q', b[p+8:p+16])[0]; hl = 16
        elif size == 0: size = end - p
        if size < hl or p + size > end: break
        out.append((t, p, size)); p += size
    return out

def patch_offsets(moov, old_moov_pos, delta):
    """add delta to every stco/co64 chunk offset that points behind the old moov position"""
    m = bytearray(moov)
    def walk(start, end):
        for t, off, size in read_boxes(bytes(m), start, end):
            hl = 8
            if t in ('trak', 'mdia', 'minf', 'stbl'): walk(off + hl, off + size)
            elif t == 'stco':
                n = struct.unpack('>I', m[off+12:off+16])[0]
                for i in range(n):
                    q = off + 16 + 4 * i; v = struct.unpack('>I', m[q:q+4])[0]
                    if v >= old_moov_pos: struct.pack_into('>I', m, q, v + delta)
            elif t == 'co64':
                n = struct.unpack('>I', m[off+12:off+16])[0]
                for i in range(n):
                    q = off + 16 + 8 * i; v = struct.unpack('>Q', m[q:q+8])[0]
                    if v >= old_moov_pos: struct.pack_into('>Q', m, q, v + delta)
    walk(8, len(m))
    return bytes(m)

def write_mp4(data, core, extras, cover):
    tops = read_boxes(data)
    moov = next(((t, o, s) for t, o, s in tops if t == 'moov'), None)
    if not moov: raise ValueError("no moov")
    _, mo, ms = moov
    mb = data[mo:mo+ms]
    kids = read_boxes(mb, 8, len(mb))
    udta = next((k for k in kids if k[0] == 'udta'), None)
    meta_children = []; hdlr = None; items = []
    udta_other = b''
    if udta:
        ub = mb[udta[1]:udta[1]+udta[2]]
        for t, o, s in read_boxes(ub, 8, len(ub)):
            if t == 'meta':
                mm = ub[o:o+s]
                for t2, o2, s2 in read_boxes(mm, 12, len(mm)):
                    if t2 == 'ilst':
                        il = mm[o2:o2+s2]
                        items = [(t3, il[o3:o3+s3]) for t3, o3, s3 in read_boxes(il, 8, len(il))]
                    elif t2 == 'keys': raise ValueError("QuickTime-style (mdta) metadata is not supported")
                    elif t2 == 'hdlr': hdlr = mm[o2:o2+s2]
                    else: meta_children.append(mm[o2:o2+s2])
            else: udta_other += ub[o:o+s]
    if hdlr is None:
        hdlr = box('hdlr', b'\x00\x00\x00\x00' + b'\x00\x00\x00\x00' + b'mdir' + b'appl' + b'\x00' * 8 + b'\x00')
    def freeform_name(raw):
        for t, o, s in read_boxes(raw, 8, len(raw)):
            if t == 'name': return raw[o+12:o+s].decode('utf-8', 'replace')
        return ''
    def remove(typ=None, name=None):
        items[:] = [(t, r) for t, r in items if not ((typ and t == typ) or (name and t == '----' and norm(freeform_name(r)) == norm(name)))]
    def old_pair(typ):
        for t, r in items:
            if t == typ:
                for t2, o2, s2 in read_boxes(r, 8, len(r)):
                    if t2 == 'data': return r[o2+16:o2+s2]
        return b''
    for k, typ in MP4_CORE.items():
        if k in core:
            remove(typ); items.append((typ, item_text(typ, core[k])))
            if k == "GENRE": remove('gnre')
    if "TRACK" in core:
        old = old_pair('trkn'); total = struct.unpack('>H', old[4:6])[0] if len(old) >= 6 else 0
        remove('trkn'); items.append(('trkn', box('trkn', data_box(0, struct.pack('>HHHH', 0, int(core["TRACK"]), total, 0)))))
    for key, val in extras.items():
        if key in MP4_TEXT:
            t = MP4_TEXT[key]; remove(t); items.append((t, item_text(t, val)))
        elif key == "DISCNUMBER":
            d, _, t_ = val.partition('/'); d = int(d or 0); t_ = int(t_ or 0)
            remove('disk'); items.append(('disk', box('disk', data_box(0, struct.pack('>HHHH', 0, d, t_, 0)))))
        elif key == "COMPILATION":
            remove('cpil'); items.append(('cpil', box('cpil', data_box(21, b'\x01' if val not in ('0', '') else b'\x00'))))
        elif key == "BPM":
            remove('tmpo'); items.append(('tmpo', box('tmpo', data_box(21, struct.pack('>H', int(val))))))
        elif key in ("MOVEMENT", "MOVEMENTTOTAL"):
            t = "\u00a9mvi" if key == "MOVEMENT" else "\u00a9mvc"
            remove(t); items.append((t, box(t, data_box(21, struct.pack('>B', int(val))))))
        else:
            name = PRETTY.get(key, key); remove(name=name); items.append(('----', item_free(name, val)))
    if cover:
        remove('covr'); items.append(('covr', box('covr', data_box(13, cover))))
    ilst = box('ilst', b''.join(r for _, r in items))
    meta = box('meta', b'\x00\x00\x00\x00' + hdlr + ilst + b''.join(meta_children))
    new_udta = box('udta', udta_other + meta)
    new_moov = box('moov', b''.join(mb[o:o+s] for t, o, s in kids if t != 'udta') + new_udta)
    new_moov = patch_offsets(new_moov, mo, len(new_moov) - ms)
    return data[:mo] + new_moov + data[mo+ms:]

def write_file(src, dst, core, extras, cover):
    data = open(src, 'rb').read()
    if data[:3] == b'ID3' or not (data[:4] in (b'fLaC',) or data[4:8] == b'ftyp'): out = write_id3(data, core, extras, cover)
    elif data[:4] == b'fLaC': out = write_flac(data, core, extras, cover)
    else: out = write_mp4(data, core, extras, cover)
    open(dst, 'wb').write(out)
