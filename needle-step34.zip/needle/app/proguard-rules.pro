# Needle release rules. Room, Media3 and Compose ship their own consumer rules.
# Add -keep lines here only if a release build crashes in a way the debug build does not.
