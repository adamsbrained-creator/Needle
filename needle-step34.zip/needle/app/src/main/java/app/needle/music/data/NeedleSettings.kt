package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import org.json.JSONObject

class AccentChoice(val name: String, val color: Color)

/** The accent colors on the Appearance page. The first one is the original violet. */
val AccentChoices = listOf(
    AccentChoice("Violet", Color(0xFFAF65F5)),
    AccentChoice("Pink", Color(0xFFEF42B8)),
    AccentChoice("Blue", Color(0xFF5B8DEF)),
    AccentChoice("Teal", Color(0xFF2DD4BF)),
    AccentChoice("Green", Color(0xFF6FCF97)),
    AccentChoice("Orange", Color(0xFFF2994A)),
    AccentChoice("Red", Color(0xFFEB5757))
)

/** When a song counts as "played" for Popular, Most played and This week. */
enum class CountAfter(val label: String, private val fixedMs: Long) {
    SEC10("10 s", 10_000L),
    SEC30("30 s", 30_000L),
    MIN1("1 min", 60_000L),
    HALF("Half the song", 0L);

    /** Short songs always count at half their length, so a 20 second song can still count. */
    fun thresholdMs(durationMs: Long): Long {
        val known = durationMs > 0L
        return when {
            this == HALF -> if (known) durationMs / 2 else 30_000L
            known -> minOf(fixedMs, durationMs / 2)
            else -> fixedMs
        }
    }
}

/**
 * Everything on the Settings pages, remembered between launches. Values are Compose state, so a page
 * that reads one redraws the moment it changes, and the playback service can watch them too.
 */
object NeedleSettings {
    private var prefs: SharedPreferences? = null

    // Appearance
    val accentIndex = mutableIntStateOf(0)
    val serifTitles = mutableStateOf(true)
    val amoled = mutableStateOf(false)

    // Playback
    val skipSilence = mutableStateOf(false)
    val pauseOnUnplug = mutableStateOf(true)
    val countAfter = mutableStateOf(CountAfter.SEC30)

    // Ratings
    val ratingStyle = mutableStateOf(RatingStyle.STARS)

    // Library
    val scanOnLaunch = mutableStateOf(true)
    val minSongSeconds = mutableIntStateOf(0)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_settings", Context.MODE_PRIVATE)
        prefs = p
        accentIndex.intValue = p.getInt("accent", 0).coerceIn(0, AccentChoices.lastIndex)
        serifTitles.value = p.getBoolean("serifTitles", true)
        amoled.value = p.getBoolean("amoled", false)
        skipSilence.value = p.getBoolean("skipSilence", false)
        pauseOnUnplug.value = p.getBoolean("pauseOnUnplug", true)
        countAfter.value = runCatching { CountAfter.valueOf(p.getString("countAfter", "SEC30") ?: "SEC30") }
            .getOrDefault(CountAfter.SEC30)
        ratingStyle.value = runCatching { RatingStyle.valueOf(p.getString("ratingStyle", "STARS") ?: "STARS") }
            .getOrDefault(RatingStyle.STARS)
        scanOnLaunch.value = p.getBoolean("scanOnLaunch", true)
        minSongSeconds.intValue = p.getInt("minSongSeconds", 0)
    }

    fun setAccent(index: Int) { accentIndex.intValue = index; prefs?.edit()?.putInt("accent", index)?.apply() }
    fun setSerifTitles(on: Boolean) { serifTitles.value = on; prefs?.edit()?.putBoolean("serifTitles", on)?.apply() }
    fun setAmoled(on: Boolean) { amoled.value = on; prefs?.edit()?.putBoolean("amoled", on)?.apply() }
    fun setSkipSilence(on: Boolean) { skipSilence.value = on; prefs?.edit()?.putBoolean("skipSilence", on)?.apply() }
    fun setPauseOnUnplug(on: Boolean) { pauseOnUnplug.value = on; prefs?.edit()?.putBoolean("pauseOnUnplug", on)?.apply() }
    fun setCountAfter(v: CountAfter) { countAfter.value = v; prefs?.edit()?.putString("countAfter", v.name)?.apply() }
    fun setRatingStyle(v: RatingStyle) { ratingStyle.value = v; prefs?.edit()?.putString("ratingStyle", v.name)?.apply() }
    fun setScanOnLaunch(on: Boolean) { scanOnLaunch.value = on; prefs?.edit()?.putBoolean("scanOnLaunch", on)?.apply() }
    fun setMinSongSeconds(s: Int) { minSongSeconds.intValue = s; prefs?.edit()?.putInt("minSongSeconds", s)?.apply() }

    fun toJson(): JSONObject = JSONObject()
        .put("accent", accentIndex.intValue)
        .put("serifTitles", serifTitles.value)
        .put("amoled", amoled.value)
        .put("skipSilence", skipSilence.value)
        .put("pauseOnUnplug", pauseOnUnplug.value)
        .put("countAfter", countAfter.value.name)
        .put("ratingStyle", ratingStyle.value.name)
        .put("scanOnLaunch", scanOnLaunch.value)
        .put("minSongSeconds", minSongSeconds.intValue)

    /** Anything missing from the file keeps its current value. */
    fun fromJson(o: JSONObject) {
        if (o.has("accent")) setAccent(o.optInt("accent", 0).coerceIn(0, AccentChoices.lastIndex))
        if (o.has("serifTitles")) setSerifTitles(o.optBoolean("serifTitles", true))
        if (o.has("amoled")) setAmoled(o.optBoolean("amoled", false))
        if (o.has("skipSilence")) setSkipSilence(o.optBoolean("skipSilence", false))
        if (o.has("pauseOnUnplug")) setPauseOnUnplug(o.optBoolean("pauseOnUnplug", true))
        if (o.has("countAfter")) {
            runCatching { CountAfter.valueOf(o.getString("countAfter")) }.getOrNull()?.let { setCountAfter(it) }
        }
        if (o.has("ratingStyle")) {
            runCatching { RatingStyle.valueOf(o.getString("ratingStyle")) }.getOrNull()?.let { setRatingStyle(it) }
        }
        if (o.has("scanOnLaunch")) setScanOnLaunch(o.optBoolean("scanOnLaunch", true))
        if (o.has("minSongSeconds")) setMinSongSeconds(o.optInt("minSongSeconds", 0))
    }
}
