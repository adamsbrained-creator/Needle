package app.needle.music.cast

import android.content.Context
import android.net.wifi.WifiManager
import android.os.SystemClock
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.IOException
import kotlin.math.abs

/**
 * Plays Needle's queue on a DLNA / UPnP device.
 *
 * The queue, shuffle, repeat, the notification and play history all stay exactly as they are: the normal
 * player keeps running, silenced, as the "brain". This class makes the device follow it:
 *  - a new song in the queue  -> tell the device to play that song's address on this phone
 *  - play / pause / seek      -> forwarded to the device
 *  - every ~1.2 s             -> ask the device where it is, pull the silent player into sync with it,
 *                                and copy pause/play pressed on the TV's own remote
 * At the end of a song we wait for the device to actually finish it (or queue the next song up front when
 * "Gapless playback" is on), so the last seconds are never cut off.
 */
class CastEngine(
    private val context: Context,
    private val player: ExoPlayer,
    private val scope: CoroutineScope   // must run on the main thread
) : CastHub.Controller {

    private val lan: LanNet get() = CastHub.lanNet
    private val server = MediaServer(context)

    private var device: CastDevice? = null
    private var renderer: UpnpRenderer? = null
    private var sink: List<String> = emptyList()
    private var host = ""

    private var loadJob: Job? = null
    private var pollJob: Job? = null
    private var loadedId: String? = null        // the song the device was last told to play
    private var nextQueuedId: String? = null    // a song the device accepted as "play after this one"
    private var nextAttemptId: String? = null
    private var nextUnsupported = false
    private var settleUntil = 0L
    private var posSyncPausedUntil = 0L
    private var expectedSelfSeek: Long? = null
    private var pendingSeekMs = 0L
    private var lastRel = 0L
    private var lastDur = 0L
    private var lastState = ""
    private var failedPolls = 0
    private var foreignPolls = 0
    private var stoppedPolls = 0
    private var skipStreak = 0
    private var pollCount = 0
    private var wifiLock: WifiManager.WifiLock? = null

    private val settings: CastSettings
        get() = device?.let { CastHub.settingsFor(it.udn) } ?: CastSettings()

    private val casting: Boolean
        get() = device != null && renderer != null && CastHub.state.value.phase == CastPhase.CONNECTED

    private fun now() = SystemClock.elapsedRealtime()
    private fun name() = device?.name ?: "the device"

    init {
        player.addListener(object : Player.Listener {
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (!casting) return
                val item = mediaItem ?: return
                val natural = reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO ||
                    reason == Player.MEDIA_ITEM_TRANSITION_REASON_REPEAT
                startLoad(item, 0L, natural)
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (!casting || loadJob?.isActive == true) return
                val r = renderer ?: return
                settleUntil = now() + 2500
                scope.launch {
                    try {
                        withContext(Dispatchers.IO) { if (playWhenReady) r.play() else r.pause() }
                        if (playWhenReady && pendingSeekMs > 0) {
                            val ms = pendingSeekMs
                            pendingSeekMs = 0
                            seekWhenReady(r, ms)
                        }
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        CastHub.log("play/pause failed: $e")
                    }
                }
            }

            override fun onPositionDiscontinuity(
                oldPosition: Player.PositionInfo,
                newPosition: Player.PositionInfo,
                reason: Int
            ) {
                if (!casting || reason != Player.DISCONTINUITY_REASON_SEEK) return
                if (loadJob?.isActive == true) return
                if (oldPosition.mediaItemIndex != newPosition.mediaItemIndex) return // a new song: handled as a transition
                val target = newPosition.positionMs
                val self = expectedSelfSeek
                if (self != null && abs(self - target) < 400) { expectedSelfSeek = null; return }
                val r = renderer ?: return
                posSyncPausedUntil = now() + 2500
                settleUntil = now() + 2000
                scope.launch {
                    try { withContext(Dispatchers.IO) { r.seek(target) } } catch (e: CancellationException) { throw e }
                    catch (e: Exception) { CastHub.log("seek failed: $e") }
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (!casting || playbackState != Player.STATE_ENDED || loadJob?.isActive == true) return
                val r = renderer ?: return
                // The queue is over on the phone's clock; let the device finish the last seconds first.
                loadJob = scope.launch {
                    awaitRendererFinished(r, "")
                    if (settings.stopWhenEnds) teardown(resume = false)
                }
            }

            override fun onTimelineChanged(timeline: Timeline, reason: Int) {
                nextQueuedId = null
                nextAttemptId = null
            }
        })
        CastHub.controller = this
    }

    // ---- connect / disconnect ----------------------------------------------------------------

    override fun connect(device: CastDevice) {
        if (this.device?.udn == device.udn && CastHub.state.value.phase != CastPhase.LOCAL) return
        if (this.device != null) teardown(resume = true)
        scope.launch { doConnect(device) }
    }

    private suspend fun doConnect(d: CastDevice) {
        CastHub.state.value = CastState(d, CastPhase.CONNECTING)
        CastHub.log("connecting to ${d.name} (${d.host})")
        val r = UpnpRenderer(lan, d)
        val probe = withContext(Dispatchers.IO) {
            runCatching {
                val st = r.transportState()
                val vol = runCatching { r.getVolume() }.getOrNull()
                val sk = runCatching { r.sinkFormats() }.getOrDefault(emptyList())
                Triple(st, vol, sk)
            }
        }
        val result = probe.getOrElse { e ->
            CastHub.log("connect failed: $e")
            CastHub.post("Couldn't connect to ${d.name}")
            CastHub.state.value = CastState()
            return
        }
        val ip = lan.localIpFor(d.host)
        if (ip == null) {
            CastHub.post("Couldn't find this phone's Wi-Fi address")
            CastHub.state.value = CastState()
            return
        }

        device = d
        renderer = r
        sink = result.third
        host = ip
        loadedId = null
        nextQueuedId = null
        nextAttemptId = null
        nextUnsupported = false
        failedPolls = 0; foreignPolls = 0; stoppedPolls = 0; skipStreak = 0
        lastRel = 0; lastDur = 0; lastState = ""
        server.alt = settings.altCompat
        server.start()
        acquireWifi()
        player.volume = 0f                      // the phone goes quiet, the device takes over
        CastHub.state.value = CastState(d, CastPhase.CONNECTED, result.second ?: -1)
        CastHub.log("connected, local address $ip, ${sink.size} formats reported")

        player.currentMediaItem?.let { startLoad(it, player.currentPosition, false) }
        startPolling()
    }

    override fun disconnect() {
        if (device != null) teardown(resume = true)
    }

    /** Back to playing on the phone. [resume] keeps the music going from where the device was. */
    private fun teardown(resume: Boolean) {
        val r = renderer
        val rel = lastRel
        val id = loadedId
        loadJob?.cancel(); loadJob = null
        pollJob?.cancel(); pollJob = null
        CastHub.log("disconnected from ${name()}")
        device = null
        renderer = null
        loadedId = null
        nextQueuedId = null
        nextAttemptId = null
        CastHub.state.value = CastState()
        player.volume = 1f
        if (r != null) scope.launch(Dispatchers.IO) { runCatching { r.stop() } }
        if (resume) {
            val cur = player.currentMediaItem
            if (cur != null && cur.mediaId == id && rel > 0 && abs(rel - player.currentPosition) > 1500) player.seekTo(rel)
        } else {
            player.pause()
        }
        releaseWifi()
        server.stop()
    }

    fun release() {
        if (device != null) teardown(resume = false)
        server.stop()
        if (CastHub.controller === this) CastHub.controller = null
    }

    // ---- loading a song onto the device ------------------------------------------------------

    private fun sourceOf(item: MediaItem): TrackSource? {
        val id = item.mediaId.toLongOrNull() ?: return null
        val uri = item.localConfiguration?.uri ?: return null
        val md = item.mediaMetadata
        val duration = if (player.currentMediaItem?.mediaId == item.mediaId && player.duration != C.TIME_UNSET) player.duration else 0L
        return TrackSource(
            id = id,
            uri = uri,
            title = md.title?.toString().orEmpty(),
            artist = md.artist?.toString().orEmpty(),
            album = md.albumTitle?.toString().orEmpty(),
            cover = md.artworkData,
            durationMs = duration
        )
    }

    private fun startLoad(item: MediaItem, startMs: Long, waitForEnd: Boolean) {
        val r = renderer ?: return
        val id = item.mediaId
        loadJob?.cancel()
        loadJob = scope.launch {
            try {
                if (waitForEnd && loadedId != null && awaitRendererFinished(r, id)) {
                    // The device moved on to this song by itself (gapless): nothing to send.
                    loadedId = id
                    nextQueuedId = null
                    settleUntil = now() + 2500
                    return@launch
                }

                val src = sourceOf(item) ?: return@launch
                server.alt = settings.altCompat
                val track = withContext(Dispatchers.IO) { server.track(src, host) }

                if (settings.reportedFormats && sink.isNotEmpty() && !FormatSupport.supports(sink, track.mime)) {
                    skipStreak++
                    if (skipStreak <= 3 && player.hasNextMediaItem()) {
                        CastHub.post("${name()} can't play .${track.ext} files, skipping")
                        player.seekToNextMediaItem()
                    } else {
                        CastHub.post("${name()} can't play .${track.ext} files. Turn off \"Use formats the device reports\" to try anyway.")
                        player.pause()
                    }
                    return@launch
                }
                skipStreak = 0

                settleUntil = now() + 6000
                posSyncPausedUntil = now() + 6000
                val didl = Didl.build(src, track, settings.altCompat)
                CastHub.log("load ${src.title} -> ${track.url}")
                withContext(Dispatchers.IO) { r.setUri(track.url, didl) }
                loadedId = id
                nextQueuedId = null
                stoppedPolls = 0

                if (player.playWhenReady) {
                    withContext(Dispatchers.IO) { playWithRetry(r) }
                    if (startMs > 1500) seekWhenReady(r, startMs)
                } else {
                    pendingSeekMs = startMs
                }
                settleUntil = now() + 5000
                posSyncPausedUntil = now() + 4000
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CastHub.log("load failed: $e")
                CastHub.post("${name()} couldn't start that song")
                player.pause()
            }
        }
    }

    private suspend fun playWithRetry(r: UpnpRenderer) {
        var last: Exception? = null
        repeat(4) {
            try {
                r.play()
                return
            } catch (e: IOException) {
                throw e
            } catch (e: UpnpException) {
                last = e
                delay(600)
            }
        }
        throw last ?: IOException("Play failed")
    }

    private suspend fun seekWhenReady(r: UpnpRenderer, ms: Long) {
        withContext(Dispatchers.IO) {
            repeat(10) {
                val st = runCatching { r.transportState() }.getOrDefault("")
                if (st == "PLAYING") {
                    runCatching { r.seek(ms) }
                    return@withContext
                }
                delay(300)
            }
            runCatching { r.seek(ms) }
            Unit
        }
    }

    /**
     * The phone's silent clock reached the end of a song. Wait until the device has really finished it.
     * Returns true when the device already started [newId] on its own (the gapless case).
     */
    private suspend fun awaitRendererFinished(r: UpnpRenderer, newId: String): Boolean {
        val limit = now() + (lastDur - lastRel).coerceIn(0L, 20_000L) + 5_000L
        while (now() < limit) {
            val got = withContext(Dispatchers.IO) { runCatching { r.transportState() to r.positionInfo() }.getOrNull() }
            if (got != null) {
                val (st, pos) = got
                if (newId.isNotEmpty() && pos.trackUri.contains("/m/$newId.")) return true
                if (st == "STOPPED" || st == "NO_MEDIA_PRESENT" || st == "PAUSED_PLAYBACK") return false
                val rel = pos.relMs
                val dur = pos.durMs
                if (nextQueuedId != newId && rel != null && dur != null && dur > 0 && rel >= dur - 300) return false
            }
            delay(350)
        }
        return false
    }

    // ---- gapless: tell the device what comes next ---------------------------------------------

    private fun queueNext(r: UpnpRenderer, item: MediaItem) {
        nextAttemptId = item.mediaId
        scope.launch {
            try {
                val src = sourceOf(item) ?: return@launch
                val track = withContext(Dispatchers.IO) { server.track(src, host) }
                if (settings.reportedFormats && sink.isNotEmpty() && !FormatSupport.supports(sink, track.mime)) return@launch
                val didl = Didl.build(src, track, settings.altCompat)
                withContext(Dispatchers.IO) { r.setNext(track.url, didl) }
                if (renderer === r) {
                    nextQueuedId = item.mediaId
                    CastHub.log("queued next: ${src.title}")
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: UpnpException) {
                nextUnsupported = true
                CastHub.log("device doesn't support gapless: $e")
            } catch (e: Exception) {
                CastHub.log("queue next failed: $e")
            }
        }
    }

    // ---- polling the device ------------------------------------------------------------------

    private fun startPolling() {
        pollJob?.cancel()
        pollJob = scope.launch {
            while (isActive) {
                delay(1200)
                pollOnce()
            }
        }
    }

    private suspend fun pollOnce() {
        val r = renderer ?: return
        if (loadJob?.isActive == true) return
        val wantVolume = ++pollCount % 5 == 0
        val got = withContext(Dispatchers.IO) {
            runCatching {
                val st = r.transportState()
                val pos = r.positionInfo()
                val vol = if (wantVolume) runCatching { r.getVolume() }.getOrNull() else null
                Triple(st, pos, vol)
            }.getOrNull()
        }
        if (renderer !== r) return // disconnected while we waited

        if (got == null) {
            if (++failedPolls >= 6) {
                CastHub.log("lost connection")
                CastHub.post("Lost connection to ${name()}")
                teardown(resume = false)
            }
            return
        }
        failedPolls = 0
        val (st, pos, vol) = got
        lastState = st
        pos.relMs?.let { lastRel = it }
        pos.durMs?.let { lastDur = it }
        if (vol != null && vol != CastHub.state.value.volume) CastHub.state.update { it.copy(volume = vol) }

        val t = now()
        val current = player.currentMediaItem
        val settled = t > settleUntil && st != "TRANSITIONING"

        // 1. Did someone else start something on the device?
        val foreign = pos.trackUri.isNotBlank() && !pos.trackUri.contains(":${server.port}/")
        if (settled && foreign) {
            if (++foreignPolls >= 2 && settings.stopIfTakenOver) {
                CastHub.post("${name()} was taken over, stopping")
                teardown(resume = false)
                return
            }
        } else if (!foreign) {
            foreignPolls = 0
        }

        val inSync = settled && !foreign && loadedId != null && loadedId == current?.mediaId

        // 2. Copy what happened on the device's own remote.
        if (inSync) {
            when (st) {
                "PLAYING" -> { stoppedPolls = 0; if (!player.playWhenReady) player.play() }
                "PAUSED_PLAYBACK" -> { stoppedPolls = 0; if (player.playWhenReady) player.pause() }
                "STOPPED", "NO_MEDIA_PRESENT" -> {
                    val nearEnd = lastDur > 0 && lastRel >= lastDur - 3000
                    if (player.playWhenReady && !nearEnd && player.playbackState != Player.STATE_ENDED) {
                        if (++stoppedPolls >= 3) {
                            CastHub.log("device stopped by itself at $lastRel / $lastDur")
                            CastHub.post("${name()} stopped playing")
                            stoppedPolls = 0
                            player.pause()
                        }
                    }
                }
                else -> stoppedPolls = 0
            }
        }

        // 3. Keep the silent player on the device's position (so the progress bar is the device's).
        if (inSync && st == "PLAYING" && t > posSyncPausedUntil) {
            val rel = pos.relMs
            if (rel != null && abs(rel - player.currentPosition) > 1500) {
                expectedSelfSeek = rel
                player.seekTo(rel)
            }
        }

        // 4. Gapless: hand the device the next song shortly before this one ends.
        if (settings.gapless && !nextUnsupported && inSync && st == "PLAYING" && lastDur > 0 &&
            lastDur - lastRel < 20_000 && player.repeatMode != Player.REPEAT_MODE_ONE
        ) {
            val ni = player.nextMediaItemIndex
            if (ni != C.INDEX_UNSET) {
                val next = player.getMediaItemAt(ni)
                if (next.mediaId != current?.mediaId && nextAttemptId != next.mediaId) queueNext(r, next)
            }
        }
    }

    // ---- volume ------------------------------------------------------------------------------

    override fun stepVolume(direction: Int, announce: Boolean) {
        val r = renderer ?: return
        if (!casting) return
        val known = CastHub.state.value.volume
        val step = settings.volumeStep
        scope.launch {
            val base = if (known >= 0) known else withContext(Dispatchers.IO) { runCatching { r.getVolume() }.getOrNull() } ?: 30
            val v = (base + direction * step).coerceIn(0, 100)
            CastHub.state.update { it.copy(volume = v) }
            if (announce) CastHub.post("Volume $v")
            try {
                withContext(Dispatchers.IO) { r.setVolume(v) }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                CastHub.log("set volume failed: $e")
                CastHub.post("${name()} didn't accept the volume change")
            }
        }
    }

    // ---- keeping Wi-Fi awake with the screen off ---------------------------------------------

    @Suppress("DEPRECATION")
    private fun acquireWifi() {
        runCatching {
            val wm = context.applicationContext.getSystemService(WifiManager::class.java)
            wifiLock = wm.createWifiLock(WifiManager.WIFI_MODE_FULL_HIGH_PERF, "needle-cast").apply {
                setReferenceCounted(false)
                acquire()
            }
        }
    }

    private fun releaseWifi() {
        runCatching { wifiLock?.let { if (it.isHeld) it.release() } }
        wifiLock = null
    }
}
