package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

/** What the lyrics screen needs to find lyrics for the song that is playing. */
data class LyricsQuery(val songId: Long, val title: String, val artist: String, val album: String, val durationMs: Long)

sealed class OnlineResult {
    class Found(val lyrics: Lyrics) : OnlineResult()
    object NotFound : OnlineResult()
    object Instrumental : OnlineResult()
    class Failed(val reason: String) : OnlineResult()
}

/**
 * "Allow access to all files": the one switch that lets Needle read the .lrc files lying next to your songs.
 * Android has no pop-up for it: it opens a settings page where the switch is flipped once.
 */
object FileAccess {
    val granted = mutableStateOf(true)

    fun refresh() {
        granted.value = if (Build.VERSION.SDK_INT >= 30) Environment.isExternalStorageManager() else true
    }

    fun openSettings(context: Context) {
        val forApp = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
            .setData(Uri.parse("package:${context.packageName}"))
        try {
            context.startActivity(forApp)
        } catch (e: Exception) {
            runCatching { context.startActivity(Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION)) }
        }
    }
}

class LyricsRepository(private val context: Context) {
    private val db = NeedleDatabase.get(context)

    /**
     * Everything that is already on the phone: the .lrc file, the Lyrics tag you saved in Needle, the lyrics
     * inside the audio file itself, lyrics saved from LRCLIB. Timed lyrics win over plain text;
     * otherwise the order is the order of this list.
     */
    suspend fun local(q: LyricsQuery): Lyrics? = withContext(Dispatchers.IO) {
        // What you wrote or saved yourself in Needle always wins, timed or not.
        runCatching {
            db.extraTagDao().valueOf(q.songId, "UNSYNCEDLYRICS")
                ?.takeIf { it.isNotBlank() }
                ?.let { LrcParser.parse(it, LyricsSource.TAGS) }
        }.getOrNull()?.let { return@withContext it }

        val found = ArrayList<Lyrics>()
        if (LyricsPrefs.useLrcFiles.value) runCatching { sidecar(q.songId) }.getOrNull()?.let { found += it }
        if (LyricsPrefs.useEmbedded.value) runCatching {
            db.fileTagDao().valueOf(q.songId, "UNSYNCEDLYRICS")
                ?.takeIf { it.isNotBlank() }
                ?.let { LrcParser.parse(it, LyricsSource.EMBEDDED) }
        }.getOrNull()?.let { found += it }
        runCatching {
            db.lyricsDao().get(q.songId)?.let { LrcParser.parse(it.text, LyricsSource.SAVED) }
        }.getOrNull()?.let { found += it }
        found.firstOrNull { it.synced } ?: found.firstOrNull()
    }

    private fun audioPath(songId: Long): String? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId)
        @Suppress("DEPRECATION")
        return context.contentResolver.query(uri, arrayOf(MediaStore.Audio.Media.DATA), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }

    private fun sidecar(songId: Long): Lyrics? {
        if (!FileAccess.granted.value) return null
        val path = audioPath(songId) ?: return null
        val base = path.substringBeforeLast('.', path)
        for (ext in listOf(".lrc", ".LRC")) {
            val f = File(base + ext)
            if (!f.isFile || !f.canRead()) continue
            val text = runCatching { f.readText() }.getOrNull() ?: continue
            LrcParser.parse(text, LyricsSource.FILE)?.let { return it }
        }
        return null
    }

    // ---- LRCLIB (free, no account) ---------------------------------------------------------

    suspend fun online(q: LyricsQuery): OnlineResult = withContext(Dispatchers.IO) {
        try {
            var chosen: JSONObject? = null
            val get = buildString {
                append("https://lrclib.net/api/get?track_name=").append(enc(q.title))
                append("&artist_name=").append(enc(q.artist))
                if (q.album.isNotBlank()) append("&album_name=").append(enc(q.album))
                if (q.durationMs > 0) append("&duration=").append((q.durationMs / 1000.0).toInt())
            }
            httpGet(get)?.let { chosen = runCatching { JSONObject(it) }.getOrNull() }

            if (chosen == null || !hasLyrics(chosen!!)) {
                val search = "https://lrclib.net/api/search?track_name=${enc(q.title)}&artist_name=${enc(q.artist)}"
                val arr = httpGet(search)?.let { runCatching { JSONArray(it) }.getOrNull() }
                chosen = arr?.let { pick(it, q.durationMs) }
            }
            val hit = chosen ?: return@withContext OnlineResult.NotFound
            if (!hasLyrics(hit)) {
                return@withContext if (hit.optBoolean("instrumental")) OnlineResult.Instrumental else OnlineResult.NotFound
            }
            val synced = hit.optString("syncedLyrics").takeIf { it.isNotBlank() && it != "null" }
            val plain = hit.optString("plainLyrics").takeIf { it.isNotBlank() && it != "null" }
            val text = synced ?: plain ?: return@withContext OnlineResult.NotFound
            val parsed = LrcParser.parse(text, LyricsSource.SAVED) ?: return@withContext OnlineResult.NotFound
            db.lyricsDao().save(LyricsCache(q.songId, text, parsed.synced, "LRCLIB", System.currentTimeMillis()))
            OnlineResult.Found(parsed)
        } catch (e: Exception) {
            OnlineResult.Failed(e.message ?: e.javaClass.simpleName)
        }
    }

    suspend fun forgetSaved(songId: Long) = withContext(Dispatchers.IO) { db.lyricsDao().delete(songId) }

    suspend fun savedCount(): Int = withContext(Dispatchers.IO) { db.lyricsDao().count() }

    suspend fun clearSaved() = withContext(Dispatchers.IO) { db.lyricsDao().clear() }

    /**
     * Lyrics written in the editor go into the same Lyrics tag the tag editor shows ("UNSYNCEDLYRICS").
     * Empty text removes your version, so the file's own lyrics (or a .lrc file) show again.
     */
    suspend fun saveUserLyrics(songId: Long, text: String) = withContext(Dispatchers.IO) {
        if (text.isBlank()) db.extraTagDao().delete(listOf(songId), listOf("UNSYNCEDLYRICS"))
        else db.extraTagDao().upsertAll(listOf(ExtraTag(songId, "UNSYNCEDLYRICS", text)))
    }

    private fun hasLyrics(o: JSONObject): Boolean =
        o.optString("syncedLyrics").let { it.isNotBlank() && it != "null" } ||
            o.optString("plainLyrics").let { it.isNotBlank() && it != "null" }

    /** From a search: prefer timed lyrics from a version of the song with (nearly) the same length. */
    private fun pick(arr: JSONArray, durationMs: Long): JSONObject? {
        val all = (0 until arr.length()).mapNotNull { arr.optJSONObject(it) }.filter { hasLyrics(it) }
        fun closeEnough(o: JSONObject) = durationMs <= 0 || abs(o.optDouble("duration", 0.0) * 1000 - durationMs) <= 3000
        fun timed(o: JSONObject) = o.optString("syncedLyrics").let { it.isNotBlank() && it != "null" }
        return all.firstOrNull { timed(it) && closeEnough(it) }
            ?: all.firstOrNull { closeEnough(it) }
            ?: all.firstOrNull { timed(it) }
            ?: all.firstOrNull()
    }

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun httpGet(url: String): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        try {
            c.connectTimeout = 8000
            c.readTimeout = 10000
            c.setRequestProperty("User-Agent", "Needle/0.11 (personal Android music player)")
            val code = c.responseCode
            if (code == 404) return null
            if (code !in 200..299) throw IOException("HTTP $code")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }
}
