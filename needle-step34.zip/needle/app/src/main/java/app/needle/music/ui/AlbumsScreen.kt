package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeAlbum

/** The Albums page: every album as a cover, A to Z. Tap one to open it. */
@Composable
fun AlbumsScreen(
    albums: List<HomeAlbum>?,
    bottomPadding: Dp,
    onOpenAlbum: (HomeAlbum) -> Unit,
    onSearch: () -> Unit,
    onEditTags: (HomeAlbum) -> Unit,
    modifier: Modifier = Modifier
) {
    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Row(
                Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(Modifier.weight(1f)) {
                    Text("Albums", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                    if (albums != null) {
                        Text("${albums.size} albums", color = Palette.Muted, fontSize = 13.sp)
                    }
                }
                RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)
            }
        }

        if (albums == null || albums.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    if (albums == null) "Loading…" else "No albums found.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp)
                )
            }
        } else {
            items(albums, key = { it.id }) { album ->
                AlbumCell(album, onClick = { onOpenAlbum(album) }, onLongClick = { onEditTags(album) })
            }
        }
    }
}

@Composable
private fun AlbumCell(album: HomeAlbum, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(Modifier.tapOrHold(onClick = onClick, onLongClick = onLongClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp))) {
            Cover(album.cover, Modifier.fillMaxSize())
        }
        Text(
            album.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            "${album.artist} · ${tracksText(album.songs.size)}", color = Palette.Muted, fontSize = 12.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}
