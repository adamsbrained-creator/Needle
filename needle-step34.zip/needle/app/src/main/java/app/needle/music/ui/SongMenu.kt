package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.HomeAlbum
import app.needle.music.data.Song

/**
 * The song menu from the mockup, opened by pressing and holding a song.
 * Only the entries that work today are shown; the rest of the mockup's list joins as those features are built.
 */
@Composable
fun SongMenuSheet(
    song: Song,
    canGoToAlbum: Boolean,
    onOpenSingle: () -> Unit,
    canGoToArtist: Boolean,
    onGoToArtist: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onRate: () -> Unit,
    onGoToAlbum: () -> Unit,
    onEditTags: () -> Unit,
    onEditLyrics: () -> Unit,
    onInfo: () -> Unit,
    onShare: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xF53C3250), Color(0xFA1E1C24))))
            .navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 10.dp)
    ) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(38.dp).height(4.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
        )
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            SongArtwork(song, size = 52.dp, corner = 14.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    song.title, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${song.artist} · ${song.album}", color = Palette.Muted, fontSize = 12.5.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        // The quick actions from the mockup
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            QuickAction(NeedleIcon.PLAY_NEXT, "Play next", onPlayNext)
            QuickAction(NeedleIcon.ADD_QUEUE, "Add to queue", onAddToQueue)
            QuickAction(NeedleIcon.ADD_PLAYLIST, "Playlist", onAddToPlaylist)
            QuickAction(NeedleIcon.SHARE, "Share", onShare)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
        Column(verticalArrangement = Arrangement.spacedBy(0.dp)) {
            // A song that is not part of an album has a page of its own too (cover, description, tags).
            if (canGoToAlbum) MenuRow(NeedleIcon.ALBUMS, "Go to album", onGoToAlbum)
            else MenuRow(NeedleIcon.ALBUMS, "Open single", onOpenSingle)
            if (canGoToArtist) MenuRow(NeedleIcon.ARTIST, "Go to artist", onGoToArtist)
            MenuRow(NeedleIcon.STAR, "Rate song", onRate)
            MenuRow(NeedleIcon.TAG, "Edit tags", onEditTags)
            MenuRow(NeedleIcon.PENCIL, "Edit lyrics", onEditLyrics)
            MenuRow(NeedleIcon.INFO, "Song info", onInfo)
        }
    }
}

@Composable
private fun QuickAction(icon: NeedleIcon, label: String, onClick: () -> Unit) {
    Column(
        Modifier.width(84.dp).clip(RoundedCornerShape(16.dp)).clickable(onClick = onClick).padding(vertical = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            Modifier.size(52.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(icon, Palette.Text, size = 22.dp) }
        Text(
            label, color = Palette.Muted, fontSize = 12.sp, textAlign = TextAlign.Center,
            modifier = Modifier.padding(top = 6.dp)
        )
    }
}

@Composable
private fun MenuRow(icon: NeedleIcon, label: String, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(54.dp).clickable(onClick = onClick),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(24.dp), contentAlignment = Alignment.Center) { NeedleIconView(icon, Palette.Muted, size = 21.dp) }
        Spacer(Modifier.width(16.dp))
        Text(label, color = Palette.Text, fontSize = 15.5.sp)
    }
}

/**
 * The menu for a whole album (pressing and holding a cover on the Albums page).
 * Play next and Add to queue put every track of the album in the queue, in album order.
 */
@Composable
fun AlbumMenuSheet(
    album: HomeAlbum,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onShuffle: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onEditTags: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp))
            .background(Brush.verticalGradient(listOf(Color(0xF53C3250), Color(0xFA1E1C24))))
            .navigationBarsPadding()
            .padding(start = 20.dp, end = 20.dp, top = 10.dp, bottom = 10.dp)
    ) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(38.dp).height(4.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.25f))
        )
        Row(Modifier.fillMaxWidth().padding(top = 16.dp, bottom = 10.dp), verticalAlignment = Alignment.CenterVertically) {
            SongArtwork(album.cover, size = 52.dp, corner = 14.dp)
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(
                    album.title, color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(
                    "${album.artist} · ${tracksText(album.songs.size)}", color = Palette.Muted, fontSize = 12.5.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
        }
        Row(Modifier.fillMaxWidth().padding(bottom = 12.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
            QuickAction(NeedleIcon.PLAY_NEXT, "Play next", onPlayNext)
            QuickAction(NeedleIcon.ADD_QUEUE, "Add to queue", onAddToQueue)
            QuickAction(NeedleIcon.SHUFFLE, "Shuffle", onShuffle)
        }
        Box(Modifier.fillMaxWidth().height(1.dp).background(Color.White.copy(alpha = 0.08f)))
        MenuRow(NeedleIcon.ADD_PLAYLIST, "Add to playlist", onAddToPlaylist)
            MenuRow(NeedleIcon.TAG, "Edit tags", onEditTags)
    }
}
