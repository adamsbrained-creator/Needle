package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ExtraTags
import app.needle.music.data.Song

private val searchableExtras = listOf("ALBUMARTIST", "COMPOSER", "CONDUCTOR", "LYRICIST", "MOOD")

/** Type to filter the whole library by title, artist or album. Tap a result to play it. */
@Composable
fun SearchScreen(
    songs: List<Song>,
    extras: ExtraTags,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onEditTags: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    val focus = remember { FocusRequester() }
    LaunchedEffect(Unit) { focus.requestFocus() }

    val results = remember(query, songs, extras) {
        val q = query.trim()
        if (q.isEmpty()) emptyList()
        else songs.filter { song ->
            song.title.contains(q, ignoreCase = true) ||
                song.artist.contains(q, ignoreCase = true) ||
                song.album.contains(q, ignoreCase = true) ||
                song.genre.contains(q, ignoreCase = true) ||
                // also the people and mood tags: album artist, composer, conductor, lyricist, mood
                searchableExtras.any { key -> extras[song.id]?.get(key)?.contains(q, ignoreCase = true) == true }
        }.take(200)
    }

    Column(modifier.fillMaxSize()) {
        Row(
            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 8.dp, bottom = 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 40.dp, iconSize = 22.dp)

            Box(
                Modifier
                    .weight(1f)
                    .padding(start = 10.dp)
                    .clip(RoundedCornerShape(24.dp))
                    .background(Palette.Card2)
                    .padding(horizontal = 18.dp, vertical = 12.dp)
            ) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Palette.Text, fontSize = 16.sp),
                    cursorBrush = SolidColor(Palette.Accent),
                    modifier = Modifier.fillMaxWidth().focusRequester(focus),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) {
                                Text("Search songs, artists, albums", color = Palette.Muted, fontSize = 16.sp)
                            }
                            inner()
                        }
                    }
                )
            }
        }

        if (query.isNotBlank() && results.isEmpty()) {
            Text(
                "Nothing found for \"${query.trim()}\".",
                color = Palette.Muted, fontSize = 14.sp,
                modifier = Modifier.padding(24.dp)
            )
        }

        LazyColumn(contentPadding = PaddingValues(bottom = bottomPadding)) {
            itemsIndexed(results, key = { _, s -> s.id }) { index, song ->
                SongRow(
                    song,
                    isCurrent = song.id.toString() == currentMediaId,
                    onClick = { onPlay(results, index) },
                    onLongClick = { onEditTags(song) }
                )
            }
        }
    }
}
