package app.needle.music.ui

import android.os.SystemClock
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.snapshotFlow
import androidx.compose.runtime.withFrameNanos
import app.needle.music.playback.PlayerViewModel
import kotlin.math.abs

/**
 * Lyrics switch a little before the exact time stamp. A line takes about 300 ms to grow and brighten,
 * so without this lead it feels like it arrives late. (The per-song sync offset in the lyrics info is on top of this.)
 */
const val LYRICS_LEAD_MS = 120L

/**
 * The playing position in ms, updated on every frame while the song plays.
 *
 * The player only reports its position a few times per second, so reading it directly makes a lyric line change up to
 * a quarter of a second late and in steps. Here the position is the last reported value plus the time that has passed
 * since, and a new report only moves it when it really disagrees (a seek, a new song, or drift over 30 ms).
 *
 * [poll] = true also asks the player for a fresh position every 100 ms (for the Lyrics page). The Now Playing page
 * already does that itself, so the preview card passes false.
 */
@Composable
fun rememberLivePositionMs(player: PlayerViewModel, poll: Boolean): State<Long> {
    val out = remember { mutableLongStateOf(player.positionMs) }
    val playing = player.isPlaying

    // Paused (also: seeked or changed song while paused): just follow the player's own value.
    LaunchedEffect(playing) {
        if (!playing) snapshotFlow { player.positionMs }.collect { out.longValue = it }
    }

    LaunchedEffect(playing) {
        if (!playing) return@LaunchedEffect
        var basePos = player.positionMs
        var baseTime = SystemClock.elapsedRealtime()
        var lastSeen = basePos
        var lastPoll = baseTime
        while (true) {
            withFrameNanos { }
            val now = SystemClock.elapsedRealtime()
            if (poll && now - lastPoll >= 100) {
                player.refreshPosition()
                lastPoll = now
            }
            val seen = player.positionMs
            if (seen != lastSeen) {
                lastSeen = seen
                if (abs(seen - (basePos + (now - baseTime))) > 30) {
                    basePos = seen
                    baseTime = now
                }
            }
            out.longValue = basePos + (now - baseTime)
        }
    }
    return out
}
