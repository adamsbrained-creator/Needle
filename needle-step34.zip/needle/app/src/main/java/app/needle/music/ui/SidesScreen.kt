package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AlbumPrefs
import app.needle.music.data.ExtraTags
import app.needle.music.data.HomeAlbum
import app.needle.music.data.discLabel
import app.needle.music.data.discOf
import kotlin.math.abs

/**
 * Sets the sides (discs) of an album. The tracks are listed in order; tap a track to start a new side there, tap
 * again to join it to the one before. Saving writes the Disc tag of every track, so the album page groups them
 * (and, with "Write tags into the files", so do other players).
 */
@Composable
fun SidesScreen(
    album: HomeAlbum,
    extras: ExtraTags,
    onClose: () -> Unit,
    onSave: (sideOf: Map<Long, Int>, totalSides: Int, newTrack: Map<Long, Int>?) -> Unit,
    modifier: Modifier = Modifier
) {
    val songs = album.songs
    val word by AlbumPrefs.discWord
    val letters by AlbumPrefs.discLetters
    val noun = word.trim().ifEmpty { "Disc" }.lowercase()

    // Where a new side starts: the index of its first track. Begins with what the tags say now.
    var starts by remember(album.id) {
        mutableStateOf(
            songs.indices.filter { it > 0 && discOf(extras[songs[it].id]) != discOf(extras[songs[it - 1].id]) }.toSet()
        )
    }
    var renumber by remember(album.id) { mutableStateOf(true) }

    // side number (from 1) of every track, and the track's place inside its side
    val side = IntArray(songs.size)
    val place = IntArray(songs.size)
    var current = 1
    var inSide = 0
    songs.indices.forEach { i ->
        if (i in starts) { current++; inSide = 0 }
        inSide++
        side[i] = current
        place[i] = inSide
    }
    val total = current

    Column(modifier.safeDrawingPadding().padding(horizontal = 16.dp)) {
        Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            RoundIconButton(NeedleIcon.CLOSE, onClose, size = 40.dp, iconSize = 20.dp)
            Spacer(Modifier.weight(1f))
            Box(
                Modifier.size(40.dp).clip(CircleShape).background(Color.White).clickable {
                    val sideOf = HashMap<Long, Int>()
                    val newTrack = HashMap<Long, Int>()
                    songs.forEachIndexed { i, s -> sideOf[s.id] = side[i]; newTrack[s.id] = place[i] }
                    onSave(sideOf, total, if (renumber) newTrack else null)
                },
                contentAlignment = Alignment.Center
            ) { NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 20.dp) }
        }
        Text(
            "Sides", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 32.sp,
            modifier = Modifier.padding(top = 10.dp)
        )
        Text(
            "${album.title} · ${if (total == 1) "1 $noun" else "$total ${noun}s"}", color = Palette.Muted, fontSize = 13.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 2.dp)
        )
        Text(
            "Tap a track to start a new $noun there. Tap it again to join it to the $noun before.",
            color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(top = 8.dp, bottom = 12.dp)
        )

        // Quick splits: cut the album into 1 to 4 parts of about the same length
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("Split evenly into", color = Palette.Muted, fontSize = 13.sp, maxLines = 1, modifier = Modifier.padding(end = 4.dp))
            listOf(1, 2, 3, 4).forEach { n ->
                if (n <= songs.size) {
                    Box(
                        Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (n == total) Color.White else Color.White.copy(alpha = 0.1f))
                            .clickable { starts = evenSplit(album, n) },
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "$n", color = if (n == total) Color(0xFF111111) else Palette.Text, fontSize = 14.sp,
                            fontWeight = if (n == total) FontWeight.SemiBold else FontWeight.Normal
                        )
                    }
                }
            }
        }

        Row(
            Modifier.fillMaxWidth().padding(vertical = 14.dp).clip(RoundedCornerShape(16.dp))
                .background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 14.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f)) {
                Text("Number tracks again on each $noun", color = Palette.Text, fontSize = 14.sp)
                Text("1, 2, 3 ... on every $noun, as on a record", color = Palette.Muted, fontSize = 12.sp)
            }
            NeedleSwitch(renumber) { renumber = it }
        }

        LazyColumn(Modifier.weight(1f), contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(songs, key = { _, s -> s.id }) { i, song ->
              Column {
                if (i == 0 || i in starts) {
                    val end = (i + 1 until songs.size).firstOrNull { it in starts } ?: songs.size
                    val length = (i until end).sumOf { songs[it].durationMs }
                    Row(
                        Modifier.fillMaxWidth().padding(top = if (i == 0) 0.dp else 14.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        NeedleIconView(NeedleIcon.ALBUMS, Palette.Accent, size = 18.dp)
                        Spacer(Modifier.width(8.dp))
                        Text(
                            discLabel(side[i], word, letters), color = Palette.Accent, fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f)
                        )
                        Text(formatTime(length), color = Palette.Muted, fontSize = 12.5.sp)
                    }
                }
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(12.dp))
                        .then(if (i > 0) Modifier.clickable { starts = if (i in starts) starts - i else starts + i } else Modifier)
                        .padding(vertical = 10.dp, horizontal = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${if (renumber) place[i] else if (song.trackNumber > 0) song.trackNumber else i + 1}",
                        color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.width(32.dp)
                    )
                    Text(
                        song.title, color = Palette.Text, fontSize = 14.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text(formatTime(song.durationMs), color = Palette.Muted, fontSize = 12.5.sp)
                }
              }
            }
        }
    }
}

/** Cuts the album into [n] sides of about the same length. Returns the index of the first track of each new side. */
private fun evenSplit(album: HomeAlbum, n: Int): Set<Int> {
    val songs = album.songs
    if (n <= 1 || songs.size < 2) return emptySet()
    val prefix = DoubleArray(songs.size + 1)
    for (i in songs.indices) prefix[i + 1] = prefix[i] + songs[i].durationMs
    val total = prefix[songs.size]
    val out = LinkedHashSet<Int>()
    for (k in 1 until n) {
        val target = total * k / n
        var best = 1
        var bestDiff = Double.MAX_VALUE
        for (i in 1 until songs.size) {
            val d = abs(prefix[i] - target)
            if (d < bestDiff) { bestDiff = d; best = i }
        }
        out += best
    }
    return out
}
