package app.needle.music.playback

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import app.needle.music.data.Song

/**
 * Song -> what the player plays. The mediaId is the MediaStore id, used to find the song again.
 * [cover] is a cover picked in the tag editor; without one the player reads the cover embedded in the file.
 */
fun Song.toMediaItem(cover: ByteArray? = null): MediaItem {
    val metadata = MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album)
    if (cover != null) metadata.setArtworkData(cover, MediaMetadata.PICTURE_TYPE_FRONT_COVER)
    return MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(metadata.build())
        .build()
}
