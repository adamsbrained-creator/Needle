package app.needle.music.cast

import android.os.SystemClock
import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.SocketTimeoutException
import java.net.URL

/** SSDP: shout "who is a media renderer?" at the whole network and collect the answers. */
object Ssdp {
    private const val GROUP = "239.255.255.250"
    private const val PORT = 1900
    private val targets = listOf(
        "urn:schemas-upnp-org:service:AVTransport:1",
        "urn:schemas-upnp-org:device:MediaRenderer:1"
    )

    /** Blocking. Calls [onLocation] once per distinct device description URL. */
    fun search(lan: LanNet, listenMs: Int, keepGoing: () -> Boolean, onLocation: (String) -> Unit) {
        val socket = DatagramSocket()
        try {
            lan.bind(socket)
            socket.soTimeout = 400
            val group = InetAddress.getByName(GROUP)
            val end = SystemClock.elapsedRealtime() + listenMs
            var nextSend = 0L
            var sendFailures = 0
            val buf = ByteArray(4096)
            val seen = HashSet<String>()
            while (keepGoing() && SystemClock.elapsedRealtime() < end) {
                val now = SystemClock.elapsedRealtime()
                if (now >= nextSend) {
                    for (st in targets) {
                        val msg = ("M-SEARCH * HTTP/1.1\r\nHOST: $GROUP:$PORT\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n" +
                            "ST: $st\r\nUSER-AGENT: Linux/Android UPnP/1.0 Needle/0.8\r\n\r\n").toByteArray()
                        try {
                            socket.send(DatagramPacket(msg, msg.size, group, PORT))
                        } catch (e: Exception) {
                            if (sendFailures++ == 0) CastHub.log("SSDP send failed: $e")
                        }
                    }
                    nextSend = now + 1300
                }
                try {
                    val p = DatagramPacket(buf, buf.size)
                    socket.receive(p)
                    val location = headers(String(p.data, 0, p.length, Charsets.UTF_8))["location"]
                    if (location != null && seen.add(location)) onLocation(location)
                } catch (e: SocketTimeoutException) {
                    // nothing yet, loop again
                }
            }
        } finally {
            socket.close()
        }
    }

    private fun headers(text: String): Map<String, String> {
        val out = HashMap<String, String>()
        for (line in text.split("\r\n").drop(1)) {
            val i = line.indexOf(':')
            if (i > 0) out[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
        }
        return out
    }
}

/** Reads a device's description XML and pulls out its name and the addresses of its control endpoints. */
object UpnpDescription {

    fun fetch(lan: LanNet, location: String): CastDevice? {
        val c = lan.open(location)
        val text = try {
            c.connectTimeout = 3000
            c.readTimeout = 4000
            c.setRequestProperty("User-Agent", "Linux/Android UPnP/1.0 Needle/0.8")
            c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
        return parse(text, location)
    }

    private class Dev { var name = ""; var maker = ""; var model = ""; var udn = "" }
    private class Svc(val type: String, val control: String, val owner: Dev?)

    fun parse(xml: String, location: String): CastDevice? {
        val p = Xml.newPullParser()
        p.setInput(StringReader(xml))
        val stack = ArrayList<Dev>()
        val services = ArrayList<Svc>()
        var root: Dev? = null
        var urlBase: String? = null
        var svcType = ""
        var svcControl = ""

        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "device" -> { val d = Dev(); stack.add(d); if (root == null) root = d }
                    "service" -> { svcType = ""; svcControl = "" }
                    "friendlyName" -> stack.lastOrNull()?.name = p.nextText().trim()
                    "manufacturer" -> stack.lastOrNull()?.maker = p.nextText().trim()
                    "modelName" -> stack.lastOrNull()?.model = p.nextText().trim()
                    "UDN" -> stack.lastOrNull()?.udn = p.nextText().trim()
                    "URLBase" -> urlBase = p.nextText().trim()
                    "serviceType" -> svcType = p.nextText().trim()
                    "controlURL" -> svcControl = p.nextText().trim()
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (p.name.substringAfter(':')) {
                    "service" -> services.add(Svc(svcType, svcControl, stack.lastOrNull()))
                    "device" -> stack.removeLastOrNull()
                }
            }
            ev = p.next()
        }

        val avt = services.firstOrNull { it.type.contains("AVTransport", ignoreCase = true) && it.control.isNotBlank() }
            ?: return null   // not a media renderer
        val owner = avt.owner ?: root
        fun sibling(name: String) = services.firstOrNull {
            it.type.contains(name, ignoreCase = true) && it.control.isNotBlank() && it.owner === avt.owner
        } ?: services.firstOrNull { it.type.contains(name, ignoreCase = true) && it.control.isNotBlank() }

        val base = urlBase?.takeIf { it.isNotBlank() } ?: location
        fun abs(u: String) = runCatching { URL(URL(base), u).toString() }.getOrDefault(u)

        val host = runCatching { URL(location).host }.getOrDefault("")
        val rc = sibling("RenderingControl")
        val cm = sibling("ConnectionManager")
        val name = owner?.name?.ifBlank { null } ?: root?.name?.ifBlank { null } ?: host
        val model = owner?.model?.ifBlank { null } ?: owner?.maker?.ifBlank { null } ?: "Media renderer"
        val udn = owner?.udn?.ifBlank { null } ?: root?.udn?.ifBlank { null } ?: location

        return CastDevice(
            udn = udn,
            name = name,
            model = model,
            kind = kindOf("$name $model ${owner?.maker.orEmpty()}"),
            host = host,
            location = location,
            avtUrl = abs(avt.control),
            avtType = avt.type,
            rcUrl = rc?.let { abs(it.control) },
            rcType = rc?.type,
            cmUrl = cm?.let { abs(it.control) },
            cmType = cm?.type
        )
    }

    private val tvWords = Regex("\\b(tv|xbox|bravia|webos|roku|chromecast|television)\\b")
    private val pcWords = Regex("\\b(kodi|pc|windows|vlc|foobar2000|desktop|laptop|mpc|jriver|linux|mac)\\b")

    private fun kindOf(text: String): DeviceKind {
        val s = text.lowercase()
        return when {
            tvWords.containsMatchIn(s) -> DeviceKind.TV
            pcWords.containsMatchIn(s) -> DeviceKind.PC
            else -> DeviceKind.SPEAKER
        }
    }
}
