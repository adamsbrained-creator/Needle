package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/**
 * One row each time a song counts as "played" (see PlaybackService).
 * Kept separate from [Song] so rescanning the library never wipes the history.
 */
@Entity(tableName = "play_events")
data class PlayEvent(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val songId: Long,
    val playedAt: Long,   // epoch millis
    val listenedMs: Long  // how long it was actually heard (updated when playback pauses or moves on)
)

@Dao
interface PlayDao {
    @Insert
    suspend fun insert(event: PlayEvent): Long

    @Query("SELECT * FROM play_events")
    suspend fun getAll(): List<PlayEvent>

    @Insert
    suspend fun insertAll(events: List<PlayEvent>)

    @Query("SELECT COUNT(*) FROM play_events")
    fun observeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM play_events WHERE songId = :id")
    suspend fun countFor(id: Long): Int

    @Query("SELECT MAX(playedAt) FROM play_events WHERE songId = :id")
    suspend fun lastPlayedAt(id: Long): Long?

    @Query("UPDATE play_events SET listenedMs = :ms WHERE id = :id")
    suspend fun setListened(id: Long, ms: Long)

    /** The ids of every song that was played at least once. */
    @Query("SELECT DISTINCT songId FROM play_events")
    fun observePlayedIds(): Flow<List<Long>>

    /** How many times each played song was played (for "Top songs" on the artist page). */
    @Query("SELECT songId, COUNT(*) AS plays FROM play_events GROUP BY songId")
    fun observePlayCounts(): Flow<List<SongPlays>>

    /** Everything, newest first. Plenty small for a personal library. */
    @Query("SELECT * FROM play_events ORDER BY playedAt DESC")
    fun observeAll(): Flow<List<PlayEvent>>
}

/** One row of the play counts query. */
data class SongPlays(val songId: Long, val plays: Int)
