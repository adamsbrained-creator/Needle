package app.needle.music.data

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch

data class LyricsState(
    val songId: Long = -1L,
    val loading: Boolean = false,
    val lyrics: Lyrics? = null,
    val searching: Boolean = false,
    /** Short note under the empty state ("Nothing found on LRCLIB...") */
    val message: String? = null
)

class LyricsViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = LyricsRepository(app)
    private var query: LyricsQuery? = null
    private var job: Job? = null

    var state by mutableStateOf(LyricsState())
        private set

    /** How many songs have lyrics saved from LRCLIB (for Settings -> Lyrics). */
    var savedCount by mutableIntStateOf(0)
        private set

    // Songs already searched automatically in this session, so a miss is not repeated on every visit.
    private val autoTried = HashSet<Long>()

    /** Called whenever the lyrics page is showing a song. Does nothing if that song is already loaded. */
    fun load(q: LyricsQuery, force: Boolean = false) {
        if (!force && q.songId == state.songId) return
        query = q
        job?.cancel()
        state = LyricsState(songId = q.songId, loading = true)
        job = viewModelScope.launch {
            val found = runCatching { repo.local(q) }.getOrNull()
            state = state.copy(loading = false, lyrics = found)
            if (found == null && LyricsPrefs.onlineSearch.value && LyricsPrefs.autoOnline.value && autoTried.add(q.songId)) {
                searchOnline()
            }
        }
    }

    /** For the editor: the lyrics that would be shown for this song right now. */
    suspend fun initialFor(q: LyricsQuery): Lyrics? = runCatching { repo.local(q) }.getOrNull()

    /** Saves what the editor wrote and refreshes the lyrics page if it shows that song. */
    fun saveEdited(songId: Long, text: String, onDone: () -> Unit = {}) {
        viewModelScope.launch {
            repo.saveUserLyrics(songId, text)
            if (state.songId == songId) reload()
            onDone()
        }
    }

    fun refreshSavedCount() {
        viewModelScope.launch { savedCount = runCatching { repo.savedCount() }.getOrDefault(0) }
    }

    fun clearAllSaved() {
        viewModelScope.launch {
            repo.clearSaved()
            savedCount = 0
            reload()
        }
    }

    /** E.g. right after "all files access" was switched on. */
    fun reload() { query?.let { load(it, force = true) } }

    fun searchOnline() {
        val q = query ?: return
        if (state.searching) return
        state = state.copy(searching = true, message = null)
        viewModelScope.launch {
            val result = repo.online(q)
            if (state.songId != q.songId) return@launch
            state = when (result) {
                is OnlineResult.Found -> {
                    // Re-resolve so a .lrc file with timing still wins over plain online text.
                    val best = runCatching { repo.local(q) }.getOrNull() ?: result.lyrics
                    state.copy(searching = false, lyrics = best, message = null)
                }
                OnlineResult.NotFound -> state.copy(
                    searching = false,
                    message = "Nothing found on LRCLIB for this song. Check its title and artist in the tag editor."
                )
                OnlineResult.Instrumental -> state.copy(searching = false, message = "LRCLIB lists this song as instrumental.")
                is OnlineResult.Failed -> state.copy(searching = false, message = "Couldn't reach LRCLIB. Check your connection.")
            }
        }
    }

    fun forgetSaved() {
        val q = query ?: return
        viewModelScope.launch {
            repo.forgetSaved(q.songId)
            load(q, force = true)
        }
    }
}
