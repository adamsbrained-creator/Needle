package app.needle.music.cast

import android.net.Uri

enum class DeviceKind { TV, PC, SPEAKER }

/** One DLNA / UPnP "MediaRenderer" found on the network (an Xbox, Kodi, a smart TV, a speaker...). */
data class CastDevice(
    val udn: String,
    val name: String,
    val model: String,
    val kind: DeviceKind,
    val host: String,
    val location: String,
    val avtUrl: String,
    val avtType: String,
    val rcUrl: String?,
    val rcType: String?,
    val cmUrl: String?,
    val cmType: String?
) {
    val subtitle: String get() = "$model · UPnP"
}

/** The per-device options from the "Cast device settings" page. Saved per device. */
data class CastSettings(
    val volumeStep: Int = 10,
    val reportedFormats: Boolean = true,
    val gapless: Boolean = true,
    val stopWhenEnds: Boolean = true,
    val stopIfTakenOver: Boolean = false,
    val altCompat: Boolean = false
)

enum class CastPhase { LOCAL, CONNECTING, CONNECTED }

/** What the UI shows: where the music is playing right now. */
data class CastState(
    val device: CastDevice? = null,
    val phase: CastPhase = CastPhase.LOCAL,
    val volume: Int = -1
)

/** Everything the renderer needs to fetch one song from this phone. */
class TrackInfo(
    val id: Long,
    val url: String,
    val artUrl: String?,
    val mime: String,
    val size: Long,
    val ext: String
)

/** Does the device's list of supported formats (from GetProtocolInfo) cover this song's type? */
object FormatSupport {
    private val groups = listOf(
        setOf("audio/mpeg", "audio/mp3", "audio/mpeg3", "audio/x-mpeg"),
        setOf("audio/mp4", "audio/x-m4a", "audio/m4a", "audio/aac", "audio/aacp", "audio/mp4a-latm", "audio/3gpp"),
        setOf("audio/flac", "audio/x-flac"),
        setOf("audio/wav", "audio/x-wav", "audio/wave", "audio/vnd.wave", "audio/l16"),
        setOf("audio/ogg", "application/ogg", "audio/x-ogg", "audio/vorbis", "audio/opus"),
        setOf("audio/x-ms-wma", "audio/wma")
    )

    fun supports(sink: List<String>, mime: String): Boolean {
        val wanted = mime.lowercase().substringBefore(';').trim()
        val group = groups.firstOrNull { wanted in it } ?: setOf(wanted)
        for (entry in sink) {
            val f = entry.trim().split(':')   // protocol : network : contentFormat : additionalInfo
            if (f.size < 3 || !f[0].equals("http-get", ignoreCase = true)) continue
            val format = f[2].lowercase().substringBefore(';').trim()
            if (format == "*" || format == "*/*" || format in group) return true
        }
        return false
    }
}

/** What the engine knows about one queue item: the edited tags and cover come straight from the player's MediaItem. */
class TrackSource(
    val id: Long,
    val uri: Uri,
    val title: String,
    val artist: String,
    val album: String,
    val cover: ByteArray?,
    val durationMs: Long
)

/** The small XML description of a song that renderers show on screen (title, artist, cover). */
object Didl {
    fun build(src: TrackSource, t: TrackInfo, alt: Boolean): String {
        val flags = "DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
        val pn = if (t.mime == "audio/mpeg") "DLNA.ORG_PN=MP3;" else ""
        // Normal mode tells the device the file can be seeked (OP=01). Alternative mode sends the plain wildcard.
        val fourth = if (alt) "*" else "$pn$flags"
        val e = Soap::escape
        return buildString {
            append("<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\" ")
            append("xmlns:dc=\"http://purl.org/dc/elements/1.1/\" ")
            append("xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\" ")
            append("xmlns:dlna=\"urn:schemas-dlna-org:metadata-1-0/\">")
            append("<item id=\"${src.id}\" parentID=\"0\" restricted=\"1\">")
            append("<dc:title>${e(src.title)}</dc:title>")
            append("<dc:creator>${e(src.artist)}</dc:creator>")
            append("<upnp:artist>${e(src.artist)}</upnp:artist>")
            append("<upnp:album>${e(src.album)}</upnp:album>")
            if (t.artUrl != null) append("<upnp:albumArtURI>${e(t.artUrl)}</upnp:albumArtURI>")
            append("<upnp:class>object.item.audioItem.musicTrack</upnp:class>")
            append("<res protocolInfo=\"${e("http-get:*:${t.mime}:$fourth")}\"")
            if (src.durationMs > 0) append(" duration=\"${Soap.formatTime(src.durationMs, true)}\"")
            if (t.size > 0) append(" size=\"${t.size}\"")
            append(">${e(t.url)}</res>")
            append("</item></DIDL-Lite>")
        }
    }
}
