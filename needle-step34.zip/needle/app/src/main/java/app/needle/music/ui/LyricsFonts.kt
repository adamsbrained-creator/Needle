package app.needle.music.ui

import androidx.compose.ui.text.font.Font
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import app.needle.music.R

/**
 * The fonts you can pick in Settings -> Lyrics. One font is used for every lyric line (the one being sung and the
 * others), so a line never changes typeface while it grows. Outfit is bundled with the app (OFL license, see
 * assets/licenses/Outfit-OFL.txt); the others are the phone's own fonts.
 */
enum class LyricsFont(val id: String, val label: String, val family: FontFamily, val weight: FontWeight) {
    OUTFIT(
        "outfit", "Outfit",
        FontFamily(Font(R.font.outfit_regular, FontWeight.Normal), Font(R.font.outfit_bold, FontWeight.Bold)),
        FontWeight.Bold
    ),
    SANS("sans", "Sans", FontFamily.Default, FontWeight.SemiBold),
    SERIF("serif", "Serif", FontFamily.Serif, FontWeight.Medium),
    MONO("mono", "Mono", FontFamily.Monospace, FontWeight.Medium);

    companion object {
        val default = OUTFIT
        fun byId(id: String?): LyricsFont = entries.firstOrNull { it.id == id } ?: default
    }
}
