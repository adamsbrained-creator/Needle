package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.content.SharedPreferences
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.media.MediaScannerConnection
import android.provider.MediaStore
import androidx.compose.runtime.mutableStateOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.OutputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.util.zip.CRC32

/** The option "Write tags into files" in Settings, remembered. */
object WritePrefs {
    private var prefs: SharedPreferences? = null

    /** When on, saving in the tag editor also writes into the audio file. Off until the person turns it on. */
    val enabled = mutableStateOf(false)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        enabled.value = p.getBoolean("write_to_files", false)
    }

    fun set(value: Boolean) {
        enabled.value = value
        prefs?.edit()?.putBoolean("write_to_files", value)?.apply()
    }
}

class WriteResult(val songId: Long, val name: String, val error: String?) {
    val ok get() = error == null
}

/**
 * Writes the tags that were edited in Needle into the audio files themselves, so other programs
 * (Symfonium, Mp3tag ...) see them. A song's file is never touched until the new version has passed these checks:
 *
 * 1. The new file is built next to nothing important: in the app's cache, from the old file.
 * 2. It must have exactly the planned size, the audio inside must be byte for byte the old audio, Android must be
 *    able to open it with the same length, and the first samples must read the same as before (for M4A, every chunk offset must point at the same audio bytes).
 * 3. A backup of the old file is made first, with a note saying so. Only then the old file is overwritten.
 * 4. The result is compared with the checked version. If anything differs, the backup is put back.
 * 5. If the app dies in the middle, the backup is put back the next time it starts ([recover]).
 *
 * Needle's own edits stay in its database, so nothing is lost if a file cannot be written.
 */
object TagWriter {
    private const val EXTRA_SPACE = 8L * 1024 * 1024
    private const val COPY_BUFFER = 256 * 1024

    private fun workDir(context: Context) = File(context.filesDir, "tagwrite").apply { mkdirs() }
    private fun cacheDir(context: Context) = File(context.cacheDir, "tagwrite").apply { mkdirs() }

    /** Writes the edits of every song in [ids]. Songs without edits are skipped. */
    suspend fun writeSongs(context: Context, ids: List<Long>, onProgress: (Int, Int) -> Unit = { _, _ -> }): List<WriteResult> =
        withContext(Dispatchers.IO) {
            val db = NeedleDatabase.get(context)
            val wanted = ids.toHashSet()
            val songs = db.songDao().getAllOnce().filter { it.id in wanted }
            val edits = db.tagDao().getAll().associateBy { it.songId }
            val extraRows = db.extraTagDao().getAll().groupBy { it.songId }

            val results = ArrayList<WriteResult>()
            val written = ArrayList<Long>()
            val paths = ArrayList<String>()
            songs.forEachIndexed { i, song ->
                onProgress(i, songs.size)
                val e = edits[song.id]
                val core = LinkedHashMap<String, String>()
                e?.title?.let { core["TITLE"] = it }
                e?.artist?.let { core["ARTIST"] = it }
                e?.album?.let { core["ALBUM"] = it }
                e?.genre?.let { core["GENRE"] = it }
                e?.year?.let { core["YEAR"] = it.toString() }
                e?.trackNumber?.let { core["TRACK"] = it.toString() }
                val extras = extraRows[song.id].orEmpty().associate { it.field to it.value }
                val write = TagWrite(core, extras, CoverStore.readBytes(context, song.id))
                if (!write.isEmpty()) {
                    val path = audioPath(context, song.id)
                    val error = if (path == null) "Cannot find the file" else writeOne(context, File(path), song.id, write)
                    results += WriteResult(song.id, song.title, error)
                    if (error == null) { written += song.id; paths += path!! }
                }
            }
            onProgress(songs.size, songs.size)

            if (written.isNotEmpty()) {
                // The tags in the files changed: read them again, and let the media database see the new files.
                for (chunk in written.chunked(500)) {
                    db.fileTagDao().deleteTags(chunk)
                    db.fileTagDao().deleteScans(chunk)
                }
                MediaScannerConnection.scanFile(context, paths.toTypedArray(), null, null)
            }
            results
        }

    @Suppress("DEPRECATION")
    private fun audioPath(context: Context, songId: Long): String? {
        val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, songId)
        return context.contentResolver.query(uri, arrayOf(MediaStore.Audio.Media.DATA), null, null, null)?.use {
            if (it.moveToFirst()) it.getString(0) else null
        }
    }

    /** null = written and checked; otherwise why not. The original file is untouched in every error case. */
    private fun writeOne(context: Context, file: File, songId: Long, write: TagWrite): String? {
        if (!file.isFile) return "The file was not found"
        if (!file.canWrite()) return "No write access (turn on All files access)"
        val size = file.length()
        val work = workDir(context)
        val cache = cacheDir(context)
        if (cache.usableSpace < size + EXTRA_SPACE || work.usableSpace < size + EXTRA_SPACE) return "Not enough free space"

        val temp = File(cache, "$songId.new")
        val backup = File(work, "$songId.orig")
        val journal = File(work, "$songId.journal")
        try {
            // 1. build the new file in the cache
            val plan = FileInputStream(file).use { FileTagWriter.plan(it.channel, write) }
            FileInputStream(file).use { input ->
                FileOutputStream(temp).use { out -> writePlan(plan, input.channel, out) }
            }

            // 2. check it before it replaces anything
            checkNewFile(file, temp, plan, write)?.let { return it }

            // 3. backup + note, 4. overwrite in place (so the media database keeps the same song)
            file.copyTo(backup, overwrite = true)
            journal.writeText(file.absolutePath)
            try {
                FileInputStream(temp).use { input ->
                    FileOutputStream(file).use { out ->
                        input.copyTo(out, COPY_BUFFER)
                        out.fd.sync()
                    }
                }
                if (!sameContent(file, temp)) throw IllegalStateException("The file differs after writing")
            } catch (e: Exception) {
                restore(backup, file)
                backup.delete(); journal.delete()
                return "Writing failed, the original file was put back (${e.message})"
            }
            backup.delete(); journal.delete()
            return null
        } catch (e: UnsupportedFormat) {
            return e.message
        } catch (e: Exception) {
            return "Could not write: ${e.message}"
        } finally {
            temp.delete()
        }
    }

    // ---- building and checking ---------------------------------------------------------------

    private fun writePlan(plan: WritePlan, src: FileChannel, out: OutputStream) {
        val buf = ByteBuffer.allocate(COPY_BUFFER)
        for (seg in plan.segments) {
            when (seg) {
                is Segment.Bytes -> out.write(seg.data)
                is Segment.Range -> {
                    var pos = seg.start
                    while (pos < seg.end) {
                        buf.clear()
                        buf.limit(minOf(buf.capacity().toLong(), seg.end - pos).toInt())
                        val n = src.read(buf, pos)
                        if (n <= 0) throw IllegalStateException("The file ended too early")
                        out.write(buf.array(), 0, n)
                        pos += n
                    }
                }
            }
        }
    }

    private fun checkNewFile(original: File, temp: File, plan: WritePlan, write: TagWrite): String? {
        // Size
        val expected = plan.segments.sumOf {
            when (it) {
                is Segment.Bytes -> it.data.size.toLong()
                is Segment.Range -> it.end - it.start
            }
        }
        if (temp.length() != expected) return "The new file has the wrong size"

        // The audio parts of the new file are the old audio, byte for byte
        FileInputStream(original).use { a ->
            FileInputStream(temp).use { b ->
                var outPos = 0L
                for (seg in plan.segments) {
                    when (seg) {
                        is Segment.Bytes -> outPos += seg.data.size
                        is Segment.Range -> {
                            val len = seg.end - seg.start
                            if (crc(a.channel, seg.start, len) != crc(b.channel, outPos, len)) return "The audio changed while copying"
                            outPos += len
                        }
                    }
                }
            }
        }

        // Android must open it the same way
        val before = probe(original.path)
        val after = probe(temp.path)
        if (before.duration > 0) {
            if (after.duration <= 0 || kotlin.math.abs(after.duration - before.duration) > 250) {
                return "Android cannot read the new file correctly"
            }
        }
        write.core["TITLE"]?.let { if (after.title != it) return "The new title is not readable in the new file" }
        write.core["ARTIST"]?.let { if (after.artist != it) return "The new artist is not readable in the new file" }
        write.core["ALBUM"]?.let { if (after.album != it) return "The new album is not readable in the new file" }

        // The first audio samples read the same as before. (Read one after the other, not by seeking: where a
        // seek lands depends on the size of the file, so it can differ even when the audio is identical.)
        val s1 = firstSamples(original.path)
        if (s1 != null) {
            val s2 = firstSamples(temp.path) ?: return "The new file cannot be decoded"
            if (s1 != s2) return "The new file decodes differently"
        }

        // M4A: every chunk offset must point at the same audio bytes as in the old file
        if (plan.format == "M4A") {
            val a = FileInputStream(original).use { FileTagWriter.chunkOffsets(it.channel) }
            val b = FileInputStream(temp).use { FileTagWriter.chunkOffsets(it.channel) }
            if (a == null || b == null || a.size != b.size) return "The chunk table of the new file is wrong"
            FileInputStream(original).use { x ->
                FileInputStream(temp).use { y ->
                    val step = maxOf(1, a.size / 300)
                    var i = 0
                    while (i < a.size) {
                        if (!sameBytes(x.channel, a[i], y.channel, b[i], 32)) return "The new file points at the wrong audio"
                        i += step
                    }
                    if (a.isNotEmpty() && !sameBytes(x.channel, a.last(), y.channel, b.last(), 32)) return "The new file points at the wrong audio"
                }
            }
        }
        return null
    }

    private fun sameBytes(x: FileChannel, xPos: Long, y: FileChannel, yPos: Long, n: Int): Boolean {
        val p = ByteBuffer.allocate(n)
        val q = ByteBuffer.allocate(n)
        val a = x.read(p, xPos)
        val b = y.read(q, yPos)
        return a == b && a > 0 && p.array().copyOf(a).contentEquals(q.array().copyOf(b))
    }

    private class Probe(val duration: Long, val title: String?, val artist: String?, val album: String?)

    private fun probe(path: String): Probe {
        val r = MediaMetadataRetriever()
        return try {
            r.setDataSource(path)
            Probe(
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L,
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST),
                r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ALBUM)
            )
        } catch (e: Exception) {
            Probe(0L, null, null, null)
        } finally {
            r.release()
        }
    }

    /** A fingerprint of the first 40 audio samples. null = cannot be decoded here. */
    private fun firstSamples(path: String): List<Long>? {
        val ex = MediaExtractor()
        return try {
            ex.setDataSource(path)
            val track = (0 until ex.trackCount).firstOrNull {
                ex.getTrackFormat(it).getString(MediaFormat.KEY_MIME)?.startsWith("audio/") == true
            } ?: return null
            ex.selectTrack(track)
            val buf = ByteBuffer.allocate(1 shl 20)
            val out = ArrayList<Long>()
            var count = 0
            while (count < 40) {
                buf.clear()
                val n = ex.readSampleData(buf, 0)
                if (n < 0) break
                val c = CRC32()
                c.update(buf.array(), 0, n)
                out += (n.toLong() shl 32) xor c.value
                out += ex.sampleTime
                if (!ex.advance()) break
                count++
            }
            out
        } catch (e: Exception) {
            null
        } finally {
            ex.release()
        }
    }

    private fun crc(ch: FileChannel, start: Long, length: Long): Long {
        val c = CRC32()
        val buf = ByteBuffer.allocate(COPY_BUFFER)
        var pos = start
        val end = start + length
        while (pos < end) {
            buf.clear()
            buf.limit(minOf(buf.capacity().toLong(), end - pos).toInt())
            val n = ch.read(buf, pos)
            if (n <= 0) break
            c.update(buf.array(), 0, n)
            pos += n
        }
        return c.value
    }

    private fun sameContent(a: File, b: File): Boolean {
        if (a.length() != b.length()) return false
        return FileInputStream(a).use { x -> FileInputStream(b).use { y -> crc(x.channel, 0, a.length()) == crc(y.channel, 0, b.length()) } }
    }

    private fun restore(backup: File, target: File) {
        FileInputStream(backup).use { input ->
            FileOutputStream(target).use { out ->
                input.copyTo(out, COPY_BUFFER)
                out.fd.sync()
            }
        }
    }

    /**
     * Runs when the app starts. A note that is still there means the app stopped while a file was being replaced,
     * so the backup is put back. (The edits are still in Needle's database; write them again whenever you like.)
     */
    fun recover(context: Context) {
        val work = workDir(context)
        work.listFiles { f -> f.name.endsWith(".journal") }?.forEach { journal ->
            try {
                val target = File(journal.readText())
                val backup = File(work, journal.name.removeSuffix(".journal") + ".orig")
                if (backup.isFile && target.parentFile?.exists() == true) restore(backup, target)
                backup.delete()
                journal.delete()
            } catch (e: Exception) {
                // keep the note and backup, try again next start
            }
        }
        cacheDir(context).listFiles()?.forEach { it.delete() } // half-built files from an earlier stop
    }
}
