package app.needle.music.cast

import android.util.Xml
import org.xmlpull.v1.XmlPullParser
import java.io.StringReader

class UpnpException(val code: Int?, message: String) : Exception(message)

/** Minimal UPnP "SOAP" client: one POST per action, answers come back as a flat name -> text map. */
object Soap {
    private const val UA = "Linux/Android UPnP/1.0 Needle/0.8"

    fun call(
        lan: LanNet,
        url: String,
        serviceType: String,
        action: String,
        args: List<Pair<String, String>> = emptyList(),
        readTimeoutMs: Int = 6000
    ): Map<String, String> {
        val body = buildString {
            append("<?xml version=\"1.0\" encoding=\"utf-8\"?>")
            append("<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\" ")
            append("s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\"><s:Body>")
            append("<u:$action xmlns:u=\"$serviceType\">")
            for ((k, v) in args) append("<$k>").append(escape(v)).append("</$k>")
            append("</u:$action></s:Body></s:Envelope>")
        }.toByteArray(Charsets.UTF_8)

        val c = lan.open(url)
        try {
            c.connectTimeout = 3000
            c.readTimeout = readTimeoutMs
            c.requestMethod = "POST"
            c.doOutput = true
            c.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"")
            c.setRequestProperty("SOAPACTION", "\"$serviceType#$action\"")
            c.setRequestProperty("User-Agent", UA)
            c.setFixedLengthStreamingMode(body.size)
            c.outputStream.use { it.write(body) }

            val code = c.responseCode
            if (code in 200..299) {
                return parse(c.inputStream.bufferedReader().use { it.readText() })
            }
            val err = runCatching { c.errorStream?.bufferedReader()?.use { it.readText() } }.getOrNull().orEmpty()
            val m = parse(err)
            throw UpnpException(m["errorCode"]?.toIntOrNull(), "$action failed: HTTP $code ${m["errorDescription"].orEmpty()}".trim())
        } finally {
            c.disconnect()
        }
    }

    /** Every leaf element's text, by local name (no namespace prefix). */
    fun parse(xml: String): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        if (xml.isBlank()) return out
        try {
            val p = Xml.newPullParser()
            p.setInput(StringReader(xml))
            var current = ""
            var ev = p.eventType
            while (ev != XmlPullParser.END_DOCUMENT) {
                when (ev) {
                    XmlPullParser.START_TAG -> current = p.name.substringAfter(':')
                    XmlPullParser.TEXT -> if (current.isNotEmpty() && p.text.isNotBlank()) out[current] = p.text.trim()
                    XmlPullParser.END_TAG -> current = ""
                }
                ev = p.next()
            }
        } catch (e: Exception) {
            // Half-broken XML from a renderer: keep whatever we managed to read.
        }
        return out
    }

    fun escape(s: String): String = s
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
        .replace("\"", "&quot;").replace("'", "&apos;")

    /** "0:03:05.250" or "0:03:05" -> milliseconds. NOT_IMPLEMENTED and friends -> null. */
    fun parseTime(s: String?): Long? {
        if (s.isNullOrBlank()) return null
        val parts = s.trim().split(':')
        if (parts.size != 3) return null
        val h = parts[0].toLongOrNull() ?: return null
        val m = parts[1].toLongOrNull() ?: return null
        val sec = parts[2].toDoubleOrNull() ?: return null
        return ((h * 3600 + m * 60) * 1000 + (sec * 1000).toLong())
    }

    fun formatTime(ms: Long, withMillis: Boolean = false): String {
        val total = ms.coerceAtLeast(0)
        val h = total / 3_600_000
        val m = (total / 60_000) % 60
        val s = (total / 1000) % 60
        val base = "%d:%02d:%02d".format(h, m, s)
        return if (withMillis) "$base.%03d".format(total % 1000) else base
    }
}
