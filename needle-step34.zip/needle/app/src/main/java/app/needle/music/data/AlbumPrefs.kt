package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

/** How the discs of an album are named on its page. Remembered. */
object AlbumPrefs {
    private var prefs: SharedPreferences? = null

    /** What a disc is called: "Disc", "Side", "Part", or anything the person types. */
    val discWord = mutableStateOf("Disc")

    /** On: A, B, C ("Side A"). Off: 1, 2, 3 ("Disc 1"). */
    val discLetters = mutableStateOf(false)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        if (p.contains("disc_word")) {
            discWord.value = p.getString("disc_word", "Disc") ?: "Disc"
            discLetters.value = p.getBoolean("disc_letters", false)
        } else if (p.getBoolean("discs_as_sides", false)) {
            // the earlier on/off switch "Show discs as sides" becomes: the word Side, with letters
            discWord.value = "Side"
            discLetters.value = true
        }
    }

    fun setDiscWord(value: String) {
        discWord.value = value
        prefs?.edit()?.putString("disc_word", value)?.apply()
    }

    fun setDiscLetters(value: Boolean) {
        discLetters.value = value
        prefs?.edit()?.putBoolean("disc_letters", value)?.apply()
        // remember the word too, so the old switch is not read again
        prefs?.edit()?.putString("disc_word", discWord.value)?.apply()
    }
}

/** The disc (or side) a song is on, from its Disc tag ("2" or "2/4"). Songs without the tag count as disc 1. */
fun discOf(extras: Map<String, String>?): Int =
    extras?.get("DISCNUMBER")?.substringBefore('/')?.trim()?.toIntOrNull()?.takeIf { it > 0 } ?: 1

/** "Disc 2", "Side B", "Part 3" ... The word and the letters-or-numbers choice come from [AlbumPrefs]. */
fun discLabel(disc: Int, word: String, letters: Boolean): String {
    val name = word.trim().ifEmpty { "Disc" }
    return if (letters && disc in 1..26) "$name ${'A' + (disc - 1)}" else "$name $disc"
}
