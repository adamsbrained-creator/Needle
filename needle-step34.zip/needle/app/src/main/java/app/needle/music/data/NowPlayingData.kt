package app.needle.music.data

import java.util.concurrent.TimeUnit

// Everything the cards under the player (About the artist, Credits, From your library) show.
// Pure functions with no Android in them, like HomeData.kt.

private const val UNKNOWN_ARTIST = "Unknown artist"

fun isKnownArtist(artist: String): Boolean = artist.isNotBlank() && artist != UNKNOWN_ARTIST

/** Songs whose artist is exactly this one (ignoring upper/lower case). */
fun songsByArtist(songs: List<Song>, artist: String): List<Song> {
    val key = artistKey(artist)
    return songs.filter { artistKey(it.artist) == key }
}

// ---- About the artist ---------------------------------------------------------------------

data class ArtistStats(
    val albums: Int,
    val songs: Int,
    val played: Int,
    /** One song per album, to show their covers. The playing song's album comes first. */
    val covers: List<Song>
) {
    /** "3 albums · 24 songs · Played 14 of 24" */
    val line: String
        get() = buildList {
            if (albums > 0) add(if (albums == 1) "1 album" else "$albums albums")
            add(if (songs == 1) "1 song" else "$songs songs")
            add("Played $played of $songs")
        }.joinToString(" · ")
}

fun buildArtistStats(current: Song, artistSongs: List<Song>, realAlbumIds: Set<Long>, playedIds: Set<Long>): ArtistStats {
    val byAlbum = artistSongs.groupBy { it.albumId }
    val real = byAlbum.keys.filter { it in realAlbumIds }
    // Covers: real albums first, the playing one at the very front, newest first after that.
    val order = (real.sortedByDescending { id -> byAlbum.getValue(id).maxOf { it.dateAdded } } +
        byAlbum.keys.filter { it !in realAlbumIds })
        .sortedBy { if (it == current.albumId) 0 else 1 }
    val covers = order.take(4).map { id -> if (id == current.albumId) current else byAlbum.getValue(id).first() }
    return ArtistStats(
        albums = real.size,
        songs = artistSongs.size,
        played = artistSongs.count { it.id in playedIds },
        covers = covers
    )
}

// ---- Credits ------------------------------------------------------------------------------

/** One person and everything they did on this song. */
data class Credit(val name: String, val roles: List<String>)

private fun String.splitNames(): List<String> =
    split(';').map { it.trim() }.filter { it.isNotEmpty() }

/** "Role:Person;Role:Person" (also one per line), as read from "Involved people" and "Musician credits". */
private fun String.splitPairs(): List<Pair<String, String>> =
    split(';', '\n').map { it.trim() }.filter { it.isNotEmpty() }.map { entry ->
        val role = entry.substringBefore(':', "").trim()
        val person = entry.substringAfter(':', entry).trim()
        role to person
    }.filter { it.second.isNotEmpty() }

/** The people behind a song, from its tags. The artist is always first. Several roles of one person are merged. */
fun buildCredits(song: Song, tags: Map<String, String>): List<Credit> {
    val order = LinkedHashMap<String, String>()      // lower-case name -> name as written
    val roles = LinkedHashMap<String, MutableList<String>>()

    fun add(name: String, role: String) {
        val key = name.lowercase()
        order.putIfAbsent(key, name)
        val list = roles.getOrPut(key) { mutableListOf() }
        if (role.isNotEmpty() && list.none { it.equals(role, ignoreCase = true) }) list += role
    }

    fun tag(key: String) = tags[key]?.takeIf { it.isNotBlank() }

    if (isKnownArtist(song.artist)) song.artist.splitNames().forEach { add(it, "Main artist") }
    tag("ALBUMARTIST")?.splitNames()?.forEach { add(it, "Album artist") }
    tag("COMPOSER")?.splitNames()?.forEach { add(it, "Composer") }
    tag("LYRICIST")?.splitNames()?.forEach { add(it, "Lyricist") }
    tag("CONDUCTOR")?.splitNames()?.forEach { add(it, "Conductor") }
    tag("MIXARTIST")?.splitNames()?.forEach { add(it, "Remixer") }
    tag("ORIGARTIST")?.splitNames()?.forEach { add(it, "Original artist") }
    tag("ORIGLYRICIST")?.splitNames()?.forEach { add(it, "Original lyricist") }
    tag("NARRATOR")?.splitNames()?.forEach { add(it, "Narrator") }
    tag("INVOLVEDPEOPLE")?.splitPairs()?.forEach { (role, person) -> add(person, role.ifEmpty { "Involved" }.cap()) }
    tag("MUSICIANCREDITS")?.splitPairs()?.forEach { (role, person) -> add(person, role.ifEmpty { "Musician" }.cap()) }

    return order.map { (key, name) -> Credit(name, roles.getValue(key)) }
}

private fun String.cap(): String = replaceFirstChar { it.uppercase() }

// ---- From your library --------------------------------------------------------------------

/** A tile under "From your library". Tapping it plays [songs]. */
data class LibraryTile(val label: String, val songs: List<Song>, val cover: Song)

private val WEEK_SEC = TimeUnit.DAYS.toSeconds(7)

fun buildLibraryTiles(current: Song, songs: List<Song>): List<LibraryTile> {
    // A cover from another album if there is one, so the tile does not just repeat the cover on the player.
    fun pick(group: List<Song>): Song = group.firstOrNull { it.albumId != current.albumId } ?: group.first()
    val tiles = ArrayList<LibraryTile>()

    if (isKnownArtist(current.artist)) {
        val more = songsByArtist(songs, current.artist).filter { it.id != current.id }
        if (more.isNotEmpty()) tiles += LibraryTile("More from ${current.artist}", more, pick(more))
    }
    val genre = current.genre.trim()
    if (genre.isNotEmpty()) {
        val same = songs.filter { it.id != current.id && it.genre.trim().equals(genre, ignoreCase = true) }
        if (same.isNotEmpty()) tiles += LibraryTile("$genre in your library", same, pick(same))
    }
    val week = songs.filter { it.id != current.id && kotlin.math.abs(it.dateAdded - current.dateAdded) <= WEEK_SEC }
    if (week.isNotEmpty()) tiles += LibraryTile("Added the same week", week, pick(week))
    return tiles
}
