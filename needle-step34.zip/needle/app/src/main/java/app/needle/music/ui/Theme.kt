package app.needle.music.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import app.needle.music.data.AccentChoices
import app.needle.music.data.NeedleSettings

/** Colors taken from the Needle mockup pack. Change the look here. */
object Palette {
    /** Pure black when AMOLED is on (Settings > Appearance). Read while drawing, so a change shows instantly. */
    val Bg: Color get() = if (NeedleSettings.amoled.value) Color.Black else Color(0xFF101012)
    val Surface = Color(0xFF1C1C20)
    val Text = Color(0xFFF2F2F5)
    val Muted = Color(0xFF9A9AA3)
    /** The accent color picked in Settings > Appearance. */
    val Accent: Color get() = AccentChoices[NeedleSettings.accentIndex.intValue].color

    /** Serif or sans, picked in Settings > Appearance. Used for every big title. */
    val TitleFont: FontFamily get() = if (NeedleSettings.serifTitles.value) FontFamily.Serif else FontFamily.SansSerif

    // Home screen cards, from the mockup
    val Card = Color(0xFF333335)
    val Card2 = Color(0xFF3C3C3E)
    val Green = Color(0xFF5C875C)
    val Pink = Color(0xFFEF42B8)
}

@Composable
fun NeedleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Bg,
            surface = Palette.Surface,
            onBackground = Palette.Text,
            onSurface = Palette.Text
        ),
        content = { GlowProvider(content) }
    )
}
