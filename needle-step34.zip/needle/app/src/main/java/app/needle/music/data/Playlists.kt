package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Index
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

/** The id of "Liked songs", the one playlist every install has. */
const val LIKED_ID = 1L

/** A playlist. [kind] is 1 for Liked songs (it cannot be renamed or deleted) and 0 for the ones you make. */
@Entity(tableName = "playlists")
data class Playlist(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val kind: Int = 0,
    val createdAt: Long,
    val updatedAt: Long
)

/** One song in one playlist. [position] keeps the order they were added in; [addedAt] is when. */
@Entity(tableName = "playlist_songs", primaryKeys = ["playlistId", "songId"], indices = [Index("songId")])
data class PlaylistSong(
    val playlistId: Long,
    val songId: Long,
    val position: Long,
    val addedAt: Long
)

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists")
    fun observePlaylists(): Flow<List<Playlist>>

    @Query("SELECT * FROM playlist_songs")
    fun observeEntries(): Flow<List<PlaylistSong>>

    @Query("SELECT * FROM playlists")
    suspend fun getAll(): List<Playlist>

    @Query("SELECT * FROM playlist_songs")
    suspend fun getAllEntries(): List<PlaylistSong>

    /** Ignored when the id is taken (that is how "Liked songs" is created once). */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertPlaylist(playlist: Playlist): Long

    /** A song that is already in the playlist is left where it is. */
    @Insert(onConflict = OnConflictStrategy.IGNORE)
    suspend fun insertEntries(rows: List<PlaylistSong>)

    @Query("SELECT COALESCE(MAX(position), 0) FROM playlist_songs WHERE playlistId = :id")
    suspend fun maxPosition(id: Long): Long

    @Query("DELETE FROM playlist_songs WHERE playlistId = :id AND songId IN (:songIds)")
    suspend fun removeSongs(id: Long, songIds: List<Long>)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :id")
    suspend fun clear(id: Long)

    @Query("DELETE FROM playlists WHERE id = :id AND kind = 0")
    suspend fun delete(id: Long)

    @Query("UPDATE playlists SET name = :name, updatedAt = :now WHERE id = :id AND kind = 0")
    suspend fun rename(id: Long, name: String, now: Long)

    @Query("UPDATE playlists SET updatedAt = :now WHERE id = :id")
    suspend fun touch(id: Long, now: Long)
}

/** A playlist ready to show: its songs (only the ones still in your library), in the order they were added. */
class PlaylistData(
    val id: Long,
    val name: String,
    val liked: Boolean,
    val songs: List<Song>,
    /** song id -> when it was added */
    val addedAt: Map<Long, Long>,
    val updatedAt: Long
) {
    val durationMs: Long get() = songs.sumOf { it.durationMs }
    val songIds: Set<Long> by lazy { songs.mapTo(HashSet()) { it.id } }

    /** Up to four covers for the mosaic: different albums first. */
    val covers: List<Song> by lazy { (songs.distinctBy { it.albumId } + songs).distinctBy { it.id }.take(4) }
}

/** Liked songs first, then the playlists you changed most recently. */
fun buildPlaylists(rows: List<Playlist>, entries: List<PlaylistSong>, songs: List<Song>): List<PlaylistData> {
    val byId = HashMap<Long, Song>(songs.size * 2)
    songs.forEach { byId[it.id] = it }
    val grouped = entries.groupBy { it.playlistId }
    return rows.map { p ->
        val es = grouped[p.id].orEmpty().sortedBy { it.position }
        val list = ArrayList<Song>(es.size)
        val added = HashMap<Long, Long>()
        for (e in es) {
            val song = byId[e.songId] ?: continue
            list += song
            added[song.id] = e.addedAt
        }
        PlaylistData(p.id, p.name, p.kind == 1, list, added, p.updatedAt)
    }.sortedWith(compareByDescending<PlaylistData> { it.liked }.thenByDescending { it.updatedAt })
}

/** "14 h 8 min", "52 min", "3 min" */
fun playlistDuration(ms: Long): String {
    val totalMin = (ms / 60_000L).toInt()
    val h = totalMin / 60
    val m = totalMin % 60
    return when {
        h > 0 -> "$h h $m min"
        else -> "${maxOf(totalMin, 1)} min"
    }
}

fun songsText(n: Int): String = if (n == 1) "1 song" else "$n songs"
