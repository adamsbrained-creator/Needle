package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.LyricsViewModel
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(
    vm: PlayerViewModel,
    onClose: () -> Unit,
    onOpenQueue: () -> Unit,
    modifier: Modifier = Modifier,
    castActive: Boolean = false,
    onOpenPlayOn: () -> Unit = {},
    onOpenLyrics: () -> Unit = {},
    onOpenControls: () -> Unit = {},
    liked: Boolean = false,
    onToggleLike: () -> Unit = {},
    onRate: () -> Unit = {},
    lyricsVm: LyricsViewModel? = null,
    library: NowPlayingLibrary? = null
) {
    // While playing, refresh the progress bar a few times per second.
    LaunchedEffect(vm.isPlaying) {
        while (vm.isPlaying) {
            vm.refreshPosition()
            delay(250)
        }
    }

    Column(
        modifier = modifier
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            Modifier.fillMaxWidth().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChevronDownButton(onClose)
            Text("Now playing", color = Palette.Muted, fontSize = 14.sp)
            // The Needle bars open the Player controls sheet; Play on (cast) sits under the playback controls.
            RoundIconButton(NeedleIcon.CONTROLS, onOpenControls, size = 44.dp, iconSize = 24.dp)
        }

        Spacer(Modifier.height(8.dp))
        Artwork(vm.artwork, Modifier.fillMaxWidth().aspectRatio(1f))
        Spacer(Modifier.height(28.dp))

        Text(
            text = vm.title ?: "Nothing playing",
            color = Palette.Text,
            fontFamily = Palette.TitleFont,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            lineHeight = 34.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = vm.artist ?: "",
            color = Palette.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(Modifier.height(24.dp))

        val duration = vm.durationMs
        val progress = if (duration > 0) (vm.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
        NeedleProgressBar(
            progress = progress,
            enabled = vm.hasMedia && duration > 0,
            onSeek = vm::seekToFraction,
            modifier = Modifier.fillMaxWidth()
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(formatTime(vm.positionMs), color = Palette.Muted, fontSize = 13.sp)
            Text(formatTime(duration), color = Palette.Muted, fontSize = 13.sp)
        }

        Spacer(Modifier.height(16.dp))

        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ShuffleButton(active = vm.shuffleEnabled, onClick = vm::toggleShuffle)
            SkipButton(next = false, enabled = vm.hasMedia, onClick = vm::previous)
            PlayPauseButton(isPlaying = vm.isPlaying, enabled = vm.hasMedia, onClick = vm::togglePlay)
            SkipButton(next = true, enabled = vm.hasMedia, onClick = vm::next)
            RepeatButton(mode = vm.repeatMode, onClick = vm::cycleRepeat)
        }

        Spacer(Modifier.height(28.dp))

        // Up next on the left; the star (Liked songs) and Play on (cast) on the right. The lyrics are opened from the preview card below.
        Row(
            Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            PillButton("Up next · ${vm.queueSize}", onClick = onOpenQueue)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                // Purple and filled when the song is in Liked songs
                RoundIconButton(
                    if (liked) NeedleIcon.STAR_FILLED else NeedleIcon.STAR, onToggleLike,
                    size = 44.dp, iconSize = 24.dp, active = liked, onLongClick = onRate   // press and hold = rate the song
                )
                RoundIconButton(NeedleIcon.CAST, onOpenPlayOn, size = 44.dp, iconSize = 24.dp, active = castActive)
            }
        }

        Spacer(Modifier.height(32.dp))

        // Below the player, as in the mockup: scroll down for the lyrics preview.
        if (lyricsVm != null && vm.hasMedia) {
            LyricsPreviewCard(player = vm, lyricsVm = lyricsVm, onOpen = onOpenLyrics)
            Spacer(Modifier.height(14.dp))
        }

        // About the artist, Credits, File details, From your library (for the song that is playing).
        val currentSong = remember(library?.songs, vm.currentMediaId) {
            library?.songs?.firstOrNull { it.id.toString() == vm.currentMediaId }
        }
        if (library != null && currentSong != null && vm.hasMedia) {
            NowPlayingInfoCards(currentSong, library)
        }
        Spacer(Modifier.height(32.dp))
    }
}

@Composable
private fun Artwork(art: ImageBitmap?, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(28.dp))) {
        if (art != null) {
            Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtworkPlaceholder(Modifier.fillMaxSize())
        }
    }
}
