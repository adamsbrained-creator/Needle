package app.needle.music.playback

import android.content.Context
import androidx.media3.common.Player
import java.io.File

/**
 * Remembers the queue between sessions so playback comes back after the app is killed.
 * The (possibly long) list of ids lives in a small file; the rest in preferences.
 */
object QueueStore {
    private const val QUEUE_FILE = "queue.txt"
    private const val PREFS = "needle_playback"

    class Saved(
        val ids: List<Long>,
        val currentId: Long,
        val positionMs: Long,
        val shuffle: Boolean,
        val repeatMode: Int
    )

    @Synchronized
    fun saveIds(context: Context, ids: List<String>) {
        val tmp = File(context.filesDir, "queue.tmp")
        tmp.writeText(ids.joinToString(","))
        tmp.renameTo(File(context.filesDir, QUEUE_FILE))
    }

    fun saveState(context: Context, currentId: Long, positionMs: Long, shuffle: Boolean, repeatMode: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putLong("currentId", currentId)
            .putLong("positionMs", positionMs)
            .putBoolean("shuffle", shuffle)
            .putInt("repeat", repeatMode)
            .apply()
    }

    fun load(context: Context): Saved? {
        val file = File(context.filesDir, QUEUE_FILE)
        if (!file.exists()) return null
        val ids = file.readText().split(',').mapNotNull { it.toLongOrNull() }
        if (ids.isEmpty()) return null
        val p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return Saved(
            ids = ids,
            currentId = p.getLong("currentId", ids.first()),
            positionMs = p.getLong("positionMs", 0L),
            shuffle = p.getBoolean("shuffle", false),
            repeatMode = p.getInt("repeat", Player.REPEAT_MODE_OFF)
        )
    }
}
