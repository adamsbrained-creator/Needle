package app.needle.music.data

/** The periods of the Most played page. [days] null = since the beginning. */
enum class MostRange(val label: String, val days: Int?) {
    WEEK("Week", 7),
    MONTH("Month", 30),
    YEAR("Year", 365),
    ALL("All time", null)
}

/** A song and how many times it counted as played in a period. */
class PlayedSong(val song: Song, val plays: Int)

private const val DAY = 86_400_000L

/**
 * The 50 most played songs of each period, most played first. A song counts as played after 30 seconds of
 * listening (see the play history), and the counts are only what Needle has seen on this phone.
 * Equal counts are ordered by title so the list does not jump around.
 */
fun buildMostPlayed(songs: List<Song>, plays: List<PlayEvent>, now: Long): Map<MostRange, List<PlayedSong>> {
    val byId = songs.associateBy { it.id }
    return MostRange.entries.associateWith { range ->
        val from = range.days?.let { now - it * DAY } ?: 0L
        plays.filter { it.playedAt >= from }
            .groupingBy { it.songId }
            .eachCount()
            .mapNotNull { (id, n) -> byId[id]?.let { PlayedSong(it, n) } }
            .sortedWith(compareByDescending<PlayedSong> { it.plays }.thenBy { it.song.title })
            .take(50)
    }
}
