package app.needle.music.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/** The one place that answers "what songs does the person have": the scan plus their tag edits. */
object Library {
    fun observe(db: NeedleDatabase): Flow<List<Song>> =
        combine(db.songDao().observeAll(), db.tagDao().observeAll()) { songs, edits -> applyEdits(songs, edits) }

    /** The other tags (composer, comment, sort names ...) of every song that has any. */
    fun observeExtras(db: NeedleDatabase): Flow<ExtraTags> =
        combine(db.fileTagDao().observeAll(), db.extraTagDao().observeAll()) { fromFiles, edits ->
            mergeExtras(groupFileTags(fromFiles), groupExtras(edits))
        }

    suspend fun load(db: NeedleDatabase): List<Song> =
        applyEdits(db.songDao().getAllOnce(), db.tagDao().getAll())
}
