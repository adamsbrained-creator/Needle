package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.Player
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.Song

/** Pink-to-purple gradient with an orange disc, straight from the mockups. Scales to any size. */
@Composable
fun ArtworkPlaceholder(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFFF4B6C8), Color(0xFF6B3F8F))))
        drawCircle(Color(0xFFF08A4B), radius = size.minDimension * 0.19f, center = center)
    }
}

/** Tap does [onClick]; press and hold buzzes briefly and does [onLongClick] (used to open the tag editor). */
@OptIn(ExperimentalFoundationApi::class)
@Composable
fun Modifier.tapOrHold(onClick: () -> Unit, onLongClick: () -> Unit): Modifier {
    val haptic = LocalHapticFeedback.current
    return combinedClickable(
        onClick = onClick,
        onLongClick = {
            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
            onLongClick()
        }
    )
}

/** Cover for a song row, loaded lazily and cached per album. */
@Composable
fun SongArtwork(song: Song, size: Dp, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peek(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peek(song) ?: ArtworkLoader.load(context, song)
    }
    Box(modifier.size(size).clip(RoundedCornerShape(corner))) {
        val bitmap = art
        if (bitmap != null) {
            Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtworkPlaceholder(Modifier.fillMaxSize())
        }
    }
}

@Composable
fun PlayPauseButton(
    isPlaying: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    iconSize: Dp = 28.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 1f else 0.3f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(iconSize)) {
            val ink = Palette.Bg
            if (isPlaying) {
                val barW = this.size.width * 0.3f
                val radius = CornerRadius(3.dp.toPx())
                drawRoundRect(ink, Offset(this.size.width * 0.12f, 0f), Size(barW, this.size.height), radius)
                drawRoundRect(ink, Offset(this.size.width * 0.58f, 0f), Size(barW, this.size.height), radius)
            } else {
                // Same overall size as before, but with softly rounded corners (fill + round-joined outline, inset).
                val w = this@Canvas.size.width
                val h = this@Canvas.size.height
                val i = 1.5.dp.toPx()
                val tri = Path().apply {
                    moveTo(w * 0.18f + i, i)
                    lineTo(w - i, h / 2f)
                    lineTo(w * 0.18f + i, h - i)
                    close()
                }
                drawPath(tri, ink)
                drawPath(tri, ink, style = Stroke(width = 2 * i, cap = StrokeCap.Round, join = StrokeJoin.Round))
            }
        }
    }
}

@Composable
fun SkipButton(next: Boolean, enabled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val c = Palette.Text.copy(alpha = if (enabled) 1f else 0.3f)
            val w = size.width
            val h = size.height
            val barW = w * 0.14f
            // Rounded corners at the same overall size (inset by 1 dp, then a 2 dp round-joined outline).
            val i = 1.dp.toPx()
            val tri = Path().apply {
                if (next) {
                    moveTo(i, i); lineTo(w * 0.8f - i, h / 2f); lineTo(i, h - i)
                } else {
                    moveTo(w - i, i); lineTo(w * 0.2f + i, h / 2f); lineTo(w - i, h - i)
                }
                close()
            }
            drawPath(tri, c)
            drawPath(tri, c, style = Stroke(width = 2 * i, cap = StrokeCap.Round, join = StrokeJoin.Round))
            drawRoundRect(c, Offset(if (next) w - barW else 0f, 0f), Size(barW, h), CornerRadius(1.5.dp.toPx()))
        }
    }
}

@Composable
fun ChevronDownButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    RoundIconButton(NeedleIcon.CHEVRON_DOWN, onClick, modifier, size = 44.dp, iconSize = 24.dp)
}

/** Pill button: filled (white) or outlined. */
@Composable
fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, filled: Boolean = false) {
    val base = modifier.clip(CircleShape)
    val styled = if (filled) base.background(Color.White) else base.border(1.dp, Palette.Muted, CircleShape)
    Box(styled.clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            color = if (filled) Palette.Bg else Palette.Text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Thin line with a small round dot, as in the mockups. Tap or drag to seek.
 * [onSeek] receives a fraction from 0 to 1.
 */
@Composable
fun NeedleProgressBar(
    progress: Float,
    enabled: Boolean,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    val shown = dragFraction ?: progress
    // The touch handlers below live across recompositions, so they must read the newest callback.
    val latestOnSeek by rememberUpdatedState(onSeek)

    Box(
        modifier
            .height(28.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val pad = 6.dp.toPx()
                detectTapGestures { o ->
                    latestOnSeek(((o.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f))
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val pad = 6.dp.toPx()
                fun frac(x: Float) = ((x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                detectHorizontalDragGestures(
                    onDragStart = { dragFraction = frac(it.x) },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        dragFraction = frac(change.position.x)
                    },
                    onDragEnd = {
                        dragFraction?.let { latestOnSeek(it) }
                        dragFraction = null
                    },
                    onDragCancel = { dragFraction = null }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val trackH = 4.dp.toPx()
            val r = 6.dp.toPx()
            val y = size.height / 2f
            val x0 = r
            val x1 = size.width - r
            val x = x0 + (x1 - x0) * shown
            val alpha = if (enabled) 1f else 0.35f
            drawLine(Color.White.copy(alpha = 0.2f * alpha), Offset(x0, y), Offset(x1, y), trackH, StrokeCap.Round)
            drawLine(Color.White.copy(alpha = alpha), Offset(x0, y), Offset(x, y), trackH, StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = alpha), r, Offset(x, y))
        }
    }
}


@Composable
fun ShuffleButton(active: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val c = if (active) Palette.Accent else Palette.Muted
            val w = size.width
            val h = size.height
            val stroke = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            val a = Path().apply {
                moveTo(0.04f * w, 0.30f * h); lineTo(0.26f * w, 0.30f * h)
                cubicTo(0.52f * w, 0.30f * h, 0.48f * w, 0.72f * h, 0.74f * w, 0.72f * h)
                lineTo(0.80f * w, 0.72f * h)
            }
            val b = Path().apply {
                moveTo(0.04f * w, 0.72f * h); lineTo(0.26f * w, 0.72f * h)
                cubicTo(0.52f * w, 0.72f * h, 0.48f * w, 0.30f * h, 0.74f * w, 0.30f * h)
                lineTo(0.80f * w, 0.30f * h)
            }
            drawPath(a, c, style = stroke)
            drawPath(b, c, style = stroke)
            for (y in floatArrayOf(0.72f * h, 0.30f * h)) {
                val head = Path().apply {
                    moveTo(0.78f * w, y - 0.14f * h); lineTo(w, y); lineTo(0.78f * w, y + 0.14f * h); close()
                }
                drawPath(head, c)
            }
        }
    }
}

/** [mode] is one of Player.REPEAT_MODE_OFF / ALL / ONE. */
@Composable
fun RepeatButton(mode: Int, onClick: () -> Unit, modifier: Modifier = Modifier) {
    val active = mode != Player.REPEAT_MODE_OFF
    val color = if (active) Palette.Accent else Palette.Muted
    Box(
        modifier = modifier.size(48.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val w = size.width
            val h = size.height
            val stroke = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            val top = Path().apply {
                moveTo(0.14f * w, 0.52f * h); lineTo(0.14f * w, 0.42f * h)
                quadraticTo(0.14f * w, 0.28f * h, 0.28f * w, 0.28f * h)
                lineTo(0.78f * w, 0.28f * h)
            }
            val bottom = Path().apply {
                moveTo(0.86f * w, 0.48f * h); lineTo(0.86f * w, 0.58f * h)
                quadraticTo(0.86f * w, 0.72f * h, 0.72f * w, 0.72f * h)
                lineTo(0.22f * w, 0.72f * h)
            }
            drawPath(top, color, style = stroke)
            drawPath(bottom, color, style = stroke)
            val headRight = Path().apply {
                moveTo(0.72f * w, 0.16f * h); lineTo(0.94f * w, 0.28f * h); lineTo(0.72f * w, 0.40f * h); close()
            }
            val headLeft = Path().apply {
                moveTo(0.28f * w, 0.60f * h); lineTo(0.06f * w, 0.72f * h); lineTo(0.28f * w, 0.84f * h); close()
            }
            drawPath(headRight, color)
            drawPath(headLeft, color)
        }
        if (mode == Player.REPEAT_MODE_ONE) {
            Text("1", color = color, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
fun CloseButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(40.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(12.dp)) {
            val stroke = 1.6.dp.toPx()
            drawLine(Palette.Muted, Offset(0f, 0f), Offset(size.width, size.height), stroke, StrokeCap.Round)
            drawLine(Palette.Muted, Offset(size.width, 0f), Offset(0f, size.height), stroke, StrokeCap.Round)
        }
    }
}

/** Small selectable pill, used for the sort options. */
@Composable
fun Chip(text: String, selected: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .clip(CircleShape)
            .background(if (selected) Palette.Accent.copy(alpha = 0.28f) else Palette.Surface)
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text,
            color = if (selected) Color.White else Palette.Muted,
            fontSize = 14.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
