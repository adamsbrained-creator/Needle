package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import kotlinx.coroutines.flow.Flow
import kotlin.math.roundToInt

/**
 * Your rating of one song. [value] is on a scale from 5 to 100 that does not depend on how ratings are shown:
 * 20 is one star, 100 is five stars, 25 is "1.25", 50 is "5 out of 10". A song without a row is not rated.
 */
@Entity(tableName = "song_ratings")
data class SongRating(
    @PrimaryKey val songId: Long,
    val value: Int,
    val ratedAt: Long
)

@Dao
interface RatingDao {
    @Query("SELECT * FROM song_ratings")
    fun observeAll(): Flow<List<SongRating>>

    @Query("SELECT * FROM song_ratings")
    suspend fun getAll(): List<SongRating>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun set(rating: SongRating)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun setAll(ratings: List<SongRating>)

    @Query("DELETE FROM song_ratings WHERE songId = :songId")
    suspend fun clear(songId: Long)
}

/** How ratings are shown and picked. The stored value is the same for all three, so switching loses nothing. */
enum class RatingStyle(val label: String) {
    STARS("5 stars"),
    DECIMAL("1.00 to 5.00"),
    TEN("1 to 10")
}

object RatingScale {
    const val MAX = 100

    /** What each way of rating can pick, as stored values: 20..100, 5..100 in steps of 5 (1.00 to 5.00), 10..100. */
    fun stepsFor(style: RatingStyle): List<Int> = when (style) {
        RatingStyle.STARS -> (1..5).map { it * 20 }
        RatingStyle.DECIMAL -> (4..20).map { it * 5 }      // 1.00, 1.25 ... 5.00
        RatingStyle.TEN -> (1..10).map { it * 10 }
    }

    /** The big text: "4 stars", "4.75", "8 / 10". */
    fun label(style: RatingStyle, value: Int): String = when (style) {
        RatingStyle.STARS -> stars(value).let { if (it == 1) "1 star" else "$it stars" }
        RatingStyle.DECIMAL -> "%.2f".format(value / 20.0)
        RatingStyle.TEN -> ten(value) + " / 10"
    }

    /** The short text for lists, after a star: "4", "4.75", "8". */
    fun short(style: RatingStyle, value: Int): String = when (style) {
        RatingStyle.STARS -> stars(value).toString()
        RatingStyle.DECIMAL -> "%.2f".format(value / 20.0)
        RatingStyle.TEN -> ten(value)
    }

    /** Whole stars, rounded to the nearest (a 3.5 shows as 4). */
    fun stars(value: Int): Int = (value / 20.0).roundToInt().coerceIn(1, 5)

    /** Out of 10, with a decimal only when the rating sits between two numbers (a 1.25 shows as 2.5). */
    private fun ten(value: Int): String = if (value % 10 == 0) (value / 10).toString() else "%.1f".format(value / 10.0)
}
