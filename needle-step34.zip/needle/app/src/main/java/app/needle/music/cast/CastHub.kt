package app.needle.music.cast

import android.content.Context
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.net.wifi.WifiManager
import android.os.Build
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * The one place the UI and the playback service meet about casting: which devices exist, which one is
 * in use, the per-device settings. The service and the UI run in the same process, so plain flows work.
 */
object CastHub {

    /** Implemented by the engine inside the playback service. */
    interface Controller {
        fun connect(device: CastDevice)
        fun disconnect()
        fun stepVolume(direction: Int, announce: Boolean)
    }

    const val LOCAL_NETWORK_PERMISSION = "android.permission.ACCESS_LOCAL_NETWORK"

    private lateinit var app: Context
    private lateinit var prefs: SharedPreferences
    private lateinit var lan: LanNet
    private var ready = false
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    val lanNet: LanNet get() = lan

    val devices = MutableStateFlow<List<CastDevice>>(emptyList())
    val scanning = MutableStateFlow(false)
    val hidden = MutableStateFlow<Set<String>>(emptySet())
    val state = MutableStateFlow(CastState())
    val settings = MutableStateFlow<Map<String, CastSettings>>(emptyMap())
    val localNetworkGranted = MutableStateFlow(true)
    val messages = MutableSharedFlow<String>(extraBufferCapacity = 16)

    @Volatile
    var controller: Controller? = null

    @Synchronized
    fun init(context: Context) {
        if (ready) { refreshPermission(); return }
        app = context.applicationContext
        prefs = app.getSharedPreferences("needle_cast", Context.MODE_PRIVATE)
        lan = LanNet(app)
        hidden.value = prefs.getStringSet("hidden", emptySet()).orEmpty().toSet()
        val loaded = HashMap<String, CastSettings>()
        for ((k, v) in prefs.all) if (k.startsWith("s.") && v is String) loaded[k.removePrefix("s.")] = decode(v)
        settings.value = loaded
        ready = true
        refreshPermission()
    }

    // ---- permission --------------------------------------------------------------------------

    /**
     * Android 17 blocks all traffic to and from the home network until the person allows
     * "local network access". Older versions do not have that permission.
     */
    fun refreshPermission() {
        if (!ready) return
        localNetworkGranted.value = Build.VERSION.SDK_INT < 37 ||
            ContextCompat.checkSelfPermission(app, LOCAL_NETWORK_PERMISSION) == PackageManager.PERMISSION_GRANTED
    }

    // ---- discovery ---------------------------------------------------------------------------

    private var scanJob: Job? = null
    private val knownLocations = ConcurrentHashMap.newKeySet<String>()

    fun startScan(clear: Boolean = false) {
        if (!ready || !localNetworkGranted.value) return
        if (scanJob?.isActive == true) return
        if (clear) {
            knownLocations.clear()
            devices.value = listOfNotNull(state.value.device)
        }
        scanJob = scope.launch {
            scanning.value = true
            val lock = runCatching {
                app.getSystemService(WifiManager::class.java)
                    .createMulticastLock("needle-ssdp").apply { setReferenceCounted(false); acquire() }
            }.getOrNull()
            val me = this.coroutineContext[Job]
            try {
                log("scan started")
                repeat(3) {
                    Ssdp.search(lan, 3500, { me?.isActive != false }) { location ->
                        if (knownLocations.add(location)) scope.launch { fetch(location) }
                    }
                }
            } catch (e: Exception) {
                log("scan failed: $e")
            } finally {
                runCatching { lock?.release() }
                scanning.value = false
                log("scan finished, ${devices.value.size} device(s)")
            }
        }
    }

    private fun fetch(location: String) {
        val d = try {
            UpnpDescription.fetch(lan, location)
        } catch (e: Exception) {
            log("couldn't read $location: $e")
            knownLocations.remove(location)
            null
        } ?: return
        log("found ${d.name} (${d.model}) at ${d.host}")
        devices.update { list -> (list.filterNot { it.udn == d.udn } + d).sortedBy { it.name.lowercase() } }
    }

    // ---- hidden devices ----------------------------------------------------------------------

    fun hide(udn: String) = setHidden(hidden.value + udn)
    fun unhide(udn: String) = setHidden(hidden.value - udn)

    private fun setHidden(set: Set<String>) {
        hidden.value = set
        prefs.edit().putStringSet("hidden", HashSet(set)).apply()
    }

    // ---- per-device settings -----------------------------------------------------------------

    fun settingsFor(udn: String): CastSettings = settings.value[udn] ?: CastSettings()

    fun updateSettings(udn: String, change: (CastSettings) -> CastSettings) {
        val next = change(settingsFor(udn))
        prefs.edit().putString("s.$udn", encode(next)).apply()
        settings.value = settings.value + (udn to next)
    }

    fun restoreDefaults(udn: String) {
        prefs.edit().remove("s.$udn").apply()
        settings.value = settings.value - udn
    }

    private fun encode(s: CastSettings): String = JSONObject()
        .put("vs", s.volumeStep).put("rf", s.reportedFormats).put("gl", s.gapless)
        .put("se", s.stopWhenEnds).put("to", s.stopIfTakenOver).put("ac", s.altCompat).toString()

    private fun decode(t: String): CastSettings = runCatching {
        val j = JSONObject(t)
        CastSettings(
            volumeStep = j.optInt("vs", 10),
            reportedFormats = j.optBoolean("rf", true),
            gapless = j.optBoolean("gl", true),
            stopWhenEnds = j.optBoolean("se", true),
            stopIfTakenOver = j.optBoolean("to", false),
            altCompat = j.optBoolean("ac", false)
        )
    }.getOrDefault(CastSettings())

    // ---- commands from the UI ----------------------------------------------------------------

    fun connect(device: CastDevice) {
        val c = controller
        if (c != null) c.connect(device) else post("The player isn't ready yet, try again in a moment")
    }

    fun disconnect() { controller?.disconnect() }

    fun stepVolume(direction: Int, announce: Boolean = false) { controller?.stepVolume(direction, announce) }

    fun isConnected(): Boolean = state.value.phase == CastPhase.CONNECTED

    suspend fun testConnection(device: CastDevice): String = withContext(Dispatchers.IO) {
        val r = UpnpRenderer(lan, device)
        try {
            val st = r.transportState()
            val vol = runCatching { r.getVolume() }.getOrNull()
            val sink = runCatching { r.sinkFormats() }.getOrDefault(emptyList())
            log("test ok: ${device.name} state=$st volume=$vol formats=${sink.size}")
            buildString {
                append("Connected · ").append(st.ifBlank { "ready" }.lowercase().replace('_', ' '))
                if (vol != null) append(" · volume ").append(vol)
                append(if (sink.isNotEmpty()) " · ${sink.size} formats reported" else " · formats not reported")
            }
        } catch (e: Exception) {
            log("test failed for ${device.name}: $e")
            "Couldn't reach ${device.name}: ${e.message ?: e.javaClass.simpleName}"
        }
    }

    fun post(message: String) { messages.tryEmit(message) }

    // ---- debug log (so problems on a real TV can be copied out of the app) -------------------

    private val logLines = ArrayDeque<String>()
    private val clock = SimpleDateFormat("HH:mm:ss.SSS", Locale.US)

    fun log(message: String) {
        Log.d("NeedleCast", message)
        synchronized(logLines) {
            logLines.addLast("${clock.format(Date())}  $message")
            while (logLines.size > 300) logLines.removeFirst()
        }
    }

    fun logText(): String = synchronized(logLines) { logLines.joinToString("\n") }
}
