package app.needle.music.playback

import android.content.Context
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import androidx.media3.common.util.UnstableApi
import java.nio.ByteBuffer
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Needle's own 10-band equalizer.
 *
 * Android's built-in equalizer only offers the bands the phone maker chose (often 5), so Needle filters the sound
 * itself, inside the player: ten peaking filters from 32 Hz to 16 kHz, +/-12 dB each, plus a preamp. It sounds the
 * same on every phone. It works on this phone's playback; a cast TV gets the original sound.
 */

/** A frozen copy of the settings, handed to the audio thread. */
class EqParams(val enabled: Boolean, val gainsDb: FloatArray, val preampDb: Float)

class EqPreset(val id: String, val name: String, val gains: FloatArray)

object EqState {
    const val BANDS = 10
    const val MAX_DB = 12f
    val FREQS = doubleArrayOf(32.0, 64.0, 125.0, 250.0, 500.0, 1000.0, 2000.0, 4000.0, 8000.0, 16000.0)
    val LABELS = listOf("32", "64", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

    /** The first five are the mockup's; the rest are common extras. */
    val PRESETS = listOf(
        EqPreset("bass", "Bass boost", floatArrayOf(6f, 5f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f)),
        EqPreset("flat", "Flat", FloatArray(BANDS)),
        EqPreset("vocal", "Vocal", floatArrayOf(-2f, -1f, 0f, 3f, 4f, 4f, 3f, 1f, 0f, -1f)),
        EqPreset("rock", "Rock", floatArrayOf(4f, 3f, 1f, -1f, -2f, 0f, 2f, 3f, 4f, 4f)),
        EqPreset("acoustic", "Acoustic", floatArrayOf(3f, 3f, 2f, 1f, 1f, 1f, 2f, 3f, 3f, 2f)),
        EqPreset("treble", "Treble boost", floatArrayOf(0f, 0f, 0f, 0f, 0f, 1f, 3f, 5f, 6f, 6f)),
        EqPreset("pop", "Pop", floatArrayOf(-1f, 0f, 2f, 4f, 4f, 2f, 0f, -1f, -1f, -2f)),
        EqPreset("jazz", "Jazz", floatArrayOf(3f, 2f, 1f, 2f, -1f, -1f, 0f, 1f, 2f, 3f)),
        EqPreset("classical", "Classical", floatArrayOf(4f, 3f, 3f, 2f, -1f, -1f, 0f, 2f, 3f, 4f)),
        EqPreset("dance", "Dance", floatArrayOf(6f, 5f, 3f, 0f, 1f, 3f, 4f, 3f, 1f, 0f)),
        EqPreset("electronic", "Electronic", floatArrayOf(5f, 4f, 1f, 0f, -2f, 2f, 1f, 1f, 4f, 5f)),
        EqPreset("hiphop", "Hip hop", floatArrayOf(5f, 4f, 2f, 3f, -1f, -1f, 2f, 0f, 2f, 3f))
    )

    // What the screen shows (Compose state) ...
    val enabled = mutableStateOf(false)
    val gains = mutableStateListOf<Float>().apply { repeat(BANDS) { add(0f) } }
    val preampDb = mutableFloatStateOf(0f)
    /** The id of the preset the bars match, or "custom" once a bar was moved. */
    val presetId = mutableStateOf("flat")

    // ... and what the audio thread reads.
    @Volatile
    var params: EqParams = EqParams(false, FloatArray(BANDS), 0f)
        private set

    /** The one processor, plugged into the player by the playback service. */
    val processor = EqProcessor()

    private var prefs: android.content.SharedPreferences? = null

    /** The text for "Equalizer: ..." in Settings and the Player controls sheet. */
    val summary: String
        get() = when {
            !enabled.value -> "Off"
            presetId.value == "custom" -> "Custom"
            else -> PRESETS.firstOrNull { it.id == presetId.value }?.name ?: "Custom"
        }

    /** Safe to call from the activity and from the service; only the first call does anything. */
    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_eq", Context.MODE_PRIVATE)
        prefs = p
        enabled.value = p.getBoolean("on", false)
        presetId.value = p.getString("preset", "flat") ?: "flat"
        preampDb.floatValue = p.getFloat("preamp", 0f).coerceIn(-MAX_DB, 0f)
        val saved = p.getString("gains", null)?.split(',')?.mapNotNull { it.toFloatOrNull() }
        if (saved != null && saved.size == BANDS) saved.forEachIndexed { i, v -> gains[i] = v.coerceIn(-MAX_DB, MAX_DB) }
        publish()
    }

    fun setEnabled(on: Boolean) {
        enabled.value = on
        save()
        publish()
    }

    /** Moves one bar (to the nearest half dB). Turns the equalizer on, like moving a bar on a hardware one would. */
    fun setBand(index: Int, db: Float) {
        gains[index] = ((db.coerceIn(-MAX_DB, MAX_DB)) * 2f).roundToInt() / 2f
        presetId.value = "custom"
        enabled.value = true
        save()
        publish()
    }

    fun applyPreset(id: String) {
        val preset = PRESETS.firstOrNull { it.id == id } ?: return
        preset.gains.forEachIndexed { i, v -> gains[i] = v }
        // The mockup's Bass boost sits at -3 dB preamp for +6 dB of boost: half the loudest boost.
        val peak = preset.gains.maxOrNull() ?: 0f
        val auto = peak.roundToInt() / 2f
        preampDb.floatValue = if (auto == 0f) 0f else -auto
        presetId.value = id
        enabled.value = true
        save()
        publish()
    }

    fun setPreamp(db: Float) {
        preampDb.floatValue = (db.coerceIn(-MAX_DB, 0f) * 2f).roundToInt() / 2f
        save()
        publish()
    }

    /** Flat, no preamp (the switch stays as it is). */
    fun reset() {
        gains.indices.forEach { gains[it] = 0f }
        preampDb.floatValue = 0f
        presetId.value = "flat"
        save()
        publish()
    }

    private fun save() {
        prefs?.edit()
            ?.putBoolean("on", enabled.value)
            ?.putString("preset", presetId.value)
            ?.putFloat("preamp", preampDb.floatValue)
            ?.putString("gains", gains.joinToString(","))
            ?.apply()
    }

    private fun publish() {
        params = EqParams(enabled.value, gains.toFloatArray(), preampDb.floatValue)
    }
}

/**
 * Ten RBJ "peaking" biquad filters in a row (16-bit or float PCM), then the preamp and a soft limiter so a boosted
 * band can never wrap around into crackle. When the equalizer is off or flat, the sound is copied through untouched.
 */
@OptIn(UnstableApi::class)
class EqProcessor : BaseAudioProcessor() {
    private val bands = EqState.BANDS
    private var channels = 2
    private var sampleRate = 44100
    private var isFloat = false

    private var applied: EqParams? = null
    private var passthrough = true
    private var preGain = 1.0

    // Filter coefficients (already divided by a0) for each band, and the filter memory for each band and channel.
    private val b0 = DoubleArray(bands)
    private val b1 = DoubleArray(bands)
    private val b2 = DoubleArray(bands)
    private val a1 = DoubleArray(bands)
    private val a2 = DoubleArray(bands)
    private val active = IntArray(bands)
    private var activeCount = 0
    private var x1 = DoubleArray(0)
    private var x2 = DoubleArray(0)
    private var y1 = DoubleArray(0)
    private var y2 = DoubleArray(0)

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        val encoding = inputAudioFormat.encoding
        // Anything else (24-bit, passthrough ...) goes through unchanged: this processor stays inactive.
        if (encoding != C.ENCODING_PCM_16BIT && encoding != C.ENCODING_PCM_FLOAT) return AudioProcessor.AudioFormat.NOT_SET
        isFloat = encoding == C.ENCODING_PCM_FLOAT
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        val n = bands * channels
        x1 = DoubleArray(n); x2 = DoubleArray(n); y1 = DoubleArray(n); y2 = DoubleArray(n)
        applied = null
        return inputAudioFormat
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return
        refresh()
        val out = replaceOutputBuffer(size)
        when {
            passthrough -> out.put(inputBuffer)
            isFloat -> processFloat(inputBuffer, out)
            else -> process16(inputBuffer, out)
        }
        out.flip()
    }

    /** Recalculates the filters when the settings changed (read once per buffer, so it is cheap). */
    private fun refresh() {
        val p = EqState.params
        if (p === applied) return
        applied = p
        passthrough = !p.enabled || (p.gainsDb.all { abs(it) < 0.05f } && abs(p.preampDb) < 0.05f)
        preGain = 10.0.pow(p.preampDb / 20.0)
        activeCount = 0
        for (band in 0 until bands) {
            val gain = p.gainsDb[band].toDouble()
            val f0 = EqState.FREQS[band]
            // A band close to half the sample rate cannot be built; skip it (16 kHz at 32 kHz audio).
            if (abs(gain) < 0.05 || f0 >= sampleRate * 0.45) continue
            val a = 10.0.pow(gain / 40.0)
            val w0 = 2.0 * PI * f0 / sampleRate
            val alpha = sin(w0) / (2.0 * Q)
            val c = cos(w0)
            val a0 = 1.0 + alpha / a
            b0[band] = (1.0 + alpha * a) / a0
            b1[band] = (-2.0 * c) / a0
            b2[band] = (1.0 - alpha * a) / a0
            a1[band] = (-2.0 * c) / a0
            a2[band] = (1.0 - alpha / a) / a0
            active[activeCount++] = band
        }
    }

    private fun filter(sample: Double, channel: Int): Double {
        var s = sample * preGain
        for (k in 0 until activeCount) {
            val band = active[k]
            val i = band * channels + channel
            val y = b0[band] * s + b1[band] * x1[i] + b2[band] * x2[i] - a1[band] * y1[i] - a2[band] * y2[i]
            x2[i] = x1[i]; x1[i] = s
            y2[i] = y1[i]; y1[i] = y
            s = y
        }
        return limit(s)
    }

    private fun process16(input: ByteBuffer, out: ByteBuffer) {
        val frameBytes = 2 * channels
        while (input.remaining() >= frameBytes) {
            for (ch in 0 until channels) {
                val s = filter(input.getShort() / 32768.0, ch)
                out.putShort((s * 32767.0).roundToInt().coerceIn(-32768, 32767).toShort())
            }
        }
        out.put(input) // a partial frame at the end (should not happen) is passed on as it is
    }

    private fun processFloat(input: ByteBuffer, out: ByteBuffer) {
        val frameBytes = 4 * channels
        while (input.remaining() >= frameBytes) {
            for (ch in 0 until channels) {
                out.putFloat(filter(input.getFloat().toDouble(), ch).toFloat())
            }
        }
        out.put(input)
    }

    /** Linear up to 0.95, then a smooth curve that never passes 1.0. */
    private fun limit(v: Double): Double {
        val a = abs(v)
        if (a <= KNEE) return v
        val over = KNEE + (1.0 - KNEE) * tanh((a - KNEE) / (1.0 - KNEE))
        return if (v < 0) -over else over
    }

    private companion object {
        /** One octave wide, which is how ten bands an octave apart blend into one smooth curve. */
        const val Q = 1.4
        const val KNEE = 0.95
    }
}
