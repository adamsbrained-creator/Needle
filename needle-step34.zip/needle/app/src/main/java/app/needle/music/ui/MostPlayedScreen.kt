package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.MostRange
import app.needle.music.data.PlayedSong
import app.needle.music.data.Song

/**
 * Home / Most played page from the mockup: the top songs of a week, month, year or all time, counted from what was
 * played on this phone. Number one gets a card, the rest a ranked list with a bar for how close they are.
 */
@Composable
fun MostPlayedScreen(
    state: Map<MostRange, List<PlayedSong>>?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var range by rememberSaveable { mutableStateOf(MostRange.MONTH) }
    val list = state?.get(range).orEmpty()
    val queue = list.map { it.song }
    val top = list.firstOrNull()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    RoundIconButton(NeedleIcon.BACK, onBack, size = 40.dp, iconSize = 22.dp)
                }
                Text(
                    "Most played", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    "Your top songs, counted on this phone.", color = Palette.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MostRange.entries.forEach { r ->
                        RangePill(r.label, selected = r == range, onClick = { range = r })
                    }
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        if (state != null && top == null) {
            item {
                Text(
                    "Nothing played in this period yet. A song counts after 30 seconds of listening.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp)
                )
            }
        }

        if (top != null) {
            item { NumberOne(top, onClick = { onPlay(queue, 0) }, onLongClick = { onMenu(top.song) }) }
            itemsIndexed(list.drop(1), key = { _, p -> p.song.id }) { i, played ->
                RankRow(
                    rank = i + 2,
                    played = played,
                    fraction = played.plays.toFloat() / top.plays,
                    onClick = { onPlay(queue, i + 1) },
                    onLongClick = { onMenu(played.song) }
                )
            }
        }
    }
}

@Composable
private fun RangePill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color(0xFF111111) else Palette.Text,
        fontSize = 13.5.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun NumberOne(played: PlayedSong, onClick: () -> Unit, onLongClick: () -> Unit) {
    val shape = RoundedCornerShape(28.dp)
    val glow = Color(0xFFFF965A).copy(alpha = 0.5f)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Accent.copy(alpha = 0.45f), Color.White.copy(alpha = 0.06f))))
            .border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape)
            .tapOrHold(onClick, onLongClick)
            .padding(16.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        val cover = RoundedCornerShape(20.dp)
        Box(
            Modifier.size(92.dp).shadow(14.dp, cover, ambientColor = glow, spotColor = glow).clip(cover).background(Palette.Card)
        ) { Cover(played.song, Modifier.fillMaxSize()) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text("Number one", color = Color(0xFFD8CDF5), fontSize = 12.sp)
            Text(
                played.song.title, color = Palette.Text, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(vertical = 2.dp)
            )
            Text(
                "${played.song.artist} · ${plays(played.plays)}", color = Color(0xFFD8CDF5), fontSize = 12.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
private fun RankRow(rank: Int, played: PlayedSong, fraction: Float, onClick: () -> Unit, onLongClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().tapOrHold(onClick, onLongClick).padding(vertical = 7.dp, horizontal = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "$rank", color = Palette.Muted, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center, modifier = Modifier.width(30.dp)
        )
        Spacer(Modifier.width(8.dp))
        SongArtwork(played.song, size = 48.dp, corner = 13.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                played.song.title, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Box(
                Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))
            ) {
                Box(
                    Modifier.fillMaxHeight().fillMaxWidth(fraction.coerceIn(0.02f, 1f)).clip(CircleShape)
                        .background(Brush.horizontalGradient(listOf(Palette.Accent, Palette.Pink)))
                )
            }
        }
        Text(
            "${played.plays}", color = Color(0xFFDDDDDD), fontSize = 12.5.sp, textAlign = TextAlign.End,
            modifier = Modifier.width(52.dp)
        )
    }
}

private fun plays(n: Int) = if (n == 1) "1 play" else "$n plays"
