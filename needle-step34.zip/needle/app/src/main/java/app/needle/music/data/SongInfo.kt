package app.needle.music.data

import android.content.Context
import android.media.MediaExtractor
import android.media.MediaFormat
import android.media.MediaMetadataRetriever
import android.os.Build
import android.provider.MediaStore
import android.provider.OpenableColumns
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** What the Song info page shows besides the tags: the file itself and the listening history. */
data class SongInfoData(
    val fileName: String?,
    val sizeBytes: Long?,
    val format: String?,
    val bitrateKbps: Int?,
    val bitsPerSample: Int?,
    val sampleRateHz: Int?,
    val channels: Int?,
    val plays: Int,
    val lastPlayedAt: Long?,
    /** The other tags that were edited in Needle (the rest come from the file). */
    val editedFields: Set<String>
) {
    /** "24-bit / 96 kHz", "44.1 kHz stereo" ... or null when the phone cannot tell. */
    val quality: String?
        get() {
            val rate = sampleRateHz ?: return null
            val khz = if (rate % 1000 == 0) "${rate / 1000}" else "%.1f".format(rate / 1000.0)
            val ch = when (channels) {
                1 -> " mono"
                2 -> " stereo"
                else -> ""
            }
            return if (bitsPerSample != null && bitsPerSample > 0) "$bitsPerSample-bit / $khz kHz" else "$khz kHz$ch"
        }
}

object SongInfoLoader {
    suspend fun load(context: Context, song: Song): SongInfoData = withContext(Dispatchers.IO) {
        var name: String? = null
        var size: Long? = null
        var mime: String? = null
        runCatching {
            context.contentResolver.query(
                song.uri,
                arrayOf(OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0)
                    size = if (c.isNull(1)) null else c.getLong(1)
                    mime = c.getString(2)
                }
            }
        }

        var bitrate: Int? = null
        var rate: Int? = null
        var bits: Int? = null
        var channels: Int? = null
        runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, song.uri)
                bitrate = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITRATE)?.toIntOrNull()?.let { it / 1000 }
                if (Build.VERSION.SDK_INT >= 31) {
                    rate = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_SAMPLERATE)?.toIntOrNull()
                    bits = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_BITS_PER_SAMPLE)?.toIntOrNull()
                }
            } finally {
                r.release()
            }
        }
        runCatching {
            val ex = MediaExtractor()
            try {
                ex.setDataSource(context, song.uri, null)
                if (ex.trackCount > 0) {
                    val f = ex.getTrackFormat(0)
                    if (rate == null && f.containsKey(MediaFormat.KEY_SAMPLE_RATE)) rate = f.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    if (f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = f.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                }
            } finally {
                ex.release()
            }
        }

        // If the file does not say, work it out from its size and length (an average).
        val total = size
        if ((bitrate == null || bitrate == 0) && total != null && song.durationMs > 0) {
            bitrate = (total * 8 / song.durationMs).toInt()
        }

        val db = NeedleDatabase.get(context)
        val plays = runCatching { db.playDao().countFor(song.id) }.getOrDefault(0)
        val last = runCatching { db.playDao().lastPlayedAt(song.id) }.getOrNull()
        val edited = runCatching { db.extraTagDao().fieldsFor(song.id).toSet() }.getOrDefault(emptySet())

        val extension = name?.substringAfterLast('.', "")?.takeIf { it.isNotEmpty() && it.length <= 5 }
        SongInfoData(
            fileName = name,
            sizeBytes = size,
            format = extension?.uppercase() ?: mime?.substringAfter('/')?.uppercase(),
            bitrateKbps = bitrate?.takeIf { it > 0 },
            bitsPerSample = bits?.takeIf { it > 0 },
            sampleRateHz = rate?.takeIf { it > 0 },
            channels = channels,
            plays = plays,
            lastPlayedAt = last,
            editedFields = edited
        )
    }
}
