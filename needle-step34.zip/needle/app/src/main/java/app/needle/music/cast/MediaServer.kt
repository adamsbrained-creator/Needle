package app.needle.music.cast

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.ParcelFileDescriptor
import android.provider.MediaStore
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.IOException
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.RejectedExecutionException

/**
 * A tiny web server inside the app. The TV / Xbox / PC does not get the file from us; it downloads it
 * from here (with Range support, so seeking works). Only files Needle has announced can be fetched,
 * and every URL contains a random token that changes each time casting starts.
 */
class MediaServer(private val context: Context) {

    private class FileInfo(val uri: Uri, val size: Long, val mime: String, val ext: String)

    private var serverSocket: ServerSocket? = null
    private var pool: ExecutorService? = null
    private var token = ""

    @Volatile
    var port = 0
        private set

    /** Alternative compatibility mode: no DLNA headers. */
    @Volatile
    var alt = false

    private val files = ConcurrentHashMap<Long, FileInfo>()
    private val noArt = ConcurrentHashMap.newKeySet<Long>()
    private val art = object : LinkedHashMap<Long, ByteArray>(16, 0.75f, true) {
        override fun removeEldestEntry(eldest: MutableMap.MutableEntry<Long, ByteArray>?): Boolean = size > 24
    }

    @Synchronized
    fun start() {
        if (serverSocket != null) return
        val ss = ServerSocket(0, 50)
        serverSocket = ss
        port = ss.localPort
        token = UUID.randomUUID().toString().replace("-", "").take(16)
        val p = Executors.newCachedThreadPool()
        pool = p
        Thread({
            while (!ss.isClosed) {
                val s = try { ss.accept() } catch (e: IOException) { break }
                try { p.execute { serve(s) } } catch (e: RejectedExecutionException) { runCatching { s.close() }; break }
            }
        }, "needle-media-server").apply { isDaemon = true }.start()
        CastHub.log("media server listening on port $port")
    }

    @Synchronized
    fun stop() {
        runCatching { serverSocket?.close() }
        serverSocket = null
        pool?.shutdownNow()
        pool = null
        port = 0
    }

    /** Works out the file's type and the URLs for it. Blocking (reads the file's metadata): call off the main thread. */
    fun track(src: TrackSource, host: String): TrackInfo {
        val info = files.getOrPut(src.id) { queryFile(src.uri) }
        val hasArt = ensureArt(src)
        val base = "http://$host:$port/$token"
        return TrackInfo(
            id = src.id,
            url = "$base/m/${src.id}.${info.ext}",
            artUrl = if (hasArt) "$base/a/${src.id}.jpg" else null,
            mime = info.mime,
            size = info.size,
            ext = info.ext
        )
    }

    // ---- the file's own details ----------------------------------------------------------

    private fun queryFile(uri: Uri): FileInfo {
        var name = ""
        var size = 0L
        var mime = ""
        runCatching {
            context.contentResolver.query(
                uri,
                arrayOf(MediaStore.MediaColumns.DISPLAY_NAME, MediaStore.MediaColumns.SIZE, MediaStore.MediaColumns.MIME_TYPE),
                null, null, null
            )?.use { c ->
                if (c.moveToFirst()) {
                    name = c.getString(0).orEmpty()
                    size = c.getLong(1)
                    mime = c.getString(2).orEmpty()
                }
            }
        }
        if (mime.isBlank()) mime = runCatching { context.contentResolver.getType(uri) }.getOrNull().orEmpty()
        var ext = name.substringAfterLast('.', "").lowercase()
        if (!mime.startsWith("audio/")) mime = mimeForExt(ext)
        if (ext.isBlank()) ext = extForMime(mime)
        return FileInfo(uri, size, mime, ext)
    }

    private fun mimeForExt(ext: String) = when (ext) {
        "mp3" -> "audio/mpeg"
        "flac" -> "audio/flac"
        "m4a", "mp4" -> "audio/mp4"
        "aac" -> "audio/aac"
        "wav" -> "audio/wav"
        "ogg", "oga", "opus" -> "audio/ogg"
        "wma" -> "audio/x-ms-wma"
        else -> "application/octet-stream"
    }

    private fun extForMime(mime: String) = when (mime) {
        "audio/mpeg" -> "mp3"
        "audio/flac", "audio/x-flac" -> "flac"
        "audio/mp4", "audio/x-m4a" -> "m4a"
        "audio/aac" -> "aac"
        "audio/wav", "audio/x-wav" -> "wav"
        "audio/ogg" -> "ogg"
        "audio/x-ms-wma" -> "wma"
        else -> "bin"
    }

    // ---- cover art ---------------------------------------------------------------------------

    /** The cover picked in the tag editor wins, then the one embedded in the file. Cached per song. */
    private fun ensureArt(src: TrackSource): Boolean {
        synchronized(art) { if (art.containsKey(src.id)) return true }
        if (src.id in noArt) return false
        val raw = src.cover ?: runCatching {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(context, src.uri)
                r.embeddedPicture
            } finally {
                r.release()
            }
        }.getOrNull()
        if (raw == null || raw.isEmpty()) {
            noArt.add(src.id)
            return false
        }
        val jpeg = scaleJpeg(raw)
        synchronized(art) { art[src.id] = jpeg }
        return true
    }

    private fun scaleJpeg(src: ByteArray, max: Int = 600): ByteArray = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeByteArray(src, 0, src.size, bounds)
        if (bounds.outWidth <= 0) return@runCatching src
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= max) sample *= 2
        val bmp = BitmapFactory.decodeByteArray(src, 0, src.size, BitmapFactory.Options().apply { inSampleSize = sample })
            ?: return@runCatching src
        val out = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 85, out)
        bmp.recycle()
        out.toByteArray()
    }.getOrDefault(src)

    // ---- serving -----------------------------------------------------------------------------

    private fun serve(s: Socket) {
        try {
            s.soTimeout = 30_000
            val input = BufferedInputStream(s.getInputStream())
            val requestLine = readLine(input) ?: return
            val h = HashMap<String, String>()
            while (true) {
                val line = readLine(input) ?: break
                if (line.isEmpty()) break
                val i = line.indexOf(':')
                if (i > 0) h[line.substring(0, i).trim().lowercase()] = line.substring(i + 1).trim()
            }
            val parts = requestLine.split(' ')
            if (parts.size < 2) return
            val method = parts[0].uppercase()
            val segs = parts[1].substringBefore('?').split('/').filter { it.isNotEmpty() }
            val out = BufferedOutputStream(s.getOutputStream(), 64 * 1024)

            if (method != "GET" && method != "HEAD") return status(out, 405, "Method Not Allowed")
            if (segs.size != 3 || segs[0] != token) return status(out, 404, "Not Found")
            val key = segs[2].substringBeforeLast('.').toLongOrNull() ?: return status(out, 404, "Not Found")
            when (segs[1]) {
                "m" -> serveMedia(out, key, method == "HEAD", h)
                "a" -> serveArt(out, key, method == "HEAD")
                else -> status(out, 404, "Not Found")
            }
        } catch (e: IOException) {
            // the device closed the connection (it does that when seeking): normal
        } catch (e: Exception) {
            CastHub.log("media server error: $e")
        } finally {
            runCatching { s.close() }
        }
    }

    private fun serveMedia(out: OutputStream, id: Long, head: Boolean, h: Map<String, String>) {
        val info = files[id] ?: return status(out, 404, "Not Found")
        val pfd = runCatching { context.contentResolver.openFileDescriptor(info.uri, "r") }.getOrNull()
            ?: return status(out, 404, "Not Found")
        pfd.use { fd ->
            val size = if (fd.statSize >= 0) fd.statSize else info.size
            var start = 0L
            var end = size - 1
            var partial = false
            val range = h["range"]
            if (range != null) {
                val m = Regex("bytes=(\\d*)-(\\d*)").find(range)
                if (m != null) {
                    val a = m.groupValues[1]
                    val b = m.groupValues[2]
                    if (a.isEmpty() && b.isNotEmpty()) {
                        start = (size - b.toLong()).coerceAtLeast(0)
                    } else if (a.isNotEmpty()) {
                        start = a.toLong()
                        if (b.isNotEmpty()) end = minOf(b.toLong(), size - 1)
                    }
                    partial = true
                    if (start > end || start >= size) {
                        return header(out, 416, "Range Not Satisfiable", "Content-Range: bytes */$size", "Content-Length: 0")
                    }
                }
            }
            val lines = ArrayList<String>()
            lines += "Content-Type: ${info.mime}"
            lines += "Content-Length: ${end - start + 1}"
            lines += "Accept-Ranges: bytes"
            if (partial) lines += "Content-Range: bytes $start-$end/$size"
            if (!alt) {
                lines += "transferMode.dlna.org: Streaming"
                lines += "contentFeatures.dlna.org: DLNA.ORG_OP=01;DLNA.ORG_CI=0;DLNA.ORG_FLAGS=01700000000000000000000000000000"
            }
            header(out, if (partial) 206 else 200, if (partial) "Partial Content" else "OK", *lines.toTypedArray())
            if (head) { out.flush(); return }

            val fis = FileInputStream(fd.fileDescriptor)
            fis.channel.position(start)
            copy(fis, out, end - start + 1)
            out.flush()
        }
    }

    private fun serveArt(out: OutputStream, id: Long, head: Boolean) {
        val bytes = synchronized(art) { art[id] } ?: return status(out, 404, "Not Found")
        val lines = arrayListOf("Content-Type: image/jpeg", "Content-Length: ${bytes.size}")
        if (!alt) {
            lines += "transferMode.dlna.org: Interactive"
            lines += "contentFeatures.dlna.org: DLNA.ORG_OP=00;DLNA.ORG_CI=0"
        }
        header(out, 200, "OK", *lines.toTypedArray())
        if (!head) out.write(bytes)
        out.flush()
    }

    private fun copy(from: InputStream, to: OutputStream, count: Long) {
        val buf = ByteArray(64 * 1024)
        var remaining = count
        while (remaining > 0) {
            val n = from.read(buf, 0, minOf(buf.size.toLong(), remaining).toInt())
            if (n <= 0) break
            to.write(buf, 0, n)
            remaining -= n
        }
    }

    private fun status(out: OutputStream, code: Int, reason: String) {
        header(out, code, reason, "Content-Length: 0")
        out.flush()
    }

    private fun header(out: OutputStream, code: Int, reason: String, vararg lines: String) {
        val sb = StringBuilder("HTTP/1.1 $code $reason\r\n")
        for (l in lines) sb.append(l).append("\r\n")
        sb.append("Connection: close\r\n\r\n")
        out.write(sb.toString().toByteArray(Charsets.ISO_8859_1))
    }

    private fun readLine(input: InputStream): String? {
        val sb = StringBuilder()
        while (sb.length < 8192) {
            val c = input.read()
            if (c < 0) return if (sb.isEmpty()) null else sb.toString()
            if (c == '\n'.code) return sb.toString().trimEnd('\r')
            sb.append(c.toChar())
        }
        return sb.toString()
    }
}
