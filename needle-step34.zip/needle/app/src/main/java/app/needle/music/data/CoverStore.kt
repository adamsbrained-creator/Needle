package app.needle.music.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import java.io.ByteArrayOutputStream
import java.io.File

/**
 * Covers the person picked in the tag editor. One small JPEG per song, named after the song id,
 * kept in the app's own storage. A song with such a file shows it instead of the cover in the audio file.
 */
object CoverStore {
    private const val MAX_SIDE = 1024

    private fun dir(context: Context) = File(context.filesDir, "covers").apply { mkdirs() }

    fun file(context: Context, songId: Long) = File(dir(context), "$songId.jpg")

    /** Ids of all songs that have a picked cover. One directory listing, cheap even for a big queue. */
    fun songIds(context: Context): Set<Long> =
        dir(context).list()?.mapNotNull { it.removeSuffix(".jpg").toLongOrNull() }?.toSet().orEmpty()

    /** Loads a picked image, shrunk so it is at most about 1024 pixels wide. Call off the main thread. */
    fun decode(context: Context, uri: Uri): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, bounds) }
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= MAX_SIDE && bounds.outHeight / (sample * 2) >= MAX_SIDE) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        context.contentResolver.openInputStream(uri)?.use { BitmapFactory.decodeStream(it, null, options) }
    }.getOrNull()

    /** Saves [bitmap] as the cover of every song in [songIds]. Call off the main thread. */
    fun save(context: Context, songIds: List<Long>, bitmap: Bitmap) {
        val bytes = ByteArrayOutputStream().also { bitmap.compress(Bitmap.CompressFormat.JPEG, 88, it) }.toByteArray()
        for (id in songIds) file(context, id).writeBytes(bytes)
    }

    fun readBytes(context: Context, songId: Long): ByteArray? =
        file(context, songId).takeIf { it.exists() }?.readBytes()

    fun decodeSampled(file: File, targetPx: Int): Bitmap? = runCatching {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(file.path, bounds)
        var sample = 1
        while (bounds.outWidth / (sample * 2) >= targetPx && bounds.outHeight / (sample * 2) >= targetPx) sample *= 2
        BitmapFactory.decodeFile(file.path, BitmapFactory.Options().apply { inSampleSize = sample })
    }.getOrNull()
}
