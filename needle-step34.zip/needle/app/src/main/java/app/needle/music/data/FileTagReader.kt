package app.needle.music.data

import java.io.ByteArrayOutputStream
import java.nio.ByteBuffer
import java.nio.channels.FileChannel
import java.nio.charset.Charset

/**
 * Reads the "other" tags (everything in [TagFields]) out of an audio file's own metadata:
 * ID3v2.3 / 2.4 in MP3, Vorbis comments in FLAC, OGG and Opus, and iTunes-style atoms in M4A / MP4.
 * The core tags (title, artist, album, genre, year, track) are not read here; Android already gives us those.
 *
 * Only the tag part at the start of the file (or the metadata atoms of an MP4) is read, and cover pictures
 * are skipped, so a file costs a few small reads. A file that cannot be read gives an empty map.
 * Tested against files written by ffmpeg and hand-built ones (unsynchronised tags, UTF-16, huge comments).
 */
object FileTagReader {

    private const val MAX_BLOCK = 16 * 1024 * 1024
    private val LATIN1: Charset = Charsets.ISO_8859_1

    fun read(channel: FileChannel): Map<String, String> = try {
        val src = Source(channel)
        val head = src.upTo(0, 12)
        when {
            head.startsWith("ID3") -> readId3(src)
            head.startsWith("fLaC") -> readFlac(src)
            head.startsWith("OggS") -> readOgg(src)
            head.size >= 8 && String(head, 4, 4, LATIN1) == "ftyp" -> readMp4(src, channel.size())
            else -> emptyMap()
        }
    } catch (e: Exception) {
        emptyMap()
    }

    // ---- reading helpers ---------------------------------------------------------------------

    /** Positional reads with a small read-ahead window, so many tiny reads do not each cost a system call. */
    private class Source(private val ch: FileChannel) {
        private var winStart = 0L
        private var win = ByteArray(0)

        /** Exactly [n] bytes at [pos], or null if the file is too short. */
        fun bytes(pos: Long, n: Int): ByteArray? {
            if (n < 0 || pos < 0) return null
            if (n == 0) return ByteArray(0)
            val got = upTo(pos, n)
            return if (got.size == n) got else null
        }

        /** Up to [n] bytes at [pos] (fewer at the end of the file). */
        fun upTo(pos: Long, n: Int): ByteArray {
            if (n <= 0 || pos < 0) return ByteArray(0)
            if (pos >= winStart && pos + n <= winStart + win.size) {
                val from = (pos - winStart).toInt()
                return win.copyOfRange(from, from + n)
            }
            if (n <= 32 * 1024) {
                // load a 64 KB window starting here
                val loaded = rawRead(pos, 64 * 1024)
                winStart = pos
                win = loaded
                val take = minOf(n, loaded.size)
                return loaded.copyOfRange(0, take)
            }
            return rawRead(pos, n)
        }

        private fun rawRead(pos: Long, n: Int): ByteArray {
            val buf = ByteBuffer.allocate(n)
            var at = pos
            while (buf.hasRemaining()) {
                val r = ch.read(buf, at)
                if (r <= 0) break
                at += r
            }
            return buf.array().copyOfRange(0, buf.position())
        }
    }

    private fun ByteArray.startsWith(text: String): Boolean =
        size >= text.length && text.indices.all { this[it] == text[it].code.toByte() }

    private fun u(b: Byte): Int = b.toInt() and 0xFF

    private fun synchsafe(b: ByteArray, at: Int): Int =
        (u(b[at]) shl 21) or (u(b[at + 1]) shl 14) or (u(b[at + 2]) shl 7) or u(b[at + 3])

    /** Big-endian number of [n] bytes. */
    private fun be(b: ByteArray, at: Int, n: Int): Long {
        var v = 0L
        for (i in 0 until n) v = (v shl 8) or u(b[at + i]).toLong()
        return v
    }

    private fun le32(b: ByteArray, at: Int): Long =
        u(b[at]).toLong() or (u(b[at + 1]).toLong() shl 8) or (u(b[at + 2]).toLong() shl 16) or (u(b[at + 3]).toLong() shl 24)

    // ---- field names -------------------------------------------------------------------------

    private fun norm(s: String): String = s.uppercase().filter { it.isLetterOrDigit() }

    private val byNorm: Map<String, String> = TagFields.all.associate { norm(it.key) to it.key }

    /** Names other programs use for the same thing (Vorbis comments, iTunes freeform atoms, ID3 TXXX). */
    private val aliases: Map<String, String> = mapOf(
        "REMIXER" to "MIXARTIST", "ORIGINALARTIST" to "ORIGARTIST", "ORIGINALLYRICIST" to "ORIGLYRICIST",
        "DISCSUBTITLE" to "SETSUBTITLE", "LYRICS" to "UNSYNCEDLYRICS", "ORGANIZATION" to "PUBLISHER",
        "LABEL" to "PUBLISHER", "RELEASEDATE" to "RELEASETIME", "ORIGINALDATE" to "ORIGYEAR",
        "ORIGINALYEAR" to "ORIGYEAR", "ORIGINALALBUM" to "ORIGALBUM", "KEY" to "INITIALKEY", "TEMPO" to "BPM",
        "MEDIA" to "MEDIATYPE", "CATALOG" to "CATALOGNUMBER", "LABELNO" to "CATALOGNUMBER"
    )

    /** "MusicBrainz Album Id" / "MUSICBRAINZ_ALBUMID" / "Remixer" ... -> one of our field keys, or null. */
    private fun mapNamed(name: String): String? {
        val n = norm(name)
        return aliases[n] ?: byNorm[n]
    }

    /** Trims the value and tidies a few fields. null = nothing worth keeping. */
    private fun clean(key: String, raw: String): String? {
        val value = raw.trim().trim { it == '\u0000' }.trim()
        if (value.isEmpty()) return null
        return when (key) {
            "ORIGYEAR" -> Regex("^\\d{4}").find(value)?.value
            "RATING" -> {
                val r = value.toIntOrNull() ?: return null
                when {
                    r <= 0 -> null
                    r <= 5 -> r.toString()
                    else -> ((r + 10) / 20).coerceIn(1, 5).toString()
                }
            }
            else -> value
        }
    }

    /** First value wins (a file can carry the same tag twice). */
    private fun MutableMap<String, String>.putFirst(key: String, raw: String) {
        if (key in this) return
        val v = clean(key, raw) ?: return
        this[key] = v
    }

    // ---- ID3v2 (MP3) -------------------------------------------------------------------------

    private val id3Text: Map<String, String> = mapOf(
        "TPE2" to "ALBUMARTIST", "TCOM" to "COMPOSER", "TPE3" to "CONDUCTOR", "TEXT" to "LYRICIST",
        "TPE4" to "MIXARTIST", "TOPE" to "ORIGARTIST", "TOLY" to "ORIGLYRICIST", "TSOT" to "TITLESORT",
        "TSOP" to "ARTISTSORT", "TSOA" to "ALBUMSORT", "TSO2" to "ALBUMARTISTSORT", "TSOC" to "COMPOSERSORT",
        "TPOS" to "DISCNUMBER", "TIT3" to "SUBTITLE", "TSST" to "SETSUBTITLE", "GRP1" to "GROUPING",
        "TIT1" to "CONTENTGROUP", "TCMP" to "COMPILATION", "MVNM" to "MOVEMENTNAME", "TDRL" to "RELEASETIME",
        "TOAL" to "ORIGALBUM", "TMOO" to "MOOD", "TBPM" to "BPM", "TKEY" to "INITIALKEY", "TLAN" to "LANGUAGE",
        "TPUB" to "PUBLISHER", "TCOP" to "COPYRIGHT", "TSRC" to "ISRC", "TMED" to "MEDIATYPE",
        "TORY" to "ORIGYEAR", "TDOR" to "ORIGYEAR"
    )

    private val id3Urls: Map<String, String> = mapOf(
        "WOAR" to "WWWARTIST", "WOAF" to "WWWAUDIOFILE", "WOAS" to "WWWAUDIOSOURCE", "WCOM" to "WWWCOMMERCIALINFO",
        "WCOP" to "WWWCOPYRIGHT", "WPAY" to "WWWPAYMENT", "WPUB" to "WWWPUBLISHER", "WORS" to "WWWRADIOPAGE"
    )

    /** Removes the 00 byte that unsynchronisation puts after every FF. */
    private fun unsync(b: ByteArray): ByteArray {
        val out = ByteArrayOutputStream(b.size)
        var i = 0
        while (i < b.size) {
            out.write(u(b[i]))
            if (b[i] == 0xFF.toByte() && i + 1 < b.size && b[i + 1] == 0.toByte()) i++
            i++
        }
        return out.toByteArray()
    }

    private fun decodeText(enc: Int, b: ByteArray): String = when (enc) {
        0 -> String(b, LATIN1)
        1 -> when {
            b.size >= 2 && u(b[0]) == 0xFF && u(b[1]) == 0xFE -> String(b, 2, b.size - 2, Charsets.UTF_16LE)
            b.size >= 2 && u(b[0]) == 0xFE && u(b[1]) == 0xFF -> String(b, 2, b.size - 2, Charsets.UTF_16BE)
            else -> String(b, Charsets.UTF_16LE)
        }
        2 -> String(b, Charsets.UTF_16BE)
        else -> String(b, Charsets.UTF_8)
    }

    /** Splits at the first terminator of the encoding (one zero byte, or two for UTF-16). */
    private fun splitTerminated(enc: Int, b: ByteArray): Pair<ByteArray, ByteArray> {
        if (enc == 1 || enc == 2) {
            var i = 0
            while (i + 1 < b.size) {
                if (b[i] == 0.toByte() && b[i + 1] == 0.toByte()) {
                    return b.copyOfRange(0, i) to b.copyOfRange(i + 2, b.size)
                }
                i += 2
            }
            return b to ByteArray(0)
        }
        val i = b.indexOf(0.toByte())
        return if (i < 0) b to ByteArray(0) else b.copyOfRange(0, i) to b.copyOfRange(i + 1, b.size)
    }

    /** All the strings of a frame (v2.4 allows several, separated by terminators). */
    private fun splitValues(enc: Int, b: ByteArray): List<String> {
        val out = ArrayList<String>()
        var rest = b
        while (true) {
            val (s, next) = splitTerminated(enc, rest)
            out += decodeText(enc, s)
            if (next.isEmpty()) break
            rest = next
        }
        return out.filter { it.isNotEmpty() }
    }

    private fun popmToStars(r: Int): Int? = when {
        r == 0 -> null
        r <= 31 -> 1
        r <= 95 -> 2
        r <= 159 -> 3
        r <= 223 -> 4
        else -> 5
    }

    private fun readId3(src: Source): Map<String, String> {
        val head = src.bytes(0, 10) ?: return emptyMap()
        val ver = u(head[3])
        val flags = u(head[5])
        val size = synchsafe(head, 6)
        if ((ver != 3 && ver != 4) || size <= 0 || size > MAX_BLOCK) return emptyMap()

        // Version 2.3 can unsynchronise the whole tag; then it has to be read and decoded in one piece.
        // Otherwise frames are read one by one, so big pictures are never loaded.
        val wholeTag: ByteArray? =
            if (ver == 3 && (flags and 0x80) != 0) unsync(src.upTo(10, size)) else null
        val limit = wholeTag?.size ?: size
        fun read(at: Int, n: Int): ByteArray? =
            if (n < 0 || at < 0 || at + n > limit) null
            else if (wholeTag != null) wholeTag.copyOfRange(at, at + n)
            else src.bytes(10L + at, n)

        var pos = 0
        if ((flags and 0x40) != 0) { // extended header: skip it
            val h = read(0, 4) ?: return emptyMap()
            pos = if (ver == 4) synchsafe(h, 0) else (be(h, 0, 4) + 4).toInt()
        }

        val out = LinkedHashMap<String, String>()
        while (pos + 10 <= limit) {
            val fh = read(pos, 10) ?: break
            if (fh[0] == 0.toByte()) break
            if (!(0..3).all { fh[it].toInt().toChar().let { c -> c in 'A'..'Z' || c in '0'..'9' } }) break
            val fid = String(fh, 0, 4, LATIN1)
            val fsize = if (ver == 4) synchsafe(fh, 4) else be(fh, 4, 4).toInt()
            val f1 = u(fh[9])
            pos += 10
            if (fsize <= 0 || pos + fsize > limit) break
            val dataAt = pos
            pos += fsize

            // Only frames we use are read. Pictures and everything else are skipped by size.
            val wanted = fid in id3Text || fid in id3Urls ||
                fid in setOf("MVIN", "TIPL", "TMCL", "IPLS", "TXXX", "COMM", "USLT", "POPM", "WXXX", "UFID")
            if (!wanted) continue

            var data = read(dataAt, fsize) ?: continue
            if (ver == 4) {
                if ((f1 and 0x0C) != 0) continue // compressed or encrypted
                if ((f1 and 0x01) != 0) { // data length indicator
                    if (data.size < 4) continue
                    data = data.copyOfRange(4, data.size)
                }
                if ((f1 and 0x02) != 0 || (flags and 0x80) != 0) data = unsync(data)
            } else {
                if ((f1 and 0xC0) != 0) continue // compressed or encrypted
                if ((f1 and 0x20) != 0) { // grouping id byte
                    if (data.isEmpty()) continue
                    data = data.copyOfRange(1, data.size)
                }
            }
            if (data.isEmpty()) continue
            readId3Frame(fid, data, out)
        }
        return out
    }

    private fun readId3Frame(fid: String, data: ByteArray, out: MutableMap<String, String>) {
        val enc = u(data[0])
        when {
            fid in id3Text -> {
                val key = id3Text.getValue(fid)
                val values = splitValues(enc, data.copyOfRange(1, data.size))
                if (values.isEmpty()) return
                out.putFirst(key, if (key == "ORIGYEAR") values[0] else values.joinToString("; "))
            }
            fid == "MVIN" -> {
                val v = splitValues(enc, data.copyOfRange(1, data.size)).firstOrNull() ?: return
                out.putFirst("MOVEMENT", v.substringBefore('/'))
                if ('/' in v) out.putFirst("MOVEMENTTOTAL", v.substringAfter('/'))
            }
            fid == "TIPL" || fid == "TMCL" || fid == "IPLS" -> {
                val v = splitValues(enc, data.copyOfRange(1, data.size))
                val pairs = (0 until v.size - 1 step 2).map { v[it] + ":" + v[it + 1] }
                out.putFirst(if (fid == "TMCL") "MUSICIANCREDITS" else "INVOLVEDPEOPLE", pairs.joinToString(";"))
            }
            fid == "TXXX" -> {
                val (d, rest) = splitTerminated(enc, data.copyOfRange(1, data.size))
                val key = mapNamed(decodeText(enc, d)) ?: return
                out.putFirst(key, splitValues(enc, rest).joinToString("; "))
            }
            fid == "COMM" -> {
                if (data.size < 5) return
                val (d, rest) = splitTerminated(enc, data.copyOfRange(4, data.size))
                if (decodeText(enc, d).isEmpty()) out.putFirst("COMMENT", decodeText(enc, rest))
            }
            fid == "USLT" -> {
                if (data.size < 5) return
                val (_, rest) = splitTerminated(enc, data.copyOfRange(4, data.size))
                out.putFirst("UNSYNCEDLYRICS", decodeText(enc, rest))
            }
            fid == "POPM" -> {
                val (_, rest) = splitTerminated(0, data)
                if (rest.isNotEmpty()) popmToStars(u(rest[0]))?.let { out.putFirst("RATING", it.toString()) }
            }
            fid in id3Urls -> out.putFirst(id3Urls.getValue(fid), String(data.takeWhile { it != 0.toByte() }.toByteArray(), LATIN1))
            fid == "WXXX" -> {
                val (_, rest) = splitTerminated(enc, data.copyOfRange(1, data.size))
                out.putFirst("WWW", String(rest.takeWhile { it != 0.toByte() }.toByteArray(), LATIN1))
            }
            fid == "UFID" -> {
                val (owner, rest) = splitTerminated(0, data)
                if (String(owner, LATIN1) == "http://musicbrainz.org") out.putFirst("MUSICBRAINZ_TRACKID", String(rest, LATIN1))
            }
        }
    }

    // ---- Vorbis comments (FLAC, OGG, Opus) -----------------------------------------------------

    private fun parseVorbisComments(b: ByteArray): Map<String, String> {
        val out = LinkedHashMap<String, String>()
        if (b.size < 8) return out
        var p = 0L
        p += 4 + le32(b, 0) // vendor string
        if (p + 4 > b.size) return out
        val count = le32(b, p.toInt())
        p += 4
        var i = 0L
        while (i < count) {
            if (p + 4 > b.size) break
            val len = le32(b, p.toInt())
            p += 4
            if (len > b.size - p) break
            val item = String(b, p.toInt(), len.toInt(), Charsets.UTF_8)
            p += len
            i++
            val eq = item.indexOf('=')
            if (eq < 0) continue
            val key = mapNamed(item.substring(0, eq)) ?: continue
            val value = clean(key, item.substring(eq + 1)) ?: continue
            out[key] = if (key in out) out.getValue(key) + "; " + value else value
        }
        return out
    }

    private fun readFlac(src: Source): Map<String, String> {
        var pos = 4L
        while (true) {
            val h = src.bytes(pos, 4) ?: return emptyMap()
            val last = (u(h[0]) and 0x80) != 0
            val type = u(h[0]) and 0x7F
            val len = (u(h[1]) shl 16) or (u(h[2]) shl 8) or u(h[3])
            if (type == 4) {
                if (len > MAX_BLOCK) return emptyMap()
                return parseVorbisComments(src.bytes(pos + 4, len) ?: return emptyMap())
            }
            pos += 4 + len
            if (last) return emptyMap()
        }
    }

    /** The comment header is the second packet of an Ogg stream; it can span several pages. */
    private fun readOgg(src: Source): Map<String, String> {
        val packets = ArrayList<ByteArray>()
        var cur = ByteArrayOutputStream()
        var pos = 0L
        var total = 0L
        while (packets.size < 2) {
            val hdr = src.bytes(pos, 27) ?: return emptyMap()
            if (!hdr.startsWith("OggS")) return emptyMap()
            val nseg = u(hdr[26])
            val segs = src.bytes(pos + 27, nseg) ?: return emptyMap()
            val bodyLen = segs.sumOf { u(it) }
            val body = src.bytes(pos + 27 + nseg, bodyLen) ?: return emptyMap()
            pos += 27L + nseg + bodyLen
            total += bodyLen
            var at = 0
            for (s in segs) {
                val n = u(s)
                cur.write(body, at, n)
                at += n
                if (n < 255) {
                    packets += cur.toByteArray()
                    cur = ByteArrayOutputStream()
                    if (packets.size >= 2) break
                }
            }
            if (total > 8 * 1024 * 1024) return emptyMap()
        }
        val c = packets[1]
        return when {
            c.startsWith("\u0003vorbis") -> parseVorbisComments(c.copyOfRange(7, c.size))
            c.startsWith("OpusTags") -> parseVorbisComments(c.copyOfRange(8, c.size))
            else -> emptyMap()
        }
    }

    // ---- MP4 / M4A -----------------------------------------------------------------------------

    private val mp4Text: Map<String, String> = mapOf(
        "aART" to "ALBUMARTIST", "\u00A9wrt" to "COMPOSER", "\u00A9grp" to "GROUPING", "\u00A9cmt" to "COMMENT",
        "desc" to "DESCRIPTION", "\u00A9lyr" to "UNSYNCEDLYRICS", "cprt" to "COPYRIGHT", "soal" to "ALBUMSORT",
        "soaa" to "ALBUMARTISTSORT", "soar" to "ARTISTSORT", "sonm" to "TITLESORT", "soco" to "COMPOSERSORT",
        "\u00A9mvn" to "MOVEMENTNAME", "\u00A9wrk" to "WORK"
    )

    private class Box(val type: String, val dataStart: Long, val end: Long)

    private fun boxAt(src: Source, pos: Long, end: Long): Box? {
        if (pos + 8 > end) return null
        val h = src.bytes(pos, 8) ?: return null
        var size = be(h, 0, 4)
        val type = String(h, 4, 4, LATIN1)
        var headerLen = 8L
        if (size == 1L) {
            val big = src.bytes(pos + 8, 8) ?: return null
            size = be(big, 0, 8)
            headerLen = 16
        } else if (size == 0L) {
            size = end - pos
        }
        if (size < headerLen || pos + size > end) return null
        return Box(type, pos + headerLen, pos + size)
    }

    private fun findChild(src: Source, start: Long, end: Long, want: String): Box? {
        var pos = start
        while (pos < end) {
            val box = boxAt(src, pos, end) ?: return null
            if (box.type == want) return box
            pos = box.end
        }
        return null
    }

    private fun readMp4(src: Source, fileSize: Long): Map<String, String> {
        val moov = findChild(src, 0, fileSize, "moov") ?: return emptyMap()
        val udta = findChild(src, moov.dataStart, moov.end, "udta") ?: return emptyMap()
        val meta = findChild(src, udta.dataStart, udta.end, "meta") ?: return emptyMap()
        // "meta" is a full box: 4 bytes of version and flags come before its children.
        val ilst = findChild(src, meta.dataStart + 4, meta.end, "ilst") ?: return emptyMap()

        val out = LinkedHashMap<String, String>()
        var pos = ilst.dataStart
        while (pos < ilst.end) {
            val item = boxAt(src, pos, ilst.end) ?: break
            pos = item.end
            if (item.type == "covr" || item.end - item.dataStart > 8L * 1024 * 1024) continue

            var mean: String? = null
            var name: String? = null
            var value: ByteArray? = null
            var cp = item.dataStart
            while (cp < item.end) {
                val child = boxAt(src, cp, item.end) ?: break
                cp = child.end
                val payload = src.bytes(child.dataStart, (child.end - child.dataStart).toInt()) ?: continue
                when (child.type) {
                    "mean" -> if (payload.size >= 4) mean = String(payload, 4, payload.size - 4, Charsets.UTF_8)
                    "name" -> if (payload.size >= 4) name = String(payload, 4, payload.size - 4, Charsets.UTF_8)
                    "data" -> if (value == null && payload.size >= 8) value = payload.copyOfRange(8, payload.size)
                }
            }
            val v = value ?: continue
            fun text() = String(v, Charsets.UTF_8)
            when {
                item.type in mp4Text -> out.putFirst(mp4Text.getValue(item.type), text())
                item.type == "cpil" -> if (v.isNotEmpty() && v.last() != 0.toByte()) out.putFirst("COMPILATION", "1")
                item.type == "tmpo" && v.isNotEmpty() ->
                    out.putFirst("BPM", (if (v.size >= 2) be(v, v.size - 2, 2) else be(v, 0, v.size)).toString())
                item.type == "disk" && v.size >= 6 -> {
                    val d = be(v, 2, 2)
                    val t = be(v, 4, 2)
                    if (d > 0) out.putFirst("DISCNUMBER", if (t > 0) "$d/$t" else "$d")
                }
                item.type == "\u00A9mvi" && v.isNotEmpty() && v.size <= 8 -> out.putFirst("MOVEMENT", be(v, 0, v.size).toString())
                item.type == "\u00A9mvc" && v.isNotEmpty() && v.size <= 8 -> out.putFirst("MOVEMENTTOTAL", be(v, 0, v.size).toString())
                item.type == "----" && name != null -> mapNamed(name)?.let { out.putFirst(it, text()) }
            }
        }
        return out
    }
}
