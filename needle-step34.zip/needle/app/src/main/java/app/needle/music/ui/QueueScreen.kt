package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.playback.PlayerViewModel

/** The next songs in playback order. Tap to jump there, X to take a song out of the queue. */
@Composable
fun QueueScreen(vm: PlayerViewModel, onClose: () -> Unit, onSaveQueue: () -> Unit, modifier: Modifier = Modifier) {
    val upNext = remember(vm.queueVersion, vm.currentMediaId, vm.shuffleEnabled) { vm.upNext(100) }
    val hidden = (vm.queueSize - 1 - upNext.size).coerceAtLeast(0)

    Column(modifier.safeDrawingPadding()) {
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            ChevronDownButton(onClose)
            Text("Up next", color = Palette.Muted, fontSize = 14.sp)
            Spacer(Modifier.width(44.dp))
        }

        Column(Modifier.padding(horizontal = 24.dp, vertical = 8.dp)) {
            Text("Playing now", color = Palette.Muted, fontSize = 13.sp)
            Text(
                vm.title ?: "", color = Palette.Accent, fontFamily = Palette.TitleFont,
                fontWeight = FontWeight.Bold, fontSize = 22.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                vm.artist ?: "", color = Palette.Muted, fontSize = 15.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Spacer(Modifier.padding(6.dp))
            Text(
                (if (vm.shuffleEnabled) "Shuffled · " else "") + "${vm.queueSize} songs in queue",
                color = Palette.Muted, fontSize = 13.sp
            )
            // From the mockup: keep this queue as a playlist
            PillButton("Save queue as playlist", onSaveQueue, Modifier.fillMaxWidth().padding(top = 12.dp), filled = true)
        }

        LazyColumn(contentPadding = PaddingValues(bottom = 24.dp)) {
            itemsIndexed(upNext, key = { _, e -> e.index }) { _, entry ->
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { vm.jumpTo(entry.index) }
                        .padding(start = 24.dp, end = 12.dp, top = 8.dp, bottom = 8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(
                            entry.title, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(
                            entry.artist, color = Palette.Muted, fontSize = 13.sp,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                    }
                    CloseButton(onClick = { vm.removeFromQueue(entry.index) })
                }
            }
            if (hidden > 0) {
                item {
                    Box(Modifier.fillMaxWidth().padding(20.dp), contentAlignment = Alignment.Center) {
                        Text("+ $hidden more", color = Palette.Muted, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}
