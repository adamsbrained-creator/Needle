package app.needle.music.data

import java.text.Normalizer

enum class SortField(val label: String) {
    TITLE("Title"),
    ARTIST("Artist"),
    ALBUM("Album"),
    RECENT("Recent"),
    DURATION("Length"),
    RATING("Rating")
}

data class SortOrder(val field: SortField, val ascending: Boolean)

/** Newest first and best rated first feel natural for these two; everything else starts A to Z. */
fun defaultAscending(field: SortField): Boolean = field != SortField.RECENT && field != SortField.RATING

private val accentMarks = Regex("\\p{Mn}+")

/**
 * Makes a string sortable the way people expect: lowercase, accents removed,
 * leading quotes / brackets / # ignored. Artists also ignore a leading "The".
 */
fun sortKey(text: String, dropThe: Boolean = false): String {
    var t = Normalizer.normalize(text, Normalizer.Form.NFD).replace(accentMarks, "").lowercase()
    t = t.trimStart { !it.isLetterOrDigit() }
    if (dropThe && t.startsWith("the ")) t = t.removePrefix("the ")
    return t
}

/** Sorts by the sort-name tags (Title sort, Artist sort, Album sort) when a song has them, else by the real names. */
private class Keyed(val song: Song, extras: Map<String, String>?) {
    val title = sortKey(extras?.get("TITLESORT") ?: song.title)
    val artist = sortKey(extras?.get("ARTISTSORT") ?: song.artist, dropThe = true)
    val album = sortKey(extras?.get("ALBUMSORT") ?: song.album)
}

fun sortSongs(songs: List<Song>, order: SortOrder, extras: ExtraTags = emptyMap(), ratings: Map<Long, Int> = emptyMap()): List<Song> {
    val keyed = songs.map { Keyed(it, extras[it.id]) }
    val base: Comparator<Keyed> = when (order.field) {
        SortField.TITLE -> compareBy({ it.title }, { it.artist })
        SortField.ARTIST -> compareBy({ it.artist }, { it.album }, { it.song.trackNumber }, { it.title })
        SortField.ALBUM -> compareBy({ it.album }, { it.song.trackNumber }, { it.title })
        SortField.RECENT -> compareBy({ it.song.dateAdded }, { it.title })
        SortField.DURATION -> compareBy({ it.song.durationMs }, { it.title })
        // Best rated first (the default); songs you have not rated come last.
        SortField.RATING -> compareBy({ ratings[it.song.id] ?: 0 }, { it.title })
    }
    val comparator = if (order.ascending) base else base.reversed()
    return keyed.sortedWith(comparator).map { it.song }
}
