package app.needle.music.data

import android.app.Application
import android.net.Uri
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Numbers and actions behind the Settings pages: counts, resets, backup and restore. */
class SettingsViewModel(private val app: Application) : AndroidViewModel(app) {
    private val db = NeedleDatabase.get(app)

    private fun counter(flow: kotlinx.coroutines.flow.Flow<Int>): StateFlow<Int> =
        flow.stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    val playCount = counter(db.playDao().observeCount())
    val editCount = counter(db.tagDao().observeCount())
    val extraCount = counter(db.extraTagDao().observeCount())
    val noteCount = counter(db.artistNoteDao().observeCount())

    var coverCount by mutableIntStateOf(0)
        private set

    /** The last thing that happened (saved, restored, reset...), shown under the buttons. */
    var message by mutableStateOf<String?>(null)
        private set

    init {
        refreshCovers()
    }

    fun refreshCovers() {
        viewModelScope.launch { coverCount = withContext(Dispatchers.IO) { CoverStore.songIds(app).size } }
    }

    fun clearMessage() { message = null }

    fun resetEdits() {
        viewModelScope.launch {
            db.tagDao().deleteAll()
            db.extraTagDao().deleteAll()
            message = "All tag edits and extra fields were removed."
        }
    }

    fun resetCovers() {
        viewModelScope.launch {
            val ids = withContext(Dispatchers.IO) {
                val found = CoverStore.songIds(app)
                found.forEach { CoverStore.file(app, it).delete() }
                found
            }
            ArtworkLoader.invalidate(ids)
            coverCount = 0
            message = "Custom covers were removed. Songs show the cover inside their file again."
        }
    }

    fun exportTo(uri: Uri, movingBackground: Boolean) {
        viewModelScope.launch {
            try {
                val (json, s) = Backup.export(app, movingBackground)
                withContext(Dispatchers.IO) {
                    app.contentResolver.openOutputStream(uri, "wt")?.use { it.write(json.toByteArray()) }
                        ?: error("Could not open the file.")
                }
                message = "Backup saved: ${s.plays} plays, ${s.edits} edited songs, ${s.extras} extra fields, ${s.notes} artist notes, ${s.playlists} playlists, ${s.ratings} ratings, and your settings."
            } catch (e: Exception) {
                message = "Could not save the backup: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }

    fun restoreFrom(uri: Uri, onMovingBackground: (Boolean) -> Unit) {
        viewModelScope.launch {
            try {
                val text = withContext(Dispatchers.IO) {
                    app.contentResolver.openInputStream(uri)?.use { it.readBytes().toString(Charsets.UTF_8) }
                        ?: error("Could not open the file.")
                }
                val r = Backup.restore(app, text)
                r.movingBackground?.let(onMovingBackground)
                message = "Restored: ${r.summary.plays} new plays, ${r.summary.edits} edited songs, " +
                    "${r.summary.extras} extra fields, ${r.summary.notes} artist notes, ${r.summary.playlists} playlists, ${r.summary.ratings} ratings, and your settings."
            } catch (e: Exception) {
                message = "Could not restore: ${e.message ?: e.javaClass.simpleName}"
            }
        }
    }
}
