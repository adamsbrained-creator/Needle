package app.needle.music.ui

fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}

/** "1 track", "9 tracks". */
fun tracksText(n: Int): String = if (n == 1) "1 track" else "$n tracks"
