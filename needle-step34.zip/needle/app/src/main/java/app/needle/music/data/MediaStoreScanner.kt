package app.needle.music.data

import android.content.Context
import android.os.Build
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media

/** Reads the phone's audio index (MediaStore) into a list of [Song]. Call off the main thread. */
object MediaStoreScanner {

    fun scan(context: Context): List<Song> {
        val projection = buildList {
            add(Media._ID)
            add(Media.TITLE)
            add(Media.ARTIST)
            add(Media.ALBUM)
            add(Media.ALBUM_ID)
            add(Media.DURATION)
            add(Media.TRACK)
            add(Media.YEAR)
            add(Media.DATE_ADDED)
            if (Build.VERSION.SDK_INT >= 29) add(Media.RELATIVE_PATH)
            if (Build.VERSION.SDK_INT >= 30) add(Media.GENRE)
        }.toTypedArray()

        NeedleSettings.init(context)
        val minMs = maxOf(1L, NeedleSettings.minSongSeconds.intValue * 1000L)
        val selection = "${Media.IS_MUSIC} != 0 AND ${Media.DURATION} >= $minMs"
        val result = ArrayList<Song>()

        context.contentResolver.query(
            Media.EXTERNAL_CONTENT_URI, projection, selection, null, null
        )?.use { c ->
            val iId = c.getColumnIndexOrThrow(Media._ID)
            val iTitle = c.getColumnIndexOrThrow(Media.TITLE)
            val iArtist = c.getColumnIndexOrThrow(Media.ARTIST)
            val iAlbum = c.getColumnIndexOrThrow(Media.ALBUM)
            val iAlbumId = c.getColumnIndexOrThrow(Media.ALBUM_ID)
            val iDuration = c.getColumnIndexOrThrow(Media.DURATION)
            val iTrack = c.getColumnIndexOrThrow(Media.TRACK)
            val iYear = c.getColumnIndexOrThrow(Media.YEAR)
            val iAdded = c.getColumnIndexOrThrow(Media.DATE_ADDED)
            val iPath = if (Build.VERSION.SDK_INT >= 29) c.getColumnIndex(Media.RELATIVE_PATH) else -1
            val iGenre = if (Build.VERSION.SDK_INT >= 30) c.getColumnIndex(Media.GENRE) else -1

            while (c.moveToNext()) {
                val artist = c.getString(iArtist)
                val album = c.getString(iAlbum)
                result.add(
                    Song(
                        id = c.getLong(iId),
                        title = c.getString(iTitle)?.takeIf { it.isNotBlank() } ?: "Unknown title",
                        artist = artist?.takeUnless { it == MediaStore.UNKNOWN_STRING || it.isBlank() } ?: "Unknown artist",
                        album = album?.takeUnless { it == MediaStore.UNKNOWN_STRING || it.isBlank() } ?: "Unknown album",
                        albumId = c.getLong(iAlbumId),
                        durationMs = c.getLong(iDuration),
                        // MediaStore stores disc*1000 + track, e.g. 1002 = disc 1, track 2
                        trackNumber = c.getInt(iTrack) % 1000,
                        year = c.getInt(iYear),
                        dateAdded = c.getLong(iAdded),
                        folder = if (iPath >= 0) c.getString(iPath).orEmpty() else "",
                        genre = if (iGenre >= 0) c.getString(iGenre)?.trim().orEmpty() else ""
                    )
                )
            }
        }
        return result
    }
}
