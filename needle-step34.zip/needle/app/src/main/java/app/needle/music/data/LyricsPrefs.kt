package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf

/** The options of Settings -> Lyrics, remembered. Compose state, so pages follow changes straight away. */
object LyricsPrefs {
    private var prefs: SharedPreferences? = null

    /** Read .lrc files next to the songs (needs "all files access"). */
    val useLrcFiles = mutableStateOf(true)

    /** Use the lyrics tag inside the audio file. */
    val useEmbedded = mutableStateOf(true)

    /** Offer the "Search online" button (LRCLIB). */
    val onlineSearch = mutableStateOf(true)

    /** Search online by itself when a song has no lyrics. On by default. */
    val autoOnline = mutableStateOf(true)

    /** Start the lyrics page with the screen kept on. */
    val keepScreenOn = mutableStateOf(false)

    /** Text size, 0.8 to 1.5. The slider on the lyrics page changes it too. */
    val scale = mutableFloatStateOf(1f)

    /** Font of the lyrics page and the preview card: "outfit", "sans", "serif" or "mono". */
    val font = mutableStateOf("outfit")

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        useLrcFiles.value = p.getBoolean("lyrics_lrc", true)
        useEmbedded.value = p.getBoolean("lyrics_embedded", true)
        onlineSearch.value = p.getBoolean("lyrics_online", true)
        autoOnline.value = p.getBoolean("lyrics_auto", true)
        keepScreenOn.value = p.getBoolean("lyrics_keep_screen", false)
        scale.floatValue = p.getFloat("lyrics_scale", 1f).coerceIn(0.8f, 1.5f)
        font.value = p.getString("lyrics_font", "outfit") ?: "outfit"
    }

    private fun put(key: String, value: Boolean) { prefs?.edit()?.putBoolean(key, value)?.apply() }

    fun setUseLrcFiles(v: Boolean) { useLrcFiles.value = v; put("lyrics_lrc", v) }
    fun setUseEmbedded(v: Boolean) { useEmbedded.value = v; put("lyrics_embedded", v) }
    fun setOnlineSearch(v: Boolean) { onlineSearch.value = v; put("lyrics_online", v) }
    fun setAutoOnline(v: Boolean) { autoOnline.value = v; put("lyrics_auto", v) }
    fun setKeepScreenOn(v: Boolean) { keepScreenOn.value = v; put("lyrics_keep_screen", v) }

    fun setFont(id: String) { font.value = id; prefs?.edit()?.putString("lyrics_font", id)?.apply() }

    /** Dragging the slider changes [scale] live; this writes it down when the finger lifts. */
    fun saveScale() { prefs?.edit()?.putFloat("lyrics_scale", scale.floatValue)?.apply() }

    fun setScale(v: Float) { scale.floatValue = v.coerceIn(0.8f, 1.5f); saveScale() }

    /** Sync offset of one song, in milliseconds. Positive shows the lines later. */
    fun offsetMs(songId: Long): Int = prefs?.getInt("lyrics_off_$songId", 0) ?: 0

    fun setOffsetMs(songId: Long, ms: Int) {
        val e = prefs?.edit() ?: return
        if (ms == 0) e.remove("lyrics_off_$songId") else e.putInt("lyrics_off_$songId", ms)
        e.apply()
    }
}
