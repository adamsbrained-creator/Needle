package app.needle.music.cast

class PositionInfo(val relMs: Long?, val durMs: Long?, val trackUri: String)

/** The handful of UPnP actions Needle needs, for one device. All calls block: run them off the main thread. */
class UpnpRenderer(private val lan: LanNet, val device: CastDevice) {

    private fun avt(action: String, extra: List<Pair<String, String>> = emptyList()): Map<String, String> =
        Soap.call(lan, device.avtUrl, device.avtType, action, listOf("InstanceID" to "0") + extra)

    fun setUri(uri: String, didl: String) {
        avt("SetAVTransportURI", listOf("CurrentURI" to uri, "CurrentURIMetaData" to didl))
    }

    fun setNext(uri: String, didl: String) {
        avt("SetNextAVTransportURI", listOf("NextURI" to uri, "NextURIMetaData" to didl))
    }

    fun play() { avt("Play", listOf("Speed" to "1")) }
    fun pause() { avt("Pause") }
    fun stop() { avt("Stop") }

    fun seek(ms: Long) {
        val target = Soap.formatTime(ms)
        try {
            avt("Seek", listOf("Unit" to "REL_TIME", "Target" to target))
        } catch (e: UpnpException) {
            avt("Seek", listOf("Unit" to "ABS_TIME", "Target" to target))
        }
    }

    fun transportState(): String = avt("GetTransportInfo")["CurrentTransportState"].orEmpty()

    fun positionInfo(): PositionInfo {
        val m = avt("GetPositionInfo")
        return PositionInfo(Soap.parseTime(m["RelTime"]), Soap.parseTime(m["TrackDuration"]), m["TrackURI"].orEmpty())
    }

    fun getVolume(): Int? {
        val url = device.rcUrl ?: return null
        val type = device.rcType ?: return null
        return Soap.call(lan, url, type, "GetVolume", listOf("InstanceID" to "0", "Channel" to "Master"))["CurrentVolume"]
            ?.toIntOrNull()
    }

    fun setVolume(v: Int) {
        val url = device.rcUrl ?: return
        val type = device.rcType ?: return
        Soap.call(
            lan, url, type, "SetVolume",
            listOf("InstanceID" to "0", "Channel" to "Master", "DesiredVolume" to v.coerceIn(0, 100).toString())
        )
    }

    /** The formats the device says it can play ("Sink" of the ConnectionManager). Empty = unknown. */
    fun sinkFormats(): List<String> {
        val url = device.cmUrl ?: return emptyList()
        val type = device.cmType ?: return emptyList()
        val sink = Soap.call(lan, url, type, "GetProtocolInfo")["Sink"].orEmpty()
        return sink.split(',').map { it.trim() }.filter { it.isNotEmpty() }
    }
}
