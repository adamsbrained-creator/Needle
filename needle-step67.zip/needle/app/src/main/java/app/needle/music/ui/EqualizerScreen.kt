package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.NeedleSettings
import app.needle.music.playback.EqState

private val BarHeight = 210.dp

/** "+6 dB", "-3 dB", "0 dB", "-2.5 dB" */
private fun dbText(v: Float): String = when {
    v == 0f -> "0 dB"
    v % 1f == 0f -> "%+d dB".format(v.toInt())
    else -> "%+.1f dB".format(v)
}

/**
 * The Equalizer page from the mockup: ten bars from 32 Hz to 16 kHz (tap or drag a bar), presets, a preamp and the
 * loudness row. Everything is applied while you touch it.
 */
@Composable
fun EqualizerScreen(
    casting: Boolean,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onSoon: () -> Unit,
    modifier: Modifier = Modifier
) {
    val on = EqState.enabled.value
    var showPreamp by remember { mutableStateOf(false) }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
            // Back to a flat curve and no preamp
            RoundIconButton(NeedleIcon.REFRESH, { EqState.reset() }, size = 42.dp, iconSize = 22.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text("Equalizer", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 36.sp)
        Text("10 bands. Tap a bar to set it.", color = Palette.Muted, fontSize = 13.sp)
        if (casting) {
            Text(
                "Casting plays the original sound. The equalizer works on this phone.",
                color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp)
            )
        }
        Spacer(Modifier.height(18.dp))

        // ---- on / off ----
        GlassRow {
            Text("Equalizer", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            NeedleSwitch(on) { EqState.setEnabled(it) }
        }

        // ---- presets ----
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            EqState.PRESETS.forEach { preset ->
                val selected = EqState.presetId.value == preset.id
                Box(
                    Modifier
                        .height(40.dp)
                        .clip(CircleShape)
                        .background(if (selected) Color.White else Color.White.copy(alpha = 0.10f))
                        .clickable { EqState.applyPreset(preset.id) }
                        .padding(horizontal = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        preset.name, fontSize = 14.sp, fontWeight = FontWeight.Medium,
                        color = if (selected) Palette.Bg else Palette.Text
                    )
                }
            }
        }

        // ---- the ten bars ----
        Box(
            Modifier
                .fillMaxWidth()
                .glass(RoundedCornerShape(26.dp))
                .padding(start = 8.dp, end = 8.dp, top = 16.dp, bottom = 10.dp)
                .alpha(if (on) 1f else 0.55f)
        ) {
            Curve(Modifier.fillMaxWidth().height(BarHeight))
            Row(Modifier.fillMaxWidth()) {
                for (i in 0 until EqState.BANDS) {
                    Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                        BandBar(i)
                        Text(EqState.LABELS[i], color = Palette.Muted, fontSize = 10.5.sp, modifier = Modifier.padding(top = 6.dp))
                    }
                }
            }
            Text("+12 dB", color = Palette.Muted, fontSize = 10.sp, modifier = Modifier.padding(start = 2.dp).align(Alignment.TopStart))
        }
        Spacer(Modifier.height(12.dp))

        // ---- preamp ----
        GlassRow(Modifier.clickable { showPreamp = true }) {
            Column(Modifier.weight(1f)) {
                Text("Preamp", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Lowers the level to avoid clipping", color = Palette.Muted, fontSize = 12.5.sp)
            }
            Text(dbText(EqState.preampDb.floatValue), color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }
        Spacer(Modifier.height(12.dp))

        // ---- loudness normalization (the same switch as Volume levelling in Settings > Playback) ----
        GlassRow {
            Column(Modifier.weight(1f)) {
                Text("Loudness normalization", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Same volume across songs", color = Palette.Muted, fontSize = 12.5.sp)
            }
            NeedleSwitch(NeedleSettings.volumeLevelling.value) { NeedleSettings.setVolumeLevelling(it) }
        }
    }

    if (showPreamp) PreampDialog(onDismiss = { showPreamp = false })
}

@Composable
private fun GlassRow(modifier: Modifier = Modifier, content: @Composable androidx.compose.foundation.layout.RowScope.() -> Unit) {
    Row(
        modifier
            .fillMaxWidth()
            .glass(RoundedCornerShape(22.dp))
            .padding(horizontal = 18.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        content = content
    )
}

/** One vertical bar. Tap anywhere on it, or drag, to set the gain (to the nearest half dB). */
@Composable
private fun BandBar(index: Int) {
    Canvas(
        Modifier
            .fillMaxWidth()
            .height(BarHeight)
            .pointerInput(index) {
                detectTapGestures { offset -> setFromY(index, offset.y, size.height) }
            }
            .pointerInput(index) {
                detectVerticalDragGestures(
                    onDragStart = { offset -> setFromY(index, offset.y, size.height) },
                    onVerticalDrag = { change, _ ->
                        change.consume()
                        setFromY(index, change.position.y, size.height)
                    }
                )
            }
    ) {
        val v = (EqState.gains[index] + EqState.MAX_DB) / (2f * EqState.MAX_DB)   // 0 = bottom, 1 = top
        val cx = size.width / 2f
        val trackW = 4.dp.toPx()
        val thumbR = 9.dp.toPx()
        // keep the thumb inside the bar's height
        val y = (size.height - thumbR) - v * (size.height - 2 * thumbR) + 0f
        drawRoundRect(
            Color.White.copy(alpha = 0.14f), Offset(cx - trackW / 2, 0f), Size(trackW, size.height),
            CornerRadius(trackW / 2)
        )
        drawRoundRect(
            Brush.verticalGradient(listOf(Palette.Accent, Palette.Pink), startY = y, endY = size.height),
            Offset(cx - trackW / 2, y), Size(trackW, size.height - y), CornerRadius(trackW / 2)
        )
        drawCircle(Palette.Accent.copy(alpha = 0.35f), thumbR * 1.6f, Offset(cx, y))
        drawCircle(Color.White, thumbR, Offset(cx, y))
    }
}

private fun setFromY(index: Int, y: Float, height: Int) {
    val v = 1f - (y / height).coerceIn(0f, 1f)
    EqState.setBand(index, v * 2f * EqState.MAX_DB - EqState.MAX_DB)
}

/** The pink line through the ten thumbs, behind the bars. */
@Composable
private fun Curve(modifier: Modifier) {
    Canvas(modifier) {
        val n = EqState.BANDS
        val thumbR = 9.dp.toPx()
        fun pt(i: Int): Offset {
            val v = (EqState.gains[i] + EqState.MAX_DB) / (2f * EqState.MAX_DB)
            return Offset((i + 0.5f) * size.width / n, (size.height - thumbR) - v * (size.height - 2 * thumbR))
        }
        // a faint 0 dB line, so you can see where flat is
        val zeroY = size.height / 2f
        drawLine(Color.White.copy(alpha = 0.08f), Offset(0f, zeroY), Offset(size.width, zeroY), 1.dp.toPx())
        val path = Path()
        val first = pt(0)
        path.moveTo(first.x, first.y)
        for (i in 1 until n) {
            val a = pt(i - 1)
            val b = pt(i)
            val midX = (a.x + b.x) / 2f
            path.cubicTo(midX, a.y, midX, b.y, b.x, b.y)   // a smooth S between neighbours
        }
        drawPath(
            path, Palette.Pink.copy(alpha = 0.55f),
            style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        )
    }
}

@Composable
private fun PreampDialog(onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Preamp") },
        text = {
            Column {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Level", color = Palette.Text, fontSize = 15.sp)
                    Text(dbText(EqState.preampDb.floatValue), color = Palette.Muted, fontSize = 15.sp)
                }
                Slider(
                    value = EqState.preampDb.floatValue,
                    onValueChange = { EqState.setPreamp(it) },
                    valueRange = -12f..0f,
                    steps = 23,
                    colors = SliderDefaults.colors(
                        thumbColor = Color.White,
                        activeTrackColor = Palette.Accent,
                        inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                        activeTickColor = Color.Transparent,
                        inactiveTickColor = Color.Transparent
                    )
                )
                Text(
                    "Boosting bands makes the sound louder, and a loud peak can distort. Lower the preamp to make room.",
                    color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = { EqState.setPreamp(0f) }) { Text("Reset", color = Palette.Muted) } }
    )
}
