package app.needle.music.ui

import app.needle.music.data.FolderGroup
import app.needle.music.data.NowPlayingStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import app.needle.music.data.GenrePrefs
import androidx.compose.foundation.background
import app.needle.music.data.Song
import app.needle.music.data.RowSwipe
import app.needle.music.data.RowDetail
import app.needle.music.data.RowSubtitle
import app.needle.music.data.RowStyle
import app.needle.music.data.AlbumRating
import app.needle.music.data.ListBool
import app.needle.music.data.ListSettings
import app.needle.music.data.contrastGrade
import app.needle.music.data.contrastRatio
import app.needle.music.data.ThemeStore
import app.needle.music.data.ColorThemes
import app.needle.music.data.ColorTheme
import androidx.compose.ui.graphics.compositeOver
import androidx.compose.ui.geometry.Offset
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxHeight
import android.widget.Toast
import android.content.Intent
import android.content.Context
import android.content.ClipboardManager
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.toArgb
import app.needle.music.data.HomeLayout
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AccentChoices
import app.needle.music.data.AlbumPrefs
import app.needle.music.data.discLabel
import app.needle.music.data.CountAfter
import app.needle.music.data.NeedleSettings
import app.needle.music.data.Skin
import app.needle.music.data.Skins
import app.needle.music.data.RatingStyle
import app.needle.music.data.RatingScale
import app.needle.music.data.SettingsViewModel
import app.needle.music.playback.EqState
import app.needle.music.playback.SleepTimer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.roundToInt

enum class SettingsPage { HOME, APPEARANCE, SKINS, COLORS_THEMES, MEDIA_LISTS, HOME_LAYOUT, NOW_PLAYING, PLAYBACK, RATINGS, LIBRARY, TAGS, BACKUP, ABOUT }

private val Danger = Color(0xFFEB5757)

/**
 * Settings, opened from the avatar on Home. The list follows the mockup. Pages that exist open;
 * Equalizer is marked "Soon". Lyrics and Cast devices open the pages that were built for them.
 */
@Composable
fun SettingsScreen(
    page: SettingsPage,
    onPage: (SettingsPage) -> Unit,
    glowOn: Boolean,
    onGlowChange: (Boolean) -> Unit,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onOpenCast: () -> Unit,
    onOpenLyricsSettings: () -> Unit,
    onOpenEq: () -> Unit,
    onOpenSleep: () -> Unit,
    tagsRead: Int,
    songCount: Int,
    tagProgress: Pair<Int, Int>?,
    onRereadTags: () -> Unit,
    onChooseGenres: () -> Unit,
    writeToFiles: Boolean,
    onWriteToFilesChange: (Boolean) -> Unit,
    writeProgress: Pair<Int, Int>?,
    onWriteAll: () -> Unit,
    isScanning: Boolean,
    onRescan: () -> Unit,
    vm: SettingsViewModel,
    hiddenCount: Int = 0,
    onOpenHidden: () -> Unit = {},
    folderGroups: List<FolderGroup> = emptyList(),
    excludedFolders: Set<String> = emptySet(),
    onToggleFolder: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    val back: () -> Unit = {
        when (page) {
            SettingsPage.HOME -> onBack()
            SettingsPage.HOME_LAYOUT, SettingsPage.COLORS_THEMES, SettingsPage.MEDIA_LISTS, SettingsPage.SKINS -> onPage(SettingsPage.APPEARANCE)
            else -> onPage(SettingsPage.HOME)
        }
    }
    when (page) {
        SettingsPage.HOME -> SettingsHome(
            songCount = songCount,
            bottomPadding = bottomPadding,
            onBack = back,
            onPage = onPage,
            onOpenCast = onOpenCast,
            onOpenLyricsSettings = onOpenLyricsSettings,
            onOpenEq = onOpenEq,
            onOpenSleep = onOpenSleep,
            modifier = modifier
        )
        SettingsPage.APPEARANCE -> PageFrame("Customization", "Make Needle yours. Changes show up right away.", back, bottomPadding, modifier) {
            AppearanceContent(glowOn, onGlowChange, onPage)
        }
        SettingsPage.SKINS -> PageFrame("Skins", "Change how Needle looks and feels, not only its colors.", back, bottomPadding, modifier) {
            SkinsContent(onGlowChange)
        }
        SettingsPage.MEDIA_LISTS -> PageFrame("Media lists", "How songs, albums and list pages look and react.", back, bottomPadding, modifier) {
            MediaListsContent()
        }
        SettingsPage.COLORS_THEMES -> PageFrame("Colors & themes", "Pick a look, or build your own.", back, bottomPadding, modifier) {
            ColorsThemesContent(glowOn, onGlowChange)
        }
        SettingsPage.HOME_LAYOUT -> PageFrame("Home layout", "Show, hide and reorder what is on Home.", back, bottomPadding, modifier) {
            HomeLayoutContent()
        }
        SettingsPage.NOW_PLAYING -> PageFrame("Now playing", "The player page and the cards under it.", back, bottomPadding, modifier) {
            NowPlayingContent()
        }
        SettingsPage.PLAYBACK -> PageFrame("Playback", "How songs play and when they count.", back, bottomPadding, modifier) {
            PlaybackContent()
        }
        SettingsPage.RATINGS -> PageFrame("Ratings", "Rate songs your way. Needle sorts by it.", back, bottomPadding, modifier) {
            RatingsContent()
        }
        SettingsPage.LIBRARY -> PageFrame("Library", "Finding and reading your music.", back, bottomPadding, modifier) {
            LibraryContent(songCount, isScanning, onRescan, tagsRead, tagProgress, onRereadTags, onChooseGenres, hiddenCount, onOpenHidden, folderGroups, excludedFolders, onToggleFolder)
        }
        SettingsPage.TAGS -> PageFrame("Tags and covers", "Your edits, and writing them into files.", back, bottomPadding, modifier) {
            TagsContent(vm, writeToFiles, onWriteToFilesChange, writeProgress, onWriteAll)
        }
        SettingsPage.BACKUP -> PageFrame("Backup and restore", "Keep what Needle can't rebuild.", back, bottomPadding, modifier) {
            BackupContent(vm, glowOn, onGlowChange)
        }
        SettingsPage.ABOUT -> PageFrame("About Needle", "A music player that stays on your phone.", back, bottomPadding, modifier) {
            AboutContent(vm, songCount)
        }
    }
}

// ---- frame and shared pieces -------------------------------------------------------------

@Composable
private fun PageFrame(
    title: String,
    subtitle: String,
    onBack: () -> Unit,
    bottomPadding: Dp,
    modifier: Modifier,
    content: @Composable () -> Unit
) {
    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(Modifier.fillMaxWidth().padding(top = 12.dp)) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
        }
        Spacer(Modifier.height(16.dp))
        Text(title, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
        Text(subtitle, color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))
        content()
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text, color = if (Skins.blackGreen) Palette.Accent else Palette.Muted, fontSize = if (Skins.blackGreen) 13.sp else 12.sp,
        fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, top = 6.dp, bottom = 8.dp)
    )
}

@Composable
private fun Note(text: String) {
    Text(text, color = Palette.Muted, fontSize = 12.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp, vertical = 6.dp))
}

@Composable
private fun OptionPills(options: List<String>, selected: Int, onSelect: (Int) -> Unit) {
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        options.forEachIndexed { i, label ->
            val on = i == selected
            Text(
                label,
                color = if (on) Color(0xFF111111) else Palette.Text,
                fontSize = 14.sp,
                fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (on) Color.White else Palette.Card2)
                    .clickable { onSelect(i) }
                    .padding(horizontal = 18.dp, vertical = 11.dp)
            )
        }
    }
}

@Composable
private fun CountTile(value: String, label: String, modifier: Modifier = Modifier) {
    Column(modifier.glass(RoundedCornerShape(18.dp)).padding(14.dp)) {
        Text(value, color = Palette.Text, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Text(label, color = Palette.Muted, fontSize = 12.sp)
    }
}

// ---- home --------------------------------------------------------------------------------

private class Entry(
    val title: String,
    val subtitle: String,
    val keywords: String,
    val icon: NeedleIcon,
    val onClick: (() -> Unit)?   // null = not built yet
)

@Composable
private fun appVersion(): String {
    val context = LocalContext.current
    return remember {
        runCatching { context.packageManager.getPackageInfo(context.packageName, 0).versionName }.getOrNull() ?: "?"
    }
}

@Composable
private fun SettingsHome(
    songCount: Int,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPage: (SettingsPage) -> Unit,
    onOpenCast: () -> Unit,
    onOpenLyricsSettings: () -> Unit,
    onOpenEq: () -> Unit,
    onOpenSleep: () -> Unit,
    modifier: Modifier
) {
    var query by rememberSaveable { mutableStateOf("") }
    val accentName = accentName()
    val version = appVersion()
    val entries = listOf(
        Entry("Customization", "Colors & themes · $accentName · ${if (NeedleSettings.amoled.value) "AMOLED" else "Dark"}",
            "customization appearance skins skin black green dock bar layout look media lists rows swipe grid counts colors themes theme accent color titles font serif sans glow moving background amoled black cards presets", NeedleIcon.PALETTE
        ) { onPage(SettingsPage.APPEARANCE) },
        Entry("Now playing", "Info cards color",
            "now playing cards color artist credits file details library info rgb", NeedleIcon.CONTROLS
        ) { onPage(SettingsPage.NOW_PLAYING) },
        Entry("Playback", "Gapless, crossfade, volume levelling",
            "skip silence headphones unplug play count history gapless popular crossfade fade volume levelling loudness normalization replaygain", NeedleIcon.PLAY
        ) { onPage(SettingsPage.PLAYBACK) },
        Entry(
            "Ratings", "Rate songs · ${NeedleSettings.ratingStyle.value.label}",
            "rating rate stars score favourite best top 5 stars decimal 10", NeedleIcon.STAR
        ) { onPage(SettingsPage.RATINGS) },
        Entry("Equalizer and audio", "10 bands · ${EqState.summary}", "equalizer eq bass audio", NeedleIcon.EQUALIZER, onOpenEq),
        Entry(
            "Sleep timer", if (SleepTimer.mode.value == SleepTimer.Mode.OFF) "Stop the music after a while" else SleepTimer.summary,
            "sleep timer stop night bed fade end of song album minutes", NeedleIcon.TIMER, onOpenSleep
        ),
        Entry("Library", "$songCount songs · scanning, short songs, tags",
            "scan folders hidden songs rescan short length tags read", NeedleIcon.FOLDER
        ) { onPage(SettingsPage.LIBRARY) },
        Entry("Cast devices", "Xbox, Kodi · UPnP", "cast dlna upnp xbox tv play on", NeedleIcon.CAST, onOpenCast),
        Entry("Lyrics", "Sources, size, sync", "lyrics lrc online font size sync", NeedleIcon.LYRICS, onOpenLyricsSettings),
        Entry("Tags and covers", "Editing, artwork, writing to files",
            "tags covers artwork edit reset write files mp3tag", NeedleIcon.TAG
        ) { onPage(SettingsPage.TAGS) },
        Entry("Backup and restore", "Play history, tag edits, settings",
            "backup restore export import history stats notes", NeedleIcon.BACKUP
        ) { onPage(SettingsPage.BACKUP) },
        Entry("About Needle", "Version $version", "about version licenses", NeedleIcon.INFO) { onPage(SettingsPage.ABOUT) }
    )
    val q = query.trim()
    val shown = entries.filter {
        q.isEmpty() || it.title.contains(q, ignoreCase = true) ||
            it.subtitle.contains(q, ignoreCase = true) || it.keywords.contains(q, ignoreCase = true)
    }

    PageFrame("Settings", "Make Needle yours.", onBack, bottomPadding, modifier) {
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(horizontal = 16.dp, vertical = 13.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            NeedleIconView(NeedleIcon.SEARCH, Palette.Muted, size = 18.dp)
            Spacer(Modifier.width(10.dp))
            Box(Modifier.weight(1f)) {
                BasicTextField(
                    value = query,
                    onValueChange = { query = it },
                    singleLine = true,
                    textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
                    cursorBrush = SolidColor(Palette.Accent),
                    modifier = Modifier.fillMaxWidth(),
                    decorationBox = { inner ->
                        Box {
                            if (query.isEmpty()) Text("Search settings", color = Palette.Muted, fontSize = 15.sp)
                            inner()
                        }
                    }
                )
            }
        }
        Spacer(Modifier.height(14.dp))

        if (q.isEmpty()) {
            val shape = RoundedCornerShape(22.dp)
            Row(
                Modifier.fillMaxWidth().glass(shape).border(1.dp, Palette.Accent.copy(alpha = 0.55f), shape).padding(16.dp),
                verticalAlignment = Alignment.Top
            ) {
                Box(
                    Modifier.size(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f)),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.LOCK, Palette.Text, size = 20.dp) }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Stays on this phone", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        "No account, no uploads. Your library, stats and notes are local. The only thing that can leave " +
                            "the phone is a lyrics lookup (song title and artist, sent to LRCLIB), and you can turn that off under Lyrics.",
                        color = Palette.Muted, fontSize = 12.sp, lineHeight = 17.sp
                    )
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        if (shown.isEmpty()) Note("No setting matches \"$q\".")
        shown.forEach { NavRow(it) }
    }
}

@Composable
private fun NavRow(entry: Entry) {
    val active = entry.onClick != null
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .glass(RoundedCornerShape(20.dp))
            .then(if (entry.onClick != null) Modifier.clickable(onClick = entry.onClick) else Modifier)
            .padding(horizontal = 14.dp, vertical = 13.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(40.dp).clip(RoundedCornerShape(12.dp)).background(Color.White.copy(alpha = if (active) 0.12f else 0.06f)),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(entry.icon, if (active) Palette.Text else Palette.Muted, size = 20.dp) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                entry.title, color = if (active) Palette.Text else Palette.Muted,
                fontSize = 15.sp, fontWeight = FontWeight.SemiBold
            )
            Text(entry.subtitle, color = Palette.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        }
        if (active) {
            NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
        } else {
            Text(
                "Soon", color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.1f)).padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
    }
}

// ---- appearance --------------------------------------------------------------------------

internal enum class ColorRole { ACCENT, BACKGROUND, GLOW1, GLOW2, GLOW3 }

private fun accentName(): String = AccentChoices.getOrNull(NeedleSettings.accentIndex.intValue)?.name ?: "Custom"

@Composable
private fun ColorRow(title: String, note: String, color: Color, onClick: () -> Unit) {
    SettingRow(title, note = note, onClick = onClick) {
        Box(Modifier.size(32.dp).clip(CircleShape).background(color).border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape))
    }
}

/** The color picker for whichever color row was tapped. Changes apply live while it is open. */
@Composable
private fun RolePicker(role: ColorRole, onDismiss: () -> Unit) {
    when (role) {
        ColorRole.ACCENT -> ColorPickerDialog(
            "Accent color", Palette.Accent,
            onChange = { NeedleSettings.setCustomAccent(it.toArgb()); NeedleSettings.setAccent(AccentChoices.size) },
            onReset = { NeedleSettings.setAccent(0) }, onDismiss = onDismiss
        )
        ColorRole.BACKGROUND -> ColorPickerDialog(
            "Background", Palette.Bg,
            onChange = { NeedleSettings.setBgColor(it.toArgb()) },
            onReset = { NeedleSettings.setBgColor(0) }, onDismiss = onDismiss, maxBrightness = 0.35f
        )
        ColorRole.GLOW1 -> ColorPickerDialog(
            "Glow 1", Palette.Glow1,
            onChange = { NeedleSettings.setGlow(1, it.toArgb()) }, onReset = { NeedleSettings.setGlow(1, 0) }, onDismiss = onDismiss
        )
        ColorRole.GLOW2 -> ColorPickerDialog(
            "Glow 2", Palette.Glow2,
            onChange = { NeedleSettings.setGlow(2, it.toArgb()) }, onReset = { NeedleSettings.setGlow(2, 0) }, onDismiss = onDismiss
        )
        ColorRole.GLOW3 -> ColorPickerDialog(
            "Glow 3", Palette.Glow3,
            onChange = { NeedleSettings.setGlow(3, it.toArgb()) }, onReset = { NeedleSettings.setGlow(3, 0) }, onDismiss = onDismiss
        )
    }
}

@Composable
private fun AppearanceContent(glowOn: Boolean, onGlowChange: (Boolean) -> Unit, onPage: (SettingsPage) -> Unit) {
    SkinsEntry(onPage)
    Spacer(Modifier.height(10.dp))
    ColorsEntry(onPage)
    Spacer(Modifier.height(10.dp))
    ListsEntry(onPage)

    Spacer(Modifier.height(10.dp))
    Label("Animated covers")
    SettingRow(
        "Animated covers",
        note = "Plays the looping Apple Music cover video on the Now playing page, when one exists for the album. Looked up online, so it needs internet. Many albums have none and keep the normal cover."
    ) { NeedleSwitch(NeedleSettings.animatedCovers.value) { NeedleSettings.setAnimatedCovers(it) } }
    if (NeedleSettings.animatedCovers.value) {
        SettingRow(
            "Full page",
            note = "Plays the animated cover behind the whole Now playing page, like Spotify's Canvas, instead of only on the cover. The cover shows until the video is ready."
        ) { NeedleSwitch(NeedleSettings.animatedFullPage.value) { NeedleSettings.setAnimatedFullPage(it) } }
        SettingRow(
            "Artists too",
            note = "Also plays the artist's looping video in the artist header, on the artist page and in About the artist, for artists Apple Music has one for."
        ) { NeedleSwitch(NeedleSettings.animatedArtistCovers.value) { NeedleSettings.setAnimatedArtistCovers(it) } }
        SettingRow(
            "Backup server",
            note = "When Apple Music's own lookup finds nothing, asks a public server that finds the same Apple Music covers. It receives the artist and album names of what you play."
        ) { NeedleSwitch(NeedleSettings.animatedBackupServer.value) { NeedleSettings.setAnimatedBackupServer(it) } }
        if (NeedleSettings.animatedBackupServer.value) {
            SettingsTextField(NeedleSettings.backupServerUrl.value, "Server address (https)") { NeedleSettings.setBackupServerUrl(it) }
            Note("The default is the public m8tec server. You can run your own copy of it and enter its https address here.")
        }
        SettingRow(
            "Tidal video covers",
            note = "Also looks for Tidal's own video cover, for albums Apple Music has none for. Needs a Tidal API token, which stays on this phone and is not saved in backups."
        ) { NeedleSwitch(NeedleSettings.animatedTidal.value) { NeedleSettings.setAnimatedTidal(it) } }
        if (NeedleSettings.animatedTidal.value) {
            SettingsTextField(NeedleSettings.tidalToken.value, "Tidal API token") { NeedleSettings.setTidalToken(it) }
            Note("This uses Tidal's private web catalog, so it can stop working at any time.")
        }
        OptionPills(listOf("Wi-Fi only", "Wi-Fi and mobile data"), if (NeedleSettings.animatedCoversWifiOnly.value) 0 else 1) {
            NeedleSettings.setAnimatedCoversWifiOnly(it == 0)
        }
        Note("The videos are streamed each time, so on mobile data they can use a fair amount.")
    }

    Spacer(Modifier.height(10.dp))
    Label("Online artwork")
    SettingRow(
        "Find missing covers",
        note = "For songs that have no cover, looks one up on iTunes and Deezer and keeps it on the phone. Each album is looked up once."
    ) { NeedleSwitch(NeedleSettings.fetchMissingCovers.value) { NeedleSettings.setFetchMissingCovers(it) } }
    SettingRow(
        "Artist backgrounds",
        note = "Shows a wide picture of the artist from Fanart.tv at the top of the artist page and in About the artist. Needs your own free Fanart.tv API key."
    ) { NeedleSwitch(NeedleSettings.artistBackgrounds.value) { NeedleSettings.setArtistBackgrounds(it) } }
    if (NeedleSettings.artistBackgrounds.value) {
        FanartKeyField()
        Note("Get a free personal key: make an account on fanart.tv, then copy the API key from your profile. The key stays on this phone and is not saved in backups.")
    }

    Spacer(Modifier.height(10.dp))
    Label("Titles")
    OptionPills(listOf("Serif", "Sans"), if (NeedleSettings.serifTitles.value) 0 else 1) { NeedleSettings.setSerifTitles(it == 0) }
    Column(Modifier.fillMaxWidth().padding(vertical = 8.dp).glass(RoundedCornerShape(20.dp)).padding(16.dp)) {
        Text("Albums", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 32.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Just added", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(CircleShape).background(Palette.Accent).padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }

    Spacer(Modifier.height(10.dp))
    Label("Home")
    SettingRow(
        "Home layout",
        note = "Show, hide and reorder the sections on Home and the pills under the title, and pick the page Home opens on.",
        onClick = { onPage(SettingsPage.HOME_LAYOUT) }
    ) { NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp) }

}


// ---- skins --------------------------------------------------------------------------------

/** The row on the Customization page that opens Skins. */
@Composable
private fun SkinsEntry(onPage: (SettingsPage) -> Unit) {
    Label("Skins")
    SettingRow(
        "Skins",
        note = "${Skins.current.label}. Colors, dock and titles in one tap.",
        onClick = { onPage(SettingsPage.SKINS) }
    ) { NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp) }
}

@Composable
private fun SkinsContent(onGlowChange: (Boolean) -> Unit) {
    Label("Pick a skin")
    Skin.entries.forEach { skin ->
        val selected = skin == Skins.current
        SkinCard(skin, selected) { if (!selected) Skins.pick(skin, onGlowChange) }
    }
    Spacer(Modifier.height(10.dp))
    Label("Now playing page")
    NowPlayingStyle.entries.forEach { style ->
        ChoiceCard(style.label, style.note, selected = Skins.nowPlayingChoice == style) { NeedleSettings.setNpStyle(style.id) }
    }
    Note("The player page can follow the skin, or keep a look of its own.")
    Note("A skin sets the colors, the bottom dock, the titles and the moving background in one tap. Afterwards you can still change colors in Colors & themes; the skin stays selected until you pick another one. Picking a skin again from the other one starts from its colors.")
}

@Composable
private fun ChoiceCard(title: String, note: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .glass(shape)
            .then(if (selected) Modifier.border(1.5.dp, Palette.Accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(14.dp)
    ) {
        Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        Text(note, color = Palette.Muted, fontSize = 12.sp, lineHeight = 16.sp)
        if (selected) {
            Text("In use", color = Palette.Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
private fun SkinCard(skin: Skin, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .glass(shape)
            .then(if (selected) Modifier.border(1.5.dp, Palette.Accent, shape) else Modifier)
            .clickable(onClick = onClick)
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SkinPreview(skin)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(skin.label, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
            Text(skin.note, color = Palette.Muted, fontSize = 12.sp, lineHeight = 16.sp)
            if (selected) {
                Text(
                    "In use", color = Palette.Accent, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.padding(top = 6.dp)
                )
            }
        }
    }
}

/** A tiny drawing of a screen in the skin: a title, two cards and the bottom bar. */
@Composable
private fun SkinPreview(skin: Skin) {
    val flat = skin == Skin.BLACK_GREEN
    val shape = RoundedCornerShape(14.dp)
    val card = if (flat) Color(0xFF161616) else Color(0xFF333335)
    val accent = if (flat) Color(0xFF2BE566) else Color(0xFFAF65F5)
    Column(
        Modifier
            .size(width = 70.dp, height = 104.dp)
            .clip(shape)
            .background(if (flat) Color.Black else Color(0xFF101012))
            .border(1.dp, Color.White.copy(alpha = 0.15f), shape)
            .padding(8.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Box(Modifier.width(30.dp).height(5.dp).clip(CircleShape).background(Color.White))
        Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(6.dp)).background(card))
        Box(Modifier.fillMaxWidth().height(22.dp).clip(RoundedCornerShape(6.dp)).background(card))
        Spacer(Modifier.weight(1f))
        Row(
            Modifier
                .fillMaxWidth()
                .height(14.dp)
                .clip(if (flat) RoundedCornerShape(5.dp) else CircleShape)
                .background(if (flat) Color(0xFF1A1A1A) else Color(0xFF4E4068)),
            horizontalArrangement = Arrangement.SpaceEvenly,
            verticalAlignment = Alignment.CenterVertically
        ) {
            repeat(4) { i ->
                Box(Modifier.size(5.dp).clip(CircleShape).background(if (i == 0) accent else Color.White.copy(alpha = 0.4f)))
            }
        }
    }
}

// ---- colors & themes ---------------------------------------------------------------------

/** The row on the Customization page that opens Colors & themes. */
@Composable
private fun ColorsEntry(onPage: (SettingsPage) -> Unit) {
    val context = LocalContext.current
    remember { ThemeStore.ensureLoaded(context); true }
    Label("Colors")
    val name = ColorThemes.nameOfCurrent(ThemeStore.saved) ?: "Custom mix"
    SettingRow(
        "Colors & themes",
        note = "$name \u00B7 ${accentName()} \u00B7 ${if (NeedleSettings.amoled.value) "AMOLED" else "Dark"}. Themes, accent, background, glow and cards.",
        onClick = { onPage(SettingsPage.COLORS_THEMES) }
    ) {
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(22.dp).clip(CircleShape).background(Palette.Bg).border(1.dp, Color.White.copy(alpha = 0.4f), CircleShape))
            Box(Modifier.size(22.dp).clip(CircleShape).background(Palette.Accent))
            Box(Modifier.size(22.dp).clip(CircleShape).background(Palette.Glow2))
            NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
        }
    }
}

/** The colors a theme shows on its card: background, accent, a glow. */
private fun ColorTheme.previewColors(): Triple<Color, Color, Color> {
    val bg = when {
        bgColor != 0 -> Color(bgColor)
        amoled -> Color.Black
        else -> Color(0xFF101012)
    }
    val acc = if (accent >= AccentChoices.size) Color(customAccent) else AccentChoices[accent].color
    val glow = if (glow2 != 0) Color(glow2) else Color(0xFFEF42B8)
    return Triple(bg, acc, glow)
}

@Composable
private fun ThemeCard(theme: ColorTheme, selected: Boolean, onClick: () -> Unit, onLongClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    val (bg, accent, glow) = theme.previewColors()
    Column(
        Modifier.width(112.dp).clip(shape).background(Palette.Card)
            .then(if (selected) Modifier.border(2.dp, Palette.Accent, shape) else Modifier)
            .tapOrHold(onClick, onLongClick).padding(10.dp)
    ) {
        Row(Modifier.fillMaxWidth().height(40.dp).clip(RoundedCornerShape(10.dp))) {
            Box(Modifier.weight(1f).fillMaxHeight().background(bg))
            Box(Modifier.weight(1f).fillMaxHeight().background(accent))
            Box(Modifier.weight(1f).fillMaxHeight().background(glow))
        }
        Text(
            theme.name, color = Palette.Text, fontSize = 14.sp, maxLines = 1, overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal, modifier = Modifier.padding(top = 8.dp)
        )
    }
}

/** A small Now playing, drawn with the colors as they are right now. */
@Composable
private fun ThemePreview() {
    val shape = RoundedCornerShape(24.dp)
    val strength = if (GlowSettings.enabled.value) NeedleSettings.glowStrength.floatValue else 0f
    Box(Modifier.fillMaxWidth().height(150.dp).clip(shape).background(Palette.Bg)) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(listOf(Palette.Glow1.copy(alpha = 0.6f * strength), Color.Transparent), center = Offset(120f, 60f), radius = 700f)
            )
        )
        Box(
            Modifier.fillMaxSize().background(
                Brush.radialGradient(listOf(Palette.Glow2.copy(alpha = 0.45f * strength), Color.Transparent), center = Offset(1000f, 380f), radius = 600f)
            )
        )
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(96.dp).clip(RoundedCornerShape(16.dp))
                    .background(Brush.linearGradient(listOf(Palette.Glow1, Palette.Glow2, Palette.Glow3)))
            )
            Column(Modifier.padding(start = 14.dp)) {
                Text("Midnight Drive", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 20.sp)
                Text("Live preview", color = Palette.Muted, fontSize = 12.sp)
                Spacer(Modifier.height(12.dp))
                Box(Modifier.fillMaxWidth().height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f))) {
                    Box(Modifier.fillMaxWidth(0.42f).height(4.dp).background(Palette.Accent))
                }
                Spacer(Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(32.dp).clip(CircleShape).background(Palette.Accent))
                    Text(
                        "Idle pill", color = Palette.Text, fontSize = 12.sp,
                        modifier = Modifier.clip(CircleShape).background(Palette.Card2).padding(horizontal = 12.dp, vertical = 7.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ReadabilityRow(title: String, ratio: Double) {
    val grade = contrastGrade(ratio)
    val tint = when (grade) {
        "AAA", "AA" -> Color(0xFF6FCF97)
        "Low" -> Color(0xFFEB5757)
        else -> Color(0xFFF2C94C)
    }
    SettingRow(title, note = "%.1f : 1".format(ratio)) {
        Text(
            grade, color = Color(0xFF111111), fontSize = 12.sp, fontWeight = FontWeight.Bold,
            modifier = Modifier.clip(CircleShape).background(tint).padding(horizontal = 10.dp, vertical = 5.dp)
        )
    }
}

@Composable
private fun NameThemeDialog(initial: String, onSave: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Save as theme") },
        text = {
            Column {
                SettingsTextField(name, "Theme name") { name = it }
                Text(
                    "Saves the mode, accent, background, glow and cards as they are now.",
                    color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 8.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = { if (name.isNotBlank()) onSave(name.trim()) }) { Text("Save", color = Palette.Accent) } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel", color = Palette.Muted) } }
    )
}

@Composable
private fun ManageThemeDialog(theme: ColorTheme, onShare: () -> Unit, onDelete: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text(theme.name) },
        text = {
            Column {
                Text(
                    "Share theme", color = Palette.Text, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onShare).padding(vertical = 12.dp)
                )
                Text(
                    "Delete theme", color = Danger, fontSize = 16.sp,
                    modifier = Modifier.fillMaxWidth().clickable(onClick = onDelete).padding(vertical = 12.dp)
                )
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Close", color = Palette.Muted) } }
    )
}

@Composable
private fun ColorsThemesContent(glowOn: Boolean, onGlowChange: (Boolean) -> Unit) {
    val context = LocalContext.current
    remember { ThemeStore.ensureLoaded(context); true }
    var picking by remember { mutableStateOf<ColorRole?>(null) }
    var naming by remember { mutableStateOf(false) }
    var managing by remember { mutableStateOf<String?>(null) }
    val customAccentOn = NeedleSettings.accentIndex.intValue >= AccentChoices.size
    val now = ColorTheme.current("")

    ThemePreview()
    Spacer(Modifier.height(14.dp))

    Label("Themes")
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        (ColorThemes.builtIn + ThemeStore.saved).forEach { t ->
            val mine = !ColorThemes.isBuiltIn(t.name)
            ThemeCard(t, selected = t.sameLook(now), onClick = { t.apply() }, onLongClick = { if (mine) managing = t.name })
        }
        val saveShape = RoundedCornerShape(20.dp)
        Column(
            Modifier.width(112.dp).clip(saveShape).border(1.dp, Palette.Muted.copy(alpha = 0.5f), saveShape)
                .clickable { naming = true }.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(Modifier.height(40.dp), contentAlignment = Alignment.Center) {
                Text("+", color = Palette.Text, fontSize = 24.sp, fontWeight = FontWeight.Bold)
            }
            Text("Save current", color = Palette.Text, fontSize = 14.sp, maxLines = 1, modifier = Modifier.padding(top = 8.dp))
        }
    }
    Note("Tap a theme to use it. Press and hold one of yours to share or delete it.")
    PillButton("Import from clipboard", onClick = {
        val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as? ClipboardManager
        val text = cm?.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString().orEmpty()
        val found = ThemeStore.parse(text)
        if (found.isEmpty()) {
            Toast.makeText(context, "Copy a shared Needle theme first", Toast.LENGTH_SHORT).show()
        } else {
            found.forEach { ThemeStore.save(context, it.copy(name = ThemeStore.freeName(it.name))) }
            Toast.makeText(context, if (found.size == 1) "Theme imported" else "${found.size} themes imported", Toast.LENGTH_SHORT).show()
        }
    })

    Spacer(Modifier.height(14.dp))
    Label("Theme")
    OptionPills(listOf("Dark", "AMOLED"), if (NeedleSettings.amoled.value) 1 else 0) {
        NeedleSettings.setAmoled(it == 1)
        NeedleSettings.setBgColor(0)
    }
    Note("AMOLED makes the background pure black, which also saves battery on OLED screens.")

    Spacer(Modifier.height(10.dp))
    Label("Accent color")
    Row(
        Modifier.horizontalScroll(rememberScrollState()).padding(bottom = 6.dp),
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AccentChoices.forEachIndexed { i, choice ->
            val selected = i == NeedleSettings.accentIndex.intValue
            Box(
                Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(choice.color)
                    .then(if (selected) Modifier.border(3.dp, Color.White, CircleShape) else Modifier)
                    .clickable { NeedleSettings.setAccent(i) },
                contentAlignment = Alignment.Center
            ) { if (selected) NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 22.dp) }
        }
        // your own color
        Box(
            Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(Color(NeedleSettings.customAccent.intValue))
                .border(if (customAccentOn) 3.dp else 1.dp, if (customAccentOn) Color.White else Color.White.copy(alpha = 0.5f), CircleShape)
                .clickable { picking = ColorRole.ACCENT },
            contentAlignment = Alignment.Center
        ) {
            if (customAccentOn) NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 22.dp)
            else Text("+", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        }
    }
    Note(accentName())

    Spacer(Modifier.height(10.dp))
    Label("Cards")
    val cardMode = if (NeedleSettings.cardCustom.value) 1 else if (NeedleSettings.cardGlass.value) 2 else 0
    OptionPills(listOf("Auto", "Custom", "Glass"), cardMode) {
        NeedleSettings.setCardCustom(it == 1)
        NeedleSettings.setCardGlass(it == 2)
    }
    if (NeedleSettings.cardCustom.value) {
        Note("Pick any color for the cards on Home and the other pages. Light colors can make the white text hard to read.")
        CardColorPicker(NeedleSettings.cardArgb.intValue) { NeedleSettings.setCardArgb(it) }
    } else if (NeedleSettings.cardGlass.value) {
        Note("Glass makes the cards see-through, so the moving background shows through them. It looks best with the moving background on.")
    } else {
        Note("Auto keeps the dark gray cards on a plain background, and tints them to match the accent color when the moving background is on.")
    }
    Column(
        Modifier.fillMaxWidth().padding(vertical = 8.dp).clip(RoundedCornerShape(22.dp)).background(Palette.Card).padding(16.dp)
    ) {
        Text("Black Monk Time", color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium)
        Text("Monks · 12 tracks", color = Palette.Muted, fontSize = 12.sp)
        Spacer(Modifier.height(10.dp))
        Text(
            "Idle pill", color = Palette.Text, fontSize = 13.sp,
            modifier = Modifier.clip(CircleShape).background(Palette.Card2).padding(horizontal = 14.dp, vertical = 7.dp)
        )
    }

    Spacer(Modifier.height(10.dp))
    Label("Background and glow")
    ColorRow(
        "Background",
        if (NeedleSettings.bgColor.intValue != 0) "Custom color" else if (NeedleSettings.amoled.value) "AMOLED black" else "Default dark",
        Palette.Bg
    ) { picking = ColorRole.BACKGROUND }
    ColorRow("Glow 1", if (NeedleSettings.glow1.intValue != 0) "Custom color" else "Follows the accent", Palette.Glow1) { picking = ColorRole.GLOW1 }
    ColorRow("Glow 2", if (NeedleSettings.glow2.intValue != 0) "Custom color" else "Pink", Palette.Glow2) { picking = ColorRole.GLOW2 }
    ColorRow("Glow 3", if (NeedleSettings.glow3.intValue != 0) "Custom color" else "Soft green", Palette.Glow3) { picking = ColorRole.GLOW3 }
    NeedleSlider(
        "Glow strength", NeedleSettings.glowStrength.floatValue,
        Brush.horizontalGradient(listOf(Color.White.copy(alpha = 0.08f), Palette.Glow1))
    ) { NeedleSettings.setGlowStrength(it) }
    SettingRow(
        "Moving background",
        note = "The slowly drifting glow behind every page. Off gives a plain dark background and saves a little battery."
    ) { NeedleSwitch(glowOn, onGlowChange) }

    SettingRow(
        "Glow follows the cover",
        note = "On Now playing, the glow takes its colors from the cover of the song that is playing. Needs Moving background."
    ) { NeedleSwitch(NeedleSettings.adaptiveNowPlayingGlow.value) { NeedleSettings.setAdaptiveNowPlayingGlow(it) } }

    Spacer(Modifier.height(10.dp))
    Label("Readability")
    val bg = Palette.Bg
    ReadabilityRow("Text on background", contrastRatio(Palette.Text, bg))
    ReadabilityRow("Text on cards", contrastRatio(Palette.Text, Palette.Card.compositeOver(bg)))
    ReadabilityRow("White on accent", contrastRatio(Color.White, Palette.Accent))
    Note("Aim for AA or better. \"Low\" means text will be hard to read in that spot.")

    Spacer(Modifier.height(14.dp))
    PillButton("Reset all colors", onClick = { NeedleSettings.resetColors() })
    Note("A light theme, corner shapes and cover shapes are not built yet.")

    picking?.let { role -> RolePicker(role) { picking = null } }
    if (naming) {
        NameThemeDialog(
            initial = ThemeStore.freeName("My theme"),
            onSave = { n ->
                val saved = ThemeStore.save(context, ColorTheme.current(n))
                naming = false
                Toast.makeText(context, "Saved as $saved", Toast.LENGTH_SHORT).show()
            },
            onDismiss = { naming = false }
        )
    }
    managing?.let { name ->
        val theme = ThemeStore.saved.firstOrNull { it.name == name }
        if (theme == null) {
            managing = null
        } else {
            ManageThemeDialog(
                theme = theme,
                onShare = {
                    managing = null
                    try {
                        val send = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_TEXT, theme.toJson().toString())
                        }
                        context.startActivity(Intent.createChooser(send, null))
                    } catch (e: Exception) {
                        Toast.makeText(context, "Could not share this theme", Toast.LENGTH_SHORT).show()
                    }
                },
                onDelete = { ThemeStore.delete(context, name); managing = null },
                onDismiss = { managing = null }
            )
        }
    }
}


// ---- media lists -------------------------------------------------------------------------

/** The row on the Customization page that opens Media lists. */
@Composable
private fun ListsEntry(onPage: (SettingsPage) -> Unit) {
    Label("Lists")
    SettingRow(
        "Media lists",
        note = "Song rows, counts, album grids, swipe actions and selecting songs.",
        onClick = { onPage(SettingsPage.MEDIA_LISTS) }
    ) { NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp) }
}

@Composable
private fun <E : Enum<E>> EnumPills(all: List<E>, label: (E) -> String, current: E, onPick: (E) -> Unit) {
    OptionPills(all.map(label), all.indexOf(current)) { onPick(all[it]) }
}

@Composable
private fun ToggleRow(title: String, note: String? = null, setting: ListBool) {
    SettingRow(title, note = note) { NeedleSwitch(setting.value) { setting.set(it) } }
}

@Composable
private fun MediaListsContent() {
    val sample = remember {
        Song(
            id = -1L, title = "Midnight Drive", artist = "The Needles", album = "After Hours", albumId = 0L,
            durationMs = 214_000L, trackNumber = 1, year = 2021, dateAdded = 1_700_000_000L, folder = "", genre = "Rock"
        )
    }
    val sample2 = remember { sample.copy(id = -2L, title = "Paper Moon", artist = "Lena Voss", album = "Small Hours", year = 2018) }
    val shape = RoundedCornerShape(24.dp)

    Column(Modifier.fillMaxWidth().clip(shape).background(Palette.Card).padding(vertical = 6.dp)) {
        SongRow(sample, isCurrent = true, onClick = {}, onLongClick = {}, rating = 80, preview = true)
        SongRow(sample2, isCurrent = false, onClick = {}, onLongClick = {}, rating = 0, preview = true)
    }
    Note("A live preview. Every change below shows here and in your lists right away.")

    Label("Song rows")
    Note("Row style")
    EnumPills(RowStyle.entries, { it.label }, ListSettings.rowStyle.value) { ListSettings.rowStyle.set(it) }
    Note("Under the title")
    EnumPills(RowSubtitle.entries, { it.label }, ListSettings.subtitle.value) { ListSettings.subtitle.set(it) }
    Note("On the right")
    EnumPills(RowDetail.entries, { it.label }, ListSettings.detail.value) { ListSettings.detail.set(it) }
    Spacer(Modifier.height(6.dp))
    ToggleRow("Rating under the title", "Shows ★ after the album for songs you rated. Hidden when the right side already shows the rating.", ListSettings.ratingInSubtitle)
    ToggleRow("Favorite heart", "A small heart on songs in Liked songs.", ListSettings.favoriteHeart)

    Spacer(Modifier.height(10.dp))
    Label("List pages")
    ToggleRow("Show counts", "\"1,204 songs\" and \"86 albums\" under page titles, and the track count and length on album pages.", ListSettings.showCounts)
    ToggleRow("Flip sort arrows", "Swaps what the up and down arrow on the sort chips mean.", ListSettings.flipSortArrows)
    ToggleRow("Pin the sort bar", "Shuffle and the sort chips stay at the top while you scroll Songs.", ListSettings.pinSortBar)
    ToggleRow("Hide back button", "Hides the round back button on list pages. The back gesture still works.", ListSettings.hideListBack)

    Spacer(Modifier.height(10.dp))
    Label("Album grid")
    Note("Columns")
    OptionPills(listOf("2", "3", "4"), ListSettings.albumColumns.value - 2) { ListSettings.albumColumns.set(it + 2) }
    ToggleRow("Center text", "Centers the title and artist under each cover.", ListSettings.centerGridText)

    Spacer(Modifier.height(10.dp))
    Label("Album pages")
    AlbumRowsPreview()
    Note("Ratings")
    EnumPills(AlbumRating.entries, { it.label }, ListSettings.albumRating.value) { ListSettings.albumRating.set(it) }
    Note("Number shows \u2605 and the rating on the right, in the way you chose in Settings > Ratings. Stars shows five small stars under the title, rounded to the nearest whole star.")
    ToggleRow("Favorite hearts", "A small heart on the tracks that are in Liked songs.", ListSettings.albumHeart)
    Note("Album pages also follow Row style, On the right, the swipe gestures, Long press selects songs and Hide back button.")

    Spacer(Modifier.height(10.dp))
    Label("Gestures")
    Note("Swipe a song right")
    EnumPills(RowSwipe.entries, { it.label }, ListSettings.swipeRight.value) { ListSettings.swipeRight.set(it) }
    Note("Swipe a song left")
    EnumPills(RowSwipe.entries, { it.label }, ListSettings.swipeLeft.value) { ListSettings.swipeLeft.set(it) }
    ToggleRow(
        "Long press selects songs",
        "Off: a long press opens the song menu. On: it starts selecting, so you can queue, add to a playlist or edit tags for many songs at once (Songs, album and genre pages).",
        ListSettings.longPressSelect
    )

    Spacer(Modifier.height(14.dp))
    PillButton("Restore defaults", onClick = { ListSettings.resetAll() })
}

// ---- home layout -------------------------------------------------------------------------

@Composable
private fun MoveButton(up: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(40.dp).clip(CircleShape).then(if (enabled) Modifier.clickable(onClick = onClick) else Modifier),
        contentAlignment = Alignment.Center
    ) {
        Box(Modifier.rotate(if (up) 180f else 0f)) {
            NeedleIconView(NeedleIcon.CHEVRON_DOWN, if (enabled) Palette.Text else Palette.Muted.copy(alpha = 0.4f), size = 20.dp)
        }
    }
}

@Composable
private fun LayoutRow(
    title: String,
    shown: Boolean,
    canUp: Boolean,
    canDown: Boolean,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onToggle: () -> Unit
) {
    Row(
        Modifier.fillMaxWidth().padding(bottom = 8.dp).glass(RoundedCornerShape(18.dp))
            .padding(start = 16.dp, end = 8.dp, top = 6.dp, bottom = 6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            title, color = if (shown) Palette.Text else Palette.Muted, fontSize = 15.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.weight(1f)
        )
        MoveButton(up = true, enabled = canUp, onClick = onUp)
        MoveButton(up = false, enabled = canDown, onClick = onDown)
        Spacer(Modifier.width(6.dp))
        NeedleSwitch(shown) { onToggle() }
    }
}

@Composable
private fun HomeLayoutContent() {
    val startChoices = listOf("NEW" to "New", "POPULAR" to "Popular")
    Label("Home opens on")
    OptionPills(
        startChoices.map { it.second },
        startChoices.indexOfFirst { it.first == HomeLayout.startTab.value }.coerceAtLeast(0)
    ) { HomeLayout.setStartTab(startChoices[it].first) }

    Spacer(Modifier.height(10.dp))
    Label("Pills under the title")
    val tabs = HomeLayout.tabs()
    tabs.forEachIndexed { i, name ->
        LayoutRow(
            title = HomeTab.entries.firstOrNull { it.name == name }?.label ?: name,
            shown = HomeLayout.isTabVisible(name),
            canUp = i > 0,
            canDown = i < tabs.lastIndex,
            onUp = { HomeLayout.moveTab(name, -1) },
            onDown = { HomeLayout.moveTab(name, 1) },
            onToggle = { HomeLayout.toggleTab(name) }
        )
    }

    listOf("NEW" to "New page", "POPULAR" to "Popular page").forEach { (tab, label) ->
        Spacer(Modifier.height(10.dp))
        Label(label)
        val sections = HomeLayout.sectionsOf(tab)
        sections.forEachIndexed { i, section ->
            LayoutRow(
                title = section.title,
                shown = HomeLayout.isVisible(section.id),
                canUp = i > 0,
                canDown = i < sections.lastIndex,
                onUp = { HomeLayout.moveSection(section.id, -1) },
                onDown = { HomeLayout.moveSection(section.id, 1) },
                onToggle = { HomeLayout.toggleSection(section.id) }
            )
        }
    }

    Spacer(Modifier.height(10.dp))
    PillButton("Reset layout", onClick = { HomeLayout.reset() })
    Note("At least one pill always stays on. Hidden sections come back when you turn them on here.")
}

@Composable
private fun SettingsTextField(value: String, hint: String, onChange: (String) -> Unit) {
    var text by remember(value.isEmpty()) { mutableStateOf(value) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it.trim(); onChange(text) },
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Palette.Accent),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (text.isEmpty()) Text(hint, color = Palette.Muted, fontSize = 15.sp)
                    inner()
                }
            }
        )
    }
}

@Composable
private fun FanartKeyField() {
    var text by remember { mutableStateOf(NeedleSettings.fanartKey.value) }
    Row(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        BasicTextField(
            value = text,
            onValueChange = { text = it.trim(); NeedleSettings.setFanartKey(text) },
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Palette.Accent),
            modifier = Modifier.fillMaxWidth(),
            decorationBox = { inner ->
                Box {
                    if (text.isEmpty()) Text("Fanart.tv API key", color = Palette.Muted, fontSize = 15.sp)
                    inner()
                }
            }
        )
    }
}

// ---- now playing ------------------------------------------------------------------------

@Composable
private fun NowPlayingContent() {
    Label("Background")
    SettingRow(
        "Glow follows the song",
        note = "The moving glow on Now playing takes its colors from the cover of the song that is playing. It needs Moving background to be on (Settings > Customization > Colors & themes). The cards under the player follow it too, unless you gave them a color."
    ) { NeedleSwitch(NeedleSettings.adaptiveNowPlayingGlow.value) { NeedleSettings.setAdaptiveNowPlayingGlow(it) } }

    Spacer(Modifier.height(10.dp))
    Label("Taps on the player")
    ActionPicker("Tap the song title", NeedleSettings.gestureTitle.intValue) { NeedleSettings.setGestureTitle(it) }
    ActionPicker("Tap the artist name", NeedleSettings.gestureArtist.intValue) { NeedleSettings.setGestureArtist(it) }
    ActionPicker("Tap the name of the queue at the top", NeedleSettings.gestureHeader.intValue) { NeedleSettings.setGestureHeader(it) }

    Spacer(Modifier.height(10.dp))
    Label("Info cards")
    OptionPills(listOf("Same as cards", "Custom"), if (NeedleSettings.npCardCustom.value) 1 else 0) { NeedleSettings.setNpCardCustom(it == 1) }
    if (NeedleSettings.npCardCustom.value) {
        Note("Pick any color for About the artist, Credits, File details and From your library. Light colors can make the white text hard to read.")
        CardColorPicker(NeedleSettings.npCardArgb.intValue) { NeedleSettings.setNpCardArgb(it) }
    } else {
        Note("These cards follow the Cards setting in Customization > Colors & themes. Choose Custom to give them a color of their own.")
    }
}

/** A card listing what a tap can do, with a dot on the chosen one. */
@Composable
private fun ActionPicker(title: String, selected: Int, onSelect: (Int) -> Unit) {
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(RoundedCornerShape(20.dp)).padding(vertical = 8.dp)) {
        Text(title, color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(horizontal = 16.dp, vertical = 6.dp))
        NowPlayingAction.values().forEach { action ->
            Row(
                Modifier.fillMaxWidth().clickable { onSelect(action.ordinal) }.padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(actionLabel(action), color = Palette.Text, fontSize = 15.sp, modifier = Modifier.weight(1f))
                if (action.ordinal == selected) Box(Modifier.size(10.dp).clip(CircleShape).background(Palette.Accent))
            }
        }
    }
}

/** RGB sliders plus opacity for the card color, with a live preview. */
@Composable
private fun CardColorPicker(argb: Int, onChange: (Int) -> Unit) {
    val a = (argb ushr 24) and 0xFF
    val r = (argb shr 16) and 0xFF
    val g = (argb shr 8) and 0xFF
    val b = argb and 0xFF
    fun set(na: Int, nr: Int, ng: Int, nb: Int) = onChange((na shl 24) or (nr shl 16) or (ng shl 8) or nb)
    val shape = RoundedCornerShape(20.dp)
    Column(Modifier.fillMaxWidth().padding(vertical = 6.dp).glass(shape).padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            val swatch = RoundedCornerShape(16.dp)
            Box(
                Modifier.size(56.dp).clip(swatch).background(Palette.Bg).background(Color(argb))
                    .border(1.dp, Color.White.copy(alpha = 0.2f), swatch)
            )
            Column(Modifier.padding(start = 14.dp)) {
                Text("#%02X%02X%02X".format(r, g, b), color = Palette.Text, fontSize = 17.sp, fontWeight = FontWeight.SemiBold)
                Text("Opacity ${(a * 100f / 255f).roundToInt()}%", color = Palette.Muted, fontSize = 12.sp)
            }
        }
        Spacer(Modifier.height(8.dp))
        ChannelSlider("Red", r, 0, Color(0xFFEB5757)) { set(a, it, g, b) }
        ChannelSlider("Green", g, 0, Color(0xFF6FCF97)) { set(a, r, it, b) }
        ChannelSlider("Blue", b, 0, Color(0xFF5B8DEF)) { set(a, r, g, it) }
        ChannelSlider("Opacity", a, 40, Color.White) { set(it, r, g, b) }
    }
}

@Composable
private fun ChannelSlider(label: String, value: Int, min: Int, color: Color, onValue: (Int) -> Unit) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Palette.Text, fontSize = 14.sp, modifier = Modifier.width(64.dp))
        Slider(
            value = value.toFloat(),
            onValueChange = { onValue(it.roundToInt()) },
            valueRange = min.toFloat()..255f,
            modifier = Modifier.weight(1f),
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = color,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
        Text("$value", color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.width(36.dp), textAlign = androidx.compose.ui.text.style.TextAlign.End)
    }
}

// ---- playback ----------------------------------------------------------------------------

@Composable
private fun PlaybackContent() {
    SettingRow("Gapless playback", note = "Songs follow each other with no gap. This is always on.") {
        Text("On", color = Palette.Muted, fontSize = 14.sp)
    }
    SettingRow("Skip silence", note = "Skips the silent stretches at the start and end of songs.") {
        NeedleSwitch(NeedleSettings.skipSilence.value) { NeedleSettings.setSkipSilence(it) }
    }
    SettingRow("Pause when headphones disconnect", note = "Stops the music when wired or Bluetooth headphones are unplugged or switch off.") {
        NeedleSwitch(NeedleSettings.pauseOnUnplug.value) { NeedleSettings.setPauseOnUnplug(it) }
    }

    Spacer(Modifier.height(10.dp))
    Label("A song counts as played after")
    OptionPills(CountAfter.entries.map { it.label }, NeedleSettings.countAfter.value.ordinal) {
        NeedleSettings.setCountAfter(CountAfter.entries[it])
    }
    Note("This feeds Popular, Most played and This week. Short songs always count at half their length. Skipping through a list counts nothing.")

    Spacer(Modifier.height(10.dp))
    Label("Volume levelling")
    SettingRow("Volume levelling", note = "Makes quiet and loud songs about equally loud. Also in the equalizer as Loudness normalization.") {
        NeedleSwitch(NeedleSettings.volumeLevelling.value) { NeedleSettings.setVolumeLevelling(it) }
    }
    Note("Songs with a ReplayGain tag are levelled right away. For the others Needle learns how loud a song is while you listen, so each song is levelled from its second play on. It works on this phone's playback, not on a cast device.")

    Spacer(Modifier.height(10.dp))
    Label("Crossfade")
    val fadeChoices = listOf(0, 2, 4, 6, 8, 12)
    OptionPills(fadeChoices.map { if (it == 0) "Off" else "$it s" }, fadeChoices.indexOf(NeedleSettings.crossfadeSec.intValue).coerceAtLeast(0)) {
        NeedleSettings.setCrossfadeSec(fadeChoices[it])
    }
    Note("The end of a song fades out and the next one fades in, over the time you choose. The songs do not overlap. Songs you pick by hand start at full volume.")
}

// ---- ratings -----------------------------------------------------------------------------

@Composable
private fun RatingsContent() {
    val style = NeedleSettings.ratingStyle.value
    Label("How you rate")
    OptionPills(RatingStyle.entries.map { it.label }, style.ordinal) { NeedleSettings.setRatingStyle(RatingStyle.entries[it]) }
    Note(
        when (style) {
            RatingStyle.STARS -> "Tap one to five stars. Tap the same star again to take the rating back."
            RatingStyle.DECIMAL -> "Slide from 1.00 to 5.00 in steps of a quarter, like 3.75 or 4.25, for the fine differences."
            RatingStyle.TEN -> "Pick a number from 1 to 10."
        }
    )

    Spacer(Modifier.height(10.dp))
    Label("The same rating, three ways")
    listOf(RatingStyle.STARS, RatingStyle.DECIMAL, RatingStyle.TEN).forEach { s ->
        SettingRow(s.label, note = null) {
            Text(RatingScale.label(s, 80), color = if (s == style) Palette.Accent else Palette.Muted, fontSize = 14.sp, fontWeight = FontWeight.Medium)
        }
    }
    Note("Switching never loses a rating. A song rated 4.25 shows as 4 stars in 5 stars, and as 8.5 in 1 to 10.")

    Spacer(Modifier.height(10.dp))
    Label("Where ratings count")
    Note("Songs: sort by Rating, best first. Artist pages: Top songs start with your best rated. Playlists: the Top rated chip. Songs list: a star and the rating next to the album.")
    Note("To rate a song, press and hold the star on Now Playing, or use Rate song in Player controls or in a song's menu.")
}

// ---- library -----------------------------------------------------------------------------

@Composable
private fun LibraryContent(
    songCount: Int,
    isScanning: Boolean,
    onRescan: () -> Unit,
    tagsRead: Int,
    tagProgress: Pair<Int, Int>?,
    onRereadTags: () -> Unit,
    onChooseGenres: () -> Unit,
    hiddenCount: Int,
    onOpenHidden: () -> Unit,
    folderGroups: List<FolderGroup>,
    excludedFolders: Set<String>,
    onToggleFolder: (String) -> Unit
) {
    val favorites by GenrePrefs.selected.collectAsState()
    SettingRow(
        "Favourite genres",
        note = if (favorites.isEmpty()) "None chosen. Chosen genres come first on Home."
        else favorites.sortedBy { it.lowercase() }.joinToString(", "),
        onClick = onChooseGenres
    ) { Text("Choose", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }
    Spacer(Modifier.height(10.dp))
    SettingRow(
        "Songs in your library",
        note = if (isScanning) "Looking for music..." else "$songCount songs. Tap to look for new music now.",
        onClick = if (isScanning) null else onRescan
    ) {
        Text(if (isScanning) "" else "Rescan", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    SettingRow(
        "Hidden songs",
        note = if (hiddenCount == 0) "None. Press and hold a song and choose Hide from library."
        else "$hiddenCount hidden from every list and search.",
        onClick = onOpenHidden
    ) { Text(if (hiddenCount == 0) "" else "Manage", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }

    if (folderGroups.size > 1) {
        Spacer(Modifier.height(10.dp))
        Label("Folders")
        FolderSwitches(folderGroups, excludedFolders, onToggleFolder)
        Note("A folder that is switched off is left out of every list and search. The files stay on your phone.")
    }
    SettingRow(
        "Scan when Needle opens",
        note = "Looks for new music every time. Off starts faster; use Rescan when you add songs."
    ) { NeedleSwitch(NeedleSettings.scanOnLaunch.value) { NeedleSettings.setScanOnLaunch(it) } }

    Spacer(Modifier.height(10.dp))
    Label("Ignore songs shorter than")
    val lengths = listOf(0, 10, 30, 60)
    OptionPills(listOf("Off", "10 s", "30 s", "1 min"), lengths.indexOf(NeedleSettings.minSongSeconds.intValue).coerceAtLeast(0)) {
        NeedleSettings.setMinSongSeconds(lengths[it])
    }
    Note("Hides voice notes, ringtones and sound effects. It applies on the next scan: tap Rescan above.")

    Spacer(Modifier.height(10.dp))
    Label("What a disc is called")
    val discWord = AlbumPrefs.discWord.value
    val discLetters = AlbumPrefs.discLetters.value
    val presets = listOf("Disc", "Side", "Part", "Volume")
    OptionPills(presets, presets.indexOf(discWord)) { AlbumPrefs.setDiscWord(presets[it]) }
    Box(
        Modifier.fillMaxWidth().padding(vertical = 4.dp).clip(RoundedCornerShape(16.dp))
            .background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        BasicTextField(
            value = discWord,
            onValueChange = { AlbumPrefs.setDiscWord(it.take(20)) },
            singleLine = true,
            textStyle = TextStyle(color = Palette.Text, fontSize = 15.sp),
            cursorBrush = SolidColor(Color.White),
            modifier = Modifier.fillMaxWidth()
        )
        if (discWord.isEmpty()) Text("Type your own name, for example Act", color = Palette.Muted, fontSize = 15.sp)
    }
    SettingRow(
        "Use letters",
        note = "A, B, C instead of 1, 2, 3. Good for records: Side A, Side B."
    ) { NeedleSwitch(discLetters) { AlbumPrefs.setDiscLetters(it) } }
    Note(
        "Album pages group the tracks by the Disc tag and show: " +
            "${discLabel(1, discWord, discLetters)}, ${discLabel(2, discWord, discLetters)}, ${discLabel(3, discWord, discLetters)}. " +
            "On an album page, the record button next to the tag button sets them."
    )

    Spacer(Modifier.height(10.dp))
    Label("Tags in your files")
    SettingRow(
        "Read tags from files",
        note = if (tagProgress != null) "Reading ${tagProgress.first} of ${tagProgress.second} songs..."
        else "Needle reads composer, comment, lyrics and the other tags inside each file once. " +
            "$tagsRead of $songCount songs read. Tap to read them all again, for example after changing files on a computer.",
        onClick = if (tagProgress == null) onRereadTags else null
    ) {
        Text(if (tagProgress == null) "Re-read" else "", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- tags and covers ---------------------------------------------------------------------

private enum class Reset { EDITS, COVERS }

@Composable
private fun TagsContent(
    vm: SettingsViewModel,
    writeToFiles: Boolean,
    onWriteToFilesChange: (Boolean) -> Unit,
    writeProgress: Pair<Int, Int>?,
    onWriteAll: () -> Unit
) {
    val edits by vm.editCount.collectAsState()
    val extras by vm.extraCount.collectAsState()
    var confirm by remember { mutableStateOf<Reset?>(null) }

    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$edits", "edited songs", Modifier.weight(1f))
        CountTile("$extras", "extra fields", Modifier.weight(1f))
        CountTile("${vm.coverCount}", "custom covers", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))

    SettingRow(
        "Write tags into the files",
        note = "When you save in the tag editor, Needle also writes the tags (and the cover) into the audio file, so " +
            "other players like Symfonium and programs like Mp3tag see them. MP3, FLAC and M4A. Every file is " +
            "checked before it is replaced and a backup is kept while it happens. Needs \"All files access\"."
    ) { NeedleSwitch(writeToFiles, onWriteToFilesChange) }
    SettingRow(
        "Write all edits to the files now",
        note = if (writeProgress != null) "Writing ${writeProgress.first} of ${writeProgress.second} files..."
        else "Writes every tag and cover you have edited in Needle into its file, for songs edited before this was turned on.",
        onClick = if (writeProgress == null) onWriteAll else null
    ) {
        Text(if (writeProgress == null) "Write" else "", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }

    Spacer(Modifier.height(10.dp))
    Label("Reset")
    SettingRow("Reset all tag edits", note = "Removes every tag and extra field you changed inside Needle.", onClick = { confirm = Reset.EDITS }) {
        Text("Reset", color = Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    SettingRow("Remove custom covers", note = "Songs go back to the cover inside their file.", onClick = { confirm = Reset.COVERS }) {
        Text("Remove", color = Danger, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
    }
    Note("Resets only change what Needle shows. Files that tags were already written into keep them.")
    vm.message?.let { MessageCard(it) { vm.clearMessage() } }

    confirm?.let { kind ->
        AlertDialog(
            onDismissRequest = { confirm = null },
            title = { Text(if (kind == Reset.EDITS) "Reset all tag edits?" else "Remove custom covers?") },
            text = {
                Text(
                    if (kind == Reset.EDITS) "$edits edited songs and $extras extra fields will go back to what is in the files."
                    else "${vm.coverCount} custom covers will be removed."
                )
            },
            confirmButton = {
                TextButton(onClick = {
                    if (kind == Reset.EDITS) vm.resetEdits() else vm.resetCovers()
                    confirm = null
                }) { Text(if (kind == Reset.EDITS) "Reset" else "Remove", color = Danger) }
            },
            dismissButton = { TextButton(onClick = { confirm = null }) { Text("Cancel", color = Palette.Text) } },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted
        )
    }
}

@Composable
private fun MessageCard(text: String, onDismiss: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().padding(top = 8.dp).glass(RoundedCornerShape(18.dp)).clickable(onClick = onDismiss).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(text, color = Palette.Text, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.weight(1f))
        Spacer(Modifier.width(10.dp))
        Text("OK", color = Palette.Accent, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

// ---- backup ------------------------------------------------------------------------------

@Composable
private fun BackupContent(vm: SettingsViewModel, glowOn: Boolean, onGlowChange: (Boolean) -> Unit) {
    val plays by vm.playCount.collectAsState()
    val edits by vm.editCount.collectAsState()
    val extras by vm.extraCount.collectAsState()
    val notes by vm.noteCount.collectAsState()

    val exportLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) vm.exportTo(uri, glowOn)
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.restoreFrom(uri) { onGlowChange(it) }
    }

    Text(
        "One file with what Needle can't rebuild by scanning: your play history, the tags you edited, extra fields, " +
            "artist notes and these settings. Covers you picked are not included. Songs are matched by their id on this phone, " +
            "so a backup restores on this phone with the same music.",
        color = Palette.Muted, fontSize = 13.sp, lineHeight = 18.sp, modifier = Modifier.padding(horizontal = 4.dp)
    )
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$plays", "plays", Modifier.weight(1f))
        CountTile("$edits", "edited songs", Modifier.weight(1f))
        CountTile("$extras", "extra fields", Modifier.weight(1f))
        CountTile("$notes", "notes", Modifier.weight(1f))
    }
    Spacer(Modifier.height(18.dp))
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        PillButton("Export backup", onClick = {
            exportLauncher.launch("needle-backup-" + SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) + ".json")
        }, filled = true)
        PillButton("Restore from file", onClick = { restoreLauncher.launch(arrayOf("application/json", "text/plain", "*/*")) })
    }
    Note("Restoring adds to what is here: plays are never counted twice, and edits and notes in the file replace the ones on the phone.")
    vm.message?.let { MessageCard(it) { vm.clearMessage() } }
}

// ---- about -------------------------------------------------------------------------------

@Composable
private fun AboutContent(vm: SettingsViewModel, songCount: Int) {
    val plays by vm.playCount.collectAsState()
    val version = appVersion()
    Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(22.dp)).padding(18.dp)) {
        Text("Needle", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp)
        Text("Version $version", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(12.dp))
        Text(
            "No account, no ads, no uploads. Your music, play history and edits live on this phone.",
            color = Palette.Text, fontSize = 14.sp, lineHeight = 20.sp
        )
    }
    Spacer(Modifier.height(14.dp))
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        CountTile("$songCount", "songs", Modifier.weight(1f))
        CountTile("$plays", "plays recorded", Modifier.weight(1f))
    }
    Spacer(Modifier.height(14.dp))
    Label("Built with")
    Note("Media3 (the player), Room (the library database), Jetpack Compose (everything you see), and LRCLIB for optional lyrics lookups.")
}
