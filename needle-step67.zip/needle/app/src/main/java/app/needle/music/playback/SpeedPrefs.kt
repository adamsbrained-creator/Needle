package app.needle.music.playback

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import kotlin.math.pow

/**
 * Speed and pitch, as the Speed & pitch dialog sets them: a speed (0.5x to 2x) and a pitch in semitones (-6 to +6).
 * One setting is for everything; a song can also have its own ("Remember for this song"), which wins for that song.
 * Remembered between runs.
 */
object SpeedPrefs {
    class Setting(val speed: Float, val semitones: Int) {
        val isNormal: Boolean get() = speed == 1f && semitones == 0
    }

    val NORMAL = Setting(1f, 0)

    /** The setting for songs that have none of their own. */
    val global = mutableStateOf(NORMAL)

    /** On: changing the speed does not change the pitch (the pitch is only what the semitones say). Off: like a tape. */
    val keepPitch = mutableStateOf(true)

    private val perSong = HashMap<Long, Setting>()
    private var prefs: SharedPreferences? = null

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        parse(p.getString("speed_global", null))?.let { global.value = it.second }
        keepPitch.value = p.getBoolean("speed_keep_pitch", true)
        perSong.clear()
        p.getString("speed_songs", "").orEmpty().lines().forEach { line ->
            parse(line)?.let { (id, s) -> if (id != null) perSong[id] = s }
        }
    }

    /** "id,speed,semitones" or "speed,semitones" (id is null then). */
    private fun parse(text: String?): Pair<Long?, Setting>? {
        val parts = text?.split(',') ?: return null
        return try {
            when (parts.size) {
                2 -> null to Setting(parts[0].toFloat().coerceIn(0.5f, 2f), parts[1].toInt().coerceIn(-6, 6))
                3 -> parts[0].toLong() to Setting(parts[1].toFloat().coerceIn(0.5f, 2f), parts[2].toInt().coerceIn(-6, 6))
                else -> null
            }
        } catch (_: NumberFormatException) {
            null
        }
    }

    fun settingFor(songId: Long?): Setting = songId?.let { perSong[it] } ?: global.value

    fun hasSong(songId: Long): Boolean = perSong.containsKey(songId)

    fun setGlobal(s: Setting) {
        global.value = s
        prefs?.edit()?.putString("speed_global", "${s.speed},${s.semitones}")?.apply()
    }

    fun setKeepPitch(on: Boolean) {
        keepPitch.value = on
        prefs?.edit()?.putBoolean("speed_keep_pitch", on)?.apply()
    }

    fun setSong(songId: Long, s: Setting) {
        perSong[songId] = s
        saveSongs()
    }

    fun clearSong(songId: Long) {
        if (perSong.remove(songId) != null) saveSongs()
    }

    private fun saveSongs() {
        prefs?.edit()?.putString("speed_songs", perSong.entries.joinToString("\n") { "${it.key},${it.value.speed},${it.value.semitones}" })?.apply()
    }

    /**
     * What the player is given: (speed, pitch). The player's pitch is a multiplier on top of the speed's own
     * time-stretching, so with "keep pitch" it is just the semitones; without it, the pitch also follows the speed.
     */
    fun toParams(s: Setting, keepPitch: Boolean): Pair<Float, Float> {
        val semis = 2.0.pow(s.semitones / 12.0).toFloat()
        return s.speed to (if (keepPitch) semis else s.speed * semis)
    }
}
