package app.needle.music.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AccentChoices
import app.needle.music.data.FolderGroup
import app.needle.music.data.NeedleSettings

/**
 * The first-launch screens from the mockup: Welcome (pick an accent), "Let Needle find your music" (the permission),
 * and "Scanning your library". Plus the empty library state.
 */

/** Welcome: the logo, one line about Needle, and a row of accent colors that repaint the screen as you tap them. */
@Composable
fun WelcomeScreen(onStart: () -> Unit, modifier: Modifier = Modifier) {
    Column(
        modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier
                .size(88.dp)
                .clip(RoundedCornerShape(28.dp))
                .background(Brush.linearGradient(listOf(Palette.Accent, Palette.Pink))),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(NeedleIcon.SONGS, Color.White, size = 40.dp) }
        Spacer(Modifier.height(22.dp))
        Text("Needle", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 46.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            "Your music, on your phone, looking the way you want.",
            color = Palette.Muted, fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(30.dp))
        val chosen = NeedleSettings.accentIndex.intValue
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            AccentChoices.forEachIndexed { i, choice ->
                Box(
                    Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(choice.color)
                        .then(if (i == chosen) Modifier.border(2.5.dp, Color.White, CircleShape) else Modifier)
                        .clickable { NeedleSettings.setAccent(i) }
                )
            }
        }
        Spacer(Modifier.height(12.dp))
        Text("Pick an accent. You can change everything later.", color = Palette.Muted, fontSize = 12.5.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(34.dp))
        PillButton("Get started", onStart, filled = true)
    }
}

/**
 * "Let Needle find your music": why the permission is needed, a switch for the playback notification (asked for
 * together with the music permission on Android 13 and newer), Allow, and Not now (Needle opens empty; the Songs
 * page offers the permission again).
 */
@Composable
fun PermissionScreen(
    notifications: Boolean,
    onNotificationsChange: (Boolean) -> Unit,
    onAllow: () -> Unit,
    onNotNow: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    Column(
        modifier.fillMaxSize().padding(horizontal = 28.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(76.dp).clip(CircleShape).background(Palette.Accent.copy(alpha = 0.22f)),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(NeedleIcon.SONGS, Palette.Accent, size = 34.dp) }
        Spacer(Modifier.height(20.dp))
        Text(
            "Let Needle find your music", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp,
            textAlign = TextAlign.Center, lineHeight = 34.sp
        )
        Spacer(Modifier.height(10.dp))
        Text(
            "Needle needs to read the audio files on this phone. Nothing is uploaded or shared.",
            color = Palette.Muted, fontSize = 15.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        Row(
            Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f).padding(end = 12.dp)) {
                Text("Playback controls", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Text("Notification with play, pause and skip", color = Palette.Muted, fontSize = 12.5.sp)
            }
            NeedleSwitch(notifications, onNotificationsChange)
        }
        Spacer(Modifier.height(26.dp))
        PillButton("Allow access to music", onAllow, filled = true)
        Spacer(Modifier.height(10.dp))
        PillButton("Not now", onNotNow)
        Spacer(Modifier.height(18.dp))
        Text(
            "If the permission box does not appear, turn on \"Music and audio\" in the app's settings.",
            color = Palette.Muted, fontSize = 12.5.sp, textAlign = TextAlign.Center
        )
        Text(
            "Open app settings", color = Palette.Accent, fontSize = 13.5.sp, fontWeight = FontWeight.Medium,
            modifier = Modifier.clip(CircleShape).clickable {
                context.startActivity(
                    Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
                )
            }.padding(horizontal = 12.dp, vertical = 8.dp)
        )
    }
}

/**
 * "Scanning your library": a ring that fills while Needle reads the tags of your songs, what it found so far, the
 * folders with a switch each (a folder switched off is left out of every list), and Continue in background.
 * [done] / [total] are null while Needle is still listing the files.
 */
@Composable
fun ScanScreen(
    songs: Int,
    albums: Int,
    artists: Int,
    done: Int?,
    total: Int?,
    groups: List<FolderGroup>,
    excluded: Set<String>,
    onToggleFolder: (String) -> Unit,
    onContinue: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxSize().padding(horizontal = 28.dp, vertical = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(Modifier.weight(0.4f))
        ProgressRing(
            fraction = if (done != null && total != null && total > 0) done.toFloat() / total else null,
            percentText = if (done != null && total != null && total > 0) "${(done * 100L / total).toInt()}%" else "…",
            caption = if (done != null && total != null && total > 0) "${"%,d".format(done)} of ${"%,d".format(total)} songs"
            else if (songs > 0) "${"%,d".format(songs)} songs" else "Looking for music"
        )
        Spacer(Modifier.height(22.dp))
        Text("Scanning your library", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 28.sp, textAlign = TextAlign.Center)
        Spacer(Modifier.height(6.dp))
        Text(
            "Found ${"%,d".format(albums)} ${if (albums == 1) "album" else "albums"} and ${"%,d".format(artists)} ${if (artists == 1) "artist" else "artists"} so far.",
            color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(18.dp))
        Column(Modifier.weight(1f, fill = false).heightIn(max = 280.dp).verticalScroll(rememberScrollState())) {
            FolderSwitches(groups, excluded, onToggleFolder)
        }
        Spacer(Modifier.weight(0.6f))
        PillButton("Continue in background", onContinue, filled = true)
    }
}

@Composable
private fun ProgressRing(fraction: Float?, percentText: String, caption: String) {
    val track = Color.White.copy(alpha = 0.12f)
    val accent = Palette.Accent
    val spin by rememberInfiniteTransition(label = "scan").animateFloat(
        initialValue = 0f, targetValue = 360f,
        animationSpec = infiniteRepeatable(tween(1400, easing = LinearEasing), RepeatMode.Restart), label = "spin"
    )
    Box(Modifier.size(170.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val stroke = Stroke(width = 12.dp.toPx(), cap = StrokeCap.Round)
            val inset = stroke.width / 2
            val arcSize = Size(size.width - stroke.width, size.height - stroke.width)
            drawArc(track, 0f, 360f, false, Offset(inset, inset), arcSize, style = stroke)
            if (fraction != null) drawArc(accent, -90f, 360f * fraction.coerceIn(0f, 1f), false, Offset(inset, inset), arcSize, style = stroke)
            else drawArc(accent, spin - 90f, 90f, false, Offset(inset, inset), arcSize, style = stroke)
        }
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(percentText, color = Palette.Text, fontSize = 34.sp, fontWeight = FontWeight.SemiBold)
            Text(caption, color = Palette.Muted, fontSize = 11.5.sp, textAlign = TextAlign.Center, modifier = Modifier.padding(horizontal = 18.dp))
        }
    }
}

/** One switch per folder. Nothing is shown when there is just one folder (older phones give no folders at all). */
@Composable
fun FolderSwitches(groups: List<FolderGroup>, excluded: Set<String>, onToggle: (String) -> Unit) {
    if (groups.size < 2) return
    groups.forEach { g ->
        val on = g.name !in excluded
        Row(
            Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp)
                .glass(RoundedCornerShape(18.dp))
                .clickable { onToggle(g.name) }
                .padding(horizontal = 16.dp, vertical = 9.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(g.name, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium, maxLines = 1, modifier = Modifier.weight(1f))
            Text("${"%,d".format(g.songs)}", color = Palette.Muted, fontSize = 12.5.sp, modifier = Modifier.padding(end = 12.dp))
            NeedleSwitch(on) { onToggle(g.name) }
        }
    }
}

/** "No music yet": what to do about it. Without the permission the first button asks for it. */
@Composable
fun EmptyLibrary(
    hasPermission: Boolean,
    onAllow: () -> Unit,
    onChooseFolders: () -> Unit,
    onScanAgain: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier.fillMaxSize().padding(horizontal = 32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Box(
            Modifier.size(96.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.08f)),
            contentAlignment = Alignment.Center
        ) {
            Box(Modifier.size(30.dp).clip(CircleShape).background(Palette.Accent.copy(alpha = 0.8f)))
        }
        Spacer(Modifier.height(20.dp))
        Text("No music yet", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 28.sp)
        Spacer(Modifier.height(8.dp))
        Text(
            if (hasPermission) "Add songs to your Music folder, or choose which folders Needle should scan."
            else "Needle needs permission to read the audio files on this phone. Nothing is uploaded or shared.",
            color = Palette.Muted, fontSize = 15.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(24.dp))
        if (hasPermission) {
            PillButton("Choose folders", onChooseFolders, filled = true)
            Spacer(Modifier.height(10.dp))
            PillButton("Scan again", onScanAgain)
        } else {
            PillButton("Allow access to music", onAllow, filled = true)
        }
    }
}
