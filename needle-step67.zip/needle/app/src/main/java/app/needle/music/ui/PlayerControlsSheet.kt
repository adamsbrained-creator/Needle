package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

/**
 * One tile of the Player controls sheet. [sub] is the small line under the label ("1.0x", "This phone" ...).
 * [enabled] = false dims it (the thing it does is not possible for this song).
 */
class ControlTile(
    val icon: NeedleIcon,
    val label: String,
    val sub: String? = null,
    val enabled: Boolean = true,
    /** Lit in the accent color (a switch that is on, a song that is a favorite). */
    val active: Boolean = false,
    /** Red, for something that cannot be undone (Delete file). */
    val danger: Boolean = false,
    val onClick: () -> Unit
)

/** A titled group of tiles on the Player controls sheet ("Playback", "Song", "Go to" ...). */
class ControlSection(val title: String, val tiles: List<ControlTile>)

private val DangerColor = Color(0xFFEB5757)

/**
 * The "Player controls" sheet: every action for the song that is playing, in titled groups.
 * Tiles for features that are not built yet are placeholders (they show a "coming soon" note when tapped).
 */
@Composable
fun PlayerControlsSheet(sections: List<ControlSection>, modifier: Modifier = Modifier) {
    val maxHeight = (LocalConfiguration.current.screenHeightDp * 0.9f).dp
    Column(
        modifier
            .fillMaxWidth()
            .heightIn(max = maxHeight)
            .clip(RoundedCornerShape(topStart = 32.dp, topEnd = 32.dp))
            .background(Brush.linearGradient(listOf(Color(0xF53C3256), Color(0xFA202024)), start = Offset(0f, 0f), end = Offset(1400f, 2400f)))
            .padding(start = 14.dp, end = 14.dp, top = 10.dp)
    ) {
        Box(
            Modifier.align(Alignment.CenterHorizontally).width(44.dp).height(5.dp)
                .clip(CircleShape).background(Color.White.copy(alpha = 0.4f))
        )
        Text(
            "Player controls", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 30.sp,
            modifier = Modifier.padding(start = 4.dp, top = 14.dp)
        )
        // The groups together are taller than a screen, so the sheet scrolls.
        Column(
            Modifier.verticalScroll(rememberScrollState()).navigationBarsPadding().padding(top = 4.dp, bottom = 16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            sections.forEach { section ->
                Text(
                    section.title.uppercase(), color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.SemiBold,
                    letterSpacing = 1.2.sp, modifier = Modifier.padding(start = 6.dp, top = 12.dp, bottom = 2.dp)
                )
                section.tiles.chunked(2).forEach { row ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        row.forEach { tile -> ControlTileView(tile, Modifier.weight(1f)) }
                        if (row.size == 1) Spacer(Modifier.weight(1f))
                    }
                }
            }
        }
    }
}

@Composable
private fun ControlTileView(tile: ControlTile, modifier: Modifier) {
    val shape = RoundedCornerShape(20.dp)
    // Accent = on, red = cannot be undone, otherwise the plain glass tile
    val tint = when {
        tile.danger -> DangerColor
        tile.active -> Palette.Accent
        else -> Palette.Text
    }
    val fill = if (tile.active || tile.danger) tint.copy(alpha = 0.14f) else Color.White.copy(alpha = 0.07f)
    val edge = if (tile.active || tile.danger) tint.copy(alpha = 0.45f) else Color.White.copy(alpha = 0.08f)
    Column(
        modifier
            .alpha(if (tile.enabled) 1f else 0.45f)
            .height(78.dp)
            .clip(shape)
            .background(fill)
            .border(1.dp, edge, shape)
            .clickable(onClick = tile.onClick)
            .padding(12.dp),
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Box(Modifier.size(30.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f)), contentAlignment = Alignment.Center) {
            NeedleIconView(tile.icon, tint, size = 16.dp)
        }
        Column {
            Text(tile.label, color = if (tile.danger) DangerColor else Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            if (tile.sub != null) {
                Text(tile.sub, color = Palette.Muted, fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

/** "1.0x", "1.25x", "1.5x" */
fun speedText(v: Float): String {
    val t = "%.2f".format(v).trimEnd('0')
    return (if (t.endsWith(".")) t + "0" else t) + "x"
}

/** "1.0x" or, with a pitch change, "1.25x · +2 st". */
fun speedSummary(speed: Float, semitones: Int): String =
    if (semitones == 0) speedText(speed) else "${speedText(speed)} \u00B7 ${semitoneText(semitones)}"

/** "0 st", "+2 st", "-3 st" */
fun semitoneText(st: Int): String = (if (st > 0) "+$st" else "$st") + " st"

/**
 * Speed & pitch of this phone's player (mockup "Speed and pitch"): speed 0.5x to 2x with quick chips, pitch in
 * semitones from -6 to +6, "Keep pitch when changing speed", and "Remember for this song". Everything applies live.
 */
@Composable
fun SpeedPitchDialog(
    speed: Float,
    semitones: Int,
    keepPitch: Boolean,
    remembered: Boolean,
    onChange: (speed: Float, semitones: Int, keepPitch: Boolean, remember: Boolean) -> Unit,
    onDismiss: () -> Unit
) {
    var s by remember { mutableFloatStateOf(speed) }
    var st by remember { mutableIntStateOf(semitones) }
    var keep by remember { mutableStateOf(keepPitch) }
    var own by remember { mutableStateOf(remembered) }
    fun snap(v: Float) = (v * 20f).roundToInt() / 20f
    fun push() = onChange(s, st, keep, own)

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Palette.Surface,
        titleContentColor = Palette.Text,
        title = { Text("Speed & pitch") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Applies to the current song, or to everything.", color = Palette.Muted, fontSize = 12.5.sp)
                Spacer(Modifier.height(12.dp))
                SliderRow("Speed", speedText(s), s, 0.5f..2f, 29, "0.5x", "1.0x", "2.0x") { s = snap(it); push() }
                Row(Modifier.fillMaxWidth().padding(top = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(0.75f, 1f, 1.25f, 1.5f).forEach { v ->
                        val on = kotlin.math.abs(s - v) < 0.001f
                        Text(
                            speedText(v), color = if (on) Color(0xFF111111) else Palette.Text, fontSize = 13.sp,
                            fontWeight = if (on) FontWeight.SemiBold else FontWeight.Normal,
                            modifier = Modifier
                                .weight(1f)
                                .clip(CircleShape)
                                .background(if (on) Color.White else Color.White.copy(alpha = 0.1f))
                                .clickable { s = v; push() }
                                .padding(vertical = 9.dp),
                            textAlign = androidx.compose.ui.text.style.TextAlign.Center
                        )
                    }
                }
                Spacer(Modifier.height(16.dp))
                SliderRow("Pitch", semitoneText(st), st.toFloat(), -6f..6f, 11, "-6", "0", "+6") { st = it.roundToInt(); push() }
                Text("Semitones", color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp))
                Spacer(Modifier.height(12.dp))
                SwitchLine("Keep pitch when changing speed", keep) { keep = it; push() }
                SwitchLine("Remember for this song", own) { own = it; push() }
            }
        },
        confirmButton = { TextButton(onClick = onDismiss) { Text("Done", color = Palette.Accent) } },
        dismissButton = {
            TextButton(onClick = { s = 1f; st = 0; push() }) { Text("Reset to normal", color = Palette.Muted) }
        }
    )
}

@Composable
private fun SwitchLine(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Palette.Text, fontSize = 14.5.sp, modifier = Modifier.weight(1f).padding(end = 12.dp))
        NeedleSwitch(checked, onChange)
    }
}

@Composable
private fun SliderRow(
    label: String, value: String, current: Float, range: ClosedFloatingPointRange<Float>, steps: Int,
    low: String, mid: String, high: String, onChange: (Float) -> Unit
) {
    Column {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(label, color = Palette.Text, fontSize = 15.sp)
            Text(value, color = Palette.Muted, fontSize = 15.sp)
        }
        Slider(
            value = current.coerceIn(range.start, range.endInclusive),
            onValueChange = onChange,
            valueRange = range,
            steps = steps,
            colors = SliderDefaults.colors(
                thumbColor = Color.White,
                activeTrackColor = Palette.Accent,
                inactiveTrackColor = Color.White.copy(alpha = 0.2f),
                activeTickColor = Color.Transparent,
                inactiveTickColor = Color.Transparent
            )
        )
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(low, color = Palette.Muted, fontSize = 11.sp)
            Text(mid, color = Palette.Muted, fontSize = 11.sp)
            Text(high, color = Palette.Muted, fontSize = 11.sp)
        }
    }
}
