package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.ui.graphics.Color
import org.json.JSONObject

class AccentChoice(val name: String, val color: Color)

/** The accent colors on the Appearance page. The first one is the original violet. */
val AccentChoices = listOf(
    AccentChoice("Violet", Color(0xFFAF65F5)),
    AccentChoice("Pink", Color(0xFFEF42B8)),
    AccentChoice("Blue", Color(0xFF5B8DEF)),
    AccentChoice("Teal", Color(0xFF2DD4BF)),
    AccentChoice("Green", Color(0xFF6FCF97)),
    AccentChoice("Orange", Color(0xFFF2994A)),
    AccentChoice("Red", Color(0xFFEB5757))
)

/** When a song counts as "played" for Popular, Most played and This week. */
enum class CountAfter(val label: String, private val fixedMs: Long) {
    SEC10("10 s", 10_000L),
    SEC30("30 s", 30_000L),
    MIN1("1 min", 60_000L),
    HALF("Half the song", 0L);

    /** Short songs always count at half their length, so a 20 second song can still count. */
    fun thresholdMs(durationMs: Long): Long {
        val known = durationMs > 0L
        return when {
            this == HALF -> if (known) durationMs / 2 else 30_000L
            known -> minOf(fixedMs, durationMs / 2)
            else -> fixedMs
        }
    }
}

/**
 * Everything on the Settings pages, remembered between launches. Values are Compose state, so a page
 * that reads one redraws the moment it changes, and the playback service can watch them too.
 */
object NeedleSettings {
    private var prefs: SharedPreferences? = null

    // Appearance
    val accentIndex = mutableIntStateOf(0)
    val serifTitles = mutableStateOf(true)
    val amoled = mutableStateOf(false)
    /** The skin in use: the id of a [Skin] (Settings > Customization > Skins). */
    val skin = mutableStateOf("needle")
    /** The Now playing look: the id of a [NowPlayingStyle]. */
    val npStyle = mutableStateOf("follow")
    /** Cards: false = Auto (classic gray on a plain background, tinted by the accent on the glow), true = the color below. */
    val cardCustom = mutableStateOf(false)
    /** Cards as frosted glass: a soft white layer that lets the background show through. Never on together with [cardCustom]. */
    val cardGlass = mutableStateOf(false)
    /** Animated covers on Now playing (Apple Music looping cover videos). Off until the person turns it on. */
    val animatedCovers = mutableStateOf(false)
    /** true = only on Wi-Fi or Ethernet, false = also on mobile data. */
    val animatedCoversWifiOnly = mutableStateOf(true)
    /** Also play Apple Music's artist videos in the artist header (needs [animatedCovers] on). */
    val animatedArtistCovers = mutableStateOf(true)
    /** The moving glow on Now playing takes its colors from the playing song's cover. */
    val adaptiveNowPlayingGlow = mutableStateOf(false)
    /** The animated cover fills the whole Now playing page (like Spotify's Canvas) instead of only the cover. */
    val animatedFullPage = mutableStateOf(false)
    /** Ask a backup server (the public m8tec Apple Music covers server by default) when Apple's own lookup finds nothing. */
    val animatedBackupServer = mutableStateOf(false)
    val backupServerUrl = mutableStateOf("https://artwork.m8tec.top")
    /** Tidal video covers; the token is the person's own and is not part of backups. */
    val animatedTidal = mutableStateOf(false)
    val tidalToken = mutableStateOf("")
    /** What a tap does on Now playing: the number of a NowPlayingAction (0 nothing, 1 album, 2 artist, 3 queue source, 4 queue). */
    val gestureTitle = mutableIntStateOf(1)
    val gestureArtist = mutableIntStateOf(2)
    val gestureHeader = mutableIntStateOf(3)
    /** Look up covers online (iTunes, Deezer) for songs that have none. */
    val fetchMissingCovers = mutableStateOf(false)
    /** Artist background pictures from Fanart.tv, with the person's own API key (the key is not part of backups). */
    val artistBackgrounds = mutableStateOf(false)
    val fanartKey = mutableStateOf("")
    /** The custom card color as ARGB. The alpha part is the card opacity. */
    val cardArgb = mutableIntStateOf(0xB37B5A9A.toInt())
    /** The info cards on Now playing (About the artist, Credits, File details, From your library). false = same as the other cards. */
    val npCardCustom = mutableStateOf(false)
    val npCardArgb = mutableIntStateOf(0xB36B5A8AL.toInt())

    // Custom colors. 0 means "use the default".
    val customAccent = mutableIntStateOf(0xFFAF65F5.toInt())
    val bgColor = mutableIntStateOf(0)
    val glow1 = mutableIntStateOf(0)
    val glow2 = mutableIntStateOf(0)
    val glow3 = mutableIntStateOf(0)
    val glowStrength = mutableFloatStateOf(1f)

    // Playback
    val skipSilence = mutableStateOf(false)
    val pauseOnUnplug = mutableStateOf(true)
    /** Volume levelling (Loudness normalization in the equalizer): quiet and loud songs end up about equally loud. */
    val volumeLevelling = mutableStateOf(false)
    /** Crossfade in seconds, 0 = off. */
    val crossfadeSec = mutableIntStateOf(0)
    val countAfter = mutableStateOf(CountAfter.SEC30)

    // Ratings
    val ratingStyle = mutableStateOf(RatingStyle.STARS)

    /** Smart flow: when the queue runs low, similar songs from the library are added by themselves. */
    val smartFlow = mutableStateOf(false)

    // Library
    val scanOnLaunch = mutableStateOf(true)
    val minSongSeconds = mutableIntStateOf(0)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_settings", Context.MODE_PRIVATE)
        prefs = p
        ListSettings.init(context)
        accentIndex.intValue = p.getInt("accent", 0).coerceIn(0, AccentChoices.size) // size = your own color
        serifTitles.value = p.getBoolean("serifTitles", true)
        amoled.value = p.getBoolean("amoled", false)
        skin.value = p.getString("skin", "needle").orEmpty()
        npStyle.value = p.getString("npStyle", "follow").orEmpty()
        cardCustom.value = p.getBoolean("cardCustom", false)
        cardGlass.value = p.getBoolean("cardGlass", false)
        animatedCovers.value = p.getBoolean("animatedCovers", false)
        animatedCoversWifiOnly.value = p.getBoolean("animatedCoversWifiOnly", true)
        animatedArtistCovers.value = p.getBoolean("animatedArtistCovers", true)
        adaptiveNowPlayingGlow.value = p.getBoolean("adaptiveNowPlayingGlow", false)
        animatedFullPage.value = p.getBoolean("animatedFullPage", false)
        animatedBackupServer.value = p.getBoolean("animatedBackupServer", false)
        backupServerUrl.value = p.getString("backupServerUrl", "https://artwork.m8tec.top").orEmpty()
        animatedTidal.value = p.getBoolean("animatedTidal", false)
        tidalToken.value = p.getString("tidalToken", "").orEmpty()
        gestureTitle.intValue = p.getInt("gestureTitle", 1)
        gestureArtist.intValue = p.getInt("gestureArtist", 2)
        gestureHeader.intValue = p.getInt("gestureHeader", 3)
        fetchMissingCovers.value = p.getBoolean("fetchMissingCovers", false)
        artistBackgrounds.value = p.getBoolean("artistBackgrounds", false)
        fanartKey.value = p.getString("fanartKey", "").orEmpty()
        cardArgb.intValue = p.getInt("cardArgb", 0xB37B5A9A.toInt())
        npCardCustom.value = p.getBoolean("npCardCustom", false)
        npCardArgb.intValue = p.getInt("npCardArgb", 0xB36B5A8AL.toInt())
        skipSilence.value = p.getBoolean("skipSilence", false)
        pauseOnUnplug.value = p.getBoolean("pauseOnUnplug", true)
        volumeLevelling.value = p.getBoolean("volumeLevelling", false)
        crossfadeSec.intValue = p.getInt("crossfadeSec", 0).coerceIn(0, 12)
        countAfter.value = runCatching { CountAfter.valueOf(p.getString("countAfter", "SEC30") ?: "SEC30") }
            .getOrDefault(CountAfter.SEC30)
        ratingStyle.value = runCatching { RatingStyle.valueOf(p.getString("ratingStyle", "STARS") ?: "STARS") }
            .getOrDefault(RatingStyle.STARS)
        smartFlow.value = p.getBoolean("smartFlow", false)
        scanOnLaunch.value = p.getBoolean("scanOnLaunch", true)
        minSongSeconds.intValue = p.getInt("minSongSeconds", 0)
        customAccent.intValue = p.getInt("customAccent", 0xFFAF65F5.toInt())
        bgColor.intValue = p.getInt("bgColor", 0)
        glow1.intValue = p.getInt("glow1", 0)
        glow2.intValue = p.getInt("glow2", 0)
        glow3.intValue = p.getInt("glow3", 0)
        glowStrength.floatValue = p.getFloat("glowStrength", 1f)
    }

    fun setAccent(index: Int) { accentIndex.intValue = index; prefs?.edit()?.putInt("accent", index)?.apply() }
    fun setSerifTitles(on: Boolean) { serifTitles.value = on; prefs?.edit()?.putBoolean("serifTitles", on)?.apply() }
    fun setNpStyle(id: String) { npStyle.value = id; prefs?.edit()?.putString("npStyle", id)?.apply() }
    fun setSkin(id: String) { skin.value = id; prefs?.edit()?.putString("skin", id)?.apply() }
    fun setAmoled(on: Boolean) { amoled.value = on; prefs?.edit()?.putBoolean("amoled", on)?.apply() }
    fun setSmartFlow(on: Boolean) { smartFlow.value = on; prefs?.edit()?.putBoolean("smartFlow", on)?.apply() }
    fun setAnimatedCovers(on: Boolean) { animatedCovers.value = on; prefs?.edit()?.putBoolean("animatedCovers", on)?.apply() }
    fun setFetchMissingCovers(on: Boolean) { fetchMissingCovers.value = on; prefs?.edit()?.putBoolean("fetchMissingCovers", on)?.apply() }
    fun setArtistBackgrounds(on: Boolean) { artistBackgrounds.value = on; prefs?.edit()?.putBoolean("artistBackgrounds", on)?.apply() }
    fun setFanartKey(key: String) { fanartKey.value = key; prefs?.edit()?.putString("fanartKey", key)?.apply() }
    fun setGestureTitle(v: Int) { gestureTitle.intValue = v; prefs?.edit()?.putInt("gestureTitle", v)?.apply() }
    fun setGestureArtist(v: Int) { gestureArtist.intValue = v; prefs?.edit()?.putInt("gestureArtist", v)?.apply() }
    fun setGestureHeader(v: Int) { gestureHeader.intValue = v; prefs?.edit()?.putInt("gestureHeader", v)?.apply() }
    fun setAnimatedBackupServer(on: Boolean) { animatedBackupServer.value = on; prefs?.edit()?.putBoolean("animatedBackupServer", on)?.apply() }
    fun setBackupServerUrl(v: String) { backupServerUrl.value = v; prefs?.edit()?.putString("backupServerUrl", v)?.apply() }
    fun setAnimatedTidal(on: Boolean) { animatedTidal.value = on; prefs?.edit()?.putBoolean("animatedTidal", on)?.apply() }
    fun setTidalToken(v: String) { tidalToken.value = v; prefs?.edit()?.putString("tidalToken", v)?.apply() }
    fun setAnimatedFullPage(on: Boolean) { animatedFullPage.value = on; prefs?.edit()?.putBoolean("animatedFullPage", on)?.apply() }
    fun setAdaptiveNowPlayingGlow(on: Boolean) { adaptiveNowPlayingGlow.value = on; prefs?.edit()?.putBoolean("adaptiveNowPlayingGlow", on)?.apply() }
    fun setAnimatedArtistCovers(on: Boolean) { animatedArtistCovers.value = on; prefs?.edit()?.putBoolean("animatedArtistCovers", on)?.apply() }
    fun setAnimatedCoversWifiOnly(on: Boolean) { animatedCoversWifiOnly.value = on; prefs?.edit()?.putBoolean("animatedCoversWifiOnly", on)?.apply() }
    fun setNpCardCustom(on: Boolean) { npCardCustom.value = on; prefs?.edit()?.putBoolean("npCardCustom", on)?.apply() }
    fun setNpCardArgb(argb: Int) { npCardArgb.intValue = argb; prefs?.edit()?.putInt("npCardArgb", argb)?.apply() }
    fun setCardCustom(on: Boolean) { cardCustom.value = on; prefs?.edit()?.putBoolean("cardCustom", on)?.apply() }
    fun setCardGlass(on: Boolean) { cardGlass.value = on; prefs?.edit()?.putBoolean("cardGlass", on)?.apply() }
    fun setCardArgb(argb: Int) { cardArgb.intValue = argb; prefs?.edit()?.putInt("cardArgb", argb)?.apply() }
    fun setSkipSilence(on: Boolean) { skipSilence.value = on; prefs?.edit()?.putBoolean("skipSilence", on)?.apply() }
    fun setVolumeLevelling(on: Boolean) { volumeLevelling.value = on; prefs?.edit()?.putBoolean("volumeLevelling", on)?.apply() }
    fun setCrossfadeSec(sec: Int) { crossfadeSec.intValue = sec.coerceIn(0, 12); prefs?.edit()?.putInt("crossfadeSec", crossfadeSec.intValue)?.apply() }
    fun setPauseOnUnplug(on: Boolean) { pauseOnUnplug.value = on; prefs?.edit()?.putBoolean("pauseOnUnplug", on)?.apply() }
    fun setCountAfter(v: CountAfter) { countAfter.value = v; prefs?.edit()?.putString("countAfter", v.name)?.apply() }
    fun setRatingStyle(v: RatingStyle) { ratingStyle.value = v; prefs?.edit()?.putString("ratingStyle", v.name)?.apply() }
    fun setScanOnLaunch(on: Boolean) { scanOnLaunch.value = on; prefs?.edit()?.putBoolean("scanOnLaunch", on)?.apply() }
    fun setCustomAccent(argb: Int) { customAccent.intValue = argb; prefs?.edit()?.putInt("customAccent", argb)?.apply() }
    fun setBgColor(argb: Int) { bgColor.intValue = argb; prefs?.edit()?.putInt("bgColor", argb)?.apply() }
    fun setGlow(n: Int, argb: Int) {
        when (n) { 1 -> glow1.intValue = argb; 2 -> glow2.intValue = argb; else -> glow3.intValue = argb }
        prefs?.edit()?.putInt("glow$n", argb)?.apply()
    }
    fun setGlowStrength(v: Float) { glowStrength.floatValue = v; prefs?.edit()?.putFloat("glowStrength", v)?.apply() }

    /** Back to the original look: violet accent, automatic cards, default background and glow. */
    fun resetColors() {
        setAccent(0); setBgColor(0); setCardCustom(false); setCardGlass(false)
        setGlow(1, 0); setGlow(2, 0); setGlow(3, 0); setGlowStrength(1f)
    }

    fun setMinSongSeconds(s: Int) { minSongSeconds.intValue = s; prefs?.edit()?.putInt("minSongSeconds", s)?.apply() }

    fun toJson(): JSONObject = JSONObject()
        .put("accent", accentIndex.intValue)
        .put("serifTitles", serifTitles.value)
        .put("amoled", amoled.value)
        .put("skin", skin.value)
        .put("npStyle", npStyle.value)
        .put("cardCustom", cardCustom.value)
        .put("cardGlass", cardGlass.value)
        .put("npCardCustom", npCardCustom.value)
        .put("npCardArgb", npCardArgb.intValue)
        .put("animatedCovers", animatedCovers.value)
        .put("animatedCoversWifiOnly", animatedCoversWifiOnly.value)
        .put("animatedArtistCovers", animatedArtistCovers.value)
        .put("adaptiveNowPlayingGlow", adaptiveNowPlayingGlow.value)
        .put("animatedFullPage", animatedFullPage.value)
        .put("animatedBackupServer", animatedBackupServer.value)
        .put("backupServerUrl", backupServerUrl.value)
        .put("animatedTidal", animatedTidal.value)
        .put("gestureTitle", gestureTitle.intValue)
        .put("gestureArtist", gestureArtist.intValue)
        .put("gestureHeader", gestureHeader.intValue)
        .put("fetchMissingCovers", fetchMissingCovers.value)
        .put("artistBackgrounds", artistBackgrounds.value)
        .put("cardArgb", cardArgb.intValue)
        .put("skipSilence", skipSilence.value)
        .put("pauseOnUnplug", pauseOnUnplug.value)
        .put("volumeLevelling", volumeLevelling.value)
        .put("crossfadeSec", crossfadeSec.intValue)
        .put("countAfter", countAfter.value.name)
        .put("ratingStyle", ratingStyle.value.name)
        .put("scanOnLaunch", scanOnLaunch.value)
        .put("minSongSeconds", minSongSeconds.intValue)
        .put("customAccent", customAccent.intValue)
        .put("bgColor", bgColor.intValue)
        .put("glow1", glow1.intValue)
        .put("glow2", glow2.intValue)
        .put("glow3", glow3.intValue)
        .put("glowStrength", glowStrength.floatValue.toDouble())

    /** Anything missing from the file keeps its current value. */
    fun fromJson(o: JSONObject) {
        if (o.has("accent")) setAccent(o.optInt("accent", 0).coerceIn(0, AccentChoices.size))
        if (o.has("serifTitles")) setSerifTitles(o.optBoolean("serifTitles", true))
        if (o.has("amoled")) setAmoled(o.optBoolean("amoled", false))
        if (o.has("skin")) setSkin(o.optString("skin", "needle"))
        if (o.has("npStyle")) setNpStyle(o.optString("npStyle", "follow"))
        if (o.has("animatedCovers")) setAnimatedCovers(o.optBoolean("animatedCovers", false))
        if (o.has("fetchMissingCovers")) setFetchMissingCovers(o.optBoolean("fetchMissingCovers", false))
        if (o.has("artistBackgrounds")) setArtistBackgrounds(o.optBoolean("artistBackgrounds", false))
        if (o.has("gestureTitle")) setGestureTitle(o.optInt("gestureTitle", 1))
        if (o.has("gestureArtist")) setGestureArtist(o.optInt("gestureArtist", 2))
        if (o.has("gestureHeader")) setGestureHeader(o.optInt("gestureHeader", 3))
        if (o.has("animatedBackupServer")) setAnimatedBackupServer(o.optBoolean("animatedBackupServer", false))
        if (o.has("backupServerUrl")) setBackupServerUrl(o.optString("backupServerUrl", "https://artwork.m8tec.top"))
        if (o.has("animatedTidal")) setAnimatedTidal(o.optBoolean("animatedTidal", false))
        if (o.has("animatedFullPage")) setAnimatedFullPage(o.optBoolean("animatedFullPage", false))
        if (o.has("adaptiveNowPlayingGlow")) setAdaptiveNowPlayingGlow(o.optBoolean("adaptiveNowPlayingGlow", false))
        if (o.has("animatedArtistCovers")) setAnimatedArtistCovers(o.optBoolean("animatedArtistCovers", true))
        if (o.has("animatedCoversWifiOnly")) setAnimatedCoversWifiOnly(o.optBoolean("animatedCoversWifiOnly", true))
        if (o.has("npCardCustom")) setNpCardCustom(o.optBoolean("npCardCustom", false))
        if (o.has("npCardArgb")) setNpCardArgb(o.optInt("npCardArgb", 0xB36B5A8AL.toInt()))
        if (o.has("cardCustom")) setCardCustom(o.optBoolean("cardCustom", false))
        if (o.has("cardGlass")) setCardGlass(o.optBoolean("cardGlass", false))
        if (o.has("cardArgb")) setCardArgb(o.optInt("cardArgb", 0xB37B5A9A.toInt()))
        if (o.has("skipSilence")) setSkipSilence(o.optBoolean("skipSilence", false))
        if (o.has("pauseOnUnplug")) setPauseOnUnplug(o.optBoolean("pauseOnUnplug", true))
        if (o.has("volumeLevelling")) setVolumeLevelling(o.optBoolean("volumeLevelling", false))
        if (o.has("crossfadeSec")) setCrossfadeSec(o.optInt("crossfadeSec", 0))
        if (o.has("countAfter")) {
            runCatching { CountAfter.valueOf(o.getString("countAfter")) }.getOrNull()?.let { setCountAfter(it) }
        }
        if (o.has("ratingStyle")) {
            runCatching { RatingStyle.valueOf(o.getString("ratingStyle")) }.getOrNull()?.let { setRatingStyle(it) }
        }
        if (o.has("scanOnLaunch")) setScanOnLaunch(o.optBoolean("scanOnLaunch", true))
        if (o.has("minSongSeconds")) setMinSongSeconds(o.optInt("minSongSeconds", 0))
        if (o.has("customAccent")) setCustomAccent(o.optInt("customAccent", customAccent.intValue))
        if (o.has("bgColor")) setBgColor(o.optInt("bgColor", 0))
        if (o.has("glow1")) setGlow(1, o.optInt("glow1", 0))
        if (o.has("glow2")) setGlow(2, o.optInt("glow2", 0))
        if (o.has("glow3")) setGlow(3, o.optInt("glow3", 0))
        if (o.has("glowStrength")) setGlowStrength(o.optDouble("glowStrength", 1.0).toFloat().coerceIn(0f, 1f))
    }
}
