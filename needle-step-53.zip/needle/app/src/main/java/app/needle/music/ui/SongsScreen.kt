package app.needle.music.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.stickyHeader
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song
import app.needle.music.data.ListSettings
import app.needle.music.data.SortField
import app.needle.music.data.SortOrder

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun SongsScreen(
    songs: List<Song>?,
    isScanning: Boolean,
    currentMediaId: String?,
    sort: SortOrder,
    bottomPadding: Dp,
    onSongClick: (Int) -> Unit,
    onSongLongClick: (Song) -> Unit,
    onShuffleAll: () -> Unit,
    onSortSelected: (SortField) -> Unit,
    onRescan: () -> Unit,
    modifier: Modifier = Modifier,
    ratings: Map<Long, Int> = emptyMap()
) {
    when {
        songs == null -> Centered("Loading…", modifier)

        songs.isEmpty() -> Column(
            modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                if (isScanning) "Scanning your music…" else "No music found",
                color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 24.sp
            )
            if (!isScanning) {
                Spacer(Modifier.padding(8.dp))
                PillButton("Scan again", onRescan)
            }
        }

        else -> {
            val listState = rememberLazyListState()
            // A new sort order starts from the top.
            LaunchedEffect(sort) { listState.scrollToItem(0) }
            val selection = remember { SongSelection() }
            val selecting = selection.active
            BackHandler(enabled = selecting) { selection.clear() }
            val picked = { songs.filter { it.id in selection.ids } }

            val sortBar: @Composable () -> Unit = {
                Row(
                    Modifier.fillMaxWidth().padding(start = 20.dp, top = 4.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    PillButton("Shuffle", onShuffleAll, filled = true)
                    Spacer(Modifier.width(12.dp))
                    Row(
                        Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        SortField.entries.forEach { field ->
                            val selected = sort.field == field
                            // "Flip sort arrows" in Settings > Customization > Media lists swaps what the arrow means
                            val up = sort.ascending != ListSettings.flipSortArrows.value
                            val arrow = if (up) "↑" else "↓"
                            Chip(
                                text = if (selected) "${field.label} $arrow" else field.label,
                                selected = selected,
                                onClick = { onSortSelected(field) }
                            )
                        }
                        Spacer(Modifier.width(12.dp))
                    }
                }
            }

            Box(modifier.fillMaxSize()) {
                LazyColumn(
                    Modifier.fillMaxSize(),
                    state = listState,
                    contentPadding = PaddingValues(bottom = bottomPadding + if (selecting) 72.dp else 0.dp)
                ) {
                    item {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(
                                    "Songs", color = Palette.Text, fontFamily = Palette.TitleFont,
                                    fontWeight = FontWeight.Bold, fontSize = 32.sp
                                )
                                if (ListSettings.showCounts.value) Text("${songs.size} songs", color = Palette.Muted, fontSize = 14.sp)
                            }
                            PillButton(if (isScanning) "Scanning…" else "Rescan", onClick = { if (!isScanning) onRescan() })
                        }
                    }
                    // "Pin sort bar" keeps Shuffle and the sort chips at the top while you scroll
                    if (ListSettings.pinSortBar.value) {
                        stickyHeader { Box(Modifier.background(Palette.Bg.copy(alpha = 0.94f))) { sortBar() } }
                    } else {
                        item { sortBar() }
                    }
                    itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                        SongRow(
                            song,
                            isCurrent = song.id.toString() == currentMediaId,
                            onClick = { if (selecting) selection.toggle(song.id) else onSongClick(index) },
                            onLongClick = {
                                if (selecting || ListSettings.longPressSelect.value) selection.toggle(song.id)
                                else onSongLongClick(song)
                            },
                            rating = ratings[song.id] ?: 0,
                            selected = if (selecting) song.id in selection.ids else null
                        )
                    }
                }
                if (selecting) {
                    SelectionBar(
                        count = selection.ids.size,
                        onAll = { selection.selectAll(songs) },
                        onNext = { RowActions.playNext(picked()); selection.clear() },
                        onQueue = { RowActions.addToQueue(picked()); selection.clear() },
                        onPlaylist = { RowActions.addToPlaylist(picked()); selection.clear() },
                        onTags = { RowActions.editTags(picked()); selection.clear() },
                        onClose = { selection.clear() },
                        modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomPadding)
                    )
                }
            }
        }
    }
}

@Composable
private fun Centered(text: String, modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = Palette.Muted, fontSize = 16.sp, textAlign = TextAlign.Center)
    }
}
