package app.needle.music.data

import java.time.DayOfWeek
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.time.format.TextStyle
import java.time.temporal.ChronoUnit
import java.util.Locale
import java.util.concurrent.TimeUnit
import kotlin.random.Random

/** An album as the Home screen sees it. [cover] is the song whose artwork represents it. */
data class HomeAlbum(
    val id: Long,
    val title: String,
    val artist: String,
    val songs: List<Song>,
    val heardTracks: Int,
    val lastPlayedAt: Long?,
    /** The genre most of its songs have (shown on the tile), or null. */
    val genre: String? = null
) {
    val cover: Song get() = songs.first()
}

/** A big card at the top of Home. Tapping "Play now" plays [songs]. */
data class HeroCard(val title: String, val subtitle: String, val songs: List<Song>) {
    val cover: Song get() = songs.first()
}

data class WeekStats(val listenedMs: Long, val plays: Int, val topArtist: String?)

data class HomeState(
    val heroes: List<HeroCard>,
    val yourAlbums: List<HomeAlbum>,
    val week: WeekStats,
    val rediscover: List<HomeAlbum>
)

private val DAY_MS = TimeUnit.DAYS.toMillis(1)

/** Folders people dump loose songs into. Songs in these are singles, even if the folder is also their "album". */
private val looseFolders = setOf("download", "downloads", "music", "audio", "sounds", "documents", "bluetooth", "telegram")

private fun isRealAlbum(group: List<Song>): Boolean {
    val first = group.first()
    if (group.size < 2 || first.album == "Unknown album") return false
    val folderName = first.folder.trimEnd('/').substringAfterLast('/').lowercase()
    return !(folderName in looseFolders && first.album.lowercase() == folderName)
}

/** Splits the library into real albums (each sorted by track) and everything else (singles). */
fun splitAlbums(songs: List<Song>): Pair<List<List<Song>>, List<Song>> {
    val albums = ArrayList<List<Song>>()
    val singles = ArrayList<Song>()
    for (group in songs.groupBy { it.albumId }.values) {
        if (isRealAlbum(group)) albums += group.sortedWith(compareBy({ it.trackNumber }, { it.title }))
        else singles += group
    }
    return albums to singles
}

private fun toHomeAlbums(
    albums: List<List<Song>>,
    songById: Map<Long, Song>,
    plays: List<PlayEvent>,
    extras: ExtraTags = emptyMap()
): List<HomeAlbum> {
    val playsByAlbum: Map<Long, List<PlayEvent>> = plays
        .mapNotNull { event -> songById[event.songId]?.let { it.albumId to event } }
        .groupBy({ it.first }, { it.second })

    return albums.map { group ->
        val events = playsByAlbum[group.first().albumId].orEmpty()
        HomeAlbum(
            id = group.first().albumId,
            title = group.first().album,
            // The "Album artist" tag if the songs have one, otherwise the most common artist.
            artist = group.mapNotNull { extras[it.id]?.get("ALBUMARTIST")?.takeIf { a -> a.isNotBlank() } }
                .groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                ?: group.map { it.artist }.groupingBy { it }.eachCount().maxByOrNull { it.value }?.key
                ?: group.first().artist,
            // Tracks go disc by disc (or side by side), then by track number.
            songs = if (extras.isEmpty()) group
            else group.sortedWith(compareBy({ discOf(extras[it.id]) }, { it.trackNumber }, { it.title })),
            heardTracks = events.map { it.songId }.distinct().size,
            lastPlayedAt = events.maxOfOrNull { it.playedAt },
            genre = topGenre(group)
        )
    }
}

/** Does the album have one of the (lower case) [favorites] among its songs' genres? */
private fun HomeAlbum.hasGenre(favorites: Set<String>): Boolean =
    favorites.isNotEmpty() && songs.any { s -> genresOf(s).any { it.lowercase() in favorites } }

/** Which of the favorites the album has, spelled as in the album. */
private fun HomeAlbum.matchingGenre(favorites: Set<String>): String? =
    songs.flatMap { genresOf(it) }.firstOrNull { it.lowercase() in favorites }

/** Every real album, A to Z, for the Albums page. Singles are left out, same as on Home. */
fun buildAlbumList(songs: List<Song>, plays: List<PlayEvent>, extras: ExtraTags = emptyMap()): List<HomeAlbum> {
    val songById = songs.associateBy { it.id }
    val (albums, _) = splitAlbums(songs)
    return toHomeAlbums(albums, songById, plays, extras)
        // "Album sort" tag first, else the title
        .map { album -> album to sortKey(album.songs.firstNotNullOfOrNull { extras[it.id]?.get("ALBUMSORT") } ?: album.title) }
        .sortedBy { it.second }
        .map { it.first }
}

/**
 * Builds everything the Home screen shows from the library and the play history.
 * Pure function (no Android), so it is easy to test and to change later.
 * [seed] keeps the "random" picks steady for the whole day.
 */
fun buildHome(
    songs: List<Song>,
    plays: List<PlayEvent>,
    now: Long,
    seed: Long,
    extras: ExtraTags = emptyMap(),
    favoriteGenres: Set<String> = emptySet()
): HomeState {
    val favorites = favoriteGenres.map { it.lowercase() }.toSet()
    val songById = songs.associateBy { it.id }
    val rng = Random(seed)
    val (albums, _) = splitAlbums(songs)
    val homeAlbums = toHomeAlbums(albums, songById, plays, extras)

    // ---- Your albums: what you listened to most recently --------------------------------
    val yourAlbums = homeAlbums
        .filter { it.lastPlayedAt != null }
        .sortedByDescending { it.lastPlayedAt }
        .take(10)

    // ---- This week ----------------------------------------------------------------------
    val weekEvents = plays.filter { it.playedAt >= now - 7 * DAY_MS }
    val week = WeekStats(
        listenedMs = weekEvents.sumOf { it.listenedMs },
        plays = weekEvents.size,
        topArtist = weekEvents
            .mapNotNull { songById[it.songId]?.artist }
            .groupingBy { it }.eachCount()
            .maxByOrNull { it.value }?.key
    )

    // ---- Rediscover: not played for a month or more (or never) ----------------------------
    val rediscover = homeAlbums
        .filter { it.lastPlayedAt == null || it.lastPlayedAt < now - 30 * DAY_MS }
        .shuffled(rng)
        .sortedBy { if (it.hasGenre(favorites)) 0 else 1 } // the chosen genres come first
        .take(10)

    // ---- Hero cards -----------------------------------------------------------------------
    val heroes = ArrayList<HeroCard>()

    val topArtistThisMonth = plays
        .filter { it.playedAt >= now - 30 * DAY_MS }
        .mapNotNull { songById[it.songId]?.artist }
        .groupingBy { it }.eachCount()
        .maxByOrNull { it.value }?.key
    val becauseAlbum = topArtistThisMonth?.let { artist ->
        homeAlbums.filter { a -> a.songs.any { it.artist == artist } }.shuffled(rng).firstOrNull()
    }
    // A chosen genre comes first: an album of it that was played least recently (or never).
    val becauseGenre = homeAlbums.filter { it.hasGenre(favorites) }
        .sortedWith(compareBy<HomeAlbum>({ it.lastPlayedAt != null }, { it.lastPlayedAt ?: 0L }))
        .take(8).shuffled(rng).firstOrNull()
    val first = becauseGenre ?: becauseAlbum ?: homeAlbums.maxByOrNull { a -> a.songs.maxOf { it.dateAdded } }
    if (first != null) {
        heroes += HeroCard(
            title = first.title,
            subtitle = when {
                becauseGenre != null -> "Because you like ${becauseGenre.matchingGenre(favorites) ?: "this genre"}"
                becauseAlbum != null -> "Because you play $topArtistThisMonth"
                else -> "New in your library"
            },
            songs = first.songs
        )
    }
    val second = rediscover.firstOrNull { it.id != first?.id }
        ?: homeAlbums.filter { it.id != first?.id }.shuffled(rng).firstOrNull()
    if (second != null) {
        heroes += HeroCard(title = second.title, subtitle = "Rediscover", songs = second.songs)
    }

    return HomeState(heroes, yourAlbums, week, rediscover)
}

/** "Never played", "Not played in 6 d", "Not played in 5 mo". */
fun notPlayedLabel(lastPlayedAt: Long?, now: Long): String {
    if (lastPlayedAt == null) return "Never played"
    val days = ((now - lastPlayedAt) / DAY_MS).toInt().coerceAtLeast(0)
    return if (days < 60) "Not played in $days d" else "Not played in ${days / 30} mo"
}

/** "0 min", "35 min", "3.5 h", "14 h". */
fun formatListened(ms: Long): String {
    val minutes = ms / 60_000
    if (minutes < 60) return "$minutes min"
    val hours = ms / 3_600_000.0
    return if (hours < 10) "%.1f h".format(hours) else "${hours.toInt()} h"
}

// ---- New page ---------------------------------------------------------------------------

/** The big card at the top of the New page. */
data class NewHero(val label: String, val title: String, val subtitle: String, val songs: List<Song>) {
    val cover: Song get() = songs.first()
}

/** A recently added loose song. [subtitle] is "Artist · Today". */
data class NewSingle(val song: Song, val subtitle: String)

data class NewState(
    val hero: NewHero?,
    val recentTitle: String,
    val recent: List<HomeAlbum>,
    val singles: List<NewSingle>,
    /** Songs added this week that have no genre yet: they cannot be used for genre picks. */
    val needTags: List<Song> = emptyList()
)

/** Songs added in the last week count as new. If nothing is that fresh, the page shows the latest additions instead. */
fun buildNew(songs: List<Song>, plays: List<PlayEvent>, now: Long, extras: ExtraTags = emptyMap()): NewState {
    val songById = songs.associateBy { it.id }
    val (albums, singles) = splitAlbums(songs)
    val nowSec = now / 1000
    val weekAgo = nowSec - 7 * 86_400

    // "this." matters: the library list above is also called songs.
    fun HomeAlbum.added() = this.songs.maxOf { it.dateAdded }
    val byNewest = toHomeAlbums(albums, songById, plays, extras).sortedByDescending { it.added() }

    val heroAlbum = byNewest.firstOrNull()
    val hero = heroAlbum?.let {
        val added = it.added()
        NewHero(
            label = if (added >= weekAgo) "Just added" else "Latest addition",
            title = it.title,
            subtitle = "${it.artist} · ${it.songs.size} tracks · ${addedPhrase(added, now)}",
            songs = it.songs
        )
    }

    val rest = byNewest.drop(1)
    val thisWeek = rest.filter { it.added() >= weekAgo }
    val recent = (if (thisWeek.isNotEmpty()) thisWeek else rest).take(10)

    val newSingles = singles
        .sortedWith(compareByDescending<Song> { it.dateAdded }.thenBy { it.title })
        .take(8)
        .map { NewSingle(it, "${it.artist} · ${dayLabel(it.dateAdded, now)}") }

    // Added this week, but no genre yet
    val needTags = songs
        .filter { it.dateAdded >= weekAgo && genresOf(it).isEmpty() }
        .sortedByDescending { it.dateAdded }
        .take(100)

    return NewState(
        hero = hero,
        recentTitle = if (thisWeek.isNotEmpty()) "Added this week" else "Recently added",
        recent = recent,
        singles = newSingles,
        needTags = needTags
    )
}

private fun daysAgo(addedSec: Long, now: Long): Long {
    val zone = ZoneId.systemDefault()
    val added = Instant.ofEpochSecond(addedSec).atZone(zone).toLocalDate()
    val today = Instant.ofEpochMilli(now).atZone(zone).toLocalDate()
    return ChronoUnit.DAYS.between(added, today).coerceAtLeast(0)
}

/** "Today", "Yesterday", "Monday" (within a week), otherwise "12 Oct". */
fun dayLabel(addedSec: Long, now: Long): String {
    val days = daysAgo(addedSec, now)
    return when {
        days == 0L -> "Today"
        days == 1L -> "Yesterday"
        days < 7 -> {
            val day: DayOfWeek = Instant.ofEpochSecond(addedSec).atZone(ZoneId.systemDefault()).dayOfWeek
            day.getDisplayName(TextStyle.FULL, Locale.getDefault())
        }
        else -> Instant.ofEpochSecond(addedSec).atZone(ZoneId.systemDefault()).toLocalDate()
            .format(DateTimeFormatter.ofPattern("d MMM yyyy", Locale.getDefault()))
    }
}

/** "added today", "added yesterday", "added on Monday", "added on 12 Oct 2025". */
fun addedPhrase(addedSec: Long, now: Long): String {
    val days = daysAgo(addedSec, now)
    return when (days) {
        0L -> "added today"
        1L -> "added yesterday"
        else -> "added on ${dayLabel(addedSec, now)}"
    }
}

// ---- Singles page -----------------------------------------------------------------------

/** One song released on its own. [year] is its release year, or the year it was added if the file has none. */
data class SingleItem(val song: Song, val year: Int, val played: Boolean)

data class SinglesState(val items: List<SingleItem>, val thisYear: Int)

/** Every song that is not part of a real album, newest year first. */
fun buildSingles(songs: List<Song>, plays: List<PlayEvent>, now: Long): SinglesState {
    val zone = ZoneId.systemDefault()
    val playedIds = plays.mapTo(HashSet()) { it.songId }
    val (_, singles) = splitAlbums(songs)
    val items = singles.map { song ->
        val year = if (song.year > 0) song.year
        else Instant.ofEpochSecond(song.dateAdded).atZone(zone).year
        SingleItem(song, year, played = song.id in playedIds)
    }.sortedWith(
        compareByDescending<SingleItem> { it.year }
            .thenByDescending { it.song.dateAdded }
            .thenBy { it.song.title }
    )
    return SinglesState(items, thisYear = Instant.ofEpochMilli(now).atZone(zone).year)
}
