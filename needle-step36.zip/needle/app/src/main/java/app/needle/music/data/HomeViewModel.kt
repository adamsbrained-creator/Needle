package app.needle.music.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.util.concurrent.TimeUnit

/** Feeds the Home screen. Rebuilds whenever the library or the play history changes. */
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)

    private class Inputs(val songs: List<Song>, val plays: List<PlayEvent>, val extras: ExtraTags)

    private val inputs = combine(Library.observe(db), db.playDao().observeAll(), Library.observeExtras(db)) { songs, plays, extras ->
        Inputs(songs, plays, extras)
    }

    /** Every genre of the library, most songs first. For "Choose your genres". */
    val genres: StateFlow<List<GenreCount>> =
        Library.observe(db)
            .map { libraryGenres(it) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    /** The Popular page. null = still loading. Rebuilt when the chosen genres change. */
    val home: StateFlow<HomeState?> =
        combine(inputs, GenrePrefs.selected) { i, favorites -> i to favorites }
            .map { (i, favorites) ->
                val now = System.currentTimeMillis()
                buildHome(i.songs, i.plays, now, seed = now / TimeUnit.DAYS.toMillis(1), extras = i.extras, favoriteGenres = favorites)
            }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** The Singles page. null = still loading. */
    val singles: StateFlow<SinglesState?> =
        inputs
            .map { i -> buildSingles(i.songs, i.plays, System.currentTimeMillis()) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** The Most played page: the top songs of each period. null = still loading. */
    val mostPlayed: StateFlow<Map<MostRange, List<PlayedSong>>?> =
        inputs
            .map { i -> buildMostPlayed(i.songs, i.plays, System.currentTimeMillis()) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** The Albums page. null = still loading. */
    val albums: StateFlow<List<HomeAlbum>?> =
        inputs
            .map { i -> buildAlbumList(i.songs, i.plays, i.extras) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** The New page. null = still loading. */
    val newState: StateFlow<NewState?> =
        inputs
            .map { i -> buildNew(i.songs, i.plays, System.currentTimeMillis(), i.extras) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}
