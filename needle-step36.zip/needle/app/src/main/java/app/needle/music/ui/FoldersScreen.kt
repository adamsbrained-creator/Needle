package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.FolderEntry
import app.needle.music.data.Song
import app.needle.music.data.buildFolderListing

/**
 * Folders page from the mockup: the folders of your music as they are on the phone. Tap a folder to go in, tap the
 * path above to go back up. "Play folder" plays everything below the folder you are in.
 */
@Composable
fun FoldersScreen(
    songs: List<Song>?,
    path: String,
    bottomPadding: Dp,
    onPath: (String) -> Unit,
    onBack: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShuffleAll: (List<Song>) -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit,
    onSearch: () -> Unit,
    modifier: Modifier = Modifier
) {
    val listing = remember(songs, path) { buildFolderListing(songs.orEmpty(), path) }
    val parts = if (path.isEmpty()) emptyList() else path.split('/')
    val empty = songs != null && listing.subfolders.isEmpty() && listing.files.isEmpty()

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    // Back goes up one folder; from the top it leaves the page.
                    RoundIconButton(
                        NeedleIcon.BACK,
                        { if (path.isEmpty()) onBack() else onPath(path.substringBeforeLast('/', "")) },
                        size = 40.dp, iconSize = 22.dp
                    )
                    Spacer(Modifier.weight(1f))
                    RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 40.dp, iconSize = 20.dp)
                }
                Text(
                    "Folders", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                // Internal storage > Music > Indie
                Row(
                    Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(top = 6.dp, bottom = 14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Crumb("Internal storage", last = parts.isEmpty()) { onPath("") }
                    parts.forEachIndexed { i, name ->
                        Text("  ›  ", color = Palette.Muted, fontSize = 13.sp)
                        Crumb(name, last = i == parts.lastIndex) { onPath(parts.take(i + 1).joinToString("/")) }
                    }
                }
                if (listing.allSongs.isNotEmpty()) {
                    Row(Modifier.fillMaxWidth().padding(bottom = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            Modifier.weight(1f).height(46.dp).clip(CircleShape).background(Color.White)
                                .clickable { onPlayAll(listing.allSongs) },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            NeedleIconView(NeedleIcon.PLAY, Color(0xFF111111), size = 16.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Play folder", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                        Row(
                            Modifier.weight(1f).height(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.12f))
                                .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                                .clickable { onShuffleAll(listing.allSongs) },
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            NeedleIconView(NeedleIcon.SHUFFLE, Palette.Text, size = 17.dp)
                            Spacer(Modifier.width(8.dp))
                            Text("Shuffle", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
                        }
                    }
                }
            }
        }

        if (empty) {
            item {
                Text(
                    "Nothing in this folder.", color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp)
                )
            }
        }

        items(listing.subfolders, key = { "folder:" + it.path }) { folder ->
            FolderRow(folder, onClick = { onPath(folder.path) })
        }

        if (listing.files.isNotEmpty()) {
            item {
                Row(
                    Modifier.fillMaxWidth().padding(top = 18.dp, bottom = 8.dp, start = 4.dp, end = 4.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("Files in this folder", color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.weight(1f))
                    Text("${listing.files.size}", color = Palette.Muted, fontSize = 13.sp)
                }
            }
            itemsIndexed(listing.files, key = { _, s -> s.id }) { index, song ->
                FileRow(song, onClick = { onPlay(listing.files, index) }, onLongClick = { onMenu(song) })
            }
        }
    }
}

@Composable
private fun Crumb(name: String, last: Boolean, onClick: () -> Unit) {
    Text(
        name,
        color = if (last) Palette.Text else Palette.Muted,
        fontSize = 13.5.sp,
        fontWeight = if (last) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier.clip(RoundedCornerShape(8.dp)).clickable(onClick = onClick).padding(horizontal = 2.dp, vertical = 2.dp)
    )
}

@Composable
private fun GlassRow(modifier: Modifier, content: @Composable () -> Unit) {
    val shape = RoundedCornerShape(18.dp)
    Row(
        modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.08f), Color.White.copy(alpha = 0.04f))))
            .border(1.dp, Color.White.copy(alpha = 0.08f), shape)
            .padding(horizontal = 12.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) { content() }
}

@Composable
private fun IconBox(icon: NeedleIcon, tint: Color) {
    Box(
        Modifier.size(44.dp).clip(RoundedCornerShape(13.dp)).background(tint),
        contentAlignment = Alignment.Center
    ) { NeedleIconView(icon, Color.White, size = 21.dp) }
}

@Composable
private fun FolderRow(folder: FolderEntry, onClick: () -> Unit) {
    GlassRow(Modifier.clickable(onClick = onClick)) {
        IconBox(NeedleIcon.FOLDER, Palette.Accent.copy(alpha = 0.45f))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                folder.name, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            val songs = if (folder.songs == 1) "1 song" else "${folder.songs} songs"
            Text(
                if (folder.albums > 0) "${if (folder.albums == 1) "1 album" else "${folder.albums} albums"} · $songs" else songs,
                color = Palette.Muted, fontSize = 12.5.sp
            )
        }
    }
}

@Composable
private fun FileRow(song: Song, onClick: () -> Unit, onLongClick: () -> Unit) {
    GlassRow(Modifier.tapOrHold(onClick, onLongClick)) {
        IconBox(NeedleIcon.SONGS, Color.White.copy(alpha = 0.14f))
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "${song.artist} · ${formatTime(song.durationMs)}", color = Palette.Muted, fontSize = 12.5.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
    }
}
