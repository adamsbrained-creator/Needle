package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** The genres the person likes ("Choose your genres"). They are used first on Home. Remembered. */
object GenrePrefs {
    private var prefs: SharedPreferences? = null

    /** The chosen genres, spelled as in the library. Matching ignores upper and lower case. */
    val selected = MutableStateFlow<Set<String>>(emptySet())

    /** True once the picker was saved or skipped, so the card on Home does not come back. */
    val asked = MutableStateFlow(false)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        selected.value = p.getStringSet("fav_genres", emptySet())?.toSet().orEmpty()
        asked.value = p.getBoolean("genres_asked", false)
    }

    fun save(genres: Set<String>) {
        selected.value = genres
        asked.value = true
        prefs?.edit()?.putStringSet("fav_genres", genres)?.putBoolean("genres_asked", true)?.apply()
    }

    fun skip() {
        asked.value = true
        prefs?.edit()?.putBoolean("genres_asked", true)?.apply()
    }
}

/** A genre of the library and how many songs have it. */
class GenreCount(val name: String, val songs: Int)

private fun isRealGenre(g: String): Boolean {
    if (g.isEmpty()) return false
    if (g.all { it.isDigit() || it == '(' || it == ')' }) return false // old ID3v1 numbers
    return !g.equals("unknown", ignoreCase = true) && g != "<unknown>"
}

/** The genres of a song. A Genre tag with several values ("Rock; Pop") counts as several. */
fun genresOf(song: Song): List<String> =
    song.genre.split(';', '\u0000').map { it.trim() }.filter { isRealGenre(it) }

/** Every genre in the library, most songs first. Upper and lower case count as the same genre. */
fun libraryGenres(songs: List<Song>): List<GenreCount> {
    val counts = HashMap<String, Int>()               // lower case -> songs
    val spellings = HashMap<String, HashMap<String, Int>>() // lower case -> spelling -> uses
    for (s in songs) {
        for (g in genresOf(s).distinct()) {
            val key = g.lowercase()
            counts[key] = (counts[key] ?: 0) + 1
            val sp = spellings.getOrPut(key) { HashMap() }
            sp[g] = (sp[g] ?: 0) + 1
        }
    }
    return counts.map { (key, n) ->
        GenreCount(spellings.getValue(key).maxByOrNull { it.value }!!.key, n)
    }.sortedWith(compareByDescending<GenreCount> { it.songs }.thenBy { it.name.lowercase() })
}

/** The genre most of an album's songs have, or null if none of them has one. */
fun topGenre(songs: List<Song>): String? =
    songs.flatMap { genresOf(it).distinct() }.groupingBy { it.lowercase() }.eachCount().maxByOrNull { it.value }
        ?.key?.let { key -> songs.flatMap { genresOf(it) }.first { it.lowercase() == key } }
