package app.needle.music.data

/** A folder one level below the one on screen. */
class FolderEntry(val name: String, val path: String, val songs: Int, val albums: Int)

/**
 * What the Folders page shows for one folder: the folders inside it, the songs directly in it, and all the songs
 * below it (for "Play folder"). Paths are the media folders Android knows, like "Music/Indie" (no leading slash);
 * the top is "".
 */
class FolderListing(
    val path: String,
    val subfolders: List<FolderEntry>,
    val files: List<Song>,
    val allSongs: List<Song>
)

private fun folderOf(song: Song): String = song.folder.trim('/')

fun buildFolderListing(songs: List<Song>, path: String): FolderListing {
    val prefix = if (path.isEmpty()) "" else "$path/"
    val files = ArrayList<Song>()
    val below = LinkedHashMap<String, ArrayList<Song>>() // name of the folder inside -> its songs (all levels)
    for (s in songs) {
        val f = folderOf(s)
        if (f == path) {
            files += s
        } else if (path.isEmpty() || f.startsWith(prefix)) {
            val child = (if (path.isEmpty()) f else f.removePrefix(prefix)).substringBefore('/')
            if (child.isNotEmpty()) below.getOrPut(child) { ArrayList() } += s
        }
    }

    val inFolder = compareBy<Song>({ it.album.lowercase() }, { it.trackNumber }, { it.title.lowercase() })
    val subfolders = below.entries
        .sortedBy { it.key.lowercase() }
        .map { (name, list) ->
            FolderEntry(
                name = name,
                path = prefix + name,
                songs = list.size,
                albums = list.filter { it.album != "Unknown album" }.map { it.albumId }.toSet().size
            )
        }
    val sortedFiles = files.sortedWith(inFolder)
    val all = (below.values.flatten() + files)
        .sortedWith(compareBy<Song>({ folderOf(it).lowercase() }, { it.album.lowercase() }, { it.trackNumber }, { it.title.lowercase() }))
    return FolderListing(path, subfolders, sortedFiles, all)
}
