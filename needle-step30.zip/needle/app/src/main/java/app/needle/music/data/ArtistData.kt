package app.needle.music.data

import java.time.Instant
import java.time.ZoneId

// Everything the artist page shows. Pure functions, like HomeData.kt.

/** The "Latest album" card: the artist's newest album, or their newest single if they have no album. */
data class LatestRelease(
    val label: String,       // "LATEST ALBUM" / "LATEST SINGLE"
    val title: String,
    val line: String,        // "9 songs · 2026" / "Single · 2025"
    val songs: List<Song>,
    val album: HomeAlbum?    // null for a single
) {
    val cover: Song get() = songs.first()
}

data class ArtistPageData(
    val name: String,
    /** Every song of the artist: albums newest first (tracks in order), then singles newest first. */
    val songs: List<Song>,
    val albums: List<HomeAlbum>,
    val singles: List<Song>,
    val latest: LatestRelease?,
    /** Most played first. Songs never played follow, newest first. */
    val top: List<Song>,
    /** One song per release, to show covers. */
    val covers: List<Song>,
    val realAlbumIds: Set<Long>
) {
    fun year(song: Song): Int = releaseYear(song)

    /** "Neon Harbor · 2026" or "Single · 2025" */
    fun subtitle(song: Song): String {
        val y = releaseYear(song)
        val first = if (song.albumId in realAlbumIds) song.album else "Single"
        return "$first · $y"
    }
}

/** The song's release year, or the year it was added if the file has none. */
fun releaseYear(song: Song): Int =
    if (song.year > 0) song.year else Instant.ofEpochSecond(song.dateAdded).atZone(ZoneId.systemDefault()).year

private fun albumYear(album: HomeAlbum): Int = album.songs.maxOf { releaseYear(it) }

fun buildArtistPage(name: String, songs: List<Song>, albums: List<HomeAlbum>, playCounts: Map<Long, Int>): ArtistPageData {
    val key = artistKey(name)
    val mine = songs.filter { artistKey(it.artist) == key }
    val realAlbumIds = albums.map { it.id }.toSet()

    val artistAlbums = albums
        .filter { album -> album.songs.any { artistKey(it.artist) == key } }
        .sortedWith(compareByDescending<HomeAlbum> { albumYear(it) }.thenByDescending { a -> a.songs.maxOf { it.dateAdded } })
    val singles = mine.filter { it.albumId !in realAlbumIds }.sortedByDescending { it.dateAdded }

    val ordered = artistAlbums.flatMap { a -> a.songs.filter { artistKey(it.artist) == key } } + singles

    val latest = artistAlbums.firstOrNull()?.let { a ->
        LatestRelease(
            "LATEST ALBUM", a.title,
            "${a.songs.size} ${if (a.songs.size == 1) "song" else "songs"} · ${albumYear(a)}",
            a.songs, a
        )
    } ?: singles.firstOrNull()?.let { s ->
        LatestRelease("LATEST SINGLE", s.title, "Single · ${releaseYear(s)}", listOf(s), null)
    }

    val top = mine.sortedWith(
        compareByDescending<Song> { playCounts[it.id] ?: 0 }.thenByDescending { it.dateAdded }
    ).take(25)

    val covers = (artistAlbums.map { it.cover } + singles).distinctBy { it.id }.take(4)

    return ArtistPageData(name, ordered, artistAlbums, singles, latest, top, covers, realAlbumIds)
}
