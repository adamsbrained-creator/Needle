package app.needle.music.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * One JSON file with what Needle can't rebuild by scanning: play history, the tags you edited,
 * the extra fields you added, your artist notes, and your settings. Covers you picked are not included.
 * Songs are identified by their id on this phone, so a backup restores on the same phone and library.
 */
object Backup {
    private const val FORMAT = 1

    class Summary(val plays: Int, val edits: Int, val extras: Int, val notes: Int)

    private fun JSONObject.str(key: String): String? = if (isNull(key)) null else getString(key)
    private fun JSONObject.int(key: String): Int? = if (isNull(key)) null else getInt(key)

    suspend fun export(context: Context, movingBackground: Boolean): Pair<String, Summary> =
        withContext(Dispatchers.IO) {
            val db = NeedleDatabase.get(context)
            val plays = db.playDao().getAll()
            val edits = db.tagDao().getAll()
            val extras = db.extraTagDao().getAll()

            val root = JSONObject()
            root.put("app", "Needle")
            root.put("format", FORMAT)
            root.put("exportedAt", System.currentTimeMillis())
            root.put("settings", NeedleSettings.toJson().put("movingBackground", movingBackground))

            val playArr = JSONArray()
            plays.forEach { playArr.put(JSONArray().put(it.songId).put(it.playedAt).put(it.listenedMs)) }
            root.put("plays", playArr)

            val editArr = JSONArray()
            edits.forEach { e ->
                val o = JSONObject().put("songId", e.songId)
                e.title?.let { o.put("title", it) }
                e.artist?.let { o.put("artist", it) }
                e.album?.let { o.put("album", it) }
                e.genre?.let { o.put("genre", it) }
                e.year?.let { o.put("year", it) }
                e.trackNumber?.let { o.put("trackNumber", it) }
                editArr.put(o)
            }
            root.put("edits", editArr)

            val extraArr = JSONArray()
            extras.forEach { extraArr.put(JSONArray().put(it.songId).put(it.field).put(it.value)) }
            root.put("extras", extraArr)

            val notes = db.artistNoteDao().getAll()
            val noteArr = JSONArray()
            notes.forEach { noteArr.put(JSONArray().put(it.artistKey).put(it.note)) }
            root.put("notes", noteArr)

            root.toString() to Summary(plays.size, edits.size, extras.size, notes.size)
        }

    class Restored(val summary: Summary, val movingBackground: Boolean?)

    /** Adds to what is already there: plays are never doubled, edits and extra fields from the file win. */
    suspend fun restore(context: Context, text: String): Restored = withContext(Dispatchers.IO) {
        val root = JSONObject(text)
        require(root.optString("app") == "Needle") { "This file is not a Needle backup." }
        val db = NeedleDatabase.get(context)

        val have = HashSet<Pair<Long, Long>>()
        db.playDao().getAll().forEach { have.add(it.songId to it.playedAt) }
        val newPlays = ArrayList<PlayEvent>()
        root.optJSONArray("plays")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                val songId = a.getLong(0)
                val at = a.getLong(1)
                if (have.add(songId to at)) newPlays += PlayEvent(songId = songId, playedAt = at, listenedMs = a.optLong(2, 0L))
            }
        }
        db.playDao().insertAll(newPlays)

        val edits = ArrayList<TagEdit>()
        root.optJSONArray("edits")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                edits += TagEdit(
                    songId = o.getLong("songId"),
                    title = o.str("title"),
                    artist = o.str("artist"),
                    album = o.str("album"),
                    genre = o.str("genre"),
                    year = o.int("year"),
                    trackNumber = o.int("trackNumber")
                )
            }
        }
        db.tagDao().upsertAll(edits)

        val extras = ArrayList<ExtraTag>()
        root.optJSONArray("extras")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                extras += ExtraTag(songId = a.getLong(0), field = a.getString(1), value = a.getString(2))
            }
        }
        db.extraTagDao().upsertAll(extras)

        val notes = ArrayList<ArtistNote>()
        root.optJSONArray("notes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                notes += ArtistNote(artistKey = a.getString(0), note = a.getString(1))
            }
        }
        db.artistNoteDao().saveAll(notes)

        var glow: Boolean? = null
        root.optJSONObject("settings")?.let { s ->
            NeedleSettings.fromJson(s)
            if (s.has("movingBackground")) glow = s.optBoolean("movingBackground", true)
        }
        Restored(Summary(newPlays.size, edits.size, extras.size, notes.size), glow)
    }
}
