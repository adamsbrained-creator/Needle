package app.needle.music.data

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibraryViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)
    private val dao = db.songDao()
    private val prefs = app.getSharedPreferences("needle_prefs", Context.MODE_PRIVATE)

    private val _sort = MutableStateFlow(loadSort())
    val sort: StateFlow<SortOrder> = _sort

    /** The other tags of every song that has any (composer, comment, ...). */
    val extras: StateFlow<ExtraTags> =
        Library.observeExtras(db).stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** Songs played at least once (for "Played 14 of 24" on Now Playing). */
    val playedIds: StateFlow<Set<Long>> =
        db.playDao().observePlayedIds().map { it.toSet() }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptySet())

    /** Play count of every song that was played (song id -> plays). */
    val playCounts: StateFlow<Map<Long, Int>> =
        db.playDao().observePlayCounts().map { rows -> rows.associate { it.songId to it.plays } }.flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    // ---- playlists ----

    val playlistRows: StateFlow<List<Playlist>> =
        db.playlistDao().observePlaylists().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    val playlistEntries: StateFlow<List<PlaylistSong>> =
        db.playlistDao().observeEntries().stateIn(viewModelScope, SharingStarted.Eagerly, emptyList())

    init {
        // "Liked songs" always exists (this does nothing when it is already there).
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            db.playlistDao().insertPlaylist(Playlist(id = LIKED_ID, name = "Liked songs", kind = 1, createdAt = now, updatedAt = now))
        }
    }

    private suspend fun appendSongs(playlistId: Long, songIds: List<Long>, now: Long) {
        val dao = db.playlistDao()
        var position = dao.maxPosition(playlistId)
        dao.insertEntries(songIds.distinct().map { PlaylistSong(playlistId, it, ++position, now) })
        dao.touch(playlistId, now)
    }

    /** Makes a playlist with these songs in it. [onDone] gets its id. */
    fun createPlaylist(name: String, songIds: List<Long>, onDone: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val id = db.playlistDao().insertPlaylist(
                Playlist(name = name.trim().ifEmpty { "New playlist" }, kind = 0, createdAt = now, updatedAt = now)
            )
            if (songIds.isNotEmpty()) appendSongs(id, songIds, now)
            onDone(id)
        }
    }

    fun addToPlaylist(playlistId: Long, songIds: List<Long>) {
        viewModelScope.launch { appendSongs(playlistId, songIds, System.currentTimeMillis()) }
    }

    fun removeFromPlaylist(playlistId: Long, songIds: List<Long>) {
        viewModelScope.launch {
            songIds.chunked(500).forEach { db.playlistDao().removeSongs(playlistId, it) }
            db.playlistDao().touch(playlistId, System.currentTimeMillis())
        }
    }

    fun renamePlaylist(playlistId: Long, name: String) {
        viewModelScope.launch { db.playlistDao().rename(playlistId, name.trim().ifEmpty { "New playlist" }, System.currentTimeMillis()) }
    }

    fun deletePlaylist(playlistId: Long) {
        viewModelScope.launch {
            db.playlistDao().clear(playlistId)
            db.playlistDao().delete(playlistId)
        }
    }

    /** The heart: in Liked songs or not. */
    fun toggleLiked(songId: Long) {
        val liked = playlistEntries.value.any { it.playlistId == LIKED_ID && it.songId == songId }
        if (liked) removeFromPlaylist(LIKED_ID, listOf(songId)) else addToPlaylist(LIKED_ID, listOf(songId))
    }

    /** Your notes about artists, by lower-case artist name. */
    val artistNotes: StateFlow<Map<String, String>> =
        db.artistNoteDao().observeAll().map { rows -> rows.associate { it.artistKey to it.note } }
            .stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** An empty note removes it. */
    fun saveArtistNote(artist: String, note: String) {
        viewModelScope.launch {
            val key = artistKey(artist)
            if (note.isBlank()) db.artistNoteDao().delete(key) else db.artistNoteDao().save(ArtistNote(key, note.trim()))
        }
    }

    /** Sorted songs. null = still loading from the database, empty = nothing found. */
    val songs: StateFlow<List<Song>?> =
        combine(Library.observe(db), Library.observeExtras(db), _sort) { list, extras, order ->
            sortSongs(list, order, extras)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var isScanning by mutableStateOf(false); private set

    /** While Needle reads the tags inside the audio files: (songs done, songs in total). Otherwise null. */
    var tagProgress by mutableStateOf<Pair<Int, Int>?>(null); private set
    private var tagJob: Job? = null

    /** How many songs have had their file read so far. */
    val tagsReadCount: StateFlow<Int> =
        db.fileTagDao().observeScannedCount().stateIn(viewModelScope, SharingStarted.Eagerly, 0)

    /**
     * Reads the tags inside the audio files (composer, comment, lyrics ...) for songs not read yet.
     * With [all] it forgets what it read and starts over, for when the files were changed elsewhere.
     */
    fun readTags(all: Boolean = false) {
        if (tagJob?.isActive == true || !hasPermission) return
        tagJob = viewModelScope.launch {
            try {
                TagScanner.run(app, db, all) { done, total -> tagProgress = done to total }
            } finally {
                tagProgress = null
            }
        }
    }

    val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    var hasPermission by mutableStateOf(checkPermission()); private set

    fun refreshPermission() {
        hasPermission = checkPermission()
    }

    /** Tap the active field to flip its direction, tap another to switch to it. */
    fun setSort(field: SortField) {
        val current = _sort.value
        val next = if (current.field == field) current.copy(ascending = !current.ascending)
        else SortOrder(field, defaultAscending(field))
        _sort.value = next
        prefs.edit().putString("sort_field", next.field.name).putBoolean("sort_asc", next.ascending).apply()
    }

    fun scan() {
        if (isScanning || !hasPermission) return
        viewModelScope.launch {
            isScanning = true
            try {
                val found = withContext(Dispatchers.IO) { MediaStoreScanner.scan(app) }
                // Compare with the scan as stored (not with the edited songs), so edits never cause a rewrite.
                val stored = dao.getAllOnce()
                val unchanged = withContext(Dispatchers.Default) { stored.toSet() == found.toSet() }
                if (!unchanged) dao.replaceAll(found)
            } finally {
                isScanning = false
            }
            readTags() // songs that were not read yet; does nothing when all are
        }
    }

    private fun loadSort(): SortOrder {
        val field = runCatching {
            SortField.valueOf(prefs.getString("sort_field", null) ?: "TITLE")
        }.getOrDefault(SortField.TITLE)
        return SortOrder(field, prefs.getBoolean("sort_asc", defaultAscending(field)))
    }

    private fun checkPermission() =
        ContextCompat.checkSelfPermission(app, audioPermission) == PackageManager.PERMISSION_GRANTED
}
