package app.needle.music.data

import android.Manifest
import android.app.Application
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibraryViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)
    private val dao = db.songDao()
    private val prefs = app.getSharedPreferences("needle_prefs", Context.MODE_PRIVATE)

    private val _sort = MutableStateFlow(loadSort())
    val sort: StateFlow<SortOrder> = _sort

    /** The other tags of every song that has any (composer, comment, ...). */
    val extras: StateFlow<ExtraTags> =
        Library.observeExtras(db).stateIn(viewModelScope, SharingStarted.Eagerly, emptyMap())

    /** Sorted songs. null = still loading from the database, empty = nothing found. */
    val songs: StateFlow<List<Song>?> =
        combine(Library.observe(db), Library.observeExtras(db), _sort) { list, extras, order ->
            sortSongs(list, order, extras)
        }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var isScanning by mutableStateOf(false); private set

    val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    var hasPermission by mutableStateOf(checkPermission()); private set

    fun refreshPermission() {
        hasPermission = checkPermission()
    }

    /** Tap the active field to flip its direction, tap another to switch to it. */
    fun setSort(field: SortField) {
        val current = _sort.value
        val next = if (current.field == field) current.copy(ascending = !current.ascending)
        else SortOrder(field, defaultAscending(field))
        _sort.value = next
        prefs.edit().putString("sort_field", next.field.name).putBoolean("sort_asc", next.ascending).apply()
    }

    fun scan() {
        if (isScanning || !hasPermission) return
        viewModelScope.launch {
            isScanning = true
            try {
                val found = withContext(Dispatchers.IO) { MediaStoreScanner.scan(app) }
                // Compare with the scan as stored (not with the edited songs), so edits never cause a rewrite.
                val stored = dao.getAllOnce()
                val unchanged = withContext(Dispatchers.Default) { stored.toSet() == found.toSet() }
                if (!unchanged) dao.replaceAll(found)
            } finally {
                isScanning = false
            }
        }
    }

    private fun loadSort(): SortOrder {
        val field = runCatching {
            SortField.valueOf(prefs.getString("sort_field", null) ?: "TITLE")
        }.getOrDefault(SortField.TITLE)
        return SortOrder(field, prefs.getBoolean("sort_asc", defaultAscending(field)))
    }

    private fun checkPermission() =
        ContextCompat.checkSelfPermission(app, audioPermission) == PackageManager.PERMISSION_GRANTED
}
