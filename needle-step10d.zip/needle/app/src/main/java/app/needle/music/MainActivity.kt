package app.needle.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import app.needle.music.cast.CastHub
import app.needle.music.ui.GlowSettings
import app.needle.music.data.LibraryViewModel
import app.needle.music.ui.NeedleApp
import app.needle.music.ui.NeedleTheme

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* nothing to do */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        CastHub.init(this)
        GlowSettings.init(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NeedleTheme {
                NeedleApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // The person may have granted music access in system settings while we were in the background.
        ViewModelProvider(this)[LibraryViewModel::class.java].refreshPermission()
        CastHub.refreshPermission()
    }

    /** While casting, the phone's volume buttons change the volume of the device instead. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (CastHub.isConnected() && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            CastHub.stepVolume(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1, announce = true)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
