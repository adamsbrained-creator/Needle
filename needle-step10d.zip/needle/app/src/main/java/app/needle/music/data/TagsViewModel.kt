package app.needle.music.data

import android.app.Application
import android.graphics.Bitmap
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/** Saves what the tag editor collected. The audio files are never changed; edits live in Needle's database. */
class TagsViewModel(private val app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)
    private val tags = db.tagDao()
    private val extraTags = db.extraTagDao()

    /** Applies [changes] (and the new [cover], if any) to every song in [ids], then calls [onDone] on the main thread. */
    fun save(ids: List<Long>, changes: TagChanges, cover: Bitmap?, onDone: () -> Unit) {
        viewModelScope.launch {
            withContext(Dispatchers.IO) {
                val existing = tags.getAll().associateBy { it.songId }
                val updated = ids.map { id -> existing[id].withChanges(id, changes) }
                val (keep, drop) = updated.partition { !it.isEmpty() }
                if (keep.isNotEmpty()) tags.upsertAll(keep)
                if (drop.isNotEmpty()) tags.delete(drop.map { it.songId })
                saveExtras(ids, changes.extras)
                if (cover != null) CoverStore.save(app, ids, cover)
            }
            if (cover != null) ArtworkLoader.invalidate(ids)
            onDone()
        }
    }

    private suspend fun saveExtras(ids: List<Long>, extras: Map<String, String>) {
        if (extras.isEmpty()) return
        val set = extras.filterValues { it.isNotBlank() }
        val clear = extras.filterValues { it.isBlank() }.keys.toList()
        if (clear.isNotEmpty()) extraTags.delete(ids, clear)
        if (set.isNotEmpty()) {
            extraTags.upsertAll(ids.flatMap { id -> set.map { (field, value) -> ExtraTag(id, field, value.trim()) } })
        }
    }
}
