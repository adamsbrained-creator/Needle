package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * Tags the person changed in Needle. Only the changed fields are stored (null = "as in the file"),
 * so a rescan never loses them and clearing a field puts the file's own value back.
 * The audio files themselves are not touched.
 */
@Entity(tableName = "tag_edits")
data class TagEdit(
    @PrimaryKey val songId: Long,
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val genre: String? = null,
    val year: Int? = null,
    val trackNumber: Int? = null
) {
    fun isEmpty(): Boolean =
        title == null && artist == null && album == null && genre == null && year == null && trackNumber == null
}

@Dao
interface TagDao {
    @Query("SELECT * FROM tag_edits")
    fun observeAll(): Flow<List<TagEdit>>

    @Query("SELECT * FROM tag_edits")
    suspend fun getAll(): List<TagEdit>

    @Upsert
    suspend fun upsertAll(edits: List<TagEdit>)

    @Query("DELETE FROM tag_edits WHERE songId IN (:ids)")
    suspend fun delete(ids: List<Long>)
}

/** An edited album gets the id of an existing album with the same name, so it joins that album. */
private fun editedAlbumId(album: String): Long = -1L - (album.trim().lowercase().hashCode().toLong() and 0x7fffffffL)

/** The songs as the person sees them: the file's tags with Needle's edits on top. */
fun applyEdits(songs: List<Song>, edits: List<TagEdit>): List<Song> {
    if (edits.isEmpty()) return songs
    val byId = edits.associateBy { it.songId }

    // Album name -> the id other (unedited) songs use for it.
    val knownAlbums: Map<String, Long> by lazy {
        val map = HashMap<String, Long>()
        for (s in songs) if (s.id !in byId || byId[s.id]?.album == null) map.putIfAbsent(s.album.lowercase(), s.albumId)
        map
    }

    return songs.map { s ->
        val e = byId[s.id] ?: return@map s
        val album = e.album ?: s.album
        s.copy(
            title = e.title ?: s.title,
            artist = e.artist ?: s.artist,
            album = album,
            albumId = if (e.album != null) knownAlbums[album.lowercase()] ?: editedAlbumId(album) else s.albumId,
            genre = e.genre ?: s.genre,
            year = e.year ?: s.year,
            trackNumber = e.trackNumber ?: s.trackNumber
        )
    }
}

/**
 * What the editor changed. null = that field was not touched, "" = cleared (back to the file's value).
 * Fields are text because that is what the person typed.
 */
data class TagChanges(
    val title: String? = null,
    val artist: String? = null,
    val album: String? = null,
    val genre: String? = null,
    val year: String? = null,
    val track: String? = null,
    /** field -> new value; "" means remove the field. Only fields that were changed are in here. */
    val extras: Map<String, String> = emptyMap()
)

private fun pickText(touched: String?, old: String?): String? =
    if (touched == null) old else touched.trim().ifBlank { null }

private fun pickNumber(touched: String?, old: Int?): Int? =
    if (touched == null) old else touched.trim().toIntOrNull()?.takeIf { it > 0 }

fun TagEdit?.withChanges(songId: Long, c: TagChanges): TagEdit {
    val base = this ?: TagEdit(songId)
    return base.copy(
        title = pickText(c.title, base.title),
        artist = pickText(c.artist, base.artist),
        album = pickText(c.album, base.album),
        genre = pickText(c.genre, base.genre),
        year = pickNumber(c.year, base.year),
        trackNumber = pickNumber(c.track, base.trackNumber)
    )
}
