package app.needle.music.playback

import android.os.Bundle
import androidx.media3.session.SessionCommand

/**
 * The one custom message the UI sends to the playback service:
 * "play this ordered list of song ids, starting at this position".
 * Ids are tiny (8 bytes each), so even a huge library is a small message,
 * and the service builds the real queue itself.
 */
object QueueCommands {
    const val PLAY_QUEUE = "app.needle.music.PLAY_QUEUE"
    const val KEY_IDS = "ids"
    const val KEY_START = "start"
    /** Optional. If present, forces shuffle on/off. If absent, the current shuffle mode is kept. */
    const val KEY_SHUFFLE = "shuffle"

    val playQueue = SessionCommand(PLAY_QUEUE, Bundle.EMPTY)
}
