package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.Query
import androidx.room.Upsert
import kotlinx.coroutines.flow.Flow

/**
 * Any tag beyond the core ones (title, artist, album, genre, year, track), saved by Needle:
 * one row per song and field. The [field] names are Mp3tag's own, so that reading and writing
 * the audio files can use the same names later.
 */
@Entity(tableName = "extra_tags", primaryKeys = ["songId", "field"])
data class ExtraTag(
    val songId: Long,
    val field: String,
    val value: String
)

@Dao
interface ExtraTagDao {
    @Query("SELECT * FROM extra_tags")
    fun observeAll(): Flow<List<ExtraTag>>

    @Upsert
    suspend fun upsertAll(tags: List<ExtraTag>)

    @Query("DELETE FROM extra_tags WHERE songId IN (:ids) AND field IN (:fields)")
    suspend fun delete(ids: List<Long>, fields: List<String>)
}

/** song id -> (field -> value). Only fields that have a value are in here. */
typealias ExtraTags = Map<Long, Map<String, String>>

fun groupExtras(rows: List<ExtraTag>): ExtraTags =
    rows.groupBy { it.songId }.mapValues { (_, list) -> list.associate { it.field to it.value } }

// ---- the list of fields the editor offers -------------------------------------------------

enum class FieldGroup(val label: String) {
    PEOPLE("People"),
    SORT("Sort names"),
    ALBUM("Album structure"),
    DATES("Dates"),
    DESCRIPTIVE("Descriptive"),
    IDS("Identifiers"),
    LINKS("Links")
}

enum class FieldKind { TEXT, LONG_TEXT, NUMBER, FLAG }

class FieldDef(
    val key: String,
    val label: String,
    val group: FieldGroup,
    val kind: FieldKind = FieldKind.TEXT,
    val hint: String = ""
)

object TagFields {
    private fun f(key: String, label: String, group: FieldGroup, kind: FieldKind = FieldKind.TEXT, hint: String = "") =
        FieldDef(key, label, group, kind, hint)

    val all: List<FieldDef> = listOf(
        // People
        f("ALBUMARTIST", "Album artist", FieldGroup.PEOPLE),
        f("COMPOSER", "Composer", FieldGroup.PEOPLE),
        f("CONDUCTOR", "Conductor", FieldGroup.PEOPLE),
        f("LYRICIST", "Lyricist", FieldGroup.PEOPLE),
        f("MIXARTIST", "Remixer", FieldGroup.PEOPLE),
        f("ORIGARTIST", "Original artist", FieldGroup.PEOPLE),
        f("ORIGLYRICIST", "Original lyricist", FieldGroup.PEOPLE),
        f("NARRATOR", "Narrator", FieldGroup.PEOPLE),
        f("INVOLVEDPEOPLE", "Involved people", FieldGroup.PEOPLE, FieldKind.LONG_TEXT, "Role:Person;"),
        f("MUSICIANCREDITS", "Musician credits", FieldGroup.PEOPLE, FieldKind.LONG_TEXT, "Drums:Name;"),

        // Sort names (Needle uses these when sorting)
        f("TITLESORT", "Title sort", FieldGroup.SORT),
        f("ARTISTSORT", "Artist sort", FieldGroup.SORT),
        f("ALBUMSORT", "Album sort", FieldGroup.SORT),
        f("ALBUMARTISTSORT", "Album artist sort", FieldGroup.SORT),
        f("COMPOSERSORT", "Composer sort", FieldGroup.SORT),

        // Album structure
        f("DISCNUMBER", "Disc", FieldGroup.ALBUM, hint = "1/2"),
        f("SUBTITLE", "Subtitle", FieldGroup.ALBUM),
        f("SETSUBTITLE", "Disc subtitle", FieldGroup.ALBUM),
        f("GROUPING", "Grouping", FieldGroup.ALBUM),
        f("CONTENTGROUP", "Content group", FieldGroup.ALBUM),
        f("COMPILATION", "Compilation", FieldGroup.ALBUM, FieldKind.FLAG),
        f("WORK", "Work", FieldGroup.ALBUM),
        f("MOVEMENTNAME", "Movement name", FieldGroup.ALBUM),
        f("MOVEMENT", "Movement number", FieldGroup.ALBUM, FieldKind.NUMBER),
        f("MOVEMENTTOTAL", "Movements in total", FieldGroup.ALBUM, FieldKind.NUMBER),

        // Dates
        f("RELEASETIME", "Release date", FieldGroup.DATES, hint = "2026-03-14"),
        f("ORIGYEAR", "Original year", FieldGroup.DATES, FieldKind.NUMBER),
        f("ORIGALBUM", "Original album", FieldGroup.DATES),

        // Descriptive
        f("COMMENT", "Comment", FieldGroup.DESCRIPTIVE, FieldKind.LONG_TEXT),
        f("DESCRIPTION", "Description", FieldGroup.DESCRIPTIVE, FieldKind.LONG_TEXT),
        f("MOOD", "Mood", FieldGroup.DESCRIPTIVE),
        f("BPM", "BPM", FieldGroup.DESCRIPTIVE, FieldKind.NUMBER),
        f("INITIALKEY", "Initial key", FieldGroup.DESCRIPTIVE, hint = "Am"),
        f("LANGUAGE", "Language", FieldGroup.DESCRIPTIVE, hint = "eng"),
        f("UNSYNCEDLYRICS", "Lyrics", FieldGroup.DESCRIPTIVE, FieldKind.LONG_TEXT),
        f("RATING", "Rating", FieldGroup.DESCRIPTIVE, FieldKind.NUMBER, "1 to 5"),
        f("PUBLISHER", "Publisher", FieldGroup.DESCRIPTIVE),
        f("COPYRIGHT", "Copyright", FieldGroup.DESCRIPTIVE),
        f("CATALOGNUMBER", "Catalog number", FieldGroup.DESCRIPTIVE),
        f("BARCODE", "Barcode", FieldGroup.DESCRIPTIVE),
        f("ISRC", "ISRC", FieldGroup.DESCRIPTIVE),
        f("MEDIATYPE", "Media type", FieldGroup.DESCRIPTIVE),

        // Identifiers
        f("ACOUSTID_ID", "AcoustID", FieldGroup.IDS),
        f("ACOUSTID_FINGERPRINT", "AcoustID fingerprint", FieldGroup.IDS),
        f("MUSICBRAINZ_ALBUMARTISTID", "MusicBrainz album artist ID", FieldGroup.IDS),
        f("MUSICBRAINZ_ALBUMID", "MusicBrainz album ID", FieldGroup.IDS),
        f("MUSICBRAINZ_ALBUMRELEASECOUNTRY", "MusicBrainz release country", FieldGroup.IDS),
        f("MUSICBRAINZ_ALBUMSTATUS", "MusicBrainz release status", FieldGroup.IDS),
        f("MUSICBRAINZ_ALBUMTYPE", "MusicBrainz release type", FieldGroup.IDS),
        f("MUSICBRAINZ_ARTISTID", "MusicBrainz artist ID", FieldGroup.IDS),
        f("MUSICBRAINZ_DISCID", "MusicBrainz disc ID", FieldGroup.IDS),
        f("MUSICBRAINZ_ORIGINALALBUMID", "MusicBrainz original album ID", FieldGroup.IDS),
        f("MUSICBRAINZ_ORIGINALARTISTID", "MusicBrainz original artist ID", FieldGroup.IDS),
        f("MUSICBRAINZ_RELEASEGROUPID", "MusicBrainz release group ID", FieldGroup.IDS),
        f("MUSICBRAINZ_RELEASETRACKID", "MusicBrainz release track ID", FieldGroup.IDS),
        f("MUSICBRAINZ_TRACKID", "MusicBrainz track ID", FieldGroup.IDS),
        f("MUSICBRAINZ_TRMID", "MusicBrainz TRM ID", FieldGroup.IDS),
        f("MUSICBRAINZ_WORKID", "MusicBrainz work ID", FieldGroup.IDS),
        f("UNIQUEFILEID", "Unique file ID", FieldGroup.IDS),
        f("ITUNESALBUMID", "iTunes album ID", FieldGroup.IDS),
        f("ITUNESARTISTID", "iTunes artist ID", FieldGroup.IDS),
        f("ITUNESCATALOGID", "iTunes catalog ID", FieldGroup.IDS),
        f("ITUNESCOMPOSERID", "iTunes composer ID", FieldGroup.IDS),
        f("ITUNESCOUNTRYID", "iTunes country ID", FieldGroup.IDS),
        f("ITUNESGENREID", "iTunes genre ID", FieldGroup.IDS),

        // Links
        f("WWW", "Website", FieldGroup.LINKS),
        f("WWWARTIST", "Artist website", FieldGroup.LINKS),
        f("WWWAUDIOFILE", "Audio file website", FieldGroup.LINKS),
        f("WWWAUDIOSOURCE", "Audio source website", FieldGroup.LINKS),
        f("WWWCOMMERCIALINFO", "Commercial info website", FieldGroup.LINKS),
        f("WWWCOPYRIGHT", "Copyright website", FieldGroup.LINKS),
        f("WWWPAYMENT", "Payment website", FieldGroup.LINKS),
        f("WWWPUBLISHER", "Publisher website", FieldGroup.LINKS),
        f("WWWRADIOPAGE", "Radio page", FieldGroup.LINKS)
    )

    private val byKey = all.associateBy { it.key }
    private val order = all.withIndex().associate { it.value.key to it.index }

    /** null for a custom field (a name the person made up). */
    fun find(key: String): FieldDef? = byKey[key]

    /** Known fields in the order above, then custom ones A to Z. */
    fun sortKeys(keys: Collection<String>): List<String> =
        keys.sortedWith(compareBy({ order[it] ?: Int.MAX_VALUE }, { it.lowercase() }))
}
