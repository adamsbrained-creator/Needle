package app.needle.music.ui

import android.content.Context
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer

/**
 * The moving glow behind every page, taken from the Needle player's background:
 * a violet wash from the top corner and three soft colour blobs (violet, pink, green) that drift slowly.
 *
 * Change [GLOW_STRENGTH] to make the whole thing stronger or calmer: 1 = as in the player,
 * 0.6 = quieter, 0 = off (plain dark background).
 */
private const val GLOW_STRENGTH = 1f

private val WashTop = Color(0xFF4B3A72)    // violet, the player's "primary container"
private val BlobViolet = Palette.Accent
private val BlobPink = Palette.Pink
private val BlobGreen = Color(0xFF8FBF8F) // the soft green

/** The "Moving background" switch in Settings. Saved, and read while drawing so toggling never recomposes pages. */
object GlowSettings {
    private var prefs: android.content.SharedPreferences? = null

    val enabled = mutableStateOf(true)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        enabled.value = p.getBoolean("moving_background", true)
    }

    fun set(on: Boolean) {
        enabled.value = on
        prefs?.edit()?.putBoolean("moving_background", on)?.apply()
    }
}

private val StillDrift = mutableStateOf(0f)

/** One shared clock, so the root background and the pages sliding over it always show the same motion. */
private val LocalGlowDrift = staticCompositionLocalOf<State<Float>> { StillDrift }

@Composable
fun GlowProvider(content: @Composable () -> Unit) {
    val transition = rememberInfiniteTransition(label = "needle_glow")
    // When the glow is off nothing animates at all.
    val drift: State<Float> = if (GlowSettings.enabled.value) {
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
            label = "drift"
        )
    } else {
        StillDrift
    }
    CompositionLocalProvider(LocalGlowDrift provides drift) { content() }
}

/**
 * The glow itself: dark base plus the drifting blobs, in a layer of its own. Put it as the first child of a
 * box ([matchParentSize]) so it sits behind the content. Because it is a separate layer, the animation only
 * redraws the glow and never the page on top of it. The drift is read while drawing, so nothing recomposes.
 */
@Composable
fun GlowLayer(modifier: Modifier = Modifier) {
    val drift = LocalGlowDrift.current
    Box(
        modifier
            .graphicsLayer { }
            .background(Palette.Bg)
            .drawBehind { if (GlowSettings.enabled.value) drawGlow(drift.value, Palette.Bg) }
    )
}

/** A full page (or a page that slides over others) with the glow behind it. */
@Composable
fun GlowSurface(modifier: Modifier = Modifier, content: @Composable () -> Unit) {
    Box(modifier) {
        GlowLayer(Modifier.matchParentSize())
        content()
    }
}

private fun DrawScope.drawGlow(drift: Float, base: Color) {
    if (GLOW_STRENGTH <= 0f) return
    val w = size.width
    val h = size.height
    fun a(alpha: Float) = (alpha * GLOW_STRENGTH).coerceIn(0f, 1f)

    drawRect(Brush.linearGradient(listOf(WashTop.copy(alpha = a(0.55f)), base), start = Offset(0f, 0f), end = Offset(w, h)))
    val c1 = Offset(w * (0.1f + 0.3f * drift), h * 0.3f)
    drawRect(Brush.radialGradient(listOf(BlobViolet.copy(alpha = a(0.45f)), Color.Transparent), center = c1, radius = w * 0.9f))
    val c2 = Offset(w * (0.95f - 0.3f * drift), h * 0.55f)
    drawRect(Brush.radialGradient(listOf(BlobPink.copy(alpha = a(0.30f)), Color.Transparent), center = c2, radius = w * 0.8f))
    val c3 = Offset(w * 0.4f, h * (0.85f - 0.1f * drift))
    drawRect(Brush.radialGradient(listOf(BlobGreen.copy(alpha = a(0.25f)), Color.Transparent), center = c3, radius = w * 0.7f))
    // Settle back to the plain background at the bottom, behind the dock.
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, base), startY = h * 0.85f, endY = h))
}
