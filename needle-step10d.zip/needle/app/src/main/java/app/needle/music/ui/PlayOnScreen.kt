package app.needle.music.ui

import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.StartOffset
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.cast.CastDevice
import app.needle.music.cast.CastPhase
import app.needle.music.cast.CastState
import app.needle.music.cast.DeviceKind

// ---- small pieces shared with the device settings page ---------------------------------------

internal fun Modifier.glass(shape: Shape): Modifier = this
    .clip(shape)
    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))))
    .border(1.dp, Color.White.copy(alpha = 0.12f), shape)

@Composable
internal fun RoundIconButton(
    icon: NeedleIcon,
    onClick: () -> Unit,
    size: Dp = 34.dp,
    iconSize: Dp = 17.dp,
    background: Color = Color.White.copy(alpha = 0.1f)
) {
    Box(
        Modifier.size(size).clip(CircleShape).background(background).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        NeedleIconView(icon, Palette.Text, size = iconSize)
    }
}

/** The on/off switch from the mockup: a 48 x 29 pill with a white knob. */
@Composable
internal fun NeedleSwitch(checked: Boolean, onChange: (Boolean) -> Unit) {
    val knobX by animateDpAsState(if (checked) 21.dp else 3.dp, label = "knob")
    Box(
        Modifier
            .size(width = 48.dp, height = 29.dp)
            .clip(CircleShape)
            .background(if (checked) Palette.Accent else Color(0xFF555558))
            .clickable { onChange(!checked) }
    ) {
        Box(Modifier.offset(x = knobX, y = 3.dp).size(23.dp).clip(CircleShape).background(Color.White))
    }
}

/** Three little bars that dance while music plays on the selected device. */
@Composable
private fun EqBars(active: Boolean) {
    val t = rememberInfiniteTransition(label = "eq")
    val a by t.animateFloat(5f, 20f, infiniteRepeatable(tween(500), RepeatMode.Reverse, StartOffset(0)), label = "a")
    val b by t.animateFloat(5f, 20f, infiniteRepeatable(tween(500), RepeatMode.Reverse, StartOffset(160)), label = "b")
    val c by t.animateFloat(5f, 20f, infiniteRepeatable(tween(500), RepeatMode.Reverse, StartOffset(320)), label = "c")
    val heights = if (active) listOf(a, b, c) else listOf(8f, 13f, 6f)
    Row(
        Modifier.height(20.dp).padding(horizontal = 4.dp),
        horizontalArrangement = Arrangement.spacedBy(3.dp),
        verticalAlignment = Alignment.Bottom
    ) {
        heights.forEach { h -> Box(Modifier.width(4.dp).height(h.dp).clip(RoundedCornerShape(2.dp)).background(Color.White)) }
    }
}

private fun iconFor(kind: DeviceKind) = when (kind) {
    DeviceKind.TV -> NeedleIcon.TV
    DeviceKind.PC -> NeedleIcon.PC
    DeviceKind.SPEAKER -> NeedleIcon.SPEAKER
}

@Composable
private fun DeviceCard(
    icon: NeedleIcon,
    title: String,
    subtitle: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    actions: @Composable RowScope.() -> Unit = {}
) {
    val shape = RoundedCornerShape(24.dp)
    val glow = Palette.Accent.copy(alpha = 0.3f)
    Row(
        modifier
            .fillMaxWidth()
            .padding(bottom = 10.dp)
            .then(if (selected) Modifier.shadow(14.dp, shape, ambientColor = glow, spotColor = glow) else Modifier)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    if (selected) listOf(Palette.Accent.copy(alpha = 0.45f), Color.White.copy(alpha = 0.07f))
                    else listOf(Color.White.copy(alpha = 0.14f), Color.White.copy(alpha = 0.04f))
                )
            )
            .border(1.dp, if (selected) Palette.Accent.copy(alpha = 0.7f) else Color.White.copy(alpha = 0.12f), shape)
            .clickable(onClick = onClick)
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(
            Modifier.size(46.dp).clip(RoundedCornerShape(15.dp)).background(Color.White.copy(alpha = 0.1f)),
            contentAlignment = Alignment.Center
        ) {
            NeedleIconView(icon, Palette.Text, size = 22.dp)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) { actions() }
    }
}

// ---- the page --------------------------------------------------------------------------------

/** "Play on": pick where the music plays. This phone, or any DLNA / UPnP device on the Wi-Fi. */
@Composable
fun PlayOnScreen(
    devices: List<CastDevice>,
    hidden: Set<String>,
    scanning: Boolean,
    cast: CastState,
    isPlaying: Boolean,
    volumeStep: Int,
    permissionGranted: Boolean,
    permissionDenied: Boolean,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onRefresh: () -> Unit,
    onUsePhone: () -> Unit,
    onUseDevice: (CastDevice) -> Unit,
    onHide: (CastDevice) -> Unit,
    onUnhide: (CastDevice) -> Unit,
    onSettings: (CastDevice) -> Unit,
    onVolume: (Int) -> Unit,
    onRequestPermission: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showInfo by remember { mutableStateOf(false) }
    var showHidden by remember { mutableStateOf(false) }
    val visible = devices.filter { it.udn !in hidden }
    val hiddenDevices = devices.filter { it.udn in hidden }
    val onPhone = cast.phase == CastPhase.LOCAL

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                RoundIconButton(NeedleIcon.REFRESH, onRefresh, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
                RoundIconButton(NeedleIcon.INFO, { showInfo = true }, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
            }
        }

        Spacer(Modifier.height(16.dp))
        Text("Play on", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp)
        Text("Pick where your music plays.", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(18.dp))

        DeviceCard(
            icon = NeedleIcon.PHONE,
            title = "This phone",
            subtitle = if (onPhone) "Local device · ${if (isPlaying) "Playing" else "Ready"}" else "Local device",
            selected = onPhone,
            onClick = onUsePhone
        ) { if (onPhone) EqBars(isPlaying) }

        if (!permissionGranted) {
            Column(Modifier.fillMaxWidth().glass(RoundedCornerShape(24.dp)).padding(16.dp)) {
                Text("Allow local network access", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.height(4.dp))
                Text(
                    "Needle needs it to find speakers, TVs and PCs on your Wi-Fi, and to stream your music to them.",
                    color = Palette.Muted, fontSize = 12.5.sp, lineHeight = 17.sp
                )
                Spacer(Modifier.height(12.dp))
                PillButton(if (permissionDenied) "Open app settings" else "Allow access", onRequestPermission, filled = true)
            }
        } else {
            visible.forEach { d -> DeviceRow(d, cast, isPlaying, onUseDevice, onSettings, onHide, onUnhide, isHidden = false) }

            Row(Modifier.padding(horizontal = 4.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
                if (scanning) {
                    CircularProgressIndicator(
                        Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp, trackColor = Color.White.copy(alpha = 0.3f)
                    )
                    Spacer(Modifier.width(10.dp))
                    Text("Looking for more devices on your network…", color = Palette.Muted, fontSize = 12.5.sp)
                } else if (visible.isEmpty()) {
                    Text(
                        "No devices found. Check that your phone and the device are on the same Wi-Fi, then tap refresh.",
                        color = Palette.Muted, fontSize = 12.5.sp, lineHeight = 17.sp
                    )
                } else {
                    Text("Tap refresh to look again.", color = Palette.Muted, fontSize = 12.5.sp)
                }
            }

            if (hiddenDevices.isNotEmpty()) {
                PillButton(
                    if (showHidden) "Hide hidden devices"
                    else if (hiddenDevices.size == 1) "1 hidden device" else "${hiddenDevices.size} hidden devices",
                    onClick = { showHidden = !showHidden }
                )
                Spacer(Modifier.height(14.dp))
                if (showHidden) {
                    hiddenDevices.forEach { d -> DeviceRow(d, cast, isPlaying, onUseDevice, onSettings, onHide, onUnhide, isHidden = true) }
                }
            }

            if (cast.phase == CastPhase.CONNECTED) {
                Spacer(Modifier.height(4.dp))
                Row(
                    Modifier.fillMaxWidth().glass(RoundedCornerShape(20.dp)).padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(Modifier.weight(1f)) {
                        Text("Volume", color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold)
                        Text("Changes by $volumeStep · phone buttons work too", color = Palette.Muted, fontSize = 12.sp)
                    }
                    RoundIconButton(NeedleIcon.MINUS, { onVolume(-1) })
                    Text(
                        if (cast.volume >= 0) "${cast.volume}" else "–",
                        color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, modifier = Modifier.width(46.dp)
                    )
                    RoundIconButton(NeedleIcon.PLUS, { onVolume(1) })
                }
            }
        }
    }

    if (showInfo) {
        AlertDialog(
            onDismissRequest = { showInfo = false },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted,
            title = { Text("Play on") },
            text = {
                Text(
                    "Needle finds DLNA / UPnP players on your Wi-Fi: Xbox, smart TVs, Kodi, many speakers and PCs. " +
                        "Pick one and your music streams to it straight from this phone. " +
                        "Keep Needle open in the background while you listen, and keep both devices on the same network."
                )
            },
            confirmButton = { TextButton(onClick = { showInfo = false }) { Text("Got it", color = Palette.Accent) } }
        )
    }
}

@Composable
private fun DeviceRow(
    d: CastDevice,
    cast: CastState,
    isPlaying: Boolean,
    onUse: (CastDevice) -> Unit,
    onSettings: (CastDevice) -> Unit,
    onHide: (CastDevice) -> Unit,
    onUnhide: (CastDevice) -> Unit,
    isHidden: Boolean
) {
    val active = cast.device?.udn == d.udn && cast.phase != CastPhase.LOCAL
    val status = when {
        active && cast.phase == CastPhase.CONNECTING -> " · Connecting…"
        active -> if (isPlaying) " · Playing" else " · Connected"
        else -> ""
    }
    DeviceCard(
        icon = iconFor(d.kind),
        title = d.name,
        subtitle = d.subtitle + status,
        selected = active,
        onClick = { if (!isHidden) onUse(d) },
        modifier = if (isHidden) Modifier.alpha(0.6f) else Modifier
    ) {
        if (active) EqBars(isPlaying)
        if (isHidden) {
            RoundIconButton(NeedleIcon.EYE, { onUnhide(d) })
        } else {
            RoundIconButton(NeedleIcon.GEAR, { onSettings(d) })
            if (!active) RoundIconButton(NeedleIcon.EYE_OFF, { onHide(d) })
        }
    }
}
