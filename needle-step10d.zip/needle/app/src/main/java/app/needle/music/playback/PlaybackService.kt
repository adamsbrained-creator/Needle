package app.needle.music.playback

import android.app.PendingIntent
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import androidx.core.app.TaskStackBuilder
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.Timeline
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.ShuffleOrder.DefaultShuffleOrder
import androidx.media3.session.MediaSession
import androidx.media3.session.MediaSessionService
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionResult
import app.needle.music.MainActivity
import app.needle.music.cast.CastEngine
import app.needle.music.cast.CastHub
import app.needle.music.data.CoverStore
import app.needle.music.data.Library
import app.needle.music.data.NeedleDatabase
import app.needle.music.data.PlayEvent
import app.needle.music.data.Song
import com.google.common.util.concurrent.ListenableFuture
import com.google.common.util.concurrent.SettableFuture
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

/**
 * The audio engine AND the owner of the queue.
 * The UI only asks for things ("play these songs", shuffle, repeat, jump, remove);
 * the queue itself lives here, so it survives the UI closing, and it is saved to disk
 * so it survives the whole app being killed.
 */
class PlaybackService : MediaSessionService() {

    private var session: MediaSession? = null
    private lateinit var player: ExoPlayer
    private var castEngine: CastEngine? = null
    private val db by lazy { NeedleDatabase.get(this) }
    private val playDao by lazy { db.playDao() }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private val handler = Handler(Looper.getMainLooper())

    // ---- saving ----------------------------------------------------------------------

    private val saveQueueRunnable = Runnable { saveQueue() }

    private val positionTicker = object : Runnable {
        override fun run() {
            saveState()
            if (player.isPlaying) handler.postDelayed(this, 15_000)
        }
    }

    private val persistListener = object : Player.Listener {
        override fun onTimelineChanged(timeline: Timeline, reason: Int) {
            // The queue changed: save it a moment later (batches bursts of changes).
            handler.removeCallbacks(saveQueueRunnable)
            handler.postDelayed(saveQueueRunnable, 1_000)
        }

        override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
            saveState()
            beginTracking(mediaItem?.mediaId?.toLongOrNull())
        }

        override fun onIsPlayingChanged(isPlaying: Boolean) {
            handler.removeCallbacks(positionTicker)
            saveState()
            if (isPlaying) {
                handler.postDelayed(positionTicker, 15_000)
                resumeClock()
            } else {
                pauseClock()
            }
        }

        override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
            if (shuffleModeEnabled) reshuffleCurrentFirst()
            saveState()
        }

        override fun onRepeatModeChanged(repeatMode: Int) = saveState()
    }

    private fun saveState() {
        val item = player.currentMediaItem ?: return
        val id = item.mediaId.toLongOrNull() ?: return
        QueueStore.saveState(this, id, player.currentPosition, player.shuffleModeEnabled, player.repeatMode)
    }

    private fun saveQueue() {
        val count = player.mediaItemCount
        if (count == 0) return
        val ids = List(count) { player.getMediaItemAt(it).mediaId }
        scope.launch(Dispatchers.IO) { QueueStore.saveIds(this@PlaybackService, ids) }
    }

    // ---- play history ------------------------------------------------------------------
    // A song counts as played once it has actually been heard for 30 seconds
    // (or half of it, for very short songs). Skipping through a list counts nothing.

    private var trackedId: Long? = null
    private var trackedListenedMs = 0L
    private var trackedSince = 0L        // elapsedRealtime when it last started playing, 0 = paused
    private var trackedCounted = false
    private var trackedRowId = 0L        // the saved play, once it is in the database
    private var trackedGeneration = 0    // changes with every song, so late database replies are ignored
    private val countRunnable = Runnable { countPlay() }

    private fun beginTracking(songId: Long?) {
        pauseClock() // saves the time of the song we are leaving
        trackedGeneration++
        trackedId = songId
        trackedListenedMs = 0L
        trackedCounted = false
        trackedRowId = 0L
        if (player.isPlaying) resumeClock()
    }

    private fun resumeClock() {
        if (trackedId == null || trackedSince != 0L) return
        trackedSince = SystemClock.elapsedRealtime()
        if (!trackedCounted) {
            val duration = player.duration
            val threshold = if (duration == C.TIME_UNSET || duration <= 0L) 30_000L else minOf(30_000L, duration / 2)
            handler.removeCallbacks(countRunnable)
            handler.postDelayed(countRunnable, (threshold - trackedListenedMs).coerceAtLeast(0L))
        }
    }

    private fun pauseClock() {
        handler.removeCallbacks(countRunnable)
        if (trackedSince != 0L) {
            trackedListenedMs += SystemClock.elapsedRealtime() - trackedSince
            trackedSince = 0L
        }
        // Keep the saved play's "listened" time up to date.
        val row = trackedRowId
        if (trackedCounted && row != 0L) {
            val ms = trackedListenedMs
            scope.launch(Dispatchers.IO) { playDao.setListened(row, ms) }
        }
    }

    private fun countPlay() {
        val songId = trackedId ?: return
        if (trackedCounted) return
        trackedCounted = true
        val heardSoFar = trackedListenedMs +
            if (trackedSince != 0L) SystemClock.elapsedRealtime() - trackedSince else 0L
        val generation = trackedGeneration
        val event = PlayEvent(songId = songId, playedAt = System.currentTimeMillis(), listenedMs = heardSoFar)
        scope.launch {
            val rowId = withContext(Dispatchers.IO) { playDao.insert(event) }
            if (generation == trackedGeneration) trackedRowId = rowId
        }
    }

    // ---- shuffle ---------------------------------------------------------------------

    /** New random order, but the song that is playing right now stays first. */
    private fun reshuffleCurrentFirst() {
        val n = player.mediaItemCount
        if (n < 2) return
        val current = player.currentMediaItemIndex
        val order = IntArray(n)
        order[0] = current
        var k = 1
        for (i in (0 until n).shuffled()) if (i != current) order[k++] = i
        player.setShuffleOrder(DefaultShuffleOrder(order, System.nanoTime()))
    }

    // ---- commands from the UI --------------------------------------------------------

    private val callback = object : MediaSession.Callback {
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            val commands = MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS
                .buildUpon()
                .add(QueueCommands.playQueue)
                .build()
            return MediaSession.ConnectionResult.AcceptedResultBuilder(session)
                .setAvailableSessionCommands(commands)
                .build()
        }

        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> =
            if (customCommand.customAction == QueueCommands.PLAY_QUEUE) {
                handlePlayQueue(args)
            } else {
                super.onCustomCommand(session, controller, customCommand, args)
            }
    }

    private fun handlePlayQueue(args: Bundle): ListenableFuture<SessionResult> {
        val ids = args.getLongArray(QueueCommands.KEY_IDS) ?: LongArray(0)
        val start = args.getInt(QueueCommands.KEY_START, 0)
        val shuffle: Boolean? =
            if (args.containsKey(QueueCommands.KEY_SHUFFLE)) args.getBoolean(QueueCommands.KEY_SHUFFLE) else null

        val result = SettableFuture.create<SessionResult>()
        scope.launch {
            try {
                val (byId, covers) = loadLibraryForQueue()
                val items = ids.asList().mapNotNull { id -> byId[id]?.let { it.toMediaItem(covers[it.id]) } }
                if (items.isNotEmpty()) {
                    val startId = ids.getOrNull(start)?.toString()
                    val startIndex = items.indexOfFirst { it.mediaId == startId }.coerceAtLeast(0)
                    player.setMediaItems(items, startIndex, C.TIME_UNSET)
                    if (shuffle != null) player.shuffleModeEnabled = shuffle
                    if (player.shuffleModeEnabled) reshuffleCurrentFirst()
                    player.prepare()
                    player.play()
                }
                result.set(SessionResult(SessionResult.RESULT_SUCCESS))
            } catch (e: Exception) {
                result.set(SessionResult(SessionResult.RESULT_ERROR_UNKNOWN))
            }
        }
        return result
    }

    /** All songs (with the person's tag edits) by id, plus the covers they picked, by song id. */
    private suspend fun loadLibraryForQueue(): Pair<Map<Long, Song>, Map<Long, ByteArray>> {
        val byId = Library.load(db).associateBy { it.id }
        val covers = withContext(Dispatchers.IO) {
            CoverStore.songIds(this@PlaybackService).mapNotNull { id ->
                CoverStore.readBytes(this@PlaybackService, id)?.let { id to it }
            }.toMap()
        }
        return byId to covers
    }

    // ---- restoring after the app was killed -------------------------------------------

    private fun restoreQueue() {
        scope.launch {
            val saved = withContext(Dispatchers.IO) { QueueStore.load(this@PlaybackService) } ?: return@launch
            val (byId, covers) = loadLibraryForQueue()
            // If the person already started something while we were loading, leave it alone.
            if (player.mediaItemCount > 0) return@launch

            val items = saved.ids.mapNotNull { id -> byId[id]?.let { it.toMediaItem(covers[it.id]) } }
            if (items.isEmpty()) return@launch

            val index = items.indexOfFirst { it.mediaId == saved.currentId.toString() }
            val found = index >= 0
            player.setMediaItems(items, if (found) index else 0, if (found) saved.positionMs else 0L)
            player.repeatMode = saved.repeatMode
            player.shuffleModeEnabled = saved.shuffle
            if (saved.shuffle) reshuffleCurrentFirst()
            player.prepare() // ready to resume, but stays paused
        }
    }

    // ---- lifecycle -------------------------------------------------------------------

    override fun onCreate() {
        super.onCreate()
        player = ExoPlayer.Builder(this)
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(C.USAGE_MEDIA)
                    .setContentType(C.AUDIO_CONTENT_TYPE_MUSIC)
                    .build(),
                /* handleAudioFocus = */ true
            )
            .setHandleAudioBecomingNoisy(true) // pause when headphones unplug
            .setWakeMode(C.WAKE_MODE_LOCAL)    // keep CPU awake for local files
            .build()
        player.addListener(persistListener)
        // DLNA / UPnP casting: the engine makes a TV, Xbox or PC follow this player.
        CastHub.init(this)
        castEngine = CastEngine(this, player, scope)
        session = MediaSession.Builder(this, player)
            .setCallback(callback)
            .setSessionActivity(openAppIntent())
            .build()
        restoreQueue()
    }

    /** What opens when the notification or the system media widget is tapped. */
    private fun openAppIntent(): PendingIntent =
        TaskStackBuilder.create(this)
            .addNextIntent(Intent(this, MainActivity::class.java))
            .getPendingIntent(0, PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)!!

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaSession? = session

    override fun onTaskRemoved(rootIntent: Intent?) {
        saveState()
        // Swiped away from recents: stop the service only if nothing is playing.
        if (!player.playWhenReady || player.mediaItemCount == 0) {
            stopSelf()
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        saveState()
        if (player.mediaItemCount > 0) {
            QueueStore.saveIds(this, List(player.mediaItemCount) { player.getMediaItemAt(it).mediaId })
        }
        castEngine?.release()
        castEngine = null
        scope.cancel()
        session?.let {
            it.player.release()
            it.release()
        }
        session = null
        super.onDestroy()
    }
}
