package app.needle.music.playback

import android.app.Application
import android.content.ComponentName
import android.content.Intent
import android.graphics.BitmapFactory
import android.net.Uri
import android.provider.OpenableColumns
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/**
 * The bridge between the UI and the playback service.
 * The UI only reads these state fields and calls the functions below, which is what
 * keeps the skin easy to redesign later.
 */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    var isPlaying by mutableStateOf(false); private set
    var hasMedia by mutableStateOf(false); private set
    var title by mutableStateOf<String?>(null); private set
    var artist by mutableStateOf<String?>(null); private set
    var artwork by mutableStateOf<ImageBitmap?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set

    private var controller: MediaController? = null
    private var pendingUri: Uri? = null
    private var fallbackName: String? = null
    private var lastArtData: ByteArray? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    private val future = MediaController.Builder(
        app,
        SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()

    init {
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                controller = c
                c.addListener(listener)
                sync(c)
                pendingUri?.let { start(c, it); pendingUri = null }
            }
        }, ContextCompat.getMainExecutor(app))
    }

    fun play(uri: Uri) {
        val ctx = getApplication<Application>()
        runCatching {
            ctx.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        fallbackName = displayName(uri)
        val c = controller
        if (c == null) pendingUri = uri else start(c, uri)
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        refreshPosition()
    }

    /** Called by the UI a few times per second while playing. */
    fun refreshPosition() {
        controller?.let {
            positionMs = it.currentPosition
            durationMs = if (it.duration == C.TIME_UNSET) 0L else it.duration
        }
    }

    private fun start(c: MediaController, uri: Uri) {
        c.setMediaItem(MediaItem.fromUri(uri))
        c.prepare()
        c.play()
    }

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        hasMedia = p.currentMediaItem != null
        val md = p.mediaMetadata
        title = md.title?.toString() ?: fallbackName
        artist = md.artist?.toString() ?: md.albumArtist?.toString()
        val data = md.artworkData
        if (data !== lastArtData) {
            lastArtData = data
            artwork = data?.let {
                runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull()
            }
        }
        positionMs = p.currentPosition
        durationMs = if (p.duration == C.TIME_UNSET) 0L else p.duration
    }

    private fun displayName(uri: Uri): String? = runCatching {
        getApplication<Application>().contentResolver
            .query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)
            ?.use { c -> if (c.moveToFirst()) c.getString(0)?.substringBeforeLast('.') else null }
    }.getOrNull()

    override fun onCleared() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        super.onCleared()
    }
}
