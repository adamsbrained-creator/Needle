package app.needle.music.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

@Composable
fun NowPlayingScreen(vm: PlayerViewModel = viewModel()) {
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) vm.play(uri)
    }

    // While playing, refresh the progress bar a few times per second.
    LaunchedEffect(vm.isPlaying) {
        while (vm.isPlaying) {
            vm.refreshPosition()
            delay(250)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Palette.Bg)
            .safeDrawingPadding()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(
            text = "Needle",
            color = Palette.Text,
            fontFamily = FontFamily.Serif,
            fontSize = 22.sp,
            modifier = Modifier.padding(vertical = 16.dp)
        )

        Artwork(vm.artwork, Modifier.fillMaxWidth().aspectRatio(1f))

        Spacer(Modifier.height(28.dp))

        Text(
            text = vm.title ?: "Nothing playing",
            color = Palette.Text,
            fontFamily = FontFamily.Serif,
            fontWeight = FontWeight.Bold,
            fontSize = 28.sp,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(4.dp))
        Text(
            text = vm.artist ?: if (vm.hasMedia) "Unknown artist" else "Pick a song to start",
            color = Palette.Muted,
            fontSize = 16.sp,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )

        Spacer(Modifier.height(20.dp))

        ProgressBar(vm)

        Spacer(Modifier.height(8.dp))

        PlayPauseButton(
            isPlaying = vm.isPlaying,
            enabled = vm.hasMedia,
            onClick = vm::togglePlay
        )

        Spacer(Modifier.height(28.dp))

        Box(
            modifier = Modifier
                .clip(CircleShape)
                .border(1.dp, Palette.Muted, CircleShape)
                .clickable { picker.launch(arrayOf("audio/*")) }
                .padding(horizontal = 22.dp, vertical = 12.dp)
        ) {
            Text("Choose a song", color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium)
        }

        Spacer(Modifier.height(24.dp))
    }
}

@Composable
private fun ProgressBar(vm: PlayerViewModel) {
    var dragging by remember { mutableStateOf<Float?>(null) }
    val duration = vm.durationMs
    val progress = if (duration > 0) (vm.positionMs.toFloat() / duration).coerceIn(0f, 1f) else 0f
    val shown = dragging ?: progress

    Slider(
        value = shown,
        onValueChange = { dragging = it },
        onValueChangeFinished = {
            dragging?.let { vm.seekTo((it * duration).toLong()) }
            dragging = null
        },
        enabled = vm.hasMedia && duration > 0,
        colors = SliderDefaults.colors(
            thumbColor = Color.White,
            activeTrackColor = Color.White,
            inactiveTrackColor = Color.White.copy(alpha = 0.2f),
            disabledThumbColor = Color.White.copy(alpha = 0.3f),
            disabledActiveTrackColor = Color.White.copy(alpha = 0.3f),
            disabledInactiveTrackColor = Color.White.copy(alpha = 0.1f)
        )
    )
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(formatTime((shown * duration).toLong()), color = Palette.Muted, fontSize = 13.sp)
        Text(formatTime(duration), color = Palette.Muted, fontSize = 13.sp)
    }
}

@Composable
private fun Artwork(art: ImageBitmap?, modifier: Modifier) {
    Box(modifier.clip(RoundedCornerShape(28.dp)), contentAlignment = Alignment.Center) {
        if (art != null) {
            Image(
                bitmap = art,
                contentDescription = null,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
        } else {
            Box(
                Modifier
                    .fillMaxSize()
                    .background(Brush.verticalGradient(listOf(Color(0xFFF4B6C8), Color(0xFF6B3F8F))))
            )
            Box(Modifier.size(120.dp).clip(CircleShape).background(Color(0xFFF08A4B)))
        }
    }
}

@Composable
private fun PlayPauseButton(isPlaying: Boolean, enabled: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 1f else 0.3f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(28.dp)) {
            val ink = Color(0xFF101012)
            if (isPlaying) {
                val barW = size.width * 0.3f
                val radius = CornerRadius(4.dp.toPx())
                drawRoundRect(ink, Offset(size.width * 0.12f, 0f), Size(barW, size.height), radius)
                drawRoundRect(ink, Offset(size.width * 0.58f, 0f), Size(barW, size.height), radius)
            } else {
                val tri = Path().apply {
                    moveTo(size.width * 0.18f, 0f)
                    lineTo(size.width, size.height / 2f)
                    lineTo(size.width * 0.18f, size.height)
                    close()
                }
                drawPath(tri, ink)
            }
        }
    }
}

private fun formatTime(ms: Long): String {
    val totalSeconds = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(totalSeconds / 60, totalSeconds % 60)
}
