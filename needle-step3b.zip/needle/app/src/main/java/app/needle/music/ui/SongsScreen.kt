package app.needle.music.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song
import app.needle.music.data.SortField
import app.needle.music.data.SortOrder

@Composable
fun SongsScreen(
    songs: List<Song>?,
    isScanning: Boolean,
    currentMediaId: String?,
    sort: SortOrder,
    bottomPadding: Dp,
    onSongClick: (Int) -> Unit,
    onShuffleAll: () -> Unit,
    onSortSelected: (SortField) -> Unit,
    onRescan: () -> Unit,
    modifier: Modifier = Modifier
) {
    when {
        songs == null -> Centered("Loading…", modifier)

        songs.isEmpty() -> Column(
            modifier.fillMaxSize(),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                if (isScanning) "Scanning your music…" else "No music found",
                color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 24.sp
            )
            if (!isScanning) {
                Spacer(Modifier.padding(8.dp))
                PillButton("Scan again", onRescan)
            }
        }

        else -> {
            val listState = rememberLazyListState()
            // A new sort order starts from the top.
            LaunchedEffect(sort) { listState.scrollToItem(0) }

            LazyColumn(
                modifier.fillMaxSize(),
                state = listState,
                contentPadding = PaddingValues(bottom = bottomPadding)
            ) {
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, end = 20.dp, top = 16.dp, bottom = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(Modifier.weight(1f)) {
                            Text(
                                "Songs", color = Palette.Text, fontFamily = FontFamily.Serif,
                                fontWeight = FontWeight.Bold, fontSize = 32.sp
                            )
                            Text("${songs.size} songs", color = Palette.Muted, fontSize = 14.sp)
                        }
                        PillButton(if (isScanning) "Scanning…" else "Rescan", onClick = { if (!isScanning) onRescan() })
                    }
                }
                item {
                    Row(
                        Modifier.fillMaxWidth().padding(start = 20.dp, bottom = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        PillButton("Shuffle", onShuffleAll, filled = true)
                        Spacer(Modifier.width(12.dp))
                        Row(
                            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            SortField.entries.forEach { field ->
                                val selected = sort.field == field
                                val arrow = if (sort.ascending) "↑" else "↓"
                                Chip(
                                    text = if (selected) "${field.label} $arrow" else field.label,
                                    selected = selected,
                                    onClick = { onSortSelected(field) }
                                )
                            }
                            Spacer(Modifier.width(12.dp))
                        }
                    }
                }
                itemsIndexed(songs, key = { _, s -> s.id }) { index, song ->
                    SongRow(song, isCurrent = song.id.toString() == currentMediaId, onClick = { onSongClick(index) })
                }
            }
        }
    }
}

@Composable
private fun SongRow(song: Song, isCurrent: Boolean, onClick: () -> Unit) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(horizontal = 20.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(song, size = 52.dp)
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) Palette.Accent else Palette.Text,
                fontSize = 16.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                "${song.artist} · ${song.album}",
                color = Palette.Muted, fontSize = 13.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Text(formatTime(song.durationMs), color = Palette.Muted, fontSize = 13.sp)
    }
}

@Composable
private fun Centered(text: String, modifier: Modifier) {
    Box(modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Text(text, color = Palette.Muted, fontSize = 16.sp, textAlign = TextAlign.Center)
    }
}
