package app.needle.music.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction
import kotlinx.coroutines.flow.Flow

@Dao
abstract class SongDao {
    @Query("SELECT * FROM songs")
    abstract fun observeAll(): Flow<List<Song>>

    @Query("SELECT * FROM songs")
    abstract suspend fun getAllOnce(): List<Song>

    @Query("DELETE FROM songs")
    abstract suspend fun clear()

    @Insert
    abstract suspend fun insertAll(songs: List<Song>)

    /** Swap the whole library in one transaction, so the UI updates once. */
    @Transaction
    open suspend fun replaceAll(songs: List<Song>) {
        clear()
        insertAll(songs)
    }
}

@Database(entities = [Song::class], version = 1, exportSchema = false)
abstract class NeedleDatabase : RoomDatabase() {
    abstract fun songDao(): SongDao

    companion object {
        @Volatile
        private var instance: NeedleDatabase? = null

        fun get(context: Context): NeedleDatabase =
            instance ?: synchronized(this) {
                instance ?: Room.databaseBuilder(
                    context.applicationContext,
                    NeedleDatabase::class.java,
                    "needle.db"
                )
                    // The library table can always be rebuilt by rescanning.
                    // Before we add likes/play counts we switch to real migrations.
                    .fallbackToDestructiveMigration(dropAllTables = true)
                    .build()
                    .also { instance = it }
            }
    }
}
