package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Small cover thumbnails for list rows.
 * - Cached per song (albums can hold different covers per file).
 * - At most 4 thumbnails load at once, so a fast fling doesn't flood the media provider.
 */
object ArtworkLoader {
    private val NONE = Any()
    private val cache = LruCache<Long, Any>(400)
    private val gate = Semaphore(4)

    /** Instant cache lookup, safe to call while composing. Null means "not loaded (yet)". */
    fun peek(song: Song): ImageBitmap? = cache.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun load(context: Context, song: Song, sizePx: Int = 144): ImageBitmap? {
        cache.get(song.id)?.let { return if (it === NONE) null else it as ImageBitmap }

        val bitmap = gate.withPermit {
            withContext(Dispatchers.IO) {
                runCatching {
                    if (Build.VERSION.SDK_INT >= 29) {
                        context.contentResolver.loadThumbnail(song.uri, Size(sizePx, sizePx), null)
                    } else {
                        val art = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"), song.albumId
                        )
                        context.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
                    }
                }.getOrNull()?.asImageBitmap()
            }
        }
        cache.put(song.id, bitmap ?: NONE)
        return bitmap
    }
}
