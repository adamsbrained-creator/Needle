package app.needle.music.playback

import android.app.Application
import android.content.ComponentName
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.needle.music.data.Song

/** One row of the "Up next" list. [index] is the position in the real queue. */
data class QueueEntry(val index: Int, val title: String, val artist: String)

/**
 * The bridge between the UI and the playback service.
 * The UI only reads these state fields and calls the functions below, which is what
 * keeps the skin easy to redesign later. The queue itself lives in the service.
 */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    var isPlaying by mutableStateOf(false); private set
    var hasMedia by mutableStateOf(false); private set
    var currentMediaId by mutableStateOf<String?>(null); private set
    var title by mutableStateOf<String?>(null); private set
    var artist by mutableStateOf<String?>(null); private set
    var artwork by mutableStateOf<ImageBitmap?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffleEnabled by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var queueSize by mutableIntStateOf(0); private set

    /** Bumps whenever the queue or its order changes, so the queue screen knows to refresh. */
    var queueVersion by mutableIntStateOf(0); private set

    private var controller: MediaController? = null
    private var pending: ((MediaController) -> Unit)? = null
    private var lastArtData: ByteArray? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
            if (events.containsAny(
                    Player.EVENT_TIMELINE_CHANGED,
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED
                )
            ) queueVersion++
        }
    }

    private val future = MediaController.Builder(
        app,
        SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()

    init {
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                controller = c
                c.addListener(listener)
                sync(c)
                queueVersion++
                pending?.let { it(c); pending = null }
            }
        }, ContextCompat.getMainExecutor(app))
    }

    // ---- starting playback -----------------------------------------------------------

    /** Play [songs] (in this order) starting at [index]. Keeps the current shuffle mode. */
    fun playSongs(songs: List<Song>, index: Int) = sendQueue(songs, index, shuffle = null)

    /** Play [songs] shuffled, starting from a random one. */
    fun shuffleAll(songs: List<Song>) {
        if (songs.isNotEmpty()) sendQueue(songs, songs.indices.random(), shuffle = true)
    }

    private fun sendQueue(songs: List<Song>, start: Int, shuffle: Boolean?) {
        if (start !in songs.indices) return
        val args = Bundle().apply {
            putLongArray(QueueCommands.KEY_IDS, LongArray(songs.size) { songs[it].id })
            putInt(QueueCommands.KEY_START, start)
            if (shuffle != null) putBoolean(QueueCommands.KEY_SHUFFLE, shuffle)
        }
        withController { it.sendCustomCommand(QueueCommands.playQueue, args) }
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending = block
    }

    // ---- transport -------------------------------------------------------------------

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }

    fun previous() { controller?.seekToPrevious() }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        refreshPosition()
    }

    /** Called by the UI a few times per second while the player screen is open and playing. */
    fun refreshPosition() {
        controller?.let {
            positionMs = it.currentPosition
            durationMs = if (it.duration == C.TIME_UNSET) 0L else it.duration
        }
    }

    // ---- queue -----------------------------------------------------------------------

    /** The songs that will play after the current one, in playback order (shuffle-aware). */
    fun upNext(limit: Int = 100): List<QueueEntry> {
        val c = controller ?: return emptyList()
        val timeline = c.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val shuffle = c.shuffleModeEnabled
        val out = ArrayList<QueueEntry>()
        var i = timeline.getNextWindowIndex(c.currentMediaItemIndex, Player.REPEAT_MODE_OFF, shuffle)
        while (i != C.INDEX_UNSET && out.size < limit) {
            val md = c.getMediaItemAt(i).mediaMetadata
            out += QueueEntry(i, md.title?.toString().orEmpty(), md.artist?.toString().orEmpty())
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, shuffle)
        }
        return out
    }

    fun jumpTo(index: Int) {
        controller?.let {
            it.seekTo(index, C.TIME_UNSET)
            it.play()
        }
    }

    fun removeFromQueue(index: Int) {
        controller?.removeMediaItem(index)
    }

    // ---- state sync ------------------------------------------------------------------

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        hasMedia = p.currentMediaItem != null
        currentMediaId = p.currentMediaItem?.mediaId
        shuffleEnabled = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        queueSize = p.mediaItemCount
        val md = p.mediaMetadata
        title = md.title?.toString()
        artist = md.artist?.toString() ?: md.albumArtist?.toString()
        val data = md.artworkData
        if (data !== lastArtData) {
            lastArtData = data
            artwork = data?.let {
                runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull()
            }
        }
        positionMs = p.currentPosition
        durationMs = if (p.duration == C.TIME_UNSET) 0L else p.duration
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        super.onCleared()
    }
}
