package app.needle.music.playback

import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import app.needle.music.data.Song

/** Song -> what the player plays. The mediaId is the MediaStore id, used to find the song again. */
fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
    .setMediaId(id.toString())
    .setUri(uri)
    .setMediaMetadata(
        // No artwork here on purpose: the player reads the cover embedded in the file.
        MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()
    )
    .build()
