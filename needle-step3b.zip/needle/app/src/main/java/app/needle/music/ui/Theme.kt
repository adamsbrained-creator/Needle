package app.needle.music.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

/** Colors taken from the Needle mockup pack. Change the look here. */
object Palette {
    val Bg = Color(0xFF101012)
    val Surface = Color(0xFF1C1C20)
    val Text = Color(0xFFF2F2F5)
    val Muted = Color(0xFF9A9AA3)
    val Accent = Color(0xFFAF65F5)
}

@Composable
fun NeedleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Bg,
            surface = Palette.Surface,
            onBackground = Palette.Text,
            onSurface = Palette.Text
        ),
        content = content
    )
}
