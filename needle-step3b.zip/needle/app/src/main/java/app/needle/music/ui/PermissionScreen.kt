package app.needle.music.ui

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun PermissionScreen(onRequest: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Column(
        modifier.fillMaxSize().background(Palette.Bg).padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = androidx.compose.foundation.layout.Arrangement.Center
    ) {
        Text(
            "Needle", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 40.sp
        )
        Spacer(Modifier.height(16.dp))
        Text(
            "Needle needs access to the music on your phone. Nothing leaves your device.",
            color = Palette.Muted, fontSize = 16.sp, textAlign = TextAlign.Center
        )
        Spacer(Modifier.height(28.dp))
        PillButton("Allow access", onRequest, filled = true)
        Spacer(Modifier.height(12.dp))
        PillButton("Open app settings", onClick = {
            context.startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.fromParts("package", context.packageName, null))
            )
        })
        Spacer(Modifier.height(16.dp))
        Text(
            "If the permission dialog doesn't appear, turn on \"Music and audio\" in settings.",
            color = Palette.Muted, fontSize = 13.sp, textAlign = TextAlign.Center
        )
    }
}
