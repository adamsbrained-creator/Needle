package app.needle.music.data

import java.text.Normalizer

enum class SortField(val label: String) {
    TITLE("Title"),
    ARTIST("Artist"),
    ALBUM("Album"),
    RECENT("Recent"),
    DURATION("Length")
}

data class SortOrder(val field: SortField, val ascending: Boolean)

/** Newest first and longest first feel natural for these two; everything else starts A to Z. */
fun defaultAscending(field: SortField): Boolean = field != SortField.RECENT

private val accentMarks = Regex("\\p{Mn}+")

/**
 * Makes a string sortable the way people expect: lowercase, accents removed,
 * leading quotes / brackets / # ignored. Artists also ignore a leading "The".
 */
fun sortKey(text: String, dropThe: Boolean = false): String {
    var t = Normalizer.normalize(text, Normalizer.Form.NFD).replace(accentMarks, "").lowercase()
    t = t.trimStart { !it.isLetterOrDigit() }
    if (dropThe && t.startsWith("the ")) t = t.removePrefix("the ")
    return t
}

private class Keyed(val song: Song) {
    val title = sortKey(song.title)
    val artist = sortKey(song.artist, dropThe = true)
    val album = sortKey(song.album)
}

fun sortSongs(songs: List<Song>, order: SortOrder): List<Song> {
    val keyed = songs.map { Keyed(it) }
    val base: Comparator<Keyed> = when (order.field) {
        SortField.TITLE -> compareBy({ it.title }, { it.artist })
        SortField.ARTIST -> compareBy({ it.artist }, { it.album }, { it.song.trackNumber }, { it.title })
        SortField.ALBUM -> compareBy({ it.album }, { it.song.trackNumber }, { it.title })
        SortField.RECENT -> compareBy({ it.song.dateAdded }, { it.title })
        SortField.DURATION -> compareBy({ it.song.durationMs }, { it.title })
    }
    val comparator = if (order.ascending) base else base.reversed()
    return keyed.sortedWith(comparator).map { it.song }
}
