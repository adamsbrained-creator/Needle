# More actions on Now playing (Player controls sheet), built on Step 50

## New files
- data/SimilarSongs.kt     picks songs like a seed song (shared genre, artist, album, years, your ratings, a little luck)
- ui/SongActions.kt        web search, Genius search, share as text, delete the audio file
- ui/GenreScreen.kt        the page "Go to genre" opens (Play, Shuffle, every song with that genre)
- ui/SongToolDialogs.kt    "which genre?" and "delete this file?" boxes

## Changed
- ui/PlayerControlsSheet.kt  tiles now sit in titled groups; tiles can be lit (on) or red (danger)
- ui/NeedleApp.kt            the tiles, genre page, delete flow, Smart flow
- ui/Icons.kt                4 new icons (smart flow, mix, genre, globe)
- playback/PlayerViewModel.kt  removeSongFromQueue(), songsLeft()
- data/NeedleSettings.kt     "smartFlow" switch (remembered)

## The sheet now
Playback:  Speed & pitch, Equalizer · DSP, Sleep timer, Play on, Smart flow, Instant mix
Song:      Favorite, Rate song, Add to playlist, Song info
Go to:     album, artist, genre
Edit:      Edit tags, Edit lyrics
Find/share: Web search, Genius search, Share, Share file
More:      Delete file (red), Edit controls (still "coming soon")

## How the new ones work
- Instant mix: starts a new queue with this song first, then up to 50 similar songs from your library.
- Smart flow: a switch. While on, when fewer than 3 songs are left in the queue, 10 similar songs are added.
- Favorite: the heart = Liked songs (same as the star on Now playing). The sheet stays open so you see it change.
- Go to genre: one genre opens its page; several genres ask which one. No genre = tile is dimmed.
- Web search / Genius search: open the browser with "Artist Title".
- Share sends "Title — Artist" as text; Share file sends the audio.
- Delete file: Android 11+ shows Android's own confirmation; older versions use Needle's box.
  Afterwards the song leaves the queue and the library is rescanned. Never undone.

## Not done / choices
- "Go to album artist" (the x³ row in Symfonium) is skipped: Needle does not store an album artist.
- Instant mix and Smart flow use only your own library (no online lookup), so they are as good as your tags.
- No compiler or Gradle here. Checked brace balance and every name used against the Step 50 code. Please build once.
