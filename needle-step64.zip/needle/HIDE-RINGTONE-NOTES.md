# Hide from library, Hidden songs, Set as ringtone, artist menu (Step 64, built on Step 63)

## New files
- data/HiddenSongs.kt        the hidden song ids, remembered (same prefs file as the pins)
- data/Ringtone.kt           Set as ringtone
- ui/HiddenSongsScreen.kt    Settings > Library > Hidden songs

## Song menu (press and hold a song)
Two new rows after Song info, from the mockup:
- Set as ringtone: Android lets an app change the ringtone only after the person allows it once, so the first
  time it opens the system screen "Modify system settings" for Needle. Allow it, come back, and choose Set as
  ringtone again. After that it is one tap ("<song> is now your ringtone"). Added the WRITE_SETTINGS permission.
- Hide from library: the song disappears from Songs, Albums, Artists, search, Home, stats and playlists' lists.
  The file is not touched. A message says where to undo it.

## Hidden songs
Settings > Library > Hidden songs (shows how many). The page lists them with Unhide on each and Unhide all.
Back returns to Settings. It is also found by the settings search ("hidden songs"). Hidden songs are included in
backups and merged on restore (restoring never un-hides anything).
How it works: the hiding is done in one place (Library.observe), so every list agrees. A song that is already in
the queue or playing keeps playing.

## Artist page menu
The ⋯ button (it said "Coming soon") opens: Pin / Unpin artist, Play next, Add all to queue.
(The star next to Play still pins too.)

## Changed
- data/Library.kt (hidden filter, observeHidden), data/LibraryViewModel.kt (hiddenSongs), data/Backup.kt, MainActivity.kt
- ui/SongMenu.kt (two rows), ui/SettingsScreen.kt (the Hidden songs row), ui/ArtistScreen.kt (menu; the `onSoon`
  parameter became onPlayNext and onAddAllToQueue), ui/NeedleApp.kt (page, Back, wiring)
- AndroidManifest.xml: WRITE_SETTINGS

## Choices I made where the mockup does not say
- Hide has no confirmation question (it is easy to undo); the message tells where.
- Hide works one song at a time from the menu. Hiding several at once from the selection bar is not added yet.

## Not done
- Some phone makers refuse ringtones that are not in the Ringtones folder; if that happens Needle says
  "Could not set the ringtone" and nothing changes.
- No compiler here: checked brace balance, duplicate/unused imports, and every name used against Step 63. Please build once.
