# Colors & themes, built on Step 51

Settings > Customization (was "Appearance") > Colors & themes

## New files
- data/ColorThemes.kt   ColorTheme (one whole look), ColorThemes.builtIn (Needle, Midnight, Sunset, Forest, Rose, Mono),
                        ThemeStore (your saved themes, kept on the phone and in backups), contrast helpers (WCAG ratio, AAA/AA/Low)

## Changed
- ui/SettingsScreen.kt  "Appearance" is now "Customization". It starts with a "Colors & themes" row; the color settings moved
                        to the new page. New enum value SettingsPage.COLORS_THEMES (Back returns to Customization).
- ui/NeedleApp.kt       Back handler knows the new page
- data/Backup.kt        saved themes are exported and restored ("colorThemes")
- Text that said "Settings > Appearance" now says "Settings > Customization" (Home, New, Theme, Glow comments)

## The page
1. Live preview (glow, accent, card) that follows every change
2. Themes: tap to apply. "Save current" stores your own. Press and hold one of yours to Share (text) or Delete.
   "Import from clipboard" reads a theme someone shared.
3. Theme (Dark / AMOLED), Accent, Cards, Background and glow (all as before), plus "Glow follows the cover"
4. Readability: text on background, text on cards, white on accent, each graded AAA / AA / Large text only / Low
5. Reset all colors

A theme = mode, accent, background, 3 glow colors, glow strength, card color. Fonts, animated covers etc. stay outside it.

## Not done
- Light theme (Palette is dark-only; ~380 uses of Palette.Text/Surface). Auto/Light from the mockup are left out.
- Editing text/surface colors and an "All roles" view: Needle only has the roles above, so Simple/All would be the same list.
- Cover-art color source (Off / Cover art / My accent) is the single "Glow follows the cover" switch for now.
- No compiler here: checked brace balance and names against Step 51. Please build once.
