# Skins, built on Step 56 (Claude), finished in Steps 58 to 62

Settings > Customization > Skins (new, the first entry on the page)

## What a skin is
The look of the whole app in one tap: colors, the bottom dock, the title font and the moving background.
It is a starting point. After picking one you can still change colors in Colors & themes and the skin stays selected.

## Skins
- Needle      the original (floating glass dock, violet glow, serif titles). Picking it restores the Needle colors, serif titles and the moving background.
- Black & Green  new, from the black-and-green mockups: pure black (AMOLED), green accent #2BE566, dark cards #161616,
                 pure white text, sans titles, moving background off, and a flat bottom bar with labels
                 (Home, Songs, Albums, Library) with the player as its own card above it. The play button on the card is green.

## New files
- data/Skins.kt          Skin (Needle, Black & Green) with its starting colors, and Skins (current skin, pick)

## Changed
- data/NeedleSettings.kt  `skin` setting, saved, exported and restored with backups ("skin")
- ui/SettingsScreen.kt    new SettingsPage.SKINS, the Skins row on Customization, the Skins page (a card with a small preview per skin,
                          "In use" on the selected one), search keywords, Back returns to Customization
- ui/NeedleApp.kt         Back handler knows the new page
- ui/Theme.kt             Palette.Text and Palette.Muted follow the skin
- ui/Dock.kt              Destination has a label; Black & Green draws FlatDock instead of the floating dock
- ui/Components.kt        PlayPauseButton has an optional `color` (default white, as before)

## Black & Green on the screens (added in the finish step)
- Home: big greeting (Good morning / afternoon / evening / night) on the left, search and a green profile circle on the right;
  the selected pill is green; section headers are bolder, with a muted "See all >" style link.
- Home (Step 59): an "Artists" row of round pictures under the pills, from the artists of Your albums and Rediscover; tap opens the artist page.
  Needle has no "followed" artists, so it is not called that.
- Now playing: 24 sp title, 24 dp cover corners, and a green "Next: <song>" line above the controls.
- Artist page: Play is the green circle, Star and Shuffle are dark.
- Album page and every PillButton: Play is a green pill with dark text, the other pill has a dark outline.
- Settings, Songs and Albums follow through the skin's colors, white text and dark cards.

## Step 60 (all skins unless noted)
- New Artists page (ui/ArtistsScreen.kt): every artist A to Z with a round picture, "N albums · M songs" and a letter index.
  Opened from Library > Artists (it said "Coming soon") and from "See all" on the Home Artists row (Black & Green).
  NeedleApp: `showArtists`, its Back handler and screen; the dock resets it.
- Black & Green: the filter chips (Songs sort chips, Library chips) are green when selected; the mini player has a thin green progress line.

## Step 61 (Black & Green)
- Settings and every page that uses the glass rows or cards: flat dark cards (the Cards color) instead of frosted glass; section labels are green.
- Album page: a smaller cover with 18 dp corners and a 22 sp semi-bold title.

## Step 62: two Now playing looks
Settings > Customization > Skins > Now playing page: Follow the skin (default), Needle, Black & Green, Cover color.
- Black & Green: what Step 58 did (centered 24 sp title, green "Next:" line, white play button).
- Cover color (new, from the first Now playing mockup): the page gradient takes the main color of the cover (eased between songs),
  a Rate header with the album name, play button in the cover color, the title in green with heart and menu beside it,
  the artist under it, the next song below in gray, and a "Local device . Phone" chip (it says Cast device / Play on while casting) that opens Play on.
  The lyrics preview and the info cards stay under it, as before.
- Files: data/Skins.kt (NowPlayingStyle), data/NeedleSettings.kt (npStyle, backed up), ui/SettingsScreen.kt, ui/NowPlayingScreen.kt.
- The "High Efficiency" chip of the mockup is not built: Needle has no such mode.

## Not done
- The screens keep their Needle layouts. Songs, Albums, Library and Settings already match the mockups closely (shuffle pill, sort chips,
  two-column album grid), so they only got the skin's colors. Home still has the hero cards, This week and Rediscover.
- The Album page track rows keep Needle's design.
- The Outfit font from the mockups is not bundled (no internet here), so Black & Green uses the system sans font.
- The mockup's 4th tab is Artists; Needle's is Library, so the bar keeps Library.
- Selecting Black & Green turns Moving background off, selecting Needle turns it on.
- No compiler here: checked brace balance and every name used against Step 56. Please build once.
