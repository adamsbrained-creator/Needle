# Search and Queue from the mockup, built on Step 49

## New files
- data/SearchData.kt       the search itself (ranking, top result, lyric lines); pure functions
- data/RecentSearches.kt   the "Recent searches" chips, remembered

## Rewritten
- ui/SearchScreen.kt
- ui/QueueScreen.kt

## Small changes
- playback/PlaybackService.kt, QueueCommands.kt, PlayerViewModel.kt: reorder the queue (works with
  shuffle on and off), clear the queue, and each queue row now carries its song id
- data/Lyrics.kt: one new query (read all saved lyrics), no database change
- ui/Icons.kt: three new icons (repeat, sort, mic)
- ui/NeedleApp.kt: Search can open an album or artist; Queue gets the songs, the "Playing from"
  name (same as Now playing) and a sleep timer button that returns to the queue
- MainActivity.kt: loads the recent searches at start

## Search
Glass search box with mic (voice) and clear, pills (All, Songs, Albums, Artists, Lyrics), a Top result
card with a play button, matches lit up in the titles, and "in lyrics: ..." under songs found by their
words. Recent searches show while the box is empty and are saved once a search leads somewhere.
Lyrics are searched from 3 letters on, in the Lyrics tag and in lyrics saved from LRCLIB.
Lyrics in a .lrc file next to a song, or never loaded, are not searched.

## Queue
Back, sleep timer and sort buttons; "Playing from ..." with song count and minutes left; the glowing
now-playing card with progress; Next up with drag handles (press and hold the dots, then drag; the
list scrolls by itself near the edges), X to remove, tap to jump; Shuffle, Repeat and Clear; and
Save queue as playlist. Clear keeps the song that is playing.

## Choices I made where the mockup does not say
- The sort button opens Reverse order / Title A-Z / Artist A-Z for the songs shown in Next up.
- The mockup shows Recent searches under the results; I show them when the box is empty instead.
- Next up lists every song in the queue, and sort and drag reorder cover all of them (this changed in the Glass / queue / .lrc update).

## Not done
No compiler or Gradle was available here. Checked by diffing, brace balance, a missing-import check
and a check of every name used against the Step 49 code. Please build once.
