# Your stats and pinned artists, merged onto Step 62 (this is Step 63)

Step 62 already had an Artists page (Step 60). I kept it and its look (back, title, count, search button, round
pictures, letter index, "See all" on the Home artists row) and added what it did not have. Stats was not there at all.

## New files
- data/Stats.kt            the numbers of the stats page for every period; pure functions
- data/ArtistList.kt       one row per artist (real albums, songs, A-Z letter); same "known artist" rule as before
- data/PinnedArtists.kt    the pinned artists, remembered
- ui/StatsScreen.kt        "Your stats"

## Your stats (new)
Week / Month / Year / All time. A card with the time listened and a bar for each weekday, then Plays and Artists,
Top songs (5; tap plays, hold opens the song menu), Top artists (5; tap opens the artist) and Top genres (5, with %).
Home's "This week > Stats" link now opens it. Same rules as Most played: only what Needle saw on this phone,
a song counts after 30 seconds.

## Artists page (polished, ui/ArtistsScreen.kt)
- Pinned artists on top (in the order pinned, with a star) under "Pinned", then "All artists". "Edit" shows an X
  on each pinned artist to unpin. Press and hold any artist to pin or unpin.
- Letter headers (A, B, ...) and a letter index you can tap OR slide a finger along. The old index jumped to the
  wrong row once anything sat above the list; it now follows the real positions.
- Sorting ignores accents and a leading "The" ("The Vantas" is under V); names starting with a number or symbol
  go under # at the end.
- "N albums" counts real albums only (singles used to count as one album each), the same rule as the Albums page.
- The name keeps its spelling from the most songs (it used to be the first song's spelling).

## Pin artist in more places
- Artist page: the star pins / unpins (filled when pinned).
- Now playing > About the artist: a "Pin artist" / "Pinned" pill next to the "3 albums · 24 songs" line.
- Home artists row (Black & Green): pinned artists come first.
- Backup: pins are saved and merged on restore (older backups just have none).

## Changed
- data/HomeViewModel.kt (stats flow), data/Backup.kt, MainActivity.kt (loads pins)
- ui/NeedleApp.kt: `showStats` page + Back; every "close the other pages" statement also closes Stats (and
  Artists, which only the dock closed before); Artists gets its rows and pins; Home's Stats link is wired
- ui/ArtistScreen.kt, ui/NowPlayingCards.kt, ui/HomeScreen.kt: the pin pieces above

## Not done yet (next steps)
- (Done in Step 64: the artist page menu, Hide from library, Hidden songs, Set as ringtone. See HIDE-RINGTONE-NOTES.md.)
- Skins: Stats and Artists use the skin's colors and fonts, but their buttons keep Needle's shapes.
- No compiler here: checked brace balance, duplicate imports, and every name used against Step 62. Please build once.
