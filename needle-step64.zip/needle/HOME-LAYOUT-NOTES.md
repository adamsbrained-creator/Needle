# Home layout + colors, applied to Step 45

Three-way merge of `home-layout-and-colors.patch` (built on step 35) into your step 45 files.

## New files
- data/HomeLayout.kt      which Home sections and pills are shown, and their order
- ui/ColorPicker.kt       the color picker dialog and the colored slider

## Changed files (9)
MainActivity, data/Backup, data/NeedleSettings, ui/Theme, ui/GlowBackground,
ui/HomeScreen, ui/NewScreen, ui/NeedleApp, ui/SettingsScreen

## Where your step 45 and the patch overlapped
- Cards: kept YOUR step 45 system (Auto / Custom, the separate Now playing card color, the
  per-song glow tint). The patch's Solid / Glass / Tinted / Custom card style was NOT added,
  because two card settings cannot both drive Palette.Card. Its live card preview was kept,
  moved under your Cards control. Say so if you want Glass back as a third option.
- Settings pages: both new pages exist (Home layout and Now playing).
- "Reset all colors" puts the cards back to Auto.

## A bug in your step 45 file that is now fixed
ui/GlowBackground.kt did not compile as uploaded: the first lines of defaultGlow() and drawGlow()
had been swapped (defaultGlow called itself and used `palette` / `accent`, which do not exist
there; drawGlow used a variable `g` that was never declared). They are back in the right functions.

## Not done
No compiler or Gradle was available here, so this was checked by diffing, brace balance, and a
cross-check that every NeedleSettings / Palette / HomeLayout member in use is defined.
Please build once.

# Step 48 (Claude)
- Now playing taps are now configurable: Settings > Now playing > Taps on the player (song title, artist name,
  queue name at the top). Choices: Nothing, album, artist, where the queue came from, the queue. Saved in backups.

# Step 49 (Claude)
- Queue name on Now playing now comes from the list the queue was started from (PlayerViewModel.sourceIds), so it
  keeps its name when songs are added later. After an app restart it reads the queue itself again.
- Animated covers: backup server (public m8tec server by default, https only) and Tidal video covers (own token),
  both in Settings > Appearance > Animated covers. Order: Apple Music, backup server, Tidal.
