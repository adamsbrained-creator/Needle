# Glass cards, whole-queue reorder and .lrc search, built on Step 54

## 1. Glass as a third card style
Settings > Customization > Colors & themes > Cards: Auto / Custom / **Glass**.
Glass makes cards a soft see-through white (10% on cards, 16% on chips and pills), so the moving
background shows through. The Now playing cards follow it too (no per-song tint while Glass is on).
- Never on together with Custom (turning one on turns the other off).
- Themes remember it: Save current, Apply, Share and Import carry the Glass setting, and the
  "which theme is this" highlight still works. Older saved themes and backups load as before (no Glass).
- "Reset all colors" turns it off. It is in backups.
- Files: data/NeedleSettings.kt, data/ColorThemes.kt, ui/Theme.kt, ui/SettingsScreen.kt

## 2. Queue: sort and reorder cover every song
Next up used to show and reorder only the first 100 songs; it now lists the whole queue (the list is
lazy, so a long queue is fine) and Reverse / Title A-Z / Artist A-Z and drag all apply to every song.
- A small change still moves songs one by one, so gapless playback is not disturbed.
- A big change (more than 24 songs out of place, like a sort) swaps the whole stretch in one go,
  instead of hundreds of single moves that would flood the player with updates.
- Dragging scrolls a little faster at the edges, for long queues.
- Files: ui/QueueScreen.kt, playback/PlaybackService.kt

## 3. Search finds lyrics in .lrc files
The Lyrics tab, and "in lyrics: ..." under songs, now also search .lrc files next to your songs
(same name, .lrc or .LRC), found the same way the lyrics screen finds them.
- Needs "All files access" and the .lrc option in the lyrics settings. Without access, the Lyrics tab
  says so in one line.
- Tag and saved lyrics are searchable at once; .lrc files join in as soon as they are read (a moment
  on a big library). A file is only read again when it changed. If a song has both a tag and a .lrc,
  both are searched.
- Files: data/SearchData.kt (LrcFiles, mergeLyrics), ui/SearchScreen.kt

## Not done
- Build errors: you said you would send them, so nothing was changed for that yet.
- No compiler or Gradle here. Checked by diffing, brace balance (NeedleSettings.kt shows the same
  4-parenthesis difference in your untouched Step 54 file, so that is the checker, not a change),
  a missing-import check, and a check that every NeedleSettings / Palette member in use exists.
  Please build once.
