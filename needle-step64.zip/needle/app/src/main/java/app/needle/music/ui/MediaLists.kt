package app.needle.music.ui

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animate
import androidx.compose.animation.core.spring
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ListSettings
import app.needle.music.data.NeedleSettings
import app.needle.music.data.RatingScale
import app.needle.music.data.RowDetail
import app.needle.music.data.RowStyle
import app.needle.music.data.RowSubtitle
import app.needle.music.data.RowSwipe
import app.needle.music.data.Song
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

// ---- what song rows need to know and do -------------------------------------------------------

/** Facts the rows show but do not own. NeedleApp keeps them up to date. */
object ListDecor {
    val liked = mutableStateOf<Set<Long>>(emptySet())
    val playCounts = mutableStateOf<Map<Long, Int>>(emptyMap())
}

/** What a swipe or the selection bar does. NeedleApp fills these in, with the toasts. */
object RowActions {
    var playNext: (List<Song>) -> Unit = {}
    var addToQueue: (List<Song>) -> Unit = {}
    var addToPlaylist: (List<Song>) -> Unit = {}
    var editTags: (List<Song>) -> Unit = {}
    var toggleLike: (Song) -> Unit = {}

    fun run(action: RowSwipe, song: Song) {
        when (action) {
            RowSwipe.PLAY_NEXT -> playNext(listOf(song))
            RowSwipe.QUEUE -> addToQueue(listOf(song))
            RowSwipe.FAVORITE -> toggleLike(song)
            RowSwipe.PLAYLIST -> addToPlaylist(listOf(song))
            RowSwipe.NONE -> {}
        }
    }
}

private fun RowSwipe.icon(): NeedleIcon = when (this) {
    RowSwipe.PLAY_NEXT -> NeedleIcon.PLAY_NEXT
    RowSwipe.QUEUE -> NeedleIcon.ADD_QUEUE
    RowSwipe.FAVORITE -> NeedleIcon.HEART_FILLED
    RowSwipe.PLAYLIST -> NeedleIcon.ADD_PLAYLIST
    RowSwipe.NONE -> NeedleIcon.CLOSE
}

private val addedFormat by lazy { SimpleDateFormat("MMM yyyy", Locale.getDefault()) }

/** The small text on the right of a row, as chosen in Settings > Customization > Media lists. Null = nothing to show. */
internal fun rowDetail(song: Song, rating: Int, preview: Boolean): String? = when (ListSettings.detail.value) {
    RowDetail.DURATION -> formatTime(song.durationMs)
    RowDetail.YEAR -> song.year.takeIf { it > 0 }?.toString()
    RowDetail.PLAYS -> (if (preview) 12 else ListDecor.playCounts.value[song.id])?.takeIf { it > 0 }?.let { "$it×" }
    RowDetail.ADDED -> if (song.dateAdded > 0) addedFormat.format(Date(song.dateAdded * 1000)) else null
    RowDetail.RATING -> rating.takeIf { it > 0 }?.let { "★ " + RatingScale.short(NeedleSettings.ratingStyle.value, it) }
    RowDetail.NONE -> null
}

// ---- the song row -------------------------------------------------------------------------------

/**
 * One song in a list. [selected] is null when nothing is being selected; while selecting it says whether this song is picked.
 * [preview] is for the settings page: fake data, and no swipe.
 */
@Composable
internal fun SongRow(
    song: Song,
    isCurrent: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    rating: Int = 0,
    selected: Boolean? = null,
    preview: Boolean = false
) {
    val style = ListSettings.rowStyle.value
    val compact = style == RowStyle.COMPACT
    val showArt = style != RowStyle.TEXT_ONLY
    val artSize = if (compact) 40.dp else 52.dp
    val liked = if (preview) song.id == -1L else ListSettings.favoriteHeart.value && song.id in ListDecor.liked.value
    val detail = rowDetail(song, rating, preview)

    val body: @Composable () -> Unit = {
        Row(
            Modifier
                .fillMaxWidth()
                .background(if (selected == true) Palette.Accent.copy(alpha = 0.16f) else Color.Transparent)
                .tapOrHold(onClick = onClick, onLongClick = onLongClick)
                .padding(horizontal = 20.dp, vertical = if (compact || !showArt) 6.dp else 8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (selected != null && !showArt) {
                SelectMark(selected)
                Spacer(Modifier.width(12.dp))
            }
            if (showArt) {
                Box {
                    SongArtwork(song, size = artSize)
                    if (selected == true) {
                        Box(
                            Modifier.size(artSize).clip(RoundedCornerShape(12.dp)).background(Palette.Accent.copy(alpha = 0.6f)),
                            contentAlignment = Alignment.Center
                        ) { NeedleIconView(NeedleIcon.CHECK, Color.White, size = 22.dp) }
                    } else if (liked && selected == null) {
                        Box(
                            Modifier.align(Alignment.BottomEnd).padding(2.dp).size(18.dp).clip(CircleShape).background(Color(0xB3000000)),
                            contentAlignment = Alignment.Center
                        ) { NeedleIconView(NeedleIcon.HEART_FILLED, Palette.Accent, size = 11.dp) }
                    }
                }
                Spacer(Modifier.width(14.dp))
            }
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    color = if (isCurrent) Palette.Accent else Palette.Text,
                    fontSize = if (compact) 15.sp else 16.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                val base = when (ListSettings.subtitle.value) {
                    RowSubtitle.ARTIST_ALBUM -> "${song.artist} · ${song.album}"
                    RowSubtitle.ARTIST -> song.artist
                    RowSubtitle.ALBUM -> song.album
                }
                // A rated song shows its rating after the album, in the way you chose in Settings > Ratings
                val rated = if (ListSettings.ratingInSubtitle.value && rating > 0 && ListSettings.detail.value != RowDetail.RATING) {
                    " · ★ ${RatingScale.short(NeedleSettings.ratingStyle.value, rating)}"
                } else ""
                Text(
                    base + rated, color = Palette.Muted, fontSize = if (compact) 12.sp else 13.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
            }
            if (liked && !showArt) {
                Spacer(Modifier.width(8.dp))
                NeedleIconView(NeedleIcon.HEART_FILLED, Palette.Accent, size = 14.dp)
            }
            if (detail != null) {
                Spacer(Modifier.width(12.dp))
                Text(detail, color = Palette.Muted, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
    if (selected == null && !preview) SwipeRow(song, body) else body()
}

@Composable
internal fun SelectMark(selected: Boolean) {
    Box(
        Modifier.size(22.dp).clip(CircleShape)
            .background(if (selected) Palette.Accent else Color.Transparent)
            .border(2.dp, if (selected) Palette.Accent else Palette.Muted, CircleShape),
        contentAlignment = Alignment.Center
    ) {
        if (selected) NeedleIconView(NeedleIcon.CHECK, Color(0xFF111111), size = 14.dp)
    }
}

// ---- swipe -----------------------------------------------------------------------------------------

/** Drag a row sideways: past the line, the action of that side runs when you let go. */
@Composable
internal fun SwipeRow(song: Song, content: @Composable () -> Unit) {
    val right = ListSettings.swipeRight.value
    val left = ListSettings.swipeLeft.value
    if (right == RowSwipe.NONE && left == RowSwipe.NONE) {
        content()
        return
    }
    val scope = rememberCoroutineScope()
    val haptic = LocalHapticFeedback.current
    val trigger = with(LocalDensity.current) { 96.dp.toPx() }
    var dragX by remember { mutableFloatStateOf(0f) }
    val action = if (dragX > 0f) right else if (dragX < 0f) left else RowSwipe.NONE
    val armed = abs(dragX) >= trigger

    Box(Modifier.fillMaxWidth()) {
        if (dragX != 0f && action != RowSwipe.NONE) {
            Row(
                Modifier.matchParentSize().background(Palette.Accent.copy(alpha = if (armed) 0.38f else 0.16f)).padding(horizontal = 24.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = if (dragX > 0f) Arrangement.Start else Arrangement.End
            ) {
                NeedleIconView(action.icon(), Palette.Text, size = 22.dp)
                Spacer(Modifier.width(8.dp))
                Text(action.label, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
            }
        }
        Box(
            Modifier
                .offset { IntOffset(dragX.roundToInt(), 0) }
                .then(if (dragX != 0f) Modifier.background(Palette.Bg) else Modifier)
                .pointerInput(right, left) {
                    var crossed = false
                    detectHorizontalDragGestures(
                        onDragStart = { crossed = false },
                        onDragEnd = {
                            val act = if (dragX > 0f) right else left
                            val fire = abs(dragX) >= trigger && act != RowSwipe.NONE
                            scope.launch { animate(dragX, 0f, animationSpec = spring(stiffness = Spring.StiffnessMedium)) { v, _ -> dragX = v } }
                            if (fire) RowActions.run(act, song)
                        },
                        onDragCancel = { scope.launch { animate(dragX, 0f) { v, _ -> dragX = v } } },
                        onHorizontalDrag = { change, amount ->
                            change.consume()
                            val minX = if (left == RowSwipe.NONE) 0f else -trigger * 1.5f
                            val maxX = if (right == RowSwipe.NONE) 0f else trigger * 1.5f
                            dragX = (dragX + amount * 0.7f).coerceIn(minX, maxX)
                            val now = abs(dragX) >= trigger
                            if (now && !crossed) haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                            crossed = now
                        }
                    )
                }
        ) { content() }
    }
}

// ---- selecting songs ----------------------------------------------------------------------------

/** The songs that are picked in a list. Selecting starts with a long press (if that is chosen in the settings). */
class SongSelection {
    val ids = mutableStateListOf<Long>()
    val active: Boolean get() = ids.isNotEmpty()
    fun toggle(id: Long) { if (id in ids) ids.remove(id) else ids.add(id) }
    fun clear() = ids.clear()
    fun selectAll(all: List<Song>) { ids.clear(); ids.addAll(all.map { it.id }) }
}

/** The bar that appears at the bottom while songs are selected. */
@Composable
internal fun SelectionBar(
    count: Int,
    onAll: () -> Unit,
    onNext: () -> Unit,
    onQueue: () -> Unit,
    onPlaylist: () -> Unit,
    onTags: () -> Unit,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(24.dp)
    Row(
        modifier.padding(horizontal = 12.dp, vertical = 8.dp).fillMaxWidth()
            .clip(shape).background(Palette.Surface).border(1.dp, Color.White.copy(alpha = 0.12f), shape)
            .padding(horizontal = 8.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        RoundIconButton(NeedleIcon.CLOSE, onClose, size = 38.dp, iconSize = 18.dp)
        Text(
            "$count selected", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.padding(horizontal = 10.dp)
        )
        Row(
            Modifier.weight(1f).horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            PillButton("All", onAll)
            PillButton("Next", onNext)
            PillButton("Queue", onQueue)
            PillButton("Playlist", onPlaylist)
            PillButton("Tags", onTags)
        }
    }
}

/** The back button of a list page, unless it is hidden in Settings (the system back still works). */
@Composable
internal fun ListBackButton(onBack: () -> Unit, modifier: Modifier = Modifier, size: androidx.compose.ui.unit.Dp = 40.dp) {
    if (!ListSettings.hideListBack.value) {
        RoundIconButton(NeedleIcon.BACK, onBack, modifier, size = size, iconSize = 22.dp)
    }
}
