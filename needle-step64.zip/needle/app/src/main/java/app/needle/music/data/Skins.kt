package app.needle.music.data

/**
 * A skin is the overall look of the app: the colors it starts from, how the bottom dock is built and what
 * the titles use. Picked in Settings > Customization > Skins. A skin is a starting point: after picking one
 * you can still change colors in Colors & themes, and the skin stays selected.
 */
enum class Skin(val id: String, val label: String, val note: String) {
    NEEDLE(
        "needle", "Needle",
        "The original look: floating glass dock, moving violet glow and serif titles."
    ),
    BLACK_GREEN(
        "black_green", "Black & Green",
        "Pure black with one green accent, sans titles and a flat bottom bar with labels."
    );

    /** The colors this skin starts from. */
    fun colors(): ColorTheme = when (this) {
        NEEDLE -> ColorThemes.builtIn.first()
        BLACK_GREEN -> ColorTheme(
            name = "Black & Green",
            accent = AccentChoices.size,
            customAccent = 0xFF2BE566.toInt(),
            amoled = true,
            cardCustom = true,
            cardArgb = 0xFF161616.toInt()
        )
    }
}

/** How the Now playing page looks. Picked in Settings > Customization > Skins. */
enum class NowPlayingStyle(val id: String, val label: String, val note: String) {
    FOLLOW("follow", "Follow the skin", "Black & Green skin: the black player. Needle skin: the original player."),
    NEEDLE("needle", "Needle", "The original player page."),
    BLACK_GREEN("black_green", "Black & Green", "Black page, centered title, a green Next line and a white play button."),
    COVER(
        "cover", "Cover color",
        "The page takes the color of the cover. Rate header, play button in the cover color, title with heart and menu, the next song and where it plays."
    )
}

object Skins {
    /** The Now playing choice made on the Skins page. */
    val nowPlayingChoice: NowPlayingStyle
        get() = NowPlayingStyle.entries.firstOrNull { it.id == NeedleSettings.npStyle.value } ?: NowPlayingStyle.FOLLOW

    /** The Now playing look in use: "Follow the skin" turned into the one it stands for. */
    val nowPlaying: NowPlayingStyle
        get() = when (val c = nowPlayingChoice) {
            NowPlayingStyle.FOLLOW -> if (blackGreen) NowPlayingStyle.BLACK_GREEN else NowPlayingStyle.NEEDLE
            else -> c
        }

    val blackPlayer: Boolean get() = nowPlaying == NowPlayingStyle.BLACK_GREEN

    /** The skin in use. Read while drawing, so a change shows instantly. */
    val current: Skin
        get() = Skin.entries.firstOrNull { it.id == NeedleSettings.skin.value } ?: Skin.NEEDLE

    val blackGreen: Boolean get() = current == Skin.BLACK_GREEN

    /**
     * Makes [skin] the look of the app: its colors, its title font and the moving background
     * (on for Needle, off for Black & Green). [setGlow] is the Moving background switch of the app.
     */
    fun pick(skin: Skin, setGlow: (Boolean) -> Unit) {
        skin.colors().apply()
        NeedleSettings.setSerifTitles(skin == Skin.NEEDLE)
        setGlow(skin == Skin.NEEDLE)
        NeedleSettings.setSkin(skin.id)
    }
}
