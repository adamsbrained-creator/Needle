package app.needle.music.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/**
 * Finds the animated cover of an album: Apple Music first (looked up directly), then, if turned on in Settings,
 * a backup server for Apple Music covers, then Tidal's video covers. Every source only ever returns null on trouble.
 */
object AnimatedCoverSources {
    private class Entry(val url: String?, val expiresAt: Long)
    private val cache = ConcurrentHashMap<String, Entry>()

    suspend fun find(title: String, artist: String, album: String?): String? {
        AnimatedCoverProvider.find(title, artist, album)?.let { return it }

        val albumName = album?.takeIf { it.isNotBlank() && !it.startsWith("<") && !it.equals("unknown", true) && it != "Unknown album" }
            ?: return null // the other sources look albums up by name
        if (artist.isBlank() || artist.contains("unknown", ignoreCase = true)) return null
        val useBackup = NeedleSettings.animatedBackupServer.value
        val useTidal = NeedleSettings.animatedTidal.value && NeedleSettings.tidalToken.value.isNotBlank()
        if (!useBackup && !useTidal) return null

        val key = (artist + "|" + albumName).lowercase(Locale.ROOT) + "|" + useBackup + useTidal
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { it.expiresAt > now }?.let { return it.url }

        val found = (if (useBackup) BackupServerCovers.find(artist, albumName) else null)
            ?: (if (useTidal) TidalCovers.find(artist, albumName) else null)
        cache[key] = Entry(found, now + if (found != null) 24L * 60 * 60 * 1000 else 30L * 60 * 1000)
        return found
    }
}

/**
 * The public m8tec "Apple Music Animated Artworks" server (or one you run yourself). It returns the same Apple Music
 * .m3u8 streams. The answer format is not documented, so the reply is searched for any .m3u8 link, square ones first.
 */
object BackupServerCovers {
    suspend fun find(artist: String, album: String): String? = withContext(Dispatchers.IO) {
        val base = NeedleSettings.backupServerUrl.value.trim().trimEnd('/')
        if (!base.startsWith("https://")) return@withContext null
        val reply = httpGet("$base/api/v1/artwork/search?artist=${enc(artist)}&album=${enc(album)}")
        val text = reply.body?.let { String(it) } ?: return@withContext null
        runCatching {
            val found = ArrayList<Pair<String, String>>() // path in the reply, link
            fun walk(node: Any?, path: String) {
                when (node) {
                    is JSONObject -> node.keys().forEach { k -> walk(node.opt(k), "$path/$k") }
                    is JSONArray -> for (i in 0 until node.length()) walk(node.opt(i), "$path/$i")
                    is String -> if (node.contains(".m3u8")) found.add(path to node)
                }
            }
            walk(JSONTokener(text).nextValue(), "")
            (found.firstOrNull { it.first.contains("square", ignoreCase = true) } ?: found.firstOrNull())?.second
        }.getOrNull()
    }
}

/**
 * Tidal's looping video covers (some albums have one). Uses Tidal's own web catalog with the token from Settings.
 * The video is a plain mp4 on resources.tidal.com.
 */
object TidalCovers {
    suspend fun find(artist: String, album: String): String? = withContext(Dispatchers.IO) {
        val token = NeedleSettings.tidalToken.value.trim()
        if (token.isEmpty()) return@withContext null
        val url = "https://api.tidal.com/v1/search/albums?query=${enc("$artist $album")}&countryCode=US&limit=8"
        val body = httpGet(url, mapOf("X-Tidal-Token" to token)).body ?: return@withContext null
        runCatching {
            val items = JSONObject(String(body)).optJSONArray("items") ?: return@runCatching null
            for (i in 0 until items.length()) {
                val a = items.optJSONObject(i) ?: continue
                if (a.isNull("videoCover")) continue
                val video = a.optString("videoCover").takeIf { it.isNotBlank() } ?: continue
                if (!sameish(a.optString("title"), album)) continue
                val artists = a.optJSONArray("artists")
                val artistOk = (0 until (artists?.length() ?: 0)).any { sameish(artists!!.optJSONObject(it)?.optString("name").orEmpty(), artist) }
                if (!artistOk) continue
                return@runCatching "https://resources.tidal.com/videos/${video.replace('-', '/')}/640x640.mp4"
            }
            null
        }.getOrNull()
    }
}
