package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.SingleItem
import app.needle.music.data.SinglesState
import app.needle.music.data.Song

private enum class SinglesFilter(val label: String) {
    ALL("All"),
    THIS_YEAR("This year"),
    NOT_PLAYED("Not played yet")
}

/**
 * Home / Singles page from the mockup: every song that is not part of an album, as a grid of covers.
 * The mockup's search and sort buttons and its "Liked" filter wait for those features.
 */
@Composable
fun SinglesScreen(
    state: SinglesState?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onEditTags: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    var filter by rememberSaveable { mutableStateOf(SinglesFilter.ALL) }
    val shown: List<SingleItem> = remember(state, filter) {
        val all = state?.items.orEmpty()
        when (filter) {
            SinglesFilter.ALL -> all
            SinglesFilter.THIS_YEAR -> all.filter { it.year == state?.thisYear }
            SinglesFilter.NOT_PLAYED -> all.filter { !it.played }
        }
    }
    val queue: List<Song> = remember(shown) { shown.map { it.song } }

    LazyVerticalGrid(
        columns = GridCells.Fixed(2),
        modifier = modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding),
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item(span = { GridItemSpan(maxLineSpan) }) {
            Column {
                ListBackButton(onBack, Modifier.padding(top = 8.dp))

                Text(
                    "Singles", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                if (state != null) {
                    Text(
                        if (filter == SinglesFilter.ALL) "${shown.size} songs released on their own."
                        else "${shown.size} songs",
                        color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                    )
                }
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SinglesFilter.entries.forEach { f ->
                        FilterPill(f.label, selected = f == filter, onClick = { filter = f })
                    }
                }
            }
        }

        if (state != null && shown.isEmpty()) {
            item(span = { GridItemSpan(maxLineSpan) }) {
                Text(
                    if (filter == SinglesFilter.ALL) "No singles found." else "Nothing here.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp)
                )
            }
        }

        items(shown, key = { it.song.id }) { item ->
            SingleCell(item, onClick = { onPlay(queue, shown.indexOf(item)) }, onLongClick = { onEditTags(item.song) })
        }
    }
}

@Composable
private fun FilterPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color(0xFF111111) else Palette.Text,
        fontSize = 13.5.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun SingleCell(item: SingleItem, onClick: () -> Unit, onLongClick: () -> Unit) {
    Column(Modifier.tapOrHold(onClick = onClick, onLongClick = onLongClick)) {
        Box(Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(20.dp))) {
            Cover(item.song, Modifier.fillMaxSize())
            Text(
                "Single", color = Color.White, fontSize = 10.5.sp,
                modifier = Modifier
                    .align(Alignment.BottomStart)
                    .padding(10.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.45f))
                    .padding(horizontal = 10.dp, vertical = 4.dp)
            )
        }
        Text(
            item.song.title, color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
        )
        Text(
            "${item.song.artist} · ${item.year}", color = Palette.Muted, fontSize = 12.sp,
            maxLines = 1, overflow = TextOverflow.Ellipsis
        )
    }
}
