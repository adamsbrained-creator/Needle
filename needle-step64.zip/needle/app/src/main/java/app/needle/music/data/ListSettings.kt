package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONObject

enum class RowStyle(val label: String) { NORMAL("Normal"), COMPACT("Compact"), TEXT_ONLY("Text only") }
enum class RowSubtitle(val label: String) { ARTIST_ALBUM("Artist · Album"), ARTIST("Artist"), ALBUM("Album") }
enum class RowDetail(val label: String) {
    DURATION("Duration"), YEAR("Year"), PLAYS("Plays"), ADDED("Added"), RATING("Rating"), NONE("Nothing")
}
enum class AlbumRating(val label: String) { OFF("Off"), NUMBER("Number"), STARS("Stars") }
enum class RowSwipe(val label: String) {
    NONE("Off"), PLAY_NEXT("Play next"), QUEUE("Add to queue"), FAVORITE("Favorite"), PLAYLIST("Add to playlist")
}

/** One media list setting that is remembered, backed up, and can go back to its default. */
interface ListSetting {
    fun load(p: SharedPreferences)
    fun reset()
    fun put(o: JSONObject)
    fun read(o: JSONObject)
}

class ListBool(private val key: String, private val def: Boolean) : ListSetting {
    private val s = mutableStateOf(def)
    val value: Boolean get() = s.value
    fun set(v: Boolean) { s.value = v; ListSettings.save { putBoolean(key, v) } }
    override fun load(p: SharedPreferences) { s.value = p.getBoolean(key, def) }
    override fun reset() = set(def)
    override fun put(o: JSONObject) { o.put(key, s.value) }
    override fun read(o: JSONObject) { if (o.has(key)) set(o.optBoolean(key, def)) }
}

class ListEnum<E : Enum<E>>(private val key: String, private val def: E, private val all: Array<E>) : ListSetting {
    private val s = mutableStateOf(def)
    val value: E get() = s.value
    private fun byName(n: String?): E = all.firstOrNull { it.name == n } ?: def
    fun set(v: E) { s.value = v; ListSettings.save { putString(key, v.name) } }
    override fun load(p: SharedPreferences) { s.value = byName(p.getString(key, def.name)) }
    override fun reset() = set(def)
    override fun put(o: JSONObject) { o.put(key, s.value.name) }
    override fun read(o: JSONObject) { if (o.has(key)) set(byName(o.optString(key))) }
}

class ListInt(private val key: String, private val def: Int, private val range: IntRange) : ListSetting {
    private val s = mutableIntStateOf(def)
    val value: Int get() = s.intValue
    fun set(v: Int) { val c = v.coerceIn(range); s.intValue = c; ListSettings.save { putInt(key, c) } }
    override fun load(p: SharedPreferences) { s.intValue = p.getInt(key, def).coerceIn(range) }
    override fun reset() = set(def)
    override fun put(o: JSONObject) { o.put(key, s.intValue) }
    override fun read(o: JSONObject) { if (o.has(key)) set(o.optInt(key, def)) }
}

/**
 * Settings > Customization > Media lists: how song rows, list headers, album grids and swipes look and behave.
 * Kept in their own file on the phone ("needle_lists") and included in backups.
 */
object ListSettings {
    private var prefs: SharedPreferences? = null
    private val all = ArrayList<ListSetting>()
    private fun <T : ListSetting> reg(s: T): T { all.add(s); return s }

    // Rows
    val rowStyle = reg(ListEnum("rowStyle", RowStyle.NORMAL, RowStyle.entries.toTypedArray()))
    val subtitle = reg(ListEnum("subtitle", RowSubtitle.ARTIST_ALBUM, RowSubtitle.entries.toTypedArray()))
    val detail = reg(ListEnum("detail", RowDetail.DURATION, RowDetail.entries.toTypedArray()))
    val ratingInSubtitle = reg(ListBool("ratingInSubtitle", true))
    val favoriteHeart = reg(ListBool("favoriteHeart", true))

    // Headers
    val showCounts = reg(ListBool("showCounts", true))
    val flipSortArrows = reg(ListBool("flipSortArrows", false))
    val pinSortBar = reg(ListBool("pinSortBar", false))
    val hideListBack = reg(ListBool("hideListBack", false))

    // Album grid
    val albumColumns = reg(ListInt("albumColumns", 2, 2..4))
    val centerGridText = reg(ListBool("centerGridText", false))

    // Album pages
    val albumRating = reg(ListEnum("albumRating", AlbumRating.OFF, AlbumRating.entries.toTypedArray()))
    val albumHeart = reg(ListBool("albumHeart", false))

    // Gestures
    val swipeRight = reg(ListEnum("swipeRight", RowSwipe.QUEUE, RowSwipe.entries.toTypedArray()))
    val swipeLeft = reg(ListEnum("swipeLeft", RowSwipe.PLAY_NEXT, RowSwipe.entries.toTypedArray()))
    val longPressSelect = reg(ListBool("longPressSelect", false))

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_lists", Context.MODE_PRIVATE)
        prefs = p
        all.forEach { it.load(p) }
    }

    internal fun save(block: SharedPreferences.Editor.() -> Unit) {
        prefs?.edit()?.apply(block)?.apply()
    }

    fun resetAll() = all.forEach { it.reset() }

    fun toJson(): JSONObject = JSONObject().also { o -> all.forEach { it.put(o) } }
    fun fromJson(o: JSONObject) = all.forEach { it.read(o) }
}
