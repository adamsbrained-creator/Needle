package app.needle.music.playback

import android.app.Application
import android.content.ComponentName
import android.graphics.BitmapFactory
import android.os.Bundle
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.C
import androidx.media3.common.PlaybackParameters
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.needle.music.data.Song

/** One row of the "Up next" list. [index] is the position in the real queue, [mediaId] the song's id. */
data class QueueEntry(val index: Int, val title: String, val artist: String, val mediaId: String = "")

/**
 * The bridge between the UI and the playback service.
 * The UI only reads these state fields and calls the functions below, which is what
 * keeps the skin easy to redesign later. The queue itself lives in the service.
 */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    var isPlaying by mutableStateOf(false); private set
    var hasMedia by mutableStateOf(false); private set
    var currentMediaId by mutableStateOf<String?>(null); private set
    var title by mutableStateOf<String?>(null); private set
    var artist by mutableStateOf<String?>(null); private set
    var album by mutableStateOf<String?>(null); private set
    var artwork by mutableStateOf<ImageBitmap?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set
    var shuffleEnabled by mutableStateOf(false); private set
    var repeatMode by mutableIntStateOf(Player.REPEAT_MODE_OFF); private set
    var queueSize by mutableIntStateOf(0); private set

    /** Playback speed and pitch of this phone's player (1.0 = normal). */
    var speed by mutableFloatStateOf(1f); private set
    var pitch by mutableFloatStateOf(1f); private set

    /** Bumps whenever the queue or its order changes, so the queue screen knows to refresh. */
    var queueVersion by mutableIntStateOf(0); private set

    private var controller: MediaController? = null
    private var pending: ((MediaController) -> Unit)? = null
    private var lastArtData: ByteArray? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) {
            sync(player)
            if (events.containsAny(
                    Player.EVENT_TIMELINE_CHANGED,
                    Player.EVENT_MEDIA_ITEM_TRANSITION,
                    Player.EVENT_SHUFFLE_MODE_ENABLED_CHANGED
                )
            ) queueVersion++
        }
    }

    private val future = MediaController.Builder(
        app,
        SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()

    init {
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                controller = c
                c.addListener(listener)
                sync(c)
                queueVersion++
                pending?.let { it(c); pending = null }
            }
        }, ContextCompat.getMainExecutor(app))
    }

    /**
     * The list the queue was started from (an album, a playlist, the song list ...), kept even when songs are added to the
     * queue later. The header on Now playing names the queue from this.
     */
    var sourceIds by androidx.compose.runtime.mutableStateOf<List<Long>>(emptyList())
        private set

    private fun rememberSource(songs: List<Song>) {
        sourceIds = songs.map { it.id }
    }

    // ---- starting playback -----------------------------------------------------------

    /** Play [songs] (in this order) starting at [index]. Keeps the current shuffle mode. */
    fun playSongs(songs: List<Song>, index: Int, shuffle: Boolean? = null) {
        rememberSource(songs)
        sendQueue(songs, index, shuffle)
    }

    /** Play [songs] shuffled, starting from a random one. */
    fun shuffleAll(songs: List<Song>) {
        if (songs.isNotEmpty()) {
            rememberSource(songs)
            sendQueue(songs, songs.indices.random(), shuffle = true)
        }
    }

    /** Play [songs] right after the current song (in the shuffled order too). */
    fun playNext(songs: List<Song>) = sendAdd(songs, next = true)

    /** Put [songs] at the end of the queue. */
    fun addToQueue(songs: List<Song>) = sendAdd(songs, next = false)

    private fun sendAdd(songs: List<Song>, next: Boolean) {
        if (songs.isEmpty()) return
        val args = Bundle().apply {
            putLongArray(QueueCommands.KEY_IDS, LongArray(songs.size) { songs[it].id })
            putBoolean(QueueCommands.KEY_NEXT, next)
        }
        withController { it.sendCustomCommand(QueueCommands.addToQueue, args) }
    }

    private fun sendQueue(songs: List<Song>, start: Int, shuffle: Boolean?) {
        if (start !in songs.indices) return
        val args = Bundle().apply {
            putLongArray(QueueCommands.KEY_IDS, LongArray(songs.size) { songs[it].id })
            putInt(QueueCommands.KEY_START, start)
            if (shuffle != null) putBoolean(QueueCommands.KEY_SHUFFLE, shuffle)
        }
        withController { it.sendCustomCommand(QueueCommands.playQueue, args) }
    }

    private fun withController(block: (MediaController) -> Unit) {
        val c = controller
        if (c != null) block(c) else pending = block
    }

    // ---- transport -------------------------------------------------------------------

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    /** 0.5x to 2x; the same value for both resets to normal. */
    fun setSpeedPitch(speed: Float, pitch: Float) {
        controller?.playbackParameters = PlaybackParameters(speed.coerceIn(0.5f, 2f), pitch.coerceIn(0.5f, 2f))
    }

    fun next() { controller?.seekToNext() }

    fun previous() { controller?.seekToPrevious() }

    fun toggleShuffle() {
        controller?.let { it.shuffleModeEnabled = !it.shuffleModeEnabled }
    }

    fun cycleRepeat() {
        controller?.let {
            it.repeatMode = when (it.repeatMode) {
                Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                else -> Player.REPEAT_MODE_OFF
            }
        }
    }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        refreshPosition()
    }

    /** Seek to a point in the current song, 0f = start, 1f = end. */
    fun seekToFraction(fraction: Float) {
        val c = controller ?: return
        val duration = c.duration
        if (duration == C.TIME_UNSET || duration <= 0L) return
        seekTo((fraction.coerceIn(0f, 1f) * duration).toLong())
    }

    /** Called by the UI a few times per second while the player screen is open and playing. */
    fun refreshPosition() {
        controller?.let {
            positionMs = it.currentPosition
            durationMs = if (it.duration == C.TIME_UNSET) 0L else it.duration
        }
    }

    // ---- queue -----------------------------------------------------------------------

    /** The ids of every song in the queue, in the order they were queued (for "Save queue as playlist"). */
    fun queueSongIds(): List<Long> {
        val c = controller ?: return emptyList()
        return (0 until c.mediaItemCount).mapNotNull { c.getMediaItemAt(it).mediaId.toLongOrNull() }
    }

    /** The songs that will play after the current one, in playback order (shuffle-aware). */
    fun upNext(limit: Int = 100): List<QueueEntry> {
        val c = controller ?: return emptyList()
        val timeline = c.currentTimeline
        if (timeline.isEmpty) return emptyList()
        val shuffle = c.shuffleModeEnabled
        val out = ArrayList<QueueEntry>()
        var i = timeline.getNextWindowIndex(c.currentMediaItemIndex, Player.REPEAT_MODE_OFF, shuffle)
        while (i != C.INDEX_UNSET && out.size < limit) {
            val md = c.getMediaItemAt(i).mediaMetadata
            out += QueueEntry(i, md.title?.toString().orEmpty(), md.artist?.toString().orEmpty(), c.getMediaItemAt(i).mediaId)
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, shuffle)
        }
        return out
    }

    fun jumpTo(index: Int) {
        controller?.let {
            it.seekTo(index, C.TIME_UNSET)
            it.play()
        }
    }

    fun removeFromQueue(index: Int) {
        controller?.removeMediaItem(index)
    }

    /** Take every copy of this song out of the queue (used after its file is deleted). If it is playing, the next song starts. */
    fun removeSongFromQueue(songId: Long) {
        val c = controller ?: return
        val id = songId.toString()
        for (i in c.mediaItemCount - 1 downTo 0) {
            if (c.getMediaItemAt(i).mediaId == id) c.removeMediaItem(i)
        }
    }

    /** How many songs are still to play after the current one in the queue (not counting repeat). */
    fun songsLeft(): Int {
        val c = controller ?: return 0
        val timeline = c.currentTimeline
        if (timeline.isEmpty) return 0
        var n = 0
        var i = timeline.getNextWindowIndex(c.currentMediaItemIndex, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
        while (i != C.INDEX_UNSET && n < 50) {
            n++
            i = timeline.getNextWindowIndex(i, Player.REPEAT_MODE_OFF, c.shuffleModeEnabled)
        }
        return n
    }

    /** Put the first songs of "Up next" in a new order. [indices] are their queue positions, first to last. */
    fun reorderUpNext(indices: List<Int>) {
        val args = Bundle().apply { putIntArray(QueueCommands.KEY_ORDER, indices.toIntArray()) }
        withController { it.sendCustomCommand(QueueCommands.reorderUpNext, args) }
    }

    /** Take every song out of the queue except the one that is playing. */
    fun clearUpNext() {
        val c = controller ?: return
        val current = c.currentMediaItemIndex
        if (current < c.mediaItemCount - 1) c.removeMediaItems(current + 1, c.mediaItemCount)
        if (current > 0) c.removeMediaItems(0, current)
    }

    // ---- state sync ------------------------------------------------------------------

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        hasMedia = p.currentMediaItem != null
        currentMediaId = p.currentMediaItem?.mediaId
        shuffleEnabled = p.shuffleModeEnabled
        repeatMode = p.repeatMode
        queueSize = p.mediaItemCount
        speed = p.playbackParameters.speed
        pitch = p.playbackParameters.pitch
        val md = p.mediaMetadata
        title = md.title?.toString()
        album = md.albumTitle?.toString()
        artist = md.artist?.toString() ?: md.albumArtist?.toString()
        val data = md.artworkData
        if (data !== lastArtData) {
            lastArtData = data
            artwork = data?.let {
                runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull()
            }
        }
        positionMs = p.currentPosition
        durationMs = if (p.duration == C.TIME_UNSET) 0L else p.duration
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        super.onCleared()
    }
}
