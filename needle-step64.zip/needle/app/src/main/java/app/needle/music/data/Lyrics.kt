package app.needle.music.data

import androidx.room.Dao
import androidx.room.Entity
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Upsert

/** Where the lyrics on screen came from. */
enum class LyricsSource(val label: String) {
    FILE("a .lrc file next to the song"),
    TAGS("the Lyrics tag you saved in Needle"),
    EMBEDDED("the lyrics inside the audio file"),
    SAVED("LRCLIB, saved on this phone")
}

/** [timeMs] is -1 for plain (not timed) lyrics. */
class LyricLine(val timeMs: Long, val text: String)

class Lyrics(val lines: List<LyricLine>, val synced: Boolean, val source: LyricsSource) {
    /** The words only, for sharing. */
    fun plainText(): String = lines.joinToString("\n") { it.text }.trim()
}

/** Lyrics found online are kept here, so that song works offline from then on. */
@Entity(tableName = "lyrics_cache")
data class LyricsCache(
    @PrimaryKey val songId: Long,
    val text: String,
    val synced: Boolean,
    val source: String,
    val fetchedAt: Long
)

@Dao
interface LyricsDao {
    @Query("SELECT * FROM lyrics_cache WHERE songId = :id")
    suspend fun get(id: Long): LyricsCache?

    @Upsert
    suspend fun save(row: LyricsCache)

    @Query("DELETE FROM lyrics_cache WHERE songId = :id")
    suspend fun delete(id: Long)

    @Query("SELECT COUNT(*) FROM lyrics_cache")
    suspend fun count(): Int

    /** Every saved lyric, for searching the words of songs. */
    @Query("SELECT * FROM lyrics_cache")
    suspend fun getAll(): List<LyricsCache>

    @Query("DELETE FROM lyrics_cache")
    suspend fun clear()
}

/** Reads .lrc text ("[01:23.45] words"), including several stamps per line, [offset:] and word tags. */
object LrcParser {
    private val stamp = Regex("""\[(\d{1,3}):(\d{1,2})(?:[.:](\d{1,3}))?]""")
    private val meta = Regex("""^\[([A-Za-z#]+):(.*)]$""")
    private val wordTag = Regex("""<\d{1,3}:\d{1,2}(?:[.:]\d{1,3})?>""")
    private val metaKeys = setOf("ar", "ti", "al", "au", "by", "length", "re", "ve", "offset", "#", "tool", "id")

    fun parse(raw: String, source: LyricsSource): Lyrics? {
        val text = raw.removePrefix("\uFEFF").replace("\r\n", "\n").replace('\r', '\n')
        var offset = 0L
        val timed = ArrayList<LyricLine>()
        val plain = ArrayList<String>()

        for (rawLine in text.split('\n')) {
            val line = rawLine.trim()
            val m = meta.find(line)
            if (m != null && m.groupValues[1].lowercase() in metaKeys) {
                if (m.groupValues[1].lowercase() == "offset") offset = m.groupValues[2].trim().toLongOrNull() ?: 0L
                continue
            }
            val times = ArrayList<Long>()
            var pos = 0
            while (true) {
                val s = stamp.matchAt(line, pos) ?: break
                val frac = s.groupValues[3]
                val ms = when (frac.length) {
                    0 -> 0
                    1 -> frac.toInt() * 100
                    2 -> frac.toInt() * 10
                    else -> frac.take(3).toInt()
                }
                times += (s.groupValues[1].toLong() * 60 + s.groupValues[2].toLong()) * 1000 + ms
                pos = s.range.last + 1
            }
            if (times.isNotEmpty()) {
                val body = line.substring(pos).replace(wordTag, "").replace(Regex("\\s+"), " ").trim()
                for (t in times) timed += LyricLine(t, body)
            } else {
                plain += line
            }
        }

        if (timed.isNotEmpty()) {
            val lines = timed.map { LyricLine((it.timeMs - offset).coerceAtLeast(0L), it.text) }.sortedBy { it.timeMs }
            return Lyrics(lines, synced = true, source = source)
        }
        // Plain text: keep the blank lines between verses, but not at the ends or twice in a row.
        val lines = ArrayList<LyricLine>()
        for (p in plain) {
            if (p.isEmpty() && (lines.isEmpty() || lines.last().text.isEmpty())) continue
            lines += LyricLine(-1L, p)
        }
        while (lines.isNotEmpty() && lines.last().text.isEmpty()) lines.removeAt(lines.size - 1)
        return if (lines.isEmpty()) null else Lyrics(lines, synced = false, source = source)
    }

    /** Index of the line being sung at [positionMs], or -1 before the first line. */
    fun activeIndex(lines: List<LyricLine>, positionMs: Long): Int {
        var lo = 0
        var hi = lines.size - 1
        var found = -1
        while (lo <= hi) {
            val mid = (lo + hi) ushr 1
            if (lines[mid].timeMs <= positionMs) { found = mid; lo = mid + 1 } else hi = mid - 1
        }
        return found
    }
}
