package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * The artists the person pinned. They sit at the top of the Artists page, in the order they were pinned.
 * Stored by [artistKey], so upper and lower case do not matter. Remembered.
 */
object PinnedArtists {
    private var prefs: SharedPreferences? = null

    /** The pinned artists' keys, oldest pin first. */
    val keys = MutableStateFlow<List<String>>(emptyList())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        keys.value = p.getString("pinned_artists", "").orEmpty().split('\n').filter { it.isNotBlank() }
    }

    fun isPinned(artist: String): Boolean = artistKey(artist) in keys.value

    /** Pins the artist, or unpins them if they were pinned. Returns true if they are pinned now. */
    fun toggle(artist: String): Boolean {
        val key = artistKey(artist)
        if (key.isEmpty()) return false
        val now = key !in keys.value
        save(if (now) keys.value + key else keys.value - key)
        return now
    }

    /** Replaces everything (restoring a backup). */
    fun replaceAll(list: List<String>) = save(list.map { artistKey(it) }.filter { it.isNotEmpty() }.distinct())

    private fun save(list: List<String>) {
        keys.value = list
        prefs?.edit()?.putString("pinned_artists", list.joinToString("\n"))?.apply()
    }
}
