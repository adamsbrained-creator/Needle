package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.MostRange
import app.needle.music.data.Song
import app.needle.music.data.StatsData
import app.needle.music.data.formatListened

/**
 * "Your stats" from the mockup: how long you listened, on which days, your top songs, artists and genres, for a
 * week, month, year or all time. Everything is counted on this phone from the play history.
 */
@Composable
fun StatsScreen(
    state: Map<MostRange, StatsData>?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onPlay: (List<Song>, Int) -> Unit,
    onMenu: (Song) -> Unit,
    onOpenArtist: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    var range by rememberSaveable { mutableStateOf(MostRange.WEEK) }
    val data = state?.get(range)

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                }
                Text(
                    "Your stats", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    "Counted on this phone. It never leaves it.", color = Palette.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    MostRange.entries.forEach { r -> StatsPill(r.label, selected = r == range, onClick = { range = r }) }
                }
                Spacer(Modifier.height(16.dp))
            }
        }

        if (data == null) return@LazyColumn

        if (data.isEmpty) {
            item {
                Text(
                    "Nothing played in this period yet. A song counts after 30 seconds of listening.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp)
                )
            }
            return@LazyColumn
        }

        item { ListeningCard(data) }
        item {
            Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                NumberCard("${data.plays}", if (data.plays == 1) "Play" else "Plays", Modifier.weight(1f))
                NumberCard("${data.artistCount}", if (data.artistCount == 1) "Artist" else "Artists", Modifier.weight(1f))
            }
        }

        if (data.topSongs.isNotEmpty()) {
            item { StatsHeader("Top songs") }
            val queue = data.topSongs.map { it.song }
            items(data.topSongs.size) { i ->
                val p = data.topSongs[i]
                Row(
                    Modifier.fillMaxWidth().tapOrHold({ onPlay(queue, i) }, { onMenu(p.song) }).padding(vertical = 7.dp, horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${i + 1}", color = Palette.Muted, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, modifier = Modifier.width(30.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    SongArtwork(p.song, size = 48.dp, corner = 13.dp)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            p.song.title, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                            maxLines = 1, overflow = TextOverflow.Ellipsis
                        )
                        Text(p.song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                    Text(playsText(p.plays), color = Color(0xFFDDDDDD), fontSize = 12.5.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        if (data.topArtists.isNotEmpty()) {
            item { StatsHeader("Top artists") }
            items(data.topArtists.size) { i ->
                val a = data.topArtists[i]
                Row(
                    Modifier.fillMaxWidth().clickable { onOpenArtist(a.name) }.padding(vertical = 12.dp, horizontal = 2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        "${i + 1}", color = Palette.Muted, fontSize = 17.sp, fontWeight = FontWeight.SemiBold,
                        textAlign = TextAlign.Center, modifier = Modifier.width(30.dp)
                    )
                    Spacer(Modifier.width(8.dp))
                    Text(
                        a.name, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.Medium,
                        maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                    )
                    Text(playsText(a.plays), color = Color(0xFFDDDDDD), fontSize = 12.5.sp, modifier = Modifier.padding(start = 8.dp))
                }
            }
        }

        if (data.topGenres.isNotEmpty()) {
            item { StatsHeader("Top genres") }
            items(data.topGenres.size) { i ->
                val g = data.topGenres[i]
                Column(Modifier.fillMaxWidth().padding(vertical = 8.dp, horizontal = 2.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            g.name, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.Medium,
                            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f)
                        )
                        Text("${g.percent}%", color = Color(0xFFDDDDDD), fontSize = 12.5.sp)
                    }
                    Box(
                        Modifier.padding(top = 7.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.1f))
                    ) {
                        Box(
                            Modifier.fillMaxHeight().fillMaxWidth((g.percent / 100f).coerceIn(0.02f, 1f)).clip(CircleShape)
                                .background(Brush.horizontalGradient(listOf(Palette.Accent, Palette.Pink)))
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun StatsPill(text: String, selected: Boolean, onClick: () -> Unit) {
    Text(
        text,
        color = if (selected) Color(0xFF111111) else Palette.Text,
        fontSize = 13.5.sp,
        fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
        maxLines = 1,
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp, vertical = 10.dp)
    )
}

@Composable
private fun StatsHeader(title: String) {
    Text(
        title, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 2.dp, top = 24.dp, bottom = 6.dp)
    )
}

@Composable
private fun NumberCard(value: String, label: String, modifier: Modifier) {
    Column(modifier.clip(RoundedCornerShape(22.dp)).background(Palette.Card).padding(horizontal = 16.dp, vertical = 14.dp)) {
        Text(value, color = Palette.Text, fontSize = 26.sp, fontWeight = FontWeight.SemiBold, maxLines = 1)
        Text(label, color = Palette.Muted, fontSize = 12.sp)
    }
}

/** The big card: the time listened and a bar for each weekday, the busiest one in the accent color. */
@Composable
private fun ListeningCard(data: StatsData) {
    val shape = RoundedCornerShape(28.dp)
    val max = (data.weekdays.maxOrNull() ?: 0L).coerceAtLeast(1L)
    val busiest = data.weekdays.indexOf(data.weekdays.maxOrNull() ?: 0L)
    Column(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Accent.copy(alpha = 0.4f), Color.White.copy(alpha = 0.06f))))
            .padding(18.dp)
    ) {
        Text("Time listened", color = Color(0xFFD8CDF5), fontSize = 12.sp)
        Text(
            formatListened(data.listenedMs), color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 38.sp,
            modifier = Modifier.padding(top = 2.dp, bottom = 16.dp)
        )
        Row(Modifier.fillMaxWidth().height(86.dp), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.Bottom) {
            data.weekdays.forEachIndexed { i, ms ->
                Column(Modifier.weight(1f).fillMaxHeight(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Bottom) {
                    Box(
                        Modifier
                            .fillMaxWidth()
                            .height((62 * ms.toFloat() / max).coerceAtLeast(4f).dp)
                            .clip(RoundedCornerShape(8.dp))
                            .background(if (i == busiest && ms > 0) Color.White else Color.White.copy(alpha = 0.22f))
                    )
                    Text(
                        DAY_LETTERS[i], color = if (i == busiest && ms > 0) Palette.Text else Palette.Muted, fontSize = 11.sp,
                        modifier = Modifier.padding(top = 6.dp)
                    )
                }
            }
        }
    }
}

private val DAY_LETTERS = listOf("M", "T", "W", "T", "F", "S", "S")

private fun playsText(n: Int) = if (n == 1) "1 play" else "$n plays"
