package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.HomeAlbum
import app.needle.music.data.HomeLayout
import app.needle.music.data.NewHero
import app.needle.music.data.NewSingle
import app.needle.music.data.NewState
import app.needle.music.data.Song

/**
 * Home / New page from the mockup: the latest album, what was added this week, and new singles.
 * The mockup's "Edit tags" button and "needs tags" card wait for the tag editor.
 * The "View all" links stay hidden while their callbacks are null.
 */
@Composable
fun NewScreen(
    state: NewState?,
    bottomPadding: Dp,
    onPlay: (List<Song>, Int) -> Unit,
    onShuffle: (List<Song>) -> Unit,
    onEditTags: (List<Song>) -> Unit,
    onTabSelected: (HomeTab) -> Unit,
    modifier: Modifier = Modifier,
    profileInitial: String = "E",
    onSearch: () -> Unit = {},
    onProfile: () -> Unit = {},
    onViewAllRecent: (() -> Unit)? = null,
    onViewAllSingles: (() -> Unit)? = null
) {
    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = bottomPadding)) {
        item { HomeHeader(profileInitial, onSearch, onProfile) }
        item { HomeTabs(selected = HomeTab.NEW, onSelect = onTabSelected) }

        if (state == null) return@LazyColumn

        if (state.hero == null && state.singles.isEmpty()) {
            item {
                Text(
                    "Nothing new yet. Add some music, then scan again from Songs.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
                )
            }
            return@LazyColumn
        }

        val order = HomeLayout.visibleSectionIds("NEW")
        order.forEach { id ->
            when (id) {
                "new_hero" -> {
        state.hero?.let { hero ->
            item {
                NewHeroCard(
                    hero,
                    onPlay = { onPlay(hero.songs, 0) },
                    onShuffle = { onShuffle(hero.songs) },
                    onEditTags = { onEditTags(hero.songs) }
                )
            }
        }

                }
                "new_recent" -> {
        if (state.recent.isNotEmpty()) {
            item { SectionHeader(state.recentTitle, "View all", onViewAllRecent) }
            item {
                LazyRow(
                    contentPadding = PaddingValues(horizontal = 18.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(state.recent) { album -> RecentTile(album, onClick = { onPlay(album.songs, 0) }) }
                }
            }
        }

                }
                "new_singles" -> {
        if (state.singles.isNotEmpty()) {
            item { SectionHeader("New singles", "View all", onViewAllSingles) }
            val queue = state.singles.map { it.song }
            items(state.singles.size) { i ->
                SingleRow(state.singles[i], onClick = { onPlay(queue, i) })
            }
        }
                }
                "new_needtags" -> {
                    if (state.needTags.isNotEmpty()) {
                        item { NeedTagsCard(state.needTags.size, onFix = { onEditTags(state.needTags) }) }
                    }
                }
            }
        }
        if (order.isEmpty()) {
            item {
                Text(
                    "Every section is hidden. Bring them back in Settings > Customization > Home layout.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 32.dp, vertical = 48.dp)
                )
            }
        }
    }
}

/** "4 new songs need tags": songs added this week without a genre. Fix tags edits them all at once. */
@Composable
private fun NeedTagsCard(count: Int, onFix: () -> Unit) {
    val shape = RoundedCornerShape(24.dp)
    Column(
        Modifier
            .padding(start = 18.dp, end = 18.dp, top = 22.dp)
            .fillMaxWidth()
            .clip(shape)
            .background(Brush.linearGradient(listOf(Palette.Pink.copy(alpha = 0.30f), Color.White.copy(alpha = 0.06f))))
            .border(1.dp, Color.White.copy(alpha = 0.1f), shape)
            .padding(18.dp)
    ) {
        Text(
            if (count == 1) "1 new song needs tags" else "$count new songs need tags",
            color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold
        )
        Text(
            "They have no genre yet, so they cannot be used for genre picks on Home.",
            color = Palette.Muted, fontSize = 13.sp, modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
        )
        Text(
            "Fix tags", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier.clip(CircleShape).background(Color.White).clickable(onClick = onFix)
                .padding(horizontal = 22.dp, vertical = 11.dp)
        )
    }
}

// ---- hero --------------------------------------------------------------------------------

@Composable
private fun NewHeroCard(hero: NewHero, onPlay: () -> Unit, onShuffle: () -> Unit, onEditTags: () -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    val glow = Color(0xFF7850FF).copy(alpha = 0.55f)
    Box(
        Modifier
            .padding(start = 18.dp, end = 18.dp, top = 14.dp)
            .fillMaxWidth()
            .height(268.dp)
            .shadow(22.dp, shape, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .background(Palette.Card)
    ) {
        HeroCover(hero.cover, Modifier.fillMaxSize())
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(0.35f to Color.Transparent, 1f to Color.Black.copy(alpha = 0.65f))
            )
        )
        Text(
            hero.label, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(16.dp)
                .clip(CircleShape)
                .background(Palette.Accent)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
        Column(Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 12.dp)) {
            Text(
                hero.title, color = Color.White, fontFamily = Palette.TitleFont, fontSize = 32.sp, lineHeight = 34.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis
            )
            Text(
                hero.subtitle, color = Color(0xFFE6E6EA), fontSize = 12.5.sp,
                maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp, bottom = 12.dp)
            )
            Row(
                Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Box(
                    Modifier.height(40.dp).clip(CircleShape).background(Color.White)
                        .clickable(onClick = onPlay).padding(horizontal = 22.dp),
                    contentAlignment = Alignment.Center
                ) { Text("Play", color = Color(0xFF111111), fontSize = 14.sp, fontWeight = FontWeight.SemiBold) }

                Box(
                    Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
                        .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                        .clickable(onClick = onShuffle),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.SHUFFLE, Color.White, size = 18.dp) }

                Spacer(Modifier.weight(1f))

                Row(
                    Modifier
                        .height(40.dp)
                        .clip(CircleShape)
                        .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
                        .border(1.dp, Color.White.copy(alpha = 0.14f), CircleShape)
                        .clickable(onClick = onEditTags)
                        .padding(horizontal = 14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    NeedleIconView(NeedleIcon.TAG, Color.White, size = 16.dp)
                    Text("Edit tags", color = Color.White, fontSize = 12.5.sp)
                }
            }
        }
    }
}

/** Same as [Cover], but loaded at a higher resolution because this card is so big. */
@Composable
internal fun HeroCover(song: Song, modifier: Modifier) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peekHero(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peekHero(song) ?: ArtworkLoader.loadHero(context, song)
    }
    val bitmap = art
    if (bitmap != null) {
        Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
    } else {
        ArtworkPlaceholder(modifier)
    }
}

// ---- added this week ---------------------------------------------------------------------

@Composable
private fun RecentTile(album: HomeAlbum, onClick: () -> Unit) {
    Column(Modifier.width(112.dp).clickable(onClick = onClick)) {
        Box(Modifier.size(112.dp).clip(RoundedCornerShape(22.dp))) {
            Cover(album.cover, Modifier.fillMaxSize())
            // Pink dot = nothing from this album has been played yet.
            if (album.heardTracks == 0) {
                Box(
                    Modifier
                        .align(Alignment.TopEnd)
                        .padding(8.dp)
                        .size(9.dp)
                        .shadow(6.dp, CircleShape, ambientColor = Palette.Pink, spotColor = Palette.Pink)
                        .clip(CircleShape)
                        .background(Palette.Pink)
                )
            }
        }
        Text(
            album.title, color = Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.Medium,
            maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp)
        )
        Text(album.artist, color = Palette.Muted, fontSize = 11.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

// ---- new singles -------------------------------------------------------------------------

@Composable
private fun SingleRow(single: NewSingle, onClick: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        SongArtwork(single.song, size = 50.dp, corner = 13.dp)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                single.song.title, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                single.subtitle, color = Palette.Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        Spacer(Modifier.width(12.dp))
        Box(
            Modifier.size(38.dp).clip(CircleShape).background(Palette.Card2),
            contentAlignment = Alignment.Center
        ) { NeedleIconView(NeedleIcon.PLAY, Palette.Text, size = 16.dp) }
    }
}
