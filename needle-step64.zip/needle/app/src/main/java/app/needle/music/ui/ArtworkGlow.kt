package app.needle.music.ui

import android.graphics.Bitmap
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.SideEffect
import androidx.compose.runtime.State
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.lerp
import app.needle.music.data.NeedleSettings
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlin.math.abs
import kotlin.math.min

/**
 * The glow colors for Now playing, taken from the cover of the playing song and eased from one song to the next.
 * Returns null when the setting is off (or the moving background is), so the usual glow is drawn.
 * Covers without color (black and white) give a calm neutral glow.
 */
@Composable
fun rememberArtworkGlow(art: ImageBitmap?): State<GlowPalette>? {
    if (!NeedleSettings.adaptiveNowPlayingGlow.value || !GlowSettings.enabled.value) return null

    val base = Palette.Bg
    val fallback = defaultGlow(base)
    val extracted by produceState<GlowPalette?>(null, art) {
        value = if (art == null) null else withContext(Dispatchers.Default) { extractGlow(art, base) }
    }
    val target = extracted ?: fallback

    val spec = tween<Color>(900)
    val wash = animateColorAsState(target.wash, spec, label = "glowWash")
    val a = animateColorAsState(target.a, spec, label = "glowA")
    val b = animateColorAsState(target.b, spec, label = "glowB")
    val c = animateColorAsState(target.c, spec, label = "glowC")

    SideEffect { NowGlowTint.color = target.a }
    DisposableEffect(Unit) { onDispose { NowGlowTint.color = null } }

    // The colors are only read while drawing, so the fade never recomposes the page.
    return remember { derivedStateOf { GlowPalette(wash.value, a.value, b.value, c.value) } }
}

private const val BUCKETS = 12

private fun hueGap(a: Int, b: Int): Int {
    val d = abs(a - b)
    return min(d, BUCKETS - d)
}

private fun glowColor(r: Float, g: Float, b: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.RGBToHSV(r.toInt().coerceIn(0, 255), g.toInt().coerceIn(0, 255), b.toInt().coerceIn(0, 255), hsv)
    hsv[1] = hsv[1].coerceAtLeast(0.5f)
    hsv[2] = hsv[2].coerceIn(0.6f, 0.95f)
    return Color(android.graphics.Color.HSVToColor(hsv))
}

private fun shiftedHue(c: Color, degrees: Float): Color {
    val hsv = FloatArray(3)
    android.graphics.Color.colorToHSV(android.graphics.Color.argb(255, (c.red * 255).toInt(), (c.green * 255).toInt(), (c.blue * 255).toInt()), hsv)
    hsv[0] = (hsv[0] + degrees + 360f) % 360f
    return Color(android.graphics.Color.HSVToColor(hsv))
}

/** The main colors of a cover: the strongest hue, then up to two clearly different ones (weighted by how vivid they are). */
internal fun extractGlow(art: ImageBitmap, base: Color): GlowPalette? = runCatching {
    val size = 32
    val small = Bitmap.createScaledBitmap(art.asAndroidBitmap().copy(Bitmap.Config.ARGB_8888, false), size, size, true)
    val px = IntArray(size * size)
    small.getPixels(px, 0, size, 0, 0, size, size)

    val weight = FloatArray(BUCKETS)
    val sr = FloatArray(BUCKETS); val sg = FloatArray(BUCKETS); val sb = FloatArray(BUCKETS)
    val hsv = FloatArray(3)
    for (p in px) {
        android.graphics.Color.colorToHSV(p, hsv)
        if (hsv[1] < 0.15f || hsv[2] < 0.15f) continue
        val w = hsv[1] * (0.3f + hsv[2])
        val i = ((hsv[0] / 360f) * BUCKETS).toInt().coerceIn(0, BUCKETS - 1)
        weight[i] += w
        sr[i] += android.graphics.Color.red(p) * w
        sg[i] += android.graphics.Color.green(p) * w
        sb[i] += android.graphics.Color.blue(p) * w
    }

    val best = weight.indices.maxByOrNull { weight[it] } ?: return@runCatching null
    if (weight[best] < 2f) {
        // No real color in the cover: a calm neutral glow.
        val grey = Color(0xFF8A90A0)
        return@runCatching GlowPalette(lerp(base, grey, 0.3f), Color(0xFF9AA0B4), Color(0xFF8A8A96), Color(0xFF7C8A8C))
    }
    fun colorOf(i: Int) = glowColor(sr[i] / weight[i], sg[i] / weight[i], sb[i] / weight[i])

    val first = colorOf(best)
    val second = weight.indices
        .filter { hueGap(it, best) >= 2 && weight[it] >= weight[best] * 0.25f }
        .maxByOrNull { weight[it] }
    val third = weight.indices
        .filter { hueGap(it, best) >= 2 && (second == null || hueGap(it, second) >= 2) && weight[it] >= weight[best] * 0.15f }
        .maxByOrNull { weight[it] }

    GlowPalette(
        wash = lerp(base, first, 0.4f),
        a = first,
        b = second?.let(::colorOf) ?: shiftedHue(first, 40f),
        c = third?.let(::colorOf) ?: shiftedHue(first, -40f)
    )
}.getOrNull()
