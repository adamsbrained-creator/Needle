package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf
import org.json.JSONArray
import org.json.JSONObject

class HomeSectionInfo(val id: String, val title: String, val tab: String)

/**
 * Which sections Home shows, in what order, and which pills sit under the title.
 * Edited in Settings > Appearance > Edit Home layout. Saved, and Compose state so Home updates at once.
 */
object HomeLayout {
    val allSections = listOf(
        HomeSectionInfo("new_hero", "Newest album", "NEW"),
        HomeSectionInfo("new_recent", "Recently added", "NEW"),
        HomeSectionInfo("new_singles", "New singles", "NEW"),
        HomeSectionInfo("new_needtags", "Songs that need tags", "NEW"),
        HomeSectionInfo("pop_heroes", "Play now cards", "POPULAR"),
        HomeSectionInfo("pop_albums", "Your albums", "POPULAR"),
        HomeSectionInfo("pop_week", "This week", "POPULAR"),
        HomeSectionInfo("pop_rediscover", "Rediscover", "POPULAR")
    )
    private val defaultTabs = listOf("NEW", "POPULAR", "MOST_PLAYED", "SINGLES")

    private var prefs: SharedPreferences? = null
    private val order = mutableStateOf(allSections.map { it.id })
    private val hidden = mutableStateOf<Set<String>>(emptySet())
    private val tabOrder = mutableStateOf(defaultTabs)
    private val hiddenTabs = mutableStateOf<Set<String>>(emptySet())

    /** NEW or POPULAR: the page Home opens on. */
    val startTab = mutableStateOf("POPULAR")

    private fun csv(p: SharedPreferences, key: String): List<String> =
        (p.getString(key, "") ?: "").split(',').filter { it.isNotBlank() }

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_home", Context.MODE_PRIVATE)
        prefs = p
        applyLists(csv(p, "order"), csv(p, "hidden"), csv(p, "tabs"), csv(p, "hiddenTabs"), p.getString("start", "POPULAR") ?: "POPULAR")
    }

    /** Takes saved lists and fixes them up: unknown names are dropped, anything missing is added back. */
    private fun applyLists(ord: List<String>, hid: List<String>, tabs: List<String>, hidTabs: List<String>, start: String) {
        val known = allSections.map { it.id }
        order.value = ord.filter { it in known }.distinct().let { kept -> kept + known.filter { it !in kept } }
        hidden.value = hid.filter { it in known }.toSet()
        tabOrder.value = tabs.filter { it in defaultTabs }.distinct().let { kept -> kept + defaultTabs.filter { it !in kept } }
        hiddenTabs.value = hidTabs.filter { it in defaultTabs }.toSet()
        if (visibleTabs().isEmpty()) hiddenTabs.value = emptySet()
        startTab.value = if (start == "NEW" || start == "POPULAR") start else "POPULAR"
    }

    private fun save() {
        prefs?.edit()
            ?.putString("order", order.value.joinToString(","))
            ?.putString("hidden", hidden.value.joinToString(","))
            ?.putString("tabs", tabOrder.value.joinToString(","))
            ?.putString("hiddenTabs", hiddenTabs.value.joinToString(","))
            ?.putString("start", startTab.value)
            ?.apply()
    }

    // ---- sections ----

    /** A page's sections in the chosen order, hidden ones included (this is what the editor lists). */
    fun sectionsOf(tab: String): List<HomeSectionInfo> =
        order.value.mapNotNull { id -> allSections.firstOrNull { it.id == id && it.tab == tab } }

    fun isVisible(id: String): Boolean = id !in hidden.value

    fun visibleSectionIds(tab: String): List<String> =
        sectionsOf(tab).filter { it.id !in hidden.value }.map { it.id }

    fun toggleSection(id: String) {
        hidden.value = if (id in hidden.value) hidden.value - id else hidden.value + id
        save()
    }

    fun moveSection(id: String, delta: Int) {
        val list = order.value.toMutableList()
        val tab = allSections.firstOrNull { it.id == id }?.tab ?: return
        val slots = list.indices.filter { i -> allSections.firstOrNull { it.id == list[i] }?.tab == tab }
        val at = slots.indexOfFirst { list[it] == id }
        val to = at + delta
        if (at < 0 || to !in slots.indices) return
        java.util.Collections.swap(list, slots[at], slots[to])
        order.value = list
        save()
    }

    // ---- pills ----

    fun tabs(): List<String> = tabOrder.value
    fun visibleTabs(): List<String> = tabOrder.value.filter { it !in hiddenTabs.value }
    fun isTabVisible(name: String): Boolean = name !in hiddenTabs.value

    fun toggleTab(name: String) {
        if (isTabVisible(name)) {
            if (visibleTabs().size <= 1) return // keep at least one pill
            hiddenTabs.value = hiddenTabs.value + name
        } else {
            hiddenTabs.value = hiddenTabs.value - name
        }
        save()
    }

    fun moveTab(name: String, delta: Int) {
        val list = tabOrder.value.toMutableList()
        val at = list.indexOf(name)
        val to = at + delta
        if (at < 0 || to !in list.indices) return
        java.util.Collections.swap(list, at, to)
        tabOrder.value = list
        save()
    }

    fun setStartTab(name: String) {
        startTab.value = name
        save()
    }

    fun reset() {
        applyLists(emptyList(), emptyList(), emptyList(), emptyList(), "POPULAR")
        save()
    }

    // ---- backup ----

    fun toJson(): JSONObject = JSONObject()
        .put("order", JSONArray(order.value))
        .put("hidden", JSONArray(hidden.value.toList()))
        .put("tabs", JSONArray(tabOrder.value))
        .put("hiddenTabs", JSONArray(hiddenTabs.value.toList()))
        .put("start", startTab.value)

    private fun JSONObject.list(key: String): List<String> {
        val a = optJSONArray(key) ?: return emptyList()
        return List(a.length()) { a.getString(it) }
    }

    fun fromJson(o: JSONObject) {
        applyLists(o.list("order"), o.list("hidden"), o.list("tabs"), o.list("hiddenTabs"), o.optString("start", "POPULAR"))
        save()
    }
}
