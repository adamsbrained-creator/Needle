package app.needle.music.data

/**
 * Android's own media scan sometimes decodes a tag wrongly and stores a row of CJK symbols instead of an
 * English title (plain text read as 2-byte characters). Needle also reads the tags itself; where Android's
 * text looks like that and the file's own text is plain, the file's text is shown instead.
 * Anything that merely differs (for example Cyrillic that Android decoded correctly) is left alone.
 */
private fun isGarbageChar(c: Char): Boolean =
    c in '\u2E80'..'\u9FFF' || c in '\uA000'..'\uA4CF' || c in '\uAC00'..'\uD7AF' ||
        c in '\uE000'..'\uFAFF' || c in '\uFE30'..'\uFE4F' || c == '\uFFFD'

private fun looksPlain(s: String): Boolean =
    s.isNotBlank() && s.none(::isGarbageChar) && s.count { it.code < 128 } * 10 >= s.length * 7

private fun repair(fromStore: String, fromFile: String?): String {
    val file = fromFile?.trim().orEmpty()
    return if (file.isNotEmpty() && file != fromStore && fromStore.any(::isGarbageChar) && looksPlain(file)) file else fromStore
}

fun repairGarbledText(songs: List<Song>, core: List<FileTag>): List<Song> {
    if (core.isEmpty()) return songs
    val byId = core.groupBy { it.songId }
    return songs.map { s ->
        val tags = byId[s.id] ?: return@map s
        fun field(name: String) = tags.firstOrNull { it.field == name }?.value
        val title = repair(s.title, field("_TITLE"))
        val artist = repair(s.artist, field("_ARTIST"))
        val album = repair(s.album, field("_ALBUM"))
        if (title == s.title && artist == s.artist && album == s.album) s else s.copy(title = title, artist = artist, album = album)
    }
}
