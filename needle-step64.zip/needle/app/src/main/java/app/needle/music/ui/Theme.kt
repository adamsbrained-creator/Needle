package app.needle.music.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.text.font.FontFamily
import app.needle.music.data.AccentChoices
import app.needle.music.data.NeedleSettings
import app.needle.music.data.Skins

/** Colors taken from the Needle mockup pack. Change the look here. */
object Palette {
    /** Pure black when AMOLED is on (Settings > Customization > Colors & themes). Read while drawing, so a change shows instantly. */
    val Bg: Color get() {
        val custom = NeedleSettings.bgColor.intValue
        return when {
            custom != 0 -> Color(custom)
            NeedleSettings.amoled.value -> Color.Black
            else -> Color(0xFF101012)
        }
    }
    val Surface = Color(0xFF1C1C20)
    /** Pure white and a cooler gray on the Black & Green skin. */
    val Text: Color get() = if (Skins.blackGreen) Color.White else Color(0xFFF2F2F5)
    val Muted: Color get() = if (Skins.blackGreen) Color(0xFFA8A8AD) else Color(0xFF9A9AA3)
    /** The accent color picked in Settings > Customization > Colors & themes. */
    val Accent: Color get() {
        val i = NeedleSettings.accentIndex.intValue
        return if (i >= AccentChoices.size) Color(NeedleSettings.customAccent.intValue) else AccentChoices[i].color
    }

    /** The three drifting blobs of the background glow. Default: the accent, pink and a soft green. */
    val Glow1: Color get() = NeedleSettings.glow1.intValue.let { if (it != 0) Color(it) else Accent }
    val Glow2: Color get() = NeedleSettings.glow2.intValue.let { if (it != 0) Color(it) else Color(0xFFEF42B8) }
    val Glow3: Color get() = NeedleSettings.glow3.intValue.let { if (it != 0) Color(it) else Color(0xFF8FBF8F) }

    /** Serif or sans, picked in Settings > Customization > Colors & themes. Used for every big title. */
    val TitleFont: FontFamily get() = if (NeedleSettings.serifTitles.value) FontFamily.Serif else FontFamily.SansSerif

    // Home screen cards, from the mockup
    private val ClassicCard = Color(0xFF333335)
    private val ClassicCard2 = Color(0xFF3C3C3E)

    /**
     * Card color. Custom: exactly what was picked in Settings > Customization > Colors & themes > Cards.
     * Glass: a soft white layer, so the moving background shows through the cards.
     * Auto: the classic dark gray on a plain background (moving background off), and a soft tint of the
     * accent color when the colored glow is on, so the cards follow whatever color the background has.
     * Read while drawing, so a change shows instantly.
     */
    val Card: Color get() = when {
        NeedleSettings.cardCustom.value -> Color(NeedleSettings.cardArgb.intValue)
        NeedleSettings.cardGlass.value -> Color.White.copy(alpha = 0.10f)
        !GlowSettings.enabled.value -> ClassicCard
        else -> lerp(Color.White, Accent, 0.6f).copy(alpha = 0.16f)
    }

    /** Cards on the Now playing page (artist, credits, file details, library). Own color when set, else the same as [Card]. */
    val NowCard: Color get() = when {
        NeedleSettings.npCardCustom.value -> Color(NeedleSettings.npCardArgb.intValue)
        else -> songTint()?.let { lerp(Color.White, it, 0.6f).copy(alpha = 0.16f) } ?: Card
    }

    /** The playing song's glow color, while the glow follows the song and the cards are on Auto. */
    private fun songTint(): Color? =
        NowGlowTint.color?.takeIf { !NeedleSettings.cardCustom.value && !NeedleSettings.cardGlass.value && GlowSettings.enabled.value }

    /** The lighter partner of [NowCard]. */
    val NowCard2: Color get() = if (NeedleSettings.npCardCustom.value) {
        val c = Color(NeedleSettings.npCardArgb.intValue)
        lerp(c, Color.White, 0.12f).copy(alpha = (c.alpha + 0.10f).coerceAtMost(1f))
    } else songTint()?.let { lerp(Color.White, it, 0.6f).copy(alpha = 0.24f) } ?: Card2

    /** A slightly lighter card, for chips, inactive tabs and small buttons. */
    val Card2: Color get() = when {
        NeedleSettings.cardCustom.value -> {
            val c = Color(NeedleSettings.cardArgb.intValue)
            lerp(c, Color.White, 0.12f).copy(alpha = (c.alpha + 0.10f).coerceAtMost(1f))
        }
        NeedleSettings.cardGlass.value -> Color.White.copy(alpha = 0.16f)
        !GlowSettings.enabled.value -> ClassicCard2
        else -> lerp(Color.White, Accent, 0.6f).copy(alpha = 0.24f)
    }
    val Green = Color(0xFF5C875C)
    val Pink = Color(0xFFEF42B8)
}

@Composable
fun NeedleTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Palette.Accent,
            background = Palette.Bg,
            surface = Palette.Surface,
            onBackground = Palette.Text,
            onSurface = Palette.Text
        ),
        content = { GlowProvider(content) }
    )
}
