package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Cover images for lists and cards.
 * - Cached per song (albums can hold different covers per file).
 * - At most 4 images load at once, so a fast fling doesn't flood the media provider.
 * - Three sizes: small thumbnails for list rows, large ones for cards, extra sharp for the big top cards.
 * - A cover picked in the tag editor wins over the one in the audio file.
 */
object ArtworkLoader {
    private const val SMALL_PX = 144
    private const val LARGE_PX = 512
    private const val HERO_PX = 960

    private val NONE = Any()
    private val small = LruCache<Long, Any>(400)
    private val large = bytesCache(40 * 1024 * 1024)
    private val hero = bytesCache(12 * 1024 * 1024)
    private val gate = Semaphore(4)

    /**
     * Changes whenever covers were replaced. Cover composables use it as a key,
     * so they reload (from the caches, which are cleared for the changed songs).
     */
    var version by mutableIntStateOf(0)
        private set

    /** A cache limited by memory used (the bigger covers vary a lot in size) instead of by count. */
    private fun bytesCache(maxBytes: Int) = object : LruCache<Long, Any>(maxBytes) {
        override fun sizeOf(key: Long, value: Any): Int =
            if (value is ImageBitmap) value.width * value.height * 4 else 1
    }

    /** Forget the covers of [songIds] after the person picked a new one. Call on the main thread. */
    fun invalidate(songIds: Collection<Long>) {
        for (id in songIds) {
            small.remove(id)
            large.remove(id)
            hero.remove(id)
        }
        version++
    }

    /** Instant cache lookup, safe to call while composing. Null means "not loaded (yet)". */
    fun peek(song: Song): ImageBitmap? = small.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun load(context: Context, song: Song, sizePx: Int = SMALL_PX): ImageBitmap? =
        load(small, context, song, sizePx)

    fun peekLarge(song: Song): ImageBitmap? = large.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun loadLarge(context: Context, song: Song): ImageBitmap? =
        load(large, context, song, LARGE_PX)

    /** Extra-sharp version for the big card at the top of the New page and the tag editor. */
    fun peekHero(song: Song): ImageBitmap? = hero.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun loadHero(context: Context, song: Song): ImageBitmap? =
        load(hero, context, song, HERO_PX)

    private suspend fun load(cache: LruCache<Long, Any>, context: Context, song: Song, sizePx: Int): ImageBitmap? {
        cache.get(song.id)?.let { return if (it === NONE) null else it as ImageBitmap }

        var bitmap = gate.withPermit {
            withContext(Dispatchers.IO) {
                runCatching {
                    val picked = CoverStore.file(context, song.id)
                    if (picked.exists()) {
                        CoverStore.decodeSampled(picked, sizePx)
                    } else if (Build.VERSION.SDK_INT >= 29) {
                        context.contentResolver.loadThumbnail(song.uri, Size(sizePx, sizePx), null)
                    } else {
                        val art = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"), song.albumId
                        )
                        context.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
                    }
                }.getOrNull()?.asImageBitmap()
            }
        }
        // Nothing in the file or the phone: the cover found online earlier (or now), if that setting is on.
        if (bitmap == null) {
            bitmap = withContext(Dispatchers.IO) {
                OnlineCovers.get(context, song)?.let { f -> CoverStore.decodeSampled(f, sizePx)?.asImageBitmap() }
            }
        }
        cache.put(song.id, bitmap ?: NONE)
        return bitmap
    }
}
