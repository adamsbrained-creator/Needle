package app.needle.music.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject

/**
 * One JSON file with what Needle can't rebuild by scanning: play history, the tags you edited,
 * the extra fields you added, your artist notes, and your settings. Covers you picked are not included.
 * Songs are identified by their id on this phone, so a backup restores on the same phone and library.
 */
object Backup {
    private const val FORMAT = 1

    class Summary(val plays: Int, val edits: Int, val extras: Int, val notes: Int, val playlists: Int = 0, val ratings: Int = 0)

    private fun JSONObject.str(key: String): String? = if (isNull(key)) null else getString(key)
    private fun JSONObject.int(key: String): Int? = if (isNull(key)) null else getInt(key)

    suspend fun export(context: Context, movingBackground: Boolean): Pair<String, Summary> =
        withContext(Dispatchers.IO) {
            val db = NeedleDatabase.get(context)
            val plays = db.playDao().getAll()
            val edits = db.tagDao().getAll()
            val extras = db.extraTagDao().getAll()

            val root = JSONObject()
            root.put("app", "Needle")
            root.put("format", FORMAT)
            root.put("exportedAt", System.currentTimeMillis())
            root.put("settings", NeedleSettings.toJson().put("movingBackground", movingBackground))
            root.put("homeLayout", HomeLayout.toJson())
            ThemeStore.ensureLoaded(context)
            root.put("colorThemes", ThemeStore.toJsonArray())
            root.put("mediaLists", ListSettings.toJson())
            root.put("pinnedArtists", JSONArray(PinnedArtists.keys.value))
            root.put("hiddenSongs", JSONArray(HiddenSongs.ids.value.toList()))

            val playArr = JSONArray()
            plays.forEach { playArr.put(JSONArray().put(it.songId).put(it.playedAt).put(it.listenedMs)) }
            root.put("plays", playArr)

            val editArr = JSONArray()
            edits.forEach { e ->
                val o = JSONObject().put("songId", e.songId)
                e.title?.let { o.put("title", it) }
                e.artist?.let { o.put("artist", it) }
                e.album?.let { o.put("album", it) }
                e.genre?.let { o.put("genre", it) }
                e.year?.let { o.put("year", it) }
                e.trackNumber?.let { o.put("trackNumber", it) }
                editArr.put(o)
            }
            root.put("edits", editArr)

            val extraArr = JSONArray()
            extras.forEach { extraArr.put(JSONArray().put(it.songId).put(it.field).put(it.value)) }
            root.put("extras", extraArr)

            val notes = db.artistNoteDao().getAll()
            val noteArr = JSONArray()
            notes.forEach { noteArr.put(JSONArray().put(it.artistKey).put(it.note)) }
            root.put("notes", noteArr)

            // Playlists, with their songs as [song id, position, added at]
            val lists = db.playlistDao().getAll()
            val entries = db.playlistDao().getAllEntries().groupBy { it.playlistId }
            val listArr = JSONArray()
            lists.forEach { p ->
                val songArr = JSONArray()
                entries[p.id].orEmpty().sortedBy { it.position }.forEach { e ->
                    songArr.put(JSONArray().put(e.songId).put(e.position).put(e.addedAt))
                }
                listArr.put(
                    JSONObject().put("name", p.name).put("kind", p.kind)
                        .put("createdAt", p.createdAt).put("updatedAt", p.updatedAt).put("songs", songArr)
                )
            }
            root.put("playlists", listArr)

            // Ratings as [song id, value, rated at]
            val rated = db.ratingDao().getAll()
            val ratingArr = JSONArray()
            rated.forEach { ratingArr.put(JSONArray().put(it.songId).put(it.value).put(it.ratedAt)) }
            root.put("ratings", ratingArr)

            root.toString() to Summary(plays.size, edits.size, extras.size, notes.size, lists.size, rated.size)
        }

    class Restored(val summary: Summary, val movingBackground: Boolean?)

    /** Adds to what is already there: plays are never doubled, edits and extra fields from the file win. */
    suspend fun restore(context: Context, text: String): Restored = withContext(Dispatchers.IO) {
        val root = JSONObject(text)
        require(root.optString("app") == "Needle") { "This file is not a Needle backup." }
        val db = NeedleDatabase.get(context)

        val have = HashSet<Pair<Long, Long>>()
        db.playDao().getAll().forEach { have.add(it.songId to it.playedAt) }
        val newPlays = ArrayList<PlayEvent>()
        root.optJSONArray("plays")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                val songId = a.getLong(0)
                val at = a.getLong(1)
                if (have.add(songId to at)) newPlays += PlayEvent(songId = songId, playedAt = at, listenedMs = a.optLong(2, 0L))
            }
        }
        db.playDao().insertAll(newPlays)

        val edits = ArrayList<TagEdit>()
        root.optJSONArray("edits")?.let { arr ->
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                edits += TagEdit(
                    songId = o.getLong("songId"),
                    title = o.str("title"),
                    artist = o.str("artist"),
                    album = o.str("album"),
                    genre = o.str("genre"),
                    year = o.int("year"),
                    trackNumber = o.int("trackNumber")
                )
            }
        }
        db.tagDao().upsertAll(edits)

        val extras = ArrayList<ExtraTag>()
        root.optJSONArray("extras")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                extras += ExtraTag(songId = a.getLong(0), field = a.getString(1), value = a.getString(2))
            }
        }
        db.extraTagDao().upsertAll(extras)

        val notes = ArrayList<ArtistNote>()
        root.optJSONArray("notes")?.let { arr ->
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                notes += ArtistNote(artistKey = a.getString(0), note = a.getString(1))
            }
        }
        db.artistNoteDao().saveAll(notes)

        // Playlists: Liked songs merges into Liked songs, a playlist with the same name gets the missing songs,
        // anything else becomes a new playlist.
        var restoredLists = 0
        root.optJSONArray("playlists")?.let { arr ->
            val dao = db.playlistDao()
            val now = System.currentTimeMillis()
            dao.insertPlaylist(Playlist(id = LIKED_ID, name = "Liked songs", kind = 1, createdAt = now, updatedAt = now))
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val kind = o.optInt("kind", 0)
                val name = o.optString("name", "Playlist")
                val existing = if (kind == 1) null else dao.getAll().firstOrNull { it.kind == 0 && it.name == name }
                val id = when {
                    kind == 1 -> LIKED_ID
                    existing != null -> existing.id
                    else -> dao.insertPlaylist(
                        Playlist(name = name, kind = 0, createdAt = o.optLong("createdAt", now), updatedAt = o.optLong("updatedAt", now))
                    )
                }
                var position = dao.maxPosition(id)
                val rows = ArrayList<PlaylistSong>()
                o.optJSONArray("songs")?.let { songs ->
                    for (j in 0 until songs.length()) {
                        val a = songs.getJSONArray(j)
                        rows += PlaylistSong(id, a.getLong(0), ++position, a.optLong(2, now))
                    }
                }
                dao.insertEntries(rows)
                restoredLists++
            }
        }

        // Ratings: the newer rating wins when a song is rated on both sides.
        var restoredRatings = 0
        root.optJSONArray("ratings")?.let { arr ->
            val dao = db.ratingDao()
            val have = dao.getAll().associateBy { it.songId }
            val take = ArrayList<SongRating>()
            for (i in 0 until arr.length()) {
                val a = arr.getJSONArray(i)
                val r = SongRating(a.getLong(0), a.getInt(1), a.optLong(2, 0L))
                val mine = have[r.songId]
                if (mine == null || r.ratedAt > mine.ratedAt) take += r
            }
            dao.setAll(take)
            restoredRatings = take.size
        }

        var glow: Boolean? = null
        root.optJSONObject("homeLayout")?.let { HomeLayout.fromJson(it) }
        root.optJSONArray("colorThemes")?.let { ThemeStore.importAll(context, it) }
        root.optJSONObject("mediaLists")?.let { ListSettings.fromJson(it) }
        root.optJSONArray("hiddenSongs")?.let { a -> HiddenSongs.merge((0 until a.length()).map { a.getLong(it) }) }
        // Pins are added to the ones already on this phone (an older backup simply has none).
        root.optJSONArray("pinnedArtists")?.let { a ->
            PinnedArtists.replaceAll(PinnedArtists.keys.value + (0 until a.length()).map { a.getString(it) })
        }
        root.optJSONObject("settings")?.let { s ->
            NeedleSettings.fromJson(s)
            if (s.has("movingBackground")) glow = s.optBoolean("movingBackground", true)
        }
        Restored(Summary(newPlays.size, edits.size, extras.size, notes.size, restoredLists, restoredRatings), glow)
    }
}
