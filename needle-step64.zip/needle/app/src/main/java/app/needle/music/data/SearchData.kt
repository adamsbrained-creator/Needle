package app.needle.music.data

import android.content.Context
import android.provider.MediaStore
import java.io.File
import java.util.concurrent.ConcurrentHashMap
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive

// Everything the Search page shows. Pure functions, like HomeData.kt.

/** A song that matched. [snippet] is the line of its lyrics that matched, or null if the song matched by its tags. */
class SongHit(val song: Song, val snippet: String?)

/** An artist that matched, with all of their songs. */
class ArtistHit(val name: String, val songs: List<Song>)

enum class TopKind { ALBUM, ARTIST, SONG }

/** The "Top result" card: exactly one of [album], [artist], [song] is set, matching [kind]. */
class TopHit(
    val kind: TopKind,
    val album: HomeAlbum? = null,
    val artist: ArtistHit? = null,
    val song: Song? = null
) {
    /** The song whose cover is shown. */
    val cover: Song get() = album?.cover ?: artist?.songs?.firstOrNull() ?: song!!
}

class SearchResults(
    /** What was searched for. The page compares it with the text box, so stale results are never shown as final. */
    val query: String,
    val top: TopHit?,
    /** Songs matching by title, artist, album or tags (best first), then songs matching only by their lyrics. */
    val songs: List<SongHit>,
    val albums: List<HomeAlbum>,
    val artists: List<ArtistHit>,
    /** Every song whose lyrics contain the text, with the matching line. */
    val lyrics: List<SongHit>
) {
    val isEmpty: Boolean get() = top == null && songs.isEmpty() && albums.isEmpty() && artists.isEmpty() && lyrics.isEmpty()

    companion object {
        val Empty = SearchResults("", null, emptyList(), emptyList(), emptyList(), emptyList())
    }
}

/** Lyrics are only searched from this many letters on: with one or two letters nearly every song matches. */
const val MIN_LYRICS_QUERY = 3

private const val MAX_HITS = 200
private val searchableExtras = listOf("ALBUMARTIST", "COMPOSER", "CONDUCTOR", "LYRICIST", "MOOD")

/** 0 = no match, 1 = somewhere inside, 2 = at the start of a word, 3 = at the start, 4 = the whole text. */
private fun matchScore(text: String, q: String): Int {
    if (text.isEmpty()) return 0
    if (text.equals(q, ignoreCase = true)) return 4
    if (text.startsWith(q, ignoreCase = true)) return 3
    val at = text.indexOf(q, ignoreCase = true)
    if (at < 0) return 0
    return if (at > 0 && !text[at - 1].isLetterOrDigit()) 2 else 1
}

/** The line of [text] that holds [q]. A very long line is cut down to the part around the match. */
private fun lyricSnippet(text: String, q: String): String? {
    val at = text.indexOf(q, ignoreCase = true)
    if (at < 0) return null
    val start = text.lastIndexOf('\n', at).let { if (it < 0) 0 else it + 1 }
    val end = text.indexOf('\n', at).let { if (it < 0) text.length else it }
    var line = text.substring(start, end).trim()
    if (line.length > 70) {
        val m = line.indexOf(q, ignoreCase = true).coerceAtLeast(0)
        val from = (m - 25).coerceAtLeast(0)
        val to = (m + q.length + 35).coerceAtMost(line.length)
        line = (if (from > 0) "…" else "") + line.substring(from, to).trim() + (if (to < line.length) "…" else "")
    }
    return line
}

/** Find [q] in the library. [lyrics] is the words of every song that has any (see [buildLyricsIndex]). */
fun searchLibrary(
    q: String,
    songs: List<Song>,
    albums: List<HomeAlbum>,
    extras: ExtraTags,
    lyrics: Map<Long, String>
): SearchResults {
    // Songs: title counts most, then artist, then album; a match only in genre or people tags comes last.
    val scored = ArrayList<Pair<Song, Int>>()
    for (s in songs) {
        var score = matchScore(s.title, q) * 4 + matchScore(s.artist, q) * 3 + matchScore(s.album, q) * 2
        if (score == 0) {
            val tags = extras[s.id]
            if (s.genre.contains(q, ignoreCase = true) ||
                searchableExtras.any { key -> tags?.get(key)?.contains(q, ignoreCase = true) == true }
            ) score = 1
        }
        if (score > 0) scored += s to score
    }
    val byTags = scored
        .sortedWith(compareByDescending<Pair<Song, Int>> { it.second }.thenBy { it.first.title.lowercase() })
        .take(MAX_HITS)
        .map { SongHit(it.first, null) }

    // Lyrics
    val byLyrics = if (q.length >= MIN_LYRICS_QUERY) {
        songs.mapNotNull { s ->
            val text = lyrics[s.id] ?: return@mapNotNull null
            lyricSnippet(text, q)?.let { SongHit(s, it) }
        }.sortedBy { it.song.title.lowercase() }.take(MAX_HITS)
    } else emptyList()

    val taken = byTags.mapTo(HashSet()) { it.song.id }
    val allSongs = (byTags + byLyrics.filter { it.song.id !in taken }).take(MAX_HITS)

    // Albums: the title counts more than the artist
    val albumHits = albums
        .map { it to (matchScore(it.title, q) * 2 + matchScore(it.artist, q)) }
        .filter { it.second > 0 }
        .sortedWith(compareByDescending<Pair<HomeAlbum, Int>> { it.second }.thenBy { it.first.title.lowercase() })
        .map { it.first }
        .take(50)

    // Artists: every artist name that holds the text, with all of their songs
    val artistHits = songs
        .filter { isKnownArtist(it.artist) && it.artist.contains(q, ignoreCase = true) }
        .groupBy { artistKey(it.artist) }
        .values
        .map { group ->
            val name = group.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }!!.key
            ArtistHit(name, group)
        }
        .sortedWith(compareByDescending<ArtistHit> { matchScore(it.name, q) }.thenByDescending { it.songs.size })
        .take(50)

    // Top result: the best name match. On a tie an artist beats an album, and an album beats a song.
    val candidates = ArrayList<Pair<Int, TopHit>>()
    artistHits.firstOrNull()?.let { candidates += matchScore(it.name, q) * 10 + 3 to TopHit(TopKind.ARTIST, artist = it) }
    albumHits.firstOrNull { matchScore(it.title, q) > 0 }
        ?.let { candidates += matchScore(it.title, q) * 10 + 2 to TopHit(TopKind.ALBUM, album = it) }
    byTags.firstOrNull { matchScore(it.song.title, q) > 0 }
        ?.let { candidates += matchScore(it.song.title, q) * 10 + 1 to TopHit(TopKind.SONG, song = it.song) }
    val top = candidates.maxByOrNull { it.first }?.second
        ?: byTags.firstOrNull()?.let { TopHit(TopKind.SONG, song = it.song) }

    return SearchResults(q, top, allSongs, albumHits, artistHits, byLyrics)
}

private fun plainLyrics(raw: String): String {
    val text = if (raw.contains('[')) LrcParser.parse(raw, LyricsSource.SAVED)?.plainText() ?: raw else raw
    return if (text.length > 20_000) text.substring(0, 20_000) else text
}

/**
 * The words of every song we hold lyrics for: the Lyrics tag (yours or the file's) first, then the lyrics
 * saved from LRCLIB. Lyrics that sit in a .lrc file next to a song, or that were never loaded, are not in here.
 */
suspend fun buildLyricsIndex(db: NeedleDatabase, extras: ExtraTags): Map<Long, String> {
    val out = HashMap<Long, String>()
    for ((id, tags) in extras) {
        val raw = tags["UNSYNCEDLYRICS"]
        if (!raw.isNullOrBlank()) out[id] = plainLyrics(raw)
    }
    for (row in db.lyricsDao().getAll()) {
        if (row.songId !in out && row.text.isNotBlank()) out[row.songId] = plainLyrics(row.text)
    }
    return out
}

/** Put the words of [files] (lyrics from .lrc files) next to the words already in [base]. A song that has both is searched in both. */
fun mergeLyrics(base: Map<Long, String>, files: Map<Long, String>): Map<Long, String> {
    val out = HashMap(base)
    for ((id, text) in files) {
        val have = out[id]
        out[id] = if (have == null) text else if (have == text) have else have + "\n" + text
    }
    return out
}

/**
 * Lyrics that sit in a .lrc file next to a song (same name, .lrc). Found the way the lyrics screen finds them, so it needs
 * "All files access" and the .lrc option in the lyrics settings. A file is only read again when it has changed.
 */
object LrcFiles {
    private class Entry(val modified: Long, val text: String)

    private val kept = ConcurrentHashMap<Long, Entry>()

    /** Song id to the words of its .lrc file, for every song that has one. */
    suspend fun read(context: Context, songIds: Collection<Long>): Map<Long, String> {
        if (!FileAccess.granted.value || !LyricsPrefs.useLrcFiles.value) return emptyMap()
        val paths = audioPaths(context)
        val out = HashMap<Long, String>()
        var n = 0
        for (id in songIds) {
            if (++n % 200 == 0) currentCoroutineContext().ensureActive()
            val path = paths[id] ?: continue
            val stem = path.substringBeforeLast('.', path)
            val file = listOf(".lrc", ".LRC").map { File(stem + it) }.firstOrNull { it.isFile && it.canRead() } ?: continue
            if (file.length() > 200_000) continue
            val modified = file.lastModified()
            val old = kept[id]
            if (old != null && old.modified == modified) {
                out[id] = old.text
                continue
            }
            val raw = runCatching { file.readText() }.getOrNull() ?: continue
            val text = plainLyrics(raw)
            kept[id] = Entry(modified, text)
            out[id] = text
        }
        return out
    }

    /** Where every song's file is, from one question to the media store. */
    @Suppress("DEPRECATION")
    private fun audioPaths(context: Context): Map<Long, String> {
        val out = HashMap<Long, String>()
        context.contentResolver.query(
            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.DATA),
            null, null, null
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
            val dataCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.DATA)
            while (c.moveToNext()) {
                val path = c.getString(dataCol)
                if (!path.isNullOrBlank()) out[c.getLong(idCol)] = path
            }
        }
        return out
    }
}
