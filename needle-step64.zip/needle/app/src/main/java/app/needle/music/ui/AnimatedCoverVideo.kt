package app.needle.music.ui

import android.view.TextureView
import android.view.ViewGroup
import androidx.annotation.OptIn
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.key
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.AudioAttributes
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.common.util.UnstableApi
import androidx.media3.datasource.DefaultHttpDataSource
import androidx.media3.datasource.cache.CacheDataSource
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.ui.AspectRatioFrameLayout
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import app.needle.music.data.AnimatedCoverProvider
import app.needle.music.data.ArtistBackgrounds
import app.needle.music.data.CoverStore
import app.needle.music.data.NeedleSettings
import app.needle.music.data.networkAllowsAnimatedCovers

/**
 * The looping, silent cover video (an HLS stream). It has its own small player that never takes audio focus,
 * so the music is untouched. Pauses with the music, fills the frame like a cropped cover, and stays invisible
 * until the first frame is drawn (or forever if the stream fails, so the normal cover shows).
 */
@OptIn(UnstableApi::class)
@Composable
fun AnimatedCoverVideo(url: String, playing: Boolean, modifier: Modifier = Modifier, onReady: (Boolean) -> Unit = {}) {
    val appContext = LocalContext.current.applicationContext
    var ready by remember(url) { mutableStateOf(false) }
    var aspect by remember(url) { mutableFloatStateOf(0f) }

    val player = remember(url) {
        // Videos are kept on the phone (up to 300 MB), so a cover that loops, or comes back later, is not downloaded again.
        val cached = CacheDataSource.Factory()
            .setCache(AnimatedCoverCache.get(appContext))
            .setUpstreamDataSourceFactory(DefaultHttpDataSource.Factory())
            .setFlags(CacheDataSource.FLAG_IGNORE_CACHE_ON_ERROR)
        ExoPlayer.Builder(appContext).setMediaSourceFactory(DefaultMediaSourceFactory(cached)).build().apply {
            volume = 0f
            repeatMode = Player.REPEAT_MODE_ONE
            setAudioAttributes(
                AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),
                /* handleAudioFocus = */ false
            )
            setMediaItem(MediaItem.Builder().setUri(url).apply { if (url.contains(".m3u8")) setMimeType(MimeTypes.APPLICATION_M3U8) }.build())
            playWhenReady = playing
            prepare()
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onRenderedFirstFrame() { ready = true }
            override fun onPlayerError(error: PlaybackException) { ready = false }
            override fun onVideoSizeChanged(size: VideoSize) {
                if (size.width > 0 && size.height > 0) aspect = size.width * size.pixelWidthHeightRatio / size.height
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }
    LaunchedEffect(playing) { player.playWhenReady = playing }
    LaunchedEffect(ready) { onReady(ready) }

    val fade by animateFloatAsState(if (ready) 1f else 0f, tween(500), label = "animatedCoverFade")

    key(player) {
        AndroidView(
            factory = { ctx ->
                AspectRatioFrameLayout(ctx).apply {
                    layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM
                    val texture = TextureView(ctx).apply {
                        layoutParams = ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)
                    }
                    addView(texture)
                    player.setVideoTextureView(texture)
                }
            },
            update = { view -> if (aspect > 0f) view.setAspectRatio(aspect) },
            modifier = modifier.alpha(fade)
        )
    }
}

/** The artist's looping video URL for the artist header, or null (setting off, no network allowed, or Apple has none). */
@Composable
fun rememberAnimatedArtistUrl(artist: String): String? {
    val context = LocalContext.current
    val on = NeedleSettings.animatedCovers.value && NeedleSettings.animatedArtistCovers.value
    val wifiOnly = NeedleSettings.animatedCoversWifiOnly.value
    var url by remember(artist) { mutableStateOf<String?>(null) }
    LaunchedEffect(artist, on, wifiOnly) {
        url = null
        if (on && networkAllowsAnimatedCovers(context, wifiOnly)) url = AnimatedCoverProvider.findArtist(artist)
    }
    return url
}

/** The Fanart.tv background picture of the artist for the artist header, or null (setting off, no key, or none exists). */
@Composable
fun rememberArtistBackground(artist: String): ImageBitmap? {
    val context = LocalContext.current
    val on = NeedleSettings.artistBackgrounds.value && NeedleSettings.fanartKey.value.isNotBlank()
    val bitmap by produceState<ImageBitmap?>(null, artist, on) {
        value = if (!on) null else withContext(Dispatchers.IO) {
            ArtistBackgrounds.find(context, artist)?.let { f -> CoverStore.decodeSampled(f, 1080)?.asImageBitmap() }
        }
    }
    return bitmap
}
