package app.needle.music.data

import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.net.Uri
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Base64
import java.util.Locale
import java.util.concurrent.ConcurrentHashMap

/** True when the current network may be used for animated covers (Wi-Fi/Ethernet only, or any network with internet). */
fun networkAllowsAnimatedCovers(context: Context, wifiOnly: Boolean): Boolean {
    val cm = context.applicationContext.getSystemService(ConnectivityManager::class.java) ?: return false
    val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return false) ?: return false
    if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return false
    return !wifiOnly || caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
}

/**
 * Finds the looping cover video (an HLS URL) Apple Music publishes for some albums.
 * It asks Apple Music's web catalog the same way the music.apple.com site does, with the public token that site uses.
 * That is not an official API: it can stop working whenever Apple changes the site. Every failure just returns null,
 * and the normal cover stays.
 */
object AnimatedCoverProvider {
    private const val UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
    private const val API = "https://amp-api.music.apple.com/v1/catalog/us"
    private const val HIT_TTL_MS = 24L * 60 * 60 * 1000
    private const val MISS_TTL_MS = 30L * 60 * 1000

    private class Entry(val url: String?, val expiresAt: Long)
    private val cache = ConcurrentHashMap<String, Entry>()

    private var token: String? = null
    private var tokenExpiryMs = 0L

    suspend fun find(title: String, artist: String, album: String?): String? = withContext(Dispatchers.IO) {
        if (title.isBlank() || artist.isBlank() || artist.contains("unknown", ignoreCase = true)) return@withContext null
        val albumName = album?.takeIf { it.isNotBlank() && !it.startsWith("<") && !it.equals("unknown", true) }
        val key = listOf(title, artist, albumName.orEmpty()).joinToString("|") { it.trim().lowercase(Locale.ROOT) }
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { it.expiresAt > now }?.let { return@withContext it.url }
        try {
            if (ensureToken() == null) return@withContext null  // offline or the site changed: try again next time
            val found = search(title, artist, albumName, "songs")
                ?: albumName?.let { search(it, artist, null, "albums") }
            cache[key] = Entry(found, now + if (found != null) HIT_TTL_MS else MISS_TTL_MS)
            found
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    /** The looping video of an artist (shown in the artist header), or null if Apple Music has none. */
    suspend fun findArtist(artist: String): String? = withContext(Dispatchers.IO) {
        val name = artist.trim()
        if (name.isBlank() || name.contains("unknown", ignoreCase = true)) return@withContext null
        val key = "artist|" + name.lowercase(Locale.ROOT)
        val now = System.currentTimeMillis()
        cache[key]?.takeIf { it.expiresAt > now }?.let { return@withContext it.url }
        try {
            if (ensureToken() == null) return@withContext null
            val found = searchArtist(name)
            cache[key] = Entry(found, now + if (found != null) HIT_TTL_MS else MISS_TTL_MS)
            found
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            null
        }
    }

    private fun searchArtist(name: String): String? {
        val url = "$API/search?term=${Uri.encode(name)}&types=artists&limit=5&extend=editorialVideo"
        val root = JSONObject(http(url, ensureToken()) ?: return null)
        val data = root.optJSONObject("results")?.optJSONObject("artists")?.optJSONArray("data") ?: return null
        for (i in 0 until data.length()) {
            val obj = data.optJSONObject(i) ?: continue
            val a = obj.optJSONObject("attributes") ?: continue
            if (!a.optString("name").equals(name, ignoreCase = true)) continue
            a.optJSONObject("editorialVideo")?.let { artistVideoUrl(it) }?.let { return it }
            val id = obj.optString("id").takeIf { it.isNotEmpty() } ?: continue
            val full = JSONObject(http("$API/artists/${Uri.encode(id)}?extend=editorialVideo", ensureToken()) ?: continue)
            full.optJSONArray("data")?.optJSONObject(0)?.optJSONObject("attributes")?.optJSONObject("editorialVideo")
                ?.let { artistVideoUrl(it) }?.let { return it }
        }
        return null
    }

    /** Artist videos come under several names (wide, square, fullscreen ...); wide first, then whatever is there. */
    private fun artistVideoUrl(ev: JSONObject): String? {
        fun pick(asset: JSONObject): String? =
            listOf("video", "videoUrl", "hlsUrl", "url").map { asset.optString(it) }.firstOrNull { it.isNotBlank() }
        val preferred = listOf("motionArtistWide", "motionArtistFullscreen16x9", "motionArtistSquare", "motionArtistFullscreen", "motionDetailSquare", "motionDetailTall")
        for (k in preferred) ev.optJSONObject(k)?.let { pick(it) }?.let { return it }
        for (k in ev.keys()) if (k.startsWith("motion") && !k.contains("Static", ignoreCase = true)) ev.optJSONObject(k)?.let { pick(it) }?.let { return it }
        return null
    }

    // ---- token -------------------------------------------------------------------------------------

    private fun ensureToken(): String? {
        val now = System.currentTimeMillis()
        token?.let { if (now < tokenExpiryMs - 60_000) return it }
        val html = http("https://music.apple.com/us/browse", null) ?: return null
        val scripts = Regex("/assets/index(?:-legacy)?[~-][a-zA-Z0-9_-]+\\.js").findAll(html).map { it.value }.distinct().toList()
        val jwt = Regex("ey[a-zA-Z0-9_-]+\\.ey[a-zA-Z0-9_-]+\\.[a-zA-Z0-9_-]+")
        for (path in scripts) {
            val js = http("https://music.apple.com$path", null) ?: continue
            for (m in jwt.findAll(js)) {
                val exp = runCatching {
                    val payload = JSONObject(String(Base64.getUrlDecoder().decode(m.value.split(".")[1]), Charsets.UTF_8))
                    if (payload.has("iss")) payload.optLong("exp", 0L) * 1000 else 0L
                }.getOrDefault(0L)
                if (exp > now) {
                    token = m.value
                    tokenExpiryMs = exp
                    return m.value
                }
            }
        }
        return null
    }

    private fun http(url: String, bearer: String?): String? {
        val c = URL(url).openConnection() as HttpURLConnection
        return try {
            c.connectTimeout = 15_000
            c.readTimeout = 25_000
            c.setRequestProperty("User-Agent", UA)
            if (bearer != null) {
                c.setRequestProperty("Authorization", "Bearer $bearer")
                c.setRequestProperty("Origin", "https://music.apple.com")
                c.setRequestProperty("Referer", "https://music.apple.com/")
            }
            if (c.responseCode != 200) null else c.inputStream.bufferedReader().use { it.readText() }
        } catch (e: java.io.IOException) {
            null
        } finally {
            c.disconnect()
        }
    }

    // ---- search ------------------------------------------------------------------------------------

    private class Candidate(val score: Int, val obj: JSONObject)

    private fun search(term: String, artist: String, album: String?, type: String): String? {
        var query = if (term.contains(artist, ignoreCase = true)) term else "$artist $term"
        if (!album.isNullOrBlank() && !query.contains(album, ignoreCase = true)) query = "$query $album"
        val url = "$API/search?term=${Uri.encode(query)}&types=$type&limit=10&extend=editorialVideo&include=albums"
        val root = JSONObject(http(url, ensureToken()) ?: return null)
        val data = root.optJSONObject("results")?.optJSONObject(type)?.optJSONArray("data") ?: return null

        val candidates = ArrayList<Candidate>()
        for (i in 0 until data.length()) {
            val obj = data.optJSONObject(i) ?: continue
            val a = obj.optJSONObject("attributes") ?: continue
            val name = a.optString("name")
            val collection = a.optString("albumName").ifBlank { a.optString("collectionName") }
            if (blacklisted(name) || blacklisted(collection)) continue
            if (!artistMatches(artist, a.optString("artistName"))) continue
            var score = 10
            score += when {
                name.equals(term, true) -> 15
                name.contains(term, true) || term.contains(name, true) -> 7
                else -> -10
            }
            for (w in listOf("deluxe", "expanded", "remastered", "remix", "version", "edit", "mix", "bonus")) {
                val inTerm = term.contains(w, true)
                val inResult = name.contains(w, true)
                if (inTerm && inResult) score += 5 else if (inResult && !inTerm) score -= 3
            }
            if (!album.isNullOrBlank() && collection.isNotEmpty()) {
                score += when {
                    collection.equals(album, true) -> 20
                    collection.contains(album, true) || album.contains(collection, true) -> 10
                    else -> 0
                }
            }
            candidates.add(Candidate(score, obj))
        }

        for (c in candidates.sortedByDescending { it.score }) {
            if (c.score < 12) continue
            val a = c.obj.optJSONObject("attributes") ?: continue
            // Songs: the video belongs to the album, so find the album's id.
            val albumId = if (c.obj.optString("type") == "songs") {
                c.obj.optJSONObject("relationships")?.optJSONObject("albums")?.optJSONArray("data")
                    ?.optJSONObject(0)?.optString("id")?.takeIf { it.isNotEmpty() }
                    ?: a.optString("collectionId").takeIf { it.isNotEmpty() }
                    ?: a.optString("url").substringAfter("/album/", "").substringBefore("?").substringAfterLast("/")
                        .takeIf { it.isNotEmpty() && it.all(Char::isDigit) }
            } else c.obj.optString("id").takeIf { it.isNotEmpty() }
            if (albumId == null || albumId.startsWith("pl.")) continue

            a.optJSONObject("editorialVideo")?.let { videoUrl(it) }?.let { return it }
            fetchAlbumVideo(albumId)?.let { return it }
        }
        return null
    }

    private fun fetchAlbumVideo(albumId: String): String? {
        val root = JSONObject(http("$API/albums/${Uri.encode(albumId)}?extend=editorialVideo", ensureToken()) ?: return null)
        val a = root.optJSONArray("data")?.optJSONObject(0)?.optJSONObject("attributes") ?: return null
        if (blacklisted(a.optString("name"))) return null
        return a.optJSONObject("editorialVideo")?.let { videoUrl(it) }
    }

    private fun videoUrl(ev: JSONObject): String? {
        for (key in listOf("motionDetailRaw", "motionDetailSquare", "motionDetailTall", "motionDetailStatic")) {
            val asset = ev.optJSONObject(key) ?: continue
            for (field in listOf("video", "videoUrl", "hlsUrl", "url")) {
                val v = asset.optString(field)
                if (v.isNotBlank()) return v
            }
        }
        return null
    }

    // ---- matching helpers --------------------------------------------------------------------------

    private fun blacklisted(s: String): Boolean {
        val n = s.lowercase(Locale.ROOT)
        return listOf("playlist", "set list", "essentials", "dj mix", "mixed", "apple music", "today's hits", "session").any { n.contains(it) }
    }

    private fun artistMatches(requested: String, returned: String): Boolean {
        val split = Regex("(?:\\s*,\\s*|\\s*&\\s*|\\s+×\\s+|\\s+x\\s+|\\bfeat\\.?\\b|\\bft\\.?\\b|\\bfeaturing\\b|\\bwith\\b)", RegexOption.IGNORE_CASE)
        fun names(s: String) = s.split(split).map { it.replace(Regex("\\s+"), " ").trim().lowercase(Locale.ROOT) }.filter { it.isNotBlank() }
        val want = names(requested)
        val got = names(returned)
        return want.isNotEmpty() && got.isNotEmpty() && want.all { w -> got.any { it == w } }
    }
}
