package app.needle.music.data

import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map

/** The one place that answers "what songs does the person have": the scan plus their tag edits. */
object Library {
    private fun observeAll(db: NeedleDatabase): Flow<List<Song>> =
        combine(db.songDao().observeAll(), db.tagDao().observeAll(), db.fileTagDao().observeCore()) { songs, edits, core ->
            applyEdits(repairGarbledText(songs, core), edits)
        }

    /** Every song except the ones hidden with "Hide from library". */
    fun observe(db: NeedleDatabase): Flow<List<Song>> =
        combine(observeAll(db), HiddenSongs.ids) { songs, hidden ->
            if (hidden.isEmpty()) songs else songs.filter { it.id !in hidden }
        }

    /** Only the hidden songs, for Settings > Library > Hidden songs. */
    fun observeHidden(db: NeedleDatabase): Flow<List<Song>> =
        combine(observeAll(db), HiddenSongs.ids) { songs, hidden ->
            if (hidden.isEmpty()) emptyList() else songs.filter { it.id in hidden }
        }

    /** The other tags (composer, comment, sort names ...) of every song that has any. */
    fun observeExtras(db: NeedleDatabase): Flow<ExtraTags> =
        combine(db.fileTagDao().observeAll(), db.extraTagDao().observeAll()) { fromFiles, edits ->
            mergeExtras(groupFileTags(fromFiles), groupExtras(edits))
        }

    suspend fun load(db: NeedleDatabase): List<Song> =
        applyEdits(repairGarbledText(db.songDao().getAllOnce(), db.fileTagDao().getCore()), db.tagDao().getAll())
}
