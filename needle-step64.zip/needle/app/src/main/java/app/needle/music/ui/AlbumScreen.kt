package app.needle.music.ui

import app.needle.music.data.Skins
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.AlbumPrefs
import app.needle.music.data.AlbumRating
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.ExtraTags
import app.needle.music.data.HomeAlbum
import app.needle.music.data.ListSettings
import app.needle.music.data.NeedleSettings
import app.needle.music.data.RatingScale
import app.needle.music.data.RowDetail
import app.needle.music.data.RowStyle
import app.needle.music.data.Song
import app.needle.music.data.discLabel
import app.needle.music.data.discOf

/**
 * One album: big cover, Play / Shuffle, and the track list. The tracks follow Settings > Customization > Media lists
 * (row style, what is on the right, swipes, selecting, counts, back button) and can show hearts and ratings.
 */
@Composable
fun AlbumScreen(
    album: HomeAlbum,
    extras: ExtraTags,
    ratings: Map<Long, Int> = emptyMap(),
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onTrack: (Int) -> Unit,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onEditTags: (List<Song>) -> Unit,
    onEditSides: () -> Unit,
    onEditTrack: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val year = album.songs.maxOf { it.year }
    // "Show counts" in the media list settings also decides whether the track count and length are shown
    val counts = ListSettings.showCounts.value
    val meta = listOfNotNull(
        year.takeIf { it > 0 }?.toString(),
        if (counts) tracksText(album.songs.size) else null,
        if (counts) "${album.songs.sumOf { it.durationMs } / 60_000} min" else null
    ).joinToString(" · ")

    // Like Symfonium: if any song of the album has a Description tag, the album page shows it.
    val description = album.songs.firstNotNullOfOrNull { extras[it.id]?.get("DESCRIPTION")?.trim()?.takeIf { d -> d.isNotEmpty() } }

    // Discs (or sides): the tracks are grouped by their Disc tag. Headers only show when there is more than one.
    val word by AlbumPrefs.discWord
    val letters by AlbumPrefs.discLetters
    val groups = remember(album, extras, word, letters) { discGroups(album.songs, extras, word, letters) }

    // Picking songs (long press, if that is chosen in the media list settings), like on the Songs page
    val selection = remember(album.id) { SongSelection() }
    val selecting = selection.active
    BackHandler(enabled = selecting) { selection.clear() }
    val picked = { album.songs.filter { it.id in selection.ids } }

    Box(modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding + if (selecting) 72.dp else 0.dp)
        ) {
            item {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                    Spacer(Modifier.weight(1f))
                    if (album.songs.size > 1) {
                        RoundIconButton(NeedleIcon.ALBUMS, onEditSides, size = 40.dp, iconSize = 20.dp)
                        Spacer(Modifier.width(8.dp))
                    }
                    RoundIconButton(NeedleIcon.TAG, { onEditTags(album.songs) }, size = 40.dp, iconSize = 20.dp)
                }
            }
            item {
                Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    AlbumArt(
                        album.cover,
                        Modifier.fillMaxWidth(if (Skins.blackGreen) 0.65f else 0.8f).aspectRatio(1f).clip(RoundedCornerShape(if (Skins.blackGreen) 18.dp else 26.dp))
                    )
                    Spacer(Modifier.height(20.dp))
                    Text(
                        album.title, color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = if (Skins.blackGreen) 22.sp else 28.sp,
                        fontWeight = if (Skins.blackGreen) FontWeight.SemiBold else null, lineHeight = if (Skins.blackGreen) 28.sp else 32.sp, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis
                    )
                    Spacer(Modifier.height(4.dp))
                    Text(
                        album.artist, color = Palette.Muted, fontSize = 16.sp,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    if (meta.isNotEmpty()) Text(meta, color = Palette.Muted, fontSize = 13.sp)
                    Spacer(Modifier.height(18.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        PillButton("Play", onPlay, filled = true)
                        PillButton("Shuffle", onShuffle)
                    }
                    // The whole album, in album order, after the song that is playing or at the end of the queue.
                    Spacer(Modifier.height(10.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        QueuePill(NeedleIcon.PLAY_NEXT, "Play next", onPlayNext)
                        QueuePill(NeedleIcon.ADD_QUEUE, "Add to queue", onAddToQueue)
                    }
                    Spacer(Modifier.height(16.dp))
                }
            }
            if (description != null) {
                item { AlbumDescription(description) }
            }
            groups.forEach { group ->
                if (groups.size > 1) {
                    item(key = "disc-${group.firstIndex}") { DiscHeader(group.label, formatTime(group.songs.sumOf { it.durationMs })) }
                }
                itemsIndexed(group.songs, key = { _, s -> s.id }) { i, song ->
                    val index = group.firstIndex + i
                    TrackRow(
                        number = if (song.trackNumber > 0) song.trackNumber else i + 1,
                        song = song,
                        showArtist = song.artist != album.artist,
                        isCurrent = song.id.toString() == currentMediaId,
                        liked = song.id in ListDecor.liked.value,
                        rating = ratings[song.id] ?: 0,
                        selected = if (selecting) song.id in selection.ids else null,
                        onClick = { if (selecting) selection.toggle(song.id) else onTrack(index) },
                        onLongClick = {
                            if (selecting || ListSettings.longPressSelect.value) selection.toggle(song.id)
                            else onEditTrack(song)
                        }
                    )
                }
            }
        }
        if (selecting) {
            SelectionBar(
                count = selection.ids.size,
                onAll = { selection.selectAll(album.songs) },
                onNext = { RowActions.playNext(picked()); selection.clear() },
                onQueue = { RowActions.addToQueue(picked()); selection.clear() },
                onPlaylist = { RowActions.addToPlaylist(picked()); selection.clear() },
                onTags = { RowActions.editTags(picked()); selection.clear() },
                onClose = { selection.clear() },
                modifier = Modifier.align(Alignment.BottomCenter).padding(bottom = bottomPadding)
            )
        }
    }
}

private class DiscGroup(val disc: Int, val label: String, val firstIndex: Int) {
    val songs = ArrayList<Song>()
}

/** The tracks of an album in order, cut into one group per disc (or side). A disc subtitle names the group if there is one. */
private fun discGroups(songs: List<Song>, extras: ExtraTags, word: String, letters: Boolean): List<DiscGroup> {
    val out = ArrayList<DiscGroup>()
    songs.forEachIndexed { index, song ->
        val disc = discOf(extras[song.id])
        val last = out.lastOrNull()
        if (last != null && last.disc == disc) {
            last.songs += song
        } else {
            val subtitle = extras[song.id]?.get("SETSUBTITLE")?.trim()?.takeIf { it.isNotEmpty() }
            out += DiscGroup(disc, subtitle ?: discLabel(disc, word, letters), index).also { it.songs += song }
        }
    }
    return out
}

/** The bar above the tracks of one disc or side: a record, its name and how long it is. */
@Composable
private fun DiscHeader(label: String, duration: String) {
    Row(
        Modifier.fillMaxWidth().padding(top = 14.dp, bottom = 4.dp).clip(RoundedCornerShape(14.dp))
            .background(Color.White.copy(alpha = 0.07f)).padding(horizontal = 14.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        NeedleIconView(NeedleIcon.ALBUMS, Palette.Text, size = 20.dp)
        Spacer(Modifier.width(12.dp))
        Text(label, color = Palette.Text, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
        Text(duration, color = Palette.Muted, fontSize = 13.sp)
    }
}

/** The album's Description tag. Four lines, and a tap shows all of it. */
@Composable
private fun AlbumDescription(text: String) {
    var expanded by remember { mutableStateOf(false) }
    val long = text.length > 160 || text.count { it == '\n' } >= 3
    Column(
        Modifier
            .fillMaxWidth()
            .padding(bottom = 14.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(Color.White.copy(alpha = 0.07f))
            .then(if (long) Modifier.clickable { expanded = !expanded } else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp)
    ) {
        Text(
            text, color = Palette.Text.copy(alpha = 0.85f), fontSize = 13.5.sp, lineHeight = 19.sp,
            maxLines = if (expanded) Int.MAX_VALUE else 4, overflow = TextOverflow.Ellipsis
        )
        if (long) {
            Text(
                if (expanded) "Less" else "More", color = Palette.Accent, fontSize = 12.5.sp,
                fontWeight = FontWeight.SemiBold, modifier = Modifier.padding(top = 6.dp)
            )
        }
    }
}

@Composable
private fun QueuePill(icon: NeedleIcon, text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        NeedleIconView(icon, Palette.Text, size = 17.dp)
        Text(text, color = Palette.Text, fontSize = 13.5.sp)
    }
}

/** Sharp cover for the page; shows the Home-size one straight away while the sharper one loads. */
@Composable
private fun AlbumArt(song: Song, modifier: Modifier) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peekHero(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peekHero(song) ?: ArtworkLoader.loadHero(context, song)
    }
    val bitmap = art
    if (bitmap != null) {
        Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
    } else {
        Cover(song, modifier)
    }
}

/**
 * One track: its number (or a check mark while selecting), title, and what the media list settings ask for:
 * compact rows, a heart for liked songs, a rating, and the detail on the right (duration by default).
 * [preview] is for the settings page: no swipe.
 */
@Composable
internal fun TrackRow(
    number: Int,
    song: Song,
    showArtist: Boolean,
    isCurrent: Boolean,
    liked: Boolean,
    rating: Int,
    selected: Boolean?,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    preview: Boolean = false
) {
    val compact = ListSettings.rowStyle.value == RowStyle.COMPACT
    val ratingMode = ListSettings.albumRating.value
    val detail = rowDetail(song, rating, preview)
    val showHeart = liked && ListSettings.albumHeart.value
    // "Number" is left out when the right side already shows the rating
    val numberRating = if (ratingMode == AlbumRating.NUMBER && rating > 0 && ListSettings.detail.value != RowDetail.RATING) {
        "\u2605 " + RatingScale.short(NeedleSettings.ratingStyle.value, rating)
    } else null
    val starCount = if (ratingMode == AlbumRating.STARS && rating > 0) RatingScale.stars(rating) else 0

    val body: @Composable () -> Unit = {
        Row(
            Modifier
                .fillMaxWidth()
                .background(if (selected == true) Palette.Accent.copy(alpha = 0.16f) else Color.Transparent)
                .tapOrHold(onClick = onClick, onLongClick = onLongClick)
                .padding(horizontal = 8.dp, vertical = if (compact) 7.dp else 11.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(Modifier.width(32.dp), contentAlignment = Alignment.CenterStart) {
                if (selected != null) {
                    SelectMark(selected)
                } else {
                    Text("$number", color = if (isCurrent) Palette.Accent else Palette.Muted, fontSize = 14.sp)
                }
            }
            Column(Modifier.weight(1f)) {
                Text(
                    song.title,
                    color = if (isCurrent) Palette.Accent else Palette.Text,
                    fontSize = if (compact) 15.sp else 16.sp, fontWeight = FontWeight.Medium,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                if (showArtist) {
                    Text(song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (starCount > 0) TrackStars(starCount)
            }
            if (showHeart) {
                Spacer(Modifier.width(8.dp))
                NeedleIconView(NeedleIcon.HEART_FILLED, Palette.Accent, size = 14.dp)
            }
            if (numberRating != null) {
                Spacer(Modifier.width(10.dp))
                Text(numberRating, color = Palette.Muted, fontSize = 13.sp, maxLines = 1)
            }
            if (detail != null) {
                Spacer(Modifier.width(10.dp))
                Text(detail, color = Palette.Muted, fontSize = 13.sp, maxLines = 1)
            }
        }
    }
    if (selected == null && !preview) SwipeRow(song, body) else body()
}

/** Five small stars, the rated ones in the accent color. */
@Composable
private fun TrackStars(count: Int) {
    Text(
        buildAnnotatedString {
            for (i in 1..5) {
                withStyle(SpanStyle(color = if (i <= count) Palette.Accent else Palette.Muted.copy(alpha = 0.35f))) { append("\u2605") }
            }
        },
        fontSize = 12.sp, modifier = Modifier.padding(top = 2.dp)
    )
}

/** A few fake tracks for Settings > Customization > Media lists, to see hearts, ratings and the row style at work. */
@Composable
internal fun AlbumRowsPreview() {
    val first = remember {
        Song(
            id = -1L, title = "Midnight Drive", artist = "The Needles", album = "After Hours", albumId = 0L,
            durationMs = 214_000L, trackNumber = 1, year = 2021, dateAdded = 1_700_000_000L, folder = "", genre = "Rock"
        )
    }
    val second = remember { first.copy(id = -2L, title = "Paper Moon", durationMs = 187_000L, trackNumber = 2) }
    val third = remember { first.copy(id = -3L, title = "Glass Harbor", artist = "Lena Voss", durationMs = 262_000L, trackNumber = 3) }
    Column(
        Modifier.fillMaxWidth().clip(RoundedCornerShape(24.dp)).background(Palette.Card).padding(vertical = 6.dp, horizontal = 8.dp)
    ) {
        TrackRow(1, first, showArtist = false, isCurrent = true, liked = true, rating = 100, selected = null, onClick = {}, onLongClick = {}, preview = true)
        TrackRow(2, second, showArtist = false, isCurrent = false, liked = false, rating = 60, selected = null, onClick = {}, onLongClick = {}, preview = true)
        TrackRow(3, third, showArtist = true, isCurrent = false, liked = true, rating = 0, selected = null, onClick = {}, onLongClick = {}, preview = true)
    }
}
