package app.needle.music.ui

import android.app.Activity
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.widget.Toast
import app.needle.music.data.Song
import app.needle.music.data.isKnownArtist

/** What to look for on the web: "Artist Title", or just the title when the artist is not known. */
private fun searchText(song: Song): String =
    (if (isKnownArtist(song.artist)) "${song.artist} " else "") + song.title

private fun openUrl(context: Context, url: String) {
    try {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    } catch (e: Exception) {
        Toast.makeText(context, "No app could open this link", Toast.LENGTH_SHORT).show()
    }
}

/** Web search for the song, in the phone's browser. */
internal fun searchSongOnWeb(context: Context, song: Song) {
    openUrl(context, "https://www.google.com/search?q=" + Uri.encode(searchText(song)))
}

/** Genius search for the song (the lyrics and what they mean). */
internal fun searchSongOnGenius(context: Context, song: Song) {
    openUrl(context, "https://genius.com/search?q=" + Uri.encode(searchText(song)))
}

/** Share the name of the song as text ("Title — Artist"), for a message. Share file sends the audio itself. */
internal fun shareSongText(context: Context, song: Song) {
    try {
        val text = if (isKnownArtist(song.artist)) "${song.title} — ${song.artist}" else song.title
        val send = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, text)
        }
        context.startActivity(Intent.createChooser(send, null))
    } catch (e: Exception) {
        Toast.makeText(context, "Could not share this song", Toast.LENGTH_SHORT).show()
    }
}

/**
 * Asks Android to delete the audio file. On Android 11 and newer, Android shows its own "Delete this file?" box and
 * [launch] must start the returned request (a result launcher in the screen). On older versions the file is deleted
 * at once, and the answer is true. Returns true when the file is already gone, false when [launch] was used,
 * and null when it could not be deleted at all.
 */
internal fun deleteSongFile(context: Context, song: Song, launch: (android.content.IntentSender) -> Unit): Boolean? {
    val uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, song.id)
    return try {
        if (Build.VERSION.SDK_INT >= 30) {
            val request = MediaStore.createDeleteRequest(context.contentResolver, listOf(uri))
            launch(request.intentSender)
            false
        } else {
            context.contentResolver.delete(uri, null, null) > 0
        }
    } catch (e: Exception) {
        null
    }
}

/** True when the result of the Android delete box says the file was deleted. */
internal fun deleteConfirmed(resultCode: Int): Boolean = resultCode == Activity.RESULT_OK
