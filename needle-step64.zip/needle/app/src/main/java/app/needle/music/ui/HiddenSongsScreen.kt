package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.Song

/**
 * Settings > Library > Hidden songs: the songs hidden with "Hide from library". They are still on the phone;
 * Unhide puts one back in every list, and Unhide all puts them all back.
 */
@Composable
fun HiddenSongsScreen(
    songs: List<Song>,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onUnhide: (Song) -> Unit,
    onUnhideAll: () -> Unit,
    modifier: Modifier = Modifier
) {
    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        item {
            Column {
                Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                    ListBackButton(onBack)
                }
                Text(
                    "Hidden songs", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp,
                    modifier = Modifier.padding(top = 10.dp)
                )
                Text(
                    "Hidden from every list and search. The files stay on your phone.", color = Palette.Muted, fontSize = 13.sp,
                    modifier = Modifier.padding(top = 4.dp, bottom = 14.dp)
                )
                if (songs.isNotEmpty()) {
                    Text(
                        "Unhide all (${songs.size})",
                        color = Color(0xFF111111), fontSize = 13.5.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable(onClick = onUnhideAll)
                            .padding(horizontal = 16.dp, vertical = 10.dp)
                    )
                }
            }
        }
        if (songs.isEmpty()) {
            item {
                Text(
                    "Nothing is hidden. To hide a song, press and hold it and choose Hide from library.",
                    color = Palette.Muted, fontSize = 14.sp, textAlign = TextAlign.Center,
                    modifier = Modifier.fillMaxWidth().padding(horizontal = 24.dp, vertical = 48.dp)
                )
            }
        }
        items(songs, key = { it.id }) { song ->
            Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                SongArtwork(song, size = 48.dp, corner = 13.dp)
                Spacer(Modifier.width(12.dp))
                Column(Modifier.weight(1f)) {
                    Text(
                        song.title, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold,
                        maxLines = 1, overflow = TextOverflow.Ellipsis
                    )
                    Text(song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                Text(
                    "Unhide", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                    modifier = Modifier.clip(CircleShape).clickable { onUnhide(song) }.padding(horizontal = 12.dp, vertical = 8.dp)
                )
            }
        }
    }
}
