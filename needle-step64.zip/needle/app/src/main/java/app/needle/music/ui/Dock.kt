package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.runtime.getValue
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import app.needle.music.data.NeedleSettings
import app.needle.music.data.Skins
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.playback.PlayerViewModel

/** The four places in the bottom bar. Only HOME and SONGS exist so far. */
enum class Destination(val icon: NeedleIcon, val label: String) {
    HOME(NeedleIcon.HOME, "Home"),
    SONGS(NeedleIcon.SONGS, "Songs"),
    ALBUMS(NeedleIcon.ALBUMS, "Albums"),
    LIBRARY(NeedleIcon.LIBRARY, "Library")
}

/**
 * The floating dock from the mockup. With a song loaded: the player row on top and the four
 * navigation buttons underneath. With nothing loaded: just a plain, narrower pill of buttons.
 * Tap the player row to open Now Playing. The expanded and small states come later.
 */
@Composable
fun NeedleDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    modifier: Modifier = Modifier,
    castName: String? = null
) {
    if (Skins.blackGreen) {
        FlatDock(selected, onSelect, player, onOpenPlayer, modifier, castName)
        return
    }
    if (!player.hasMedia) {
        Row(
            modifier
                .shadow(10.dp, CircleShape)
                .clip(CircleShape)
                .background(Color(0xFF3A3A3C))
                .padding(6.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Destination.entries.forEach { dest ->
                DockButton(dest, isSelected = dest == selected, onClick = { onSelect(dest) }, size = 54.dp)
            }
        }
        return
    }

    val shape = RoundedCornerShape(32.dp)
    val glow = Palette.Accent.copy(alpha = 0.3f)
    Column(
        modifier
            .fillMaxWidth()
            .shadow(20.dp, shape, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .background(
                Brush.linearGradient(
                    0f to (if (NeedleSettings.accentIndex.intValue == 0) Color(0xF24E4068)
                    else lerp(Color(0xFF2A2A2E), Palette.Accent, 0.3f).copy(alpha = 0.95f)),
                    0.6f to Color(0xF52E2E32),
                    start = Offset.Zero,
                    end = Offset.Infinite
                )
            )
            .border(1.dp, Color.White.copy(alpha = 0.12f), shape)
    ) {
        DockPlayerRow(player, onOpenPlayer, castName)

        Row(
            Modifier.fillMaxWidth().padding(start = 10.dp, end = 10.dp, top = 6.dp, bottom = 10.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Destination.entries.forEach { dest ->
                DockButton(dest, isSelected = dest == selected, onClick = { onSelect(dest) })
            }
        }
    }
}

@Composable
private fun DockPlayerRow(vm: PlayerViewModel, onClick: () -> Unit, castName: String?) {
    Row(
        Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .padding(start = 12.dp, end = 12.dp, top = 10.dp, bottom = 2.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(12.dp))) {
            val art = vm.artwork
            if (art != null) {
                Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                ArtworkPlaceholder(Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                vm.title ?: "", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (castName != null) "Playing on $castName" else vm.artist ?: "",
                color = if (castName != null) Color(0xFFC9B8EE) else Palette.Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        PlayPauseButton(
            isPlaying = vm.isPlaying,
            enabled = true,
            onClick = vm::togglePlay,
            size = 40.dp,
            iconSize = 16.dp
        )
    }
}

@Composable
private fun DockButton(dest: Destination, isSelected: Boolean, onClick: () -> Unit, size: Dp = 48.dp) {
    Box(
        Modifier
            .size(size)
            .then(
                if (isSelected) {
                    val halo = Color.White.copy(alpha = 0.35f)
                    Modifier.shadow(10.dp, CircleShape, ambientColor = halo, spotColor = halo)
                } else Modifier
            )
            .clip(CircleShape)
            .background(if (isSelected) Color.White else Color.Transparent)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        NeedleIconView(dest.icon, tint = if (isSelected) Color(0xFF111111) else Color(0xFFA9A9AE))
    }
}

// ---- Black & Green skin: a flat bar with labels, and the player as its own card above it --------

@Composable
private fun FlatDock(
    selected: Destination,
    onSelect: (Destination) -> Unit,
    player: PlayerViewModel,
    onOpenPlayer: () -> Unit,
    modifier: Modifier,
    castName: String?
) {
    val barShape = RoundedCornerShape(30.dp)
    Column(modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        if (player.hasMedia) FlatPlayerCard(player, onOpenPlayer, castName)
        Row(
            Modifier
                .fillMaxWidth()
                .clip(barShape)
                .background(Color(0xFF0C0C0C))
                .border(1.dp, Color(0xFF1E1E1E), barShape)
                .padding(horizontal = 8.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceAround
        ) {
            Destination.entries.forEach { dest ->
                FlatTab(dest, isSelected = dest == selected, onClick = { onSelect(dest) })
            }
        }
    }
}

@Composable
private fun FlatPlayerCard(vm: PlayerViewModel, onClick: () -> Unit, castName: String?) {
    val shape = RoundedCornerShape(20.dp)
    // A thin green line along the bottom shows how far the song is.
    val pos by rememberLivePositionMs(vm, poll = true)
    val fraction = if (vm.durationMs > 0) (pos.toFloat() / vm.durationMs).coerceIn(0f, 1f) else 0f
    val line = Palette.Accent
    Row(
        Modifier
            .fillMaxWidth()
            .clip(shape)
            .background(Color(0xFF1A1A1A))
            .drawBehind {
                val h = 3.dp.toPx()
                drawRect(line, topLeft = Offset(0f, size.height - h), size = Size(size.width * fraction, h))
            }
            .clickable(onClick = onClick)
            .padding(start = 10.dp, end = 10.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp))) {
            val art = vm.artwork
            if (art != null) {
                Image(art, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
            } else {
                ArtworkPlaceholder(Modifier.fillMaxSize())
            }
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(
                vm.title ?: "", color = Palette.Text, fontSize = 14.sp, fontWeight = FontWeight.SemiBold,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            Text(
                if (castName != null) "Playing on $castName" else vm.artist ?: "",
                color = Palette.Muted, fontSize = 12.sp,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
        }
        PlayPauseButton(
            isPlaying = vm.isPlaying,
            enabled = true,
            onClick = vm::togglePlay,
            size = 44.dp,
            iconSize = 16.dp,
            color = Palette.Accent
        )
    }
}

@Composable
private fun FlatTab(dest: Destination, isSelected: Boolean, onClick: () -> Unit) {
    val ink = if (isSelected) Palette.Accent else Palette.Muted
    Column(
        Modifier
            .width(76.dp)
            .clip(RoundedCornerShape(20.dp))
            .background(if (isSelected) Palette.Accent.copy(alpha = 0.14f) else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(vertical = 7.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(3.dp)
    ) {
        NeedleIconView(dest.icon, tint = ink)
        Text(dest.label, color = ink, fontSize = 11.sp, fontWeight = FontWeight.Medium)
    }
}
