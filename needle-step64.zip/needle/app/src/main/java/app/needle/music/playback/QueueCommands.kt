package app.needle.music.playback

import android.os.Bundle
import androidx.media3.session.SessionCommand

/**
 * The custom messages the UI sends to the playback service:
 * "play this ordered list of song ids, starting at this position" and
 * "add these song ids to the queue (right after the current song, or at the end)".
 * Ids are tiny (8 bytes each), so even a huge library is a small message,
 * and the service builds the real queue itself.
 */
object QueueCommands {
    const val PLAY_QUEUE = "app.needle.music.PLAY_QUEUE"
    const val KEY_IDS = "ids"
    const val KEY_START = "start"
    /** Optional. If present, forces shuffle on/off. If absent, the current shuffle mode is kept. */
    const val KEY_SHUFFLE = "shuffle"

    const val ADD_TO_QUEUE = "app.needle.music.ADD_TO_QUEUE"
    /** true = play right after the current song, false = at the end of the queue. */
    const val KEY_NEXT = "next"

    /** Put the first songs of "Up next" in a new order. [KEY_ORDER] = their queue positions, first to last. */
    const val REORDER_UP_NEXT = "app.needle.music.REORDER_UP_NEXT"
    const val KEY_ORDER = "order"

    val playQueue = SessionCommand(PLAY_QUEUE, Bundle.EMPTY)
    val addToQueue = SessionCommand(ADD_TO_QUEUE, Bundle.EMPTY)
    val reorderUpNext = SessionCommand(REORDER_UP_NEXT, Bundle.EMPTY)
}
