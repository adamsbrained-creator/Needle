package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/**
 * Songs the person hid with "Hide from library". They stay on the phone but no list, search or Home shelf shows
 * them, until they are unhidden in Settings > Library > Hidden songs. Stored by song id. Remembered.
 */
object HiddenSongs {
    private var prefs: SharedPreferences? = null

    val ids = MutableStateFlow<Set<Long>>(emptySet())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        ids.value = p.getString("hidden_songs", "").orEmpty().split(',').mapNotNull { it.trim().toLongOrNull() }.toSet()
    }

    fun hide(songIds: Collection<Long>) = save(ids.value + songIds)

    fun unhide(songIds: Collection<Long>) = save(ids.value - songIds.toSet())

    fun unhideAll() = save(emptySet())

    /** Adds to what is hidden (restoring a backup never un-hides anything). */
    fun merge(songIds: Collection<Long>) = save(ids.value + songIds)

    private fun save(set: Set<Long>) {
        ids.value = set
        prefs?.edit()?.putString("hidden_songs", set.joinToString(","))?.apply()
    }
}
