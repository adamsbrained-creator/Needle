package app.needle.music.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtistRow
import kotlinx.coroutines.launch

/** What one line of the Artists list is. [key] keeps the list steady while it changes. */
private sealed class ArtistEntry(val key: String) {
    object Title : ArtistEntry("title")
    class Header(val text: String, val action: String?, key: String) : ArtistEntry(key)
    class Artist(val row: ArtistRow, val pinned: Boolean, val inPinnedList: Boolean) :
        ArtistEntry((if (inPinnedList) "p:" else "a:") + row.key)
    class Letter(val letter: Char) : ArtistEntry("l:$letter")
}

/**
 * Every artist in the library, A to Z, with a round picture (the cover of one of their songs), "N albums · M songs"
 * and a letter index on the right (tap it or slide a finger along it). Opened from Library > Artists and from
 * "See all" on the Home artists row (Black & Green).
 *
 * Pinned artists sit on top in the order they were pinned. Press and hold an artist to pin or unpin them
 * ([onTogglePin]); "Edit" on the Pinned part shows an X on each to unpin. The star on the artist page and the
 * Pin artist button on Now playing pin too.
 */
@Composable
fun ArtistsScreen(
    artists: List<ArtistRow>?,
    pinnedKeys: List<String>,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onSearch: () -> Unit,
    onOpenArtist: (String) -> Unit,
    onTogglePin: (ArtistRow) -> Unit,
    modifier: Modifier = Modifier
) {
    var editing by remember { mutableStateOf(false) }
    val list = artists.orEmpty()
    val pinned = remember(list, pinnedKeys) {
        val byKey = list.associateBy { it.key }
        pinnedKeys.mapNotNull { byKey[it] }
    }
    LaunchedEffect(pinned.isEmpty()) { if (pinned.isEmpty()) editing = false }

    val entries = remember(list, pinned, editing) {
        val out = ArrayList<ArtistEntry>()
        out += ArtistEntry.Title
        if (pinned.isNotEmpty()) {
            out += ArtistEntry.Header("Pinned", if (editing) "Done" else "Edit", "h:pinned")
            pinned.forEach { out += ArtistEntry.Artist(it, pinned = true, inPinnedList = true) }
            out += ArtistEntry.Header("All artists", null, "h:all")
        }
        val pinnedSet = pinned.map { it.key }.toSet()
        var last: Char? = null
        for (row in list) {
            if (row.letter != last) {
                last = row.letter
                out += ArtistEntry.Letter(row.letter)
            }
            out += ArtistEntry.Artist(row, pinned = row.key in pinnedSet, inPinnedList = false)
        }
        out
    }
    val letters = remember(list) { list.map { it.letter }.distinct() }
    val letterAt = remember(entries) {
        entries.withIndex().filter { it.value is ArtistEntry.Letter }.associate { (it.value as ArtistEntry.Letter).letter to it.index }
    }

    val state = rememberLazyListState()
    val scope = rememberCoroutineScope()

    Box(modifier.fillMaxSize()) {
        LazyColumn(Modifier.fillMaxSize(), state = state, contentPadding = PaddingValues(bottom = bottomPadding)) {
            items(entries.size, key = { entries[it].key }) { i ->
                when (val e = entries[i]) {
                    ArtistEntry.Title -> Column {
                        Row(
                            Modifier.fillMaxWidth().padding(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp)
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Artists", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp)
                                Text(
                                    when {
                                        artists == null -> "Loading…"
                                        list.size == 1 -> "1 artist"
                                        else -> "${"%,d".format(list.size)} artists"
                                    },
                                    color = Palette.Muted, fontSize = 13.sp
                                )
                            }
                            RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 42.dp, iconSize = 22.dp)
                        }
                        if (artists != null && list.isEmpty()) {
                            Text(
                                "No artists yet. Open Songs and scan for music.", color = Palette.Muted, fontSize = 14.sp,
                                modifier = Modifier.padding(horizontal = 24.dp, vertical = 32.dp)
                            )
                        }
                    }
                    is ArtistEntry.Header -> Row(
                        Modifier.fillMaxWidth().padding(start = 18.dp, end = 22.dp, top = 16.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(e.text, color = Palette.Text, fontSize = 18.sp, fontWeight = FontWeight.Medium, modifier = Modifier.weight(1f))
                        if (e.action != null) {
                            Text(
                                e.action, color = Color(0xFFDDDDDD), fontSize = 13.sp,
                                modifier = Modifier.clickable { editing = !editing }.padding(horizontal = 4.dp, vertical = 6.dp)
                            )
                        }
                    }
                    is ArtistEntry.Letter -> Text(
                        e.letter.toString(), color = Palette.Muted, fontSize = 13.sp, fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(start = 22.dp, top = 14.dp, bottom = 2.dp)
                    )
                    is ArtistEntry.Artist -> ArtistLine(
                        row = e.row,
                        pinned = e.pinned,
                        showUnpin = editing && e.inPinnedList,
                        onClick = { onOpenArtist(e.row.name) },
                        onLongClick = { onTogglePin(e.row) },
                        onUnpin = { onTogglePin(e.row) }
                    )
                }
            }
        }

        // The letter index: tap a letter or slide a finger along it to jump.
        if (letters.size > 1) {
            var height by remember { mutableStateOf(1) }
            // The list changes when something is pinned, so the index must always use the latest positions.
            val currentLetterAt by rememberUpdatedState(letterAt)
            fun jump(y: Float) {
                val i = (y / height * letters.size).toInt().coerceIn(0, letters.lastIndex)
                currentLetterAt[letters[i]]?.let { target -> scope.launch { state.scrollToItem(target) } }
            }
            Column(
                Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 4.dp, bottom = 80.dp)
                    .width(26.dp)
                    .onSizeChanged { height = it.height.coerceAtLeast(1) }
                    .pointerInput(letters) { detectTapGestures(onPress = { jump(it.y) }) }
                    .pointerInput(letters) { detectVerticalDragGestures { change, _ -> jump(change.position.y) } },
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                letters.forEach { l ->
                    Text(
                        l.toString(), color = Palette.Muted, fontSize = 11.sp, fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(vertical = 2.dp)
                    )
                }
            }
        }
    }
}

@Composable
private fun ArtistLine(
    row: ArtistRow,
    pinned: Boolean,
    showUnpin: Boolean,
    onClick: () -> Unit,
    onLongClick: () -> Unit,
    onUnpin: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .tapOrHold(onClick, onLongClick)
            .padding(start = 18.dp, end = if (showUnpin) 18.dp else 36.dp, top = 8.dp, bottom = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(52.dp).clip(CircleShape)) { Cover(row.cover, Modifier.fillMaxSize()) }
        Spacer(Modifier.width(14.dp))
        Column(Modifier.weight(1f)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(
                    row.name, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.SemiBold,
                    maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f, fill = false)
                )
                if (pinned && !showUnpin) {
                    NeedleIconView(NeedleIcon.STAR_FILLED, Palette.Accent, Modifier.padding(start = 6.dp), size = 13.dp)
                }
            }
            Text(row.line, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        if (showUnpin) {
            RoundIconButton(NeedleIcon.CLOSE, onUnpin, size = 32.dp, iconSize = 15.dp)
        }
    }
}
