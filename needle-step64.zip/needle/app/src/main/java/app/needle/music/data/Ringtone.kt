package app.needle.music.data

import android.content.Context
import android.content.Intent
import android.media.RingtoneManager
import android.net.Uri
import android.provider.Settings

/** "Set as ringtone" from the song menu. Android asks the person once to let Needle change system settings. */
object Ringtone {
    enum class Result { SET, NEEDS_PERMISSION, FAILED }

    /** Makes [song] the phone's ringtone. If Needle may not change settings yet, opens the screen where that is allowed. */
    fun set(context: Context, song: Song): Result {
        if (!Settings.System.canWrite(context)) {
            val intent = Intent(Settings.ACTION_MANAGE_WRITE_SETTINGS, Uri.parse("package:${context.packageName}"))
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            try {
                context.startActivity(intent)
            } catch (_: Exception) {
                return Result.FAILED
            }
            return Result.NEEDS_PERMISSION
        }
        return try {
            RingtoneManager.setActualDefaultRingtoneUri(context, RingtoneManager.TYPE_RINGTONE, song.uri)
            Result.SET
        } catch (_: Exception) {
            Result.FAILED
        }
    }
}
