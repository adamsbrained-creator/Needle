package app.needle.music.data

import java.time.Instant
import java.time.ZoneId

/** One genre of the stats page and its share (0..100) of everything played in the period. */
class GenreShare(val name: String, val percent: Int)

/** One artist of the stats page and how many plays their songs got in the period. */
class PlayedArtist(val name: String, val plays: Int)

/**
 * Everything the "Your stats" page shows for one period.
 * [weekdays] is the listening time (ms) of Monday .. Sunday added up over the period.
 */
class StatsData(
    val listenedMs: Long,
    val plays: Int,
    val artistCount: Int,
    val weekdays: List<Long>,
    val topSongs: List<PlayedSong>,
    val topArtists: List<PlayedArtist>,
    val topGenres: List<GenreShare>
) {
    val isEmpty: Boolean get() = plays == 0
}

private const val DAY_MS = 86_400_000L

/**
 * Builds the stats of every period from the play history. Like Most played, it only knows what Needle has seen on
 * this phone, and a song counts as played after 30 seconds. A song with several genres counts for each of them,
 * and the shares are taken from all those counts, so they add up to about 100.
 */
fun buildStats(songs: List<Song>, plays: List<PlayEvent>, now: Long): Map<MostRange, StatsData> {
    val byId = songs.associateBy { it.id }
    val zone = ZoneId.systemDefault()
    return MostRange.entries.associateWith { range ->
        val from = range.days?.let { now - it * DAY_MS } ?: 0L
        val events = plays.filter { it.playedAt >= from && byId.containsKey(it.songId) }

        val weekdays = LongArray(7)
        for (e in events) {
            val day = Instant.ofEpochMilli(e.playedAt).atZone(zone).dayOfWeek.value // 1 = Monday .. 7 = Sunday
            weekdays[day - 1] += e.listenedMs
        }

        val bySong = events.groupingBy { it.songId }.eachCount()
        val topSongs = bySong
            .mapNotNull { (id, n) -> byId[id]?.let { PlayedSong(it, n) } }
            .sortedWith(compareByDescending<PlayedSong> { it.plays }.thenBy { it.song.title })
            .take(5)

        // Artists are matched ignoring upper and lower case, and shown the way most of their songs spell them.
        val artistPlays = HashMap<String, Int>()
        val spellings = HashMap<String, HashMap<String, Int>>()
        for (e in events) {
            val artist = byId.getValue(e.songId).artist
            val key = artistKey(artist)
            artistPlays[key] = (artistPlays[key] ?: 0) + 1
            val sp = spellings.getOrPut(key) { HashMap() }
            sp[artist] = (sp[artist] ?: 0) + 1
        }
        val topArtists = artistPlays
            .map { (key, n) -> PlayedArtist(spellings.getValue(key).maxByOrNull { it.value }!!.key, n) }
            .sortedWith(compareByDescending<PlayedArtist> { it.plays }.thenBy { it.name.lowercase() })

        val genreCounts = HashMap<String, Int>()
        val genreSpellings = HashMap<String, HashMap<String, Int>>()
        for (e in events) {
            for (g in genresOf(byId.getValue(e.songId)).distinctBy { it.lowercase() }) {
                val key = g.lowercase()
                genreCounts[key] = (genreCounts[key] ?: 0) + 1
                val sp = genreSpellings.getOrPut(key) { HashMap() }
                sp[g] = (sp[g] ?: 0) + 1
            }
        }
        val genreTotal = genreCounts.values.sum()
        val topGenres = if (genreTotal == 0) emptyList() else genreCounts
            .map { (key, n) ->
                n to GenreShare(genreSpellings.getValue(key).maxByOrNull { it.value }!!.key, Math.round(n * 100f / genreTotal))
            }
            .sortedWith(compareByDescending<Pair<Int, GenreShare>> { it.first }.thenBy { it.second.name.lowercase() })
            .map { it.second }
            .take(5)

        StatsData(
            listenedMs = events.sumOf { it.listenedMs },
            plays = events.size,
            artistCount = artistPlays.size,
            weekdays = weekdays.toList(),
            topSongs = topSongs,
            topArtists = topArtists.take(5),
            topGenres = topGenres
        )
    }
}
