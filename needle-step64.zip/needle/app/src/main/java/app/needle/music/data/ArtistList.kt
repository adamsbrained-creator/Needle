package app.needle.music.data

/** One row of the Artists page. */
class ArtistRow(
    val name: String,
    val key: String,
    val albums: Int,
    val songs: Int,
    /** A song whose cover stands for the artist: the newest one from a real album, else the newest song. */
    val cover: Song
) {
    /** "3 albums · 41 songs", or just the songs when the artist has no real album. */
    val line: String
        get() {
            val s = if (songs == 1) "1 song" else "$songs songs"
            return if (albums == 0) s else "${if (albums == 1) "1 album" else "$albums albums"} · $s"
        }

    /** The letter of the A to Z index: the first letter without accents, or '#'. */
    val letter: Char
        get() = sortKey(name, dropThe = true).firstOrNull()?.takeIf { it in 'a'..'z' }?.uppercaseChar() ?: '#'
}

/**
 * Every artist of the library, A to Z (a leading "The" is ignored, like in Songs). [realAlbumIds] are the ids of
 * the albums that count as albums, so singles do not add to an artist's album count.
 */
fun buildArtistList(songs: List<Song>, realAlbumIds: Set<Long>): List<ArtistRow> =
    songs.groupBy { artistKey(it.artist) }
        .filterValues { group -> isKnownArtist(group.first().artist) }
        .map { (key, mine) ->
            val spelling = mine.groupingBy { it.artist }.eachCount().maxByOrNull { it.value }!!.key
            val cover = mine.filter { it.albumId in realAlbumIds }.maxByOrNull { it.dateAdded }
                ?: mine.maxByOrNull { it.dateAdded }!!
            ArtistRow(
                name = spelling,
                key = key,
                albums = mine.filter { it.albumId in realAlbumIds }.map { it.albumId }.distinct().size,
                songs = mine.size,
                cover = cover
            )
        }
        .sortedWith(compareBy({ it.letter == '#' }, { sortKey(it.name, dropThe = true) }))
