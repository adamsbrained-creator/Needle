package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow

/** The last things the person searched for (the chips under the search box). Newest first. Remembered. */
object RecentSearches {
    private const val MAX = 8
    private var prefs: SharedPreferences? = null

    val items = MutableStateFlow<List<String>>(emptyList())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        items.value = p.getString("recent_searches", "").orEmpty().split('\n').filter { it.isNotBlank() }
    }

    /** Called when a search led somewhere (a song was played, an album or artist opened). */
    fun add(query: String) {
        val q = query.trim().replace('\n', ' ')
        if (q.length < 2) return
        save((listOf(q) + items.value.filterNot { it.equals(q, ignoreCase = true) }).take(MAX))
    }

    fun remove(query: String) = save(items.value.filterNot { it == query })

    fun clear() = save(emptyList())

    private fun save(list: List<String>) {
        items.value = list
        prefs?.edit()?.putString("recent_searches", list.joinToString("\n"))?.apply()
    }
}
