package app.needle.music.data

import kotlin.math.abs
import kotlin.random.Random

/**
 * "Instant mix" and "Smart flow": picks songs from the library that sound like a seed song.
 * There is no online lookup. A song is close to the seed when it shares a genre, the artist or the album,
 * comes from about the same years, and (a little) when you rated it high. A bit of luck is mixed in so
 * the same seed does not give the same list every time, and no artist can fill the whole list.
 */
object SimilarSongs {
    private const val MAX_PER_ARTIST = 4

    fun score(seed: Song, other: Song, rating: Int, random: Random): Double {
        var s = 0.0
        val seedGenres = genresOf(seed).map { it.lowercase() }.toSet()
        if (seedGenres.isNotEmpty()) {
            val shared = genresOf(other).map { it.lowercase() }.count { it in seedGenres }
            s += 3.0 * shared.coerceAtMost(2)
        }
        if (isKnownArtist(seed.artist) && artistKey(seed.artist) == artistKey(other.artist)) s += 2.5
        if (seed.albumId == other.albumId && seed.albumId != 0L) s += 0.8
        if (seed.year > 0 && other.year > 0) {
            val gap = abs(seed.year - other.year)
            s += when {
                gap <= 3 -> 1.5
                gap <= 8 -> 0.8
                gap <= 15 -> 0.3
                else -> 0.0
            }
        }
        if (rating > 0) s += rating.toDouble() / RatingScale.MAX
        return s + random.nextDouble() * 2.0   // the luck
    }

    /**
     * Up to [limit] songs close to [seed], best first. Songs in [exclude] (and the seed itself) are left out.
     * [ratings] is song id -> rating (see RatingScale).
     */
    fun pick(
        seed: Song,
        all: List<Song>,
        ratings: Map<Long, Int> = emptyMap(),
        exclude: Set<Long> = emptySet(),
        limit: Int = 40,
        random: Random = Random.Default
    ): List<Song> {
        val ranked = all.asSequence()
            .filter { it.id != seed.id && it.id !in exclude }
            .map { it to score(seed, it, ratings[it.id] ?: 0, random) }
            .sortedByDescending { it.second }
            .map { it.first }
            .toList()
        val perArtist = HashMap<String, Int>()
        val out = ArrayList<Song>()
        for (song in ranked) {
            if (out.size >= limit) break
            val key = artistKey(song.artist)
            val n = perArtist[key] ?: 0
            if (n >= MAX_PER_ARTIST) continue
            perArtist[key] = n + 1
            out += song
        }
        return out
    }
}
