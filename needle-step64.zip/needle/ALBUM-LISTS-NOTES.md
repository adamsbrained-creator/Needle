# Media lists on album pages, with ratings and hearts (built on Step 54)

## What changed
Album pages (and Singles, which use the same page) now follow Settings > Customization > Media lists,
and can show hearts and ratings on the tracks.

### Follows the media list settings
- Row style: Compact makes the track rows tighter and a little smaller (Normal and Text only look the same here,
  album tracks have no cover).
- On the right: Duration (as before), Year, Plays, Added, Rating or Nothing.
- Swipe right / left on a track: the actions you chose (play next, add to queue, favorite, add to playlist).
- Long press selects songs: a long press picks tracks and shows the selection bar (All, Next, Queue, Playlist, Tags),
  like the Songs page. Back leaves selecting first.
- Show counts: off hides the track count and length under the album title (the year stays).
- Hide back button: the round back button on the album page is hidden too (the back gesture still works).

### Two new options (Media lists > Album pages), both Off until you turn them on
- Ratings: Off / Number / Stars
  - Number: "★ 4" on the right, in the way you chose in Settings > Ratings (4, 4.75, 8 ...). It is left out
    when "On the right" already shows the rating.
  - Stars: five small stars under the title, the rated ones in your accent color, rounded to the nearest whole star.
- Favorite hearts: a small accent-colored heart on tracks that are in Liked songs.

The settings page has a live preview of three album tracks under "Album pages".
All of it is remembered, backed up with the other media list settings, and goes back to Off with "Restore defaults".

## Files
- data/ListSettings.kt   AlbumRating, albumRating, albumHeart
- ui/AlbumScreen.kt      new TrackRow, selection, back button, counts, AlbumRowsPreview
- ui/MediaLists.kt       SwipeRow and SelectMark made available to the album page
- ui/SettingsScreen.kt   "Album pages" section with the preview; two notes updated
- ui/NeedleApp.kt        passes the ratings to the album page

## Not done / choices
- "Under the title" (artist / album) is not used: every track of an album has the same album, so the album page keeps
  showing the artist only when it differs from the album artist.
- Hearts show only on liked tracks (no empty hearts), like the Songs page.
- No compiler or Gradle here. Checked brace balance (unchanged on every file I touched), missing imports, that every
  ListSettings member in use exists, and that all call sites match. Please build once.
