# Media lists, built on Step 52

Settings > Customization > Media lists

## New files
- data/ListSettings.kt   all media list settings (own prefs file "needle_lists", in backups as "mediaLists", Restore defaults)
- ui/MediaLists.kt       the new SongRow, swipe actions, selection state and bar, ListBackButton, ListDecor/RowActions

## Changed
- ui/SongsScreen.kt      counts, flipped arrows, pinned sort bar, selection mode (old SongRow moved to MediaLists.kt)
- ui/GenreScreen.kt      counts, selection mode, back button toggle
- ui/AlbumsScreen.kt     2 to 4 columns, centered text, counts
- ui/MostPlayedScreen.kt, SinglesScreen.kt, PlaylistScreens.kt   back button follows "Hide back button"
- ui/SettingsScreen.kt   Media lists page + row on the Customization page
- ui/NeedleApp.kt        feeds the rows (liked, play counts) and wires swipe / selection actions
- data/NeedleSettings.kt, data/Backup.kt   init and backup hooks

## Settings
Song rows:  Row style (Normal / Compact / Text only), Under the title (Artist · Album / Artist / Album),
            On the right (Duration / Year / Plays / Added / Rating / Nothing), Rating under the title, Favorite heart
List pages: Show counts, Flip sort arrows, Pin the sort bar, Hide back button
Album grid: Columns (2, 3, 4), Center text
Gestures:   Swipe right (default Add to queue), Swipe left (default Play next), each can be Off / Play next / Add to queue /
            Favorite / Add to playlist; "Long press selects songs"
A live preview at the top. Restore defaults at the bottom.

## Selecting songs (new)
With "Long press selects songs" on, a long press on Songs or a genre page starts selecting. Tap to pick more.
The bar at the bottom: All, Next, Queue, Playlist, Tags. Back or X ends it.

## Left out on purpose
- "Show offline status overlay", smart filter chips, top button row styles: they belong to Symfonium's server features and
  its button rows, which Needle does not have.
- Selecting is only on Songs and genre pages for now (other pages still open the song menu on long press).
- No compiler here: braces and names checked against Step 52. Please build once.
