# Step 79: new bottom bar, Library page, Browse page, Internet radio

NOTHING IN THIS STEP HAS BEEN COMPILED (no build tools where it was written). If GitHub Actions shows errors, send them over; they are most likely small name or type slips.

## Bottom bar
Home - Playlists (Songs note icon) - Browse - Library.
- Playlists = the old Library grid (mixes, smart mixes, playlists), retitled "Playlists", without the row of links.
- Browse = new page made from your own library (shortcuts, Jump back in, Your artists, You keep coming back to, Rediscover, Radio).
- Library = new page that links to everything: Songs, Albums, Artists, Playlists, Liked songs, Folders, Singles, Your stats, Most played, Radio, Hidden songs, Settings.
- Songs and Albums are still pages; the bar highlights Library while you are on them.

## Radio
- Stations are kept on the phone (needle_radio preferences). Fields: Name, Default URL, Mobile URL (used on metered networks), Thumbnail URL, Description, tags.
- Pages: Radio list, station page, add/edit form, Find stations (public Radio Browser directory), live player (no seek bar, song from the stream's ICY title, heart to save a song).
- Playback goes through the existing service with a custom command; media id is "radio:<id>", so play history, queue restore, loudness and casting ignore radio.
- Not done: station logo in the dock mini-player, sleep timer / cast from the radio player, time listened per station.
- The directory mirrors and API were not tested from here.

## Files
New: data/RadioStations.kt, data/RadioDirectory.kt, data/RadioArt.kt, ui/RadioScreens.kt, ui/BrowseScreen.kt, ui/LibraryHubScreen.kt
Changed: ui/Dock.kt, ui/Icons.kt, ui/NeedleApp.kt, ui/PlaylistScreens.kt (title + showLinks), playback/QueueCommands.kt, playback/PlaybackService.kt, playback/PlayerViewModel.kt, MainActivity.kt

## Next (Stage 2)
Insights page, recommendations (MusicBrainz / Deezer / optional Last.fm, artist and album names only, Wi-Fi only, cached), wishlist, recommendation settings.
