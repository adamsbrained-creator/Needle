package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import android.net.ConnectivityManager
import kotlinx.coroutines.flow.MutableStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * One internet radio station, with the same fields as the add form (Name, Default URL, Mobile URL, Thumbnail URL,
 * Description, tags).
 */
data class RadioStation(
    val id: String,
    val name: String,
    val url: String,
    val mobileUrl: String = "",
    val thumbUrl: String = "",
    val description: String = "",
    val tags: List<String> = emptyList(),
    val addedAt: Long = 0L,
    val favorite: Boolean = false
) {
    /** One or two letters for the logo tile when there is no picture ("SomaFM Groove Salad" -> "SG"). */
    val initials: String get() = radioInitials(name)

    /** "Jazz, Late night" for the second line of a row. */
    val tagLine: String get() = tags.joinToString(", ")

    /** The logo tile color, the same for the same station every time. */
    val tileIndex: Int get() = radioTileIndex(name)
}

/** One or two letters for a station's logo tile. */
fun radioInitials(name: String): String {
    val words = name.trim().split(' ', '-', '.').filter { it.isNotEmpty() }
    val letters = when {
        words.isEmpty() -> "?"
        words.size == 1 -> words[0].take(2)
        else -> "" + words[0].first() + words[1].first()
    }
    return letters.uppercase()
}

/** Which of the six tile colors a station name gets. */
fun radioTileIndex(name: String): Int = (name.lowercase().hashCode() and 0x7fffffff) % 6

/** A song caught from a station's stream (the person tapped the heart), or one that played there recently. */
data class RadioSong(val stationId: String, val title: String, val artist: String, val at: Long)

/**
 * The person's radio stations and the songs they saved from them. Remembered in its own small preferences file
 * (needle_radio), so it does not touch anything else.
 */
object RadioStations {
    private var prefs: SharedPreferences? = null

    val stations = MutableStateFlow<List<RadioStation>>(emptyList())

    /** Songs the person saved from a stream, newest first. */
    val saved = MutableStateFlow<List<RadioSong>>(emptyList())

    /** What played lately on the stations (this session only), newest first. */
    val recent = MutableStateFlow<List<RadioSong>>(emptyList())

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_radio", Context.MODE_PRIVATE)
        prefs = p
        stations.value = runCatching { parseStations(p.getString("stations", "[]").orEmpty()) }.getOrDefault(emptyList())
        saved.value = runCatching { parseSongs(p.getString("saved", "[]").orEmpty()) }.getOrDefault(emptyList())
    }

    fun get(id: String): RadioStation? = stations.value.firstOrNull { it.id == id }

    /** Adds a station and returns it. Tags are split at the commas. */
    fun add(
        name: String, url: String, mobileUrl: String = "", thumbUrl: String = "",
        description: String = "", tags: String = ""
    ): RadioStation {
        val station = RadioStation(
            id = UUID.randomUUID().toString().take(8),
            name = name.trim().ifEmpty { url.trim() },
            url = url.trim(),
            mobileUrl = mobileUrl.trim(),
            thumbUrl = thumbUrl.trim(),
            description = description.trim(),
            tags = splitTags(tags),
            addedAt = System.currentTimeMillis()
        )
        saveStations(stations.value + station)
        return station
    }

    /** Replaces the station that has the same id. */
    fun update(station: RadioStation) {
        saveStations(stations.value.map { if (it.id == station.id) station else it })
    }

    fun delete(id: String) {
        saveStations(stations.value.filter { it.id != id })
        saveSongs(saved.value.filter { it.stationId != id })
    }

    fun toggleFavorite(id: String) {
        val s = get(id) ?: return
        update(s.copy(favorite = !s.favorite))
    }

    /** True when a station with this stream address is already in the list. */
    fun hasUrl(url: String): Boolean = stations.value.any { it.url.equals(url.trim(), ignoreCase = true) }

    fun splitTags(text: String): List<String> =
        text.split(',').map { it.trim() }.filter { it.isNotEmpty() }.distinctBy { it.lowercase() }

    // ---- songs ----------------------------------------------------------------------

    /** The stream told us what is playing now. Remembered for the "Played recently" list; the same song twice in a row counts once. */
    fun noteSong(stationId: String, title: String, artist: String) {
        if (title.isBlank()) return
        val last = recent.value.firstOrNull()
        if (last != null && last.stationId == stationId && last.title == title && last.artist == artist) return
        recent.value = (listOf(RadioSong(stationId, title, artist, System.currentTimeMillis())) + recent.value).take(60)
    }

    fun isSaved(stationId: String, title: String, artist: String): Boolean =
        saved.value.any { it.stationId == stationId && it.title == title && it.artist == artist }

    /** Saves the song, or takes it out again if it was saved. Returns true if it is saved now. */
    fun toggleSaved(stationId: String, title: String, artist: String): Boolean {
        if (title.isBlank()) return false
        return if (isSaved(stationId, title, artist)) {
            saveSongs(saved.value.filterNot { it.stationId == stationId && it.title == title && it.artist == artist })
            false
        } else {
            saveSongs(listOf(RadioSong(stationId, title, artist, System.currentTimeMillis())) + saved.value)
            true
        }
    }

    // ---- which address to play -------------------------------------------------------

    /** On mobile data (or any metered network) the Mobile URL is used when the station has one. */
    fun urlToPlay(context: Context, station: RadioStation): String {
        if (station.mobileUrl.isBlank()) return station.url
        val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as? ConnectivityManager
        val metered = runCatching { cm?.isActiveNetworkMetered == true }.getOrDefault(false)
        return if (metered) station.mobileUrl else station.url
    }

    // ---- saving ----------------------------------------------------------------------

    private fun saveStations(list: List<RadioStation>) {
        stations.value = list
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(
                JSONObject()
                    .put("id", s.id).put("name", s.name).put("url", s.url).put("mobile", s.mobileUrl)
                    .put("thumb", s.thumbUrl).put("desc", s.description).put("tags", s.tags.joinToString(","))
                    .put("added", s.addedAt).put("fav", s.favorite)
            )
        }
        prefs?.edit()?.putString("stations", arr.toString())?.apply()
    }

    private fun saveSongs(list: List<RadioSong>) {
        saved.value = list
        val arr = JSONArray()
        list.forEach { s ->
            arr.put(JSONObject().put("station", s.stationId).put("title", s.title).put("artist", s.artist).put("at", s.at))
        }
        prefs?.edit()?.putString("saved", arr.toString())?.apply()
    }

    private fun parseStations(text: String): List<RadioStation> {
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            RadioStation(
                id = o.getString("id"),
                name = o.optString("name"),
                url = o.optString("url"),
                mobileUrl = o.optString("mobile"),
                thumbUrl = o.optString("thumb"),
                description = o.optString("desc"),
                tags = splitTags(o.optString("tags")),
                addedAt = o.optLong("added"),
                favorite = o.optBoolean("fav")
            )
        }
    }

    private fun parseSongs(text: String): List<RadioSong> {
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            RadioSong(o.optString("station"), o.optString("title"), o.optString("artist"), o.optLong("at"))
        }
    }
}
