package app.needle.music.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.songsText

/** One line of the Library page. */
private class HubEntry(val icon: NeedleIcon, val title: String, val note: String, val onClick: () -> Unit)

/**
 * Library: one page that links to everything Needle has, so nothing gets lost when the bottom bar changes.
 * Every page that exists is listed here, grouped: your music, listening, radio, and the settings.
 */
@Composable
fun LibraryHubScreen(
    songCount: Int,
    albumCount: Int,
    artistCount: Int,
    playlistCount: Int,
    likedCount: Int,
    stationCount: Int,
    hiddenCount: Int,
    bottomPadding: Dp,
    onSearch: () -> Unit,
    onSongs: () -> Unit,
    onAlbums: () -> Unit,
    onArtists: () -> Unit,
    onPlaylists: () -> Unit,
    onLiked: () -> Unit,
    onFolders: () -> Unit,
    onSingles: () -> Unit,
    onMostPlayed: () -> Unit,
    onStats: () -> Unit,
    onRadio: () -> Unit,
    onHidden: () -> Unit,
    onSettings: () -> Unit,
    modifier: Modifier = Modifier
) {
    val music = listOf(
        HubEntry(NeedleIcon.SONGS, "Songs", songsText(songCount), onSongs),
        HubEntry(NeedleIcon.ALBUMS, "Albums", countText(albumCount, "album"), onAlbums),
        HubEntry(NeedleIcon.ARTIST, "Artists", countText(artistCount, "artist"), onArtists),
        HubEntry(NeedleIcon.LIBRARY, "Playlists", countText(playlistCount, "playlist"), onPlaylists),
        HubEntry(NeedleIcon.HEART, "Liked songs", songsText(likedCount), onLiked),
        HubEntry(NeedleIcon.FOLDER, "Folders", "Browse by folder", onFolders),
        HubEntry(NeedleIcon.PLAY_NEXT, "Singles", "Songs without an album", onSingles)
    )
    val listening = listOf(
        HubEntry(NeedleIcon.CHART, "Your stats", "Time listened, top songs and artists", onStats),
        HubEntry(NeedleIcon.STAR, "Most played", "Week, month, year and all time", onMostPlayed)
    )
    val radio = listOf(
        HubEntry(NeedleIcon.RADIO, "Radio", if (stationCount == 0) "Add your first station" else countText(stationCount, "station"), onRadio)
    )
    val more = listOf(
        HubEntry(NeedleIcon.EYE_OFF, "Hidden songs", if (hiddenCount == 0) "Nothing hidden" else songsText(hiddenCount), onHidden),
        HubEntry(NeedleIcon.GEAR, "Settings", "Look, library, playback and more", onSettings)
    )

    LazyColumn(modifier.fillMaxSize(), contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 12.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("Library", color = Palette.Text, fontFamily = Palette.TitleFont, fontSize = 34.sp, modifier = Modifier.weight(1f))
                RoundIconButton(NeedleIcon.SEARCH, onSearch, size = 40.dp, iconSize = 20.dp)
            }
        }
        item { HubGroup("Your music", music) }
        item { HubGroup("Listening", listening) }
        item { HubGroup("Radio", radio) }
        item { HubGroup("More", more) }
    }
}

private fun countText(n: Int, noun: String) = if (n == 1) "1 $noun" else "$n ${noun}s"

@Composable
private fun HubGroup(title: String, entries: List<HubEntry>) {
    Text(
        title, color = Palette.Muted, fontSize = 13.sp, fontWeight = FontWeight.Medium,
        modifier = Modifier.padding(start = 4.dp, top = 18.dp, bottom = 8.dp)
    )
    Column(Modifier.fillMaxWidth().glass(cornerShape(22.dp))) {
        entries.forEachIndexed { i, e ->
            Row(
                Modifier.fillMaxWidth().clickable(onClick = e.onClick).padding(horizontal = 14.dp).height(60.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    Modifier.size(36.dp).clip(CircleShape).background(Palette.Accent.copy(alpha = 0.18f)),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(e.icon, Palette.Accent, size = 20.dp) }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(e.title, color = Palette.Text, fontSize = 16.sp, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(e.note, color = Palette.Muted, fontSize = 12.5.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                NeedleIconView(NeedleIcon.CHEVRON_RIGHT, Palette.Muted, size = 18.dp)
            }
            if (i < entries.lastIndex) {
                Box(Modifier.fillMaxWidth().padding(start = 64.dp).height(1.dp).background(androidx.compose.ui.graphics.Color.White.copy(alpha = 0.07f)))
            }
        }
    }
}
