package app.needle.player.features.local.presentation.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Needle's artist page: the page takes on a color picked from the artist's name, with a big photo,
 * three round buttons, the latest album, all albums and the artist's songs.
 */
@Composable
fun NeedleArtistScreen(
    artistName: String,
    artworkUri: Uri?,
    songs: List<Song>,
    albums: List<Album>,
    currentSong: Song?,
    isPlaying: Boolean,
    onBack: () -> Unit,
    onCustomizeImage: () -> Unit,
    onPlayAll: (List<Song>) -> Unit,
    onShufflePlay: (List<Song>) -> Unit,
    onAddToQueueAll: (List<Song>) -> Unit,
    onSongClick: (Song, List<Song>) -> Unit,
    onAlbumClick: (Album) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val hue = remember(artistName) { ((artistName.lowercase().hashCode().toLong() and 0x7fffffffL) % 360L).toFloat() }
    val bg = remember(hue) { Color.hsv(hue, 0.55f, 0.16f) }
    val accent = remember(hue) { Color.hsv(hue, 0.5f, 0.98f) }
    val card = remember(hue) { Color.hsv(hue, 0.45f, 0.27f) }
    val glass = Color.White.copy(alpha = 0.16f)
    val latestAlbum = remember(albums) { albums.maxByOrNull { it.year } ?: albums.firstOrNull() }
    val shownSongs = remember(songs) { songs.take(60) }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(bg),
        contentPadding = PaddingValues(bottom = 200.dp)
    ) {
        item {
            Box(modifier = Modifier.fillMaxWidth().height(360.dp)) {
                if (artworkUri != null) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(artworkUri).crossfade(300).build(),
                        contentDescription = artistName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.fillMaxSize()
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(
                                Brush.radialGradient(
                                    listOf(accent.copy(alpha = 0.55f), card, bg)
                                )
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = artistName.trim().take(1).uppercase(),
                            style = MaterialTheme.typography.displayLarge,
                            color = Color.White.copy(alpha = 0.85f)
                        )
                    }
                }
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(Brush.verticalGradient(listOf(Color.Transparent, bg), startY = 300f))
                )
                Row(
                    modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = 16.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Box(
                        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable { onBack() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(icon = RhythmIcons.ExpandMore, contentDescription = "Back", tint = Color.White, modifier = Modifier.size(24.dp).rotate(90f))
                    }
                    Box(
                        modifier = Modifier.size(42.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.35f)).clickable { onCustomizeImage() },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(modifier = Modifier.size(24.dp), icon = RhythmIcons.More, contentDescription = "Change photo", tint = Color.White)
                    }
                }
                Text(
                    text = artistName,
                    style = MaterialTheme.typography.displaySmall.copy(fontFamily = FontFamily.Serif),
                    color = Color.White,
                    textAlign = TextAlign.Center,
                    maxLines = 2,
                    overflow = TextOverflow.Ellipsis,
                    modifier = Modifier.align(Alignment.BottomCenter).padding(horizontal = 24.dp, vertical = 10.dp)
                )
            }
        }

        item {
            Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                Text(
                    text = "${albums.size} albums \u00B7 ${songs.size} songs",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.White.copy(alpha = 0.7f)
                )
                Spacer(Modifier.height(16.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier.size(54.dp).clip(CircleShape).background(glass).clickable { onShufflePlay(songs) },
                        contentAlignment = Alignment.Center
                    ) { Icon(modifier = Modifier.size(24.dp), icon = RhythmIcons.Shuffle, contentDescription = "Shuffle", tint = Color.White) }
                    Box(
                        modifier = Modifier.size(64.dp).clip(CircleShape).background(accent).clickable { onPlayAll(songs) },
                        contentAlignment = Alignment.Center
                    ) { Icon(modifier = Modifier.size(30.dp), icon = RhythmIcons.Play, contentDescription = "Play all", tint = bg, size = 30.dp) }
                    Box(
                        modifier = Modifier.size(54.dp).clip(CircleShape).background(glass).clickable { onAddToQueueAll(songs) },
                        contentAlignment = Alignment.Center
                    ) { Icon(modifier = Modifier.size(24.dp), icon = RhythmIcons.Queue, contentDescription = "Add to queue", tint = Color.White) }
                }
            }
        }

        if (latestAlbum != null) {
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 18.dp)
                        .clip(RoundedCornerShape(22.dp))
                        .background(card)
                        .clickable { onAlbumClick(latestAlbum) }
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(latestAlbum.artworkUri).size(200, 200).build(),
                        contentDescription = null,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier.size(58.dp).clip(RoundedCornerShape(12.dp)).background(bg)
                    )
                    Column(modifier = Modifier.weight(1f)) {
                        Text("LATEST ALBUM", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                        Text(latestAlbum.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        val year = if (latestAlbum.year > 0) " \u00B7 ${latestAlbum.year}" else ""
                        Text("${latestAlbum.numberOfSongs.coerceAtLeast(latestAlbum.songs.size)} songs$year", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.7f))
                    }
                    Icon(modifier = Modifier.size(24.dp), icon = RhythmIcons.More, contentDescription = null, tint = Color.White.copy(alpha = 0.7f))
                }
            }
        }

        if (albums.size > 1) {
            item {
              Column {
                Text("Albums", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(start = 20.dp, bottom = 10.dp))
                LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(albums, key = { it.id }) { album ->
                        Column(modifier = Modifier.width(116.dp).clickable { onAlbumClick(album) }) {
                            AsyncImage(
                                model = ImageRequest.Builder(context).data(album.artworkUri).size(300, 300).build(),
                                contentDescription = album.title,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(116.dp).clip(RoundedCornerShape(20.dp)).background(card)
                            )
                            Text(album.title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                            if (album.year > 0) {
                                Text(album.year.toString(), style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.6f))
                            }
                        }
                    }
                }
              }
            }
        }

        item {
            Text("Songs", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White, modifier = Modifier.padding(start = 20.dp, top = 22.dp, bottom = 6.dp))
        }
        items(shownSongs, key = { it.id }) { song ->
            val isCurrent = currentSong?.id == song.id
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onSongClick(song, songs) }
                    .padding(horizontal = 20.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context).data(song.artworkUri).size(160, 160).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(48.dp).clip(RoundedCornerShape(10.dp)).background(card)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        song.title,
                        style = MaterialTheme.typography.bodyLarge,
                        fontWeight = FontWeight.SemiBold,
                        color = if (isCurrent) accent else Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(song.album, style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.65f), maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                if (isCurrent && isPlaying) {
                    Icon(modifier = Modifier.size(22.dp), icon = RhythmIcons.Pause, contentDescription = null, tint = accent, size = 22.dp)
                }
            }
        }
    }
}
