/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.features.local.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import app.needle.player.features.local.data.database.entity.ArtistEntity

@Dao
interface ArtistDao {
    @Query("SELECT * FROM artists WHERE groupByAlbumArtist = :groupByAlbumArtist")
    suspend fun getArtists(groupByAlbumArtist: Boolean): List<ArtistEntity>

    @Query("SELECT * FROM artists WHERE groupByAlbumArtist = :groupByAlbumArtist ORDER BY name ASC")
    fun getArtistsFlow(groupByAlbumArtist: Boolean): kotlinx.coroutines.flow.Flow<List<ArtistEntity>>

    @Query("SELECT * FROM artists WHERE groupByAlbumArtist = :groupByAlbumArtist ORDER BY name ASC")
    fun getArtistsPagingSource(groupByAlbumArtist: Boolean): androidx.paging.PagingSource<Int, ArtistEntity>

    @Query("UPDATE artists SET artworkUri = :artworkUri WHERE name = :name")
    suspend fun updateArtworkForArtist(name: String, artworkUri: String?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAll(artists: List<ArtistEntity>)

    @Query("DELETE FROM artists WHERE groupByAlbumArtist = :groupByAlbumArtist")
    suspend fun deleteByGroupType(groupByAlbumArtist: Boolean)

    @Query("DELETE FROM artists")
    suspend fun deleteAll()

    @Transaction
    suspend fun replaceAll(artists: List<ArtistEntity>, groupByAlbumArtist: Boolean) {
        deleteByGroupType(groupByAlbumArtist)
        insertAll(artists)
    }
}
