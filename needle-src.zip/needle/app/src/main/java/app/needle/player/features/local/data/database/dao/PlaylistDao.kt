/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.features.local.data.database.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Transaction
import app.needle.player.features.local.data.database.entity.PlaylistEntity
import app.needle.player.features.local.data.database.entity.PlaylistSongEntity
import app.needle.player.features.local.data.database.entity.SongEntity

@Dao
interface PlaylistDao {
    @Query("SELECT * FROM playlists ORDER BY dateCreated DESC")
    suspend fun getAllPlaylists(): List<PlaylistEntity>

    @Query("SELECT * FROM playlists WHERE id = :playlistId")
    suspend fun getPlaylistById(playlistId: String): PlaylistEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylist(playlist: PlaylistEntity)

    @Query("UPDATE playlists SET artworkUri = :artworkUri WHERE id = :playlistId")
    suspend fun updateArtworkForPlaylist(playlistId: String, artworkUri: String?)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylists(playlists: List<PlaylistEntity>)

    @Query("DELETE FROM playlists WHERE id = :playlistId")
    suspend fun deletePlaylistById(playlistId: String)

    @Query("DELETE FROM playlists")
    suspend fun deleteAllPlaylists()

    @Query("DELETE FROM playlist_songs")
    suspend fun deleteAllPlaylistSongs()

    // Playlist songs relationships
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistSong(playlistSong: PlaylistSongEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPlaylistSongs(playlistSongs: List<PlaylistSongEntity>)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId AND songId = :songId")
    suspend fun deletePlaylistSong(playlistId: String, songId: String)

    @Query("DELETE FROM playlist_songs WHERE playlistId = :playlistId")
    suspend fun deleteSongsFromPlaylist(playlistId: String)

    @Query("DELETE FROM playlist_songs WHERE songId = :songId")
    suspend fun deleteSongFromAllPlaylists(songId: String)

    // Retrieve all song entities associated with a playlist, ordered by orderIndex
    @Query("""
        SELECT s.* FROM songs s 
        INNER JOIN playlist_songs ps ON s.id = ps.songId 
        WHERE ps.playlistId = :playlistId 
        ORDER BY ps.orderIndex ASC
    """)
    suspend fun getSongsForPlaylist(playlistId: String): List<SongEntity>

    // Get all song IDs inside a playlist
    @Query("SELECT songId FROM playlist_songs WHERE playlistId = :playlistId ORDER BY orderIndex ASC")
    suspend fun getSongIdsForPlaylist(playlistId: String): List<String>

    @Transaction
    suspend fun updatePlaylistSongs(playlistId: String, playlistSongs: List<PlaylistSongEntity>) {
        deleteSongsFromPlaylist(playlistId)
        insertPlaylistSongs(playlistSongs)
    }
}
