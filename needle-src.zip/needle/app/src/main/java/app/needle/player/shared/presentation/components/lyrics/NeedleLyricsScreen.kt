package app.needle.player.shared.presentation.components.lyrics

import android.content.Intent
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.gestures.detectVerticalDragGestures
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.LyricsData
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.RhythmIcons

/**
 * Needle's lyrics page: a glowing background, an Original / Translation switch, the lyrics list
 * (tap a line to jump there), a text-size slider on the right edge and a heart / edit / share bar.
 */
@Composable
fun NeedleLyricsScreen(
    song: Song?,
    isFavorite: Boolean,
    currentTimeMs: Long,
    lyrics: LyricsData?,
    isLoadingLyrics: Boolean,
    onLyricsSeek: ((Long) -> Unit)?,
    onRetryLyrics: () -> Unit,
    onClose: () -> Unit,
    onShowLyricsEditor: () -> Unit,
    onNavigateToLyricsSettings: () -> Unit,
    onToggleFavorite: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scheme = MaterialTheme.colorScheme
    val appSettings = remember { AppSettings.getInstance(context) }
    val savedSize by appSettings.playerLyricsTextSize.collectAsState()
    val showTranslation by appSettings.showLyricsTranslation.collectAsState()
    val showRomanization by appSettings.showLyricsRomanization.collectAsState()
    var textSize by remember { mutableFloatStateOf(savedSize.coerceIn(0.8f, 1.8f)) }
    val lyricsText = remember(lyrics) { lyrics?.getBestLyrics().orEmpty() }
    val sliderHeight = 240.dp

    Box(modifier = modifier.fillMaxSize().background(scheme.surfaceContainerLowest)) {
        val glowA = scheme.primary
        val glowB = scheme.tertiary
        val top = scheme.primaryContainer
        val base = scheme.surfaceContainerLowest
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(brush = Brush.linearGradient(listOf(top.copy(alpha = 0.5f), base), start = Offset(0f, 0f), end = Offset(w, h)))
            val c1 = Offset(w * 0.1f, h * 0.15f)
            drawCircle(brush = Brush.radialGradient(listOf(glowB.copy(alpha = 0.3f), Color.Transparent), center = c1, radius = w * 0.8f), radius = w * 0.8f, center = c1)
            val c2 = Offset(w * 0.95f, h * 0.85f)
            drawCircle(brush = Brush.radialGradient(listOf(glowA.copy(alpha = 0.4f), Color.Transparent), center = c2, radius = w * 0.9f), radius = w * 0.9f, center = c2)
        }

        Column(modifier = Modifier.fillMaxSize().statusBarsPadding()) {
            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                NeedleRoundButton(onClick = onClose) {
                    Icon(icon = RhythmIcons.ExpandMore, contentDescription = "Close", tint = Color.White, size = 26.dp)
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song?.title.orEmpty(),
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = Color.White,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song?.artist.orEmpty(),
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White.copy(alpha = 0.7f),
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                NeedleRoundButton(onClick = onNavigateToLyricsSettings) {
                    Icon(icon = RhythmIcons.Info, contentDescription = "Lyrics settings", tint = Color.White)
                }
            }

            Row(modifier = Modifier.fillMaxWidth().padding(top = 6.dp), horizontalArrangement = Arrangement.Center) {
                Row(modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.14f)).padding(3.dp)) {
                    NeedleSegment("Original", !showTranslation) { appSettings.setShowLyricsTranslation(false) }
                    NeedleSegment("Translation", showTranslation) { appSettings.setShowLyricsTranslation(true) }
                }
            }

            Box(modifier = Modifier.weight(1f).fillMaxWidth()) {
                when {
                    isLoadingLyrics -> CircularProgressIndicator(
                        modifier = Modifier.align(Alignment.Center),
                        color = Color.White
                    )
                    lyricsText.isBlank() -> Column(
                        modifier = Modifier.align(Alignment.Center).padding(32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "No lyrics for this song yet.",
                            style = MaterialTheme.typography.titleMedium,
                            color = Color.White,
                            textAlign = TextAlign.Center
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            NeedlePill("Retry", onRetryLyrics)
                            NeedlePill("Add lyrics", onShowLyricsEditor)
                        }
                    }
                    else -> SyncedLyricsView(
                        lyrics = lyricsText,
                        currentPlaybackTime = currentTimeMs,
                        modifier = Modifier.fillMaxSize().padding(start = 22.dp, end = 56.dp),
                        onSeek = onLyricsSeek,
                        showTranslation = showTranslation,
                        showRomanization = showRomanization,
                        lyricsSource = lyrics?.source,
                        textSizeMultiplier = textSize,
                        textAlignment = TextAlign.Start,
                        textColor = Color.White.copy(alpha = 0.5f),
                        activeColor = Color.White,
                        subtitleColor = Color.White.copy(alpha = 0.6f)
                    )
                }

                if (lyricsText.isNotBlank()) {
                    Box(
                        modifier = Modifier
                            .align(Alignment.CenterEnd)
                            .padding(end = 14.dp)
                            .width(34.dp)
                            .height(sliderHeight)
                            .pointerInput(Unit) {
                                detectVerticalDragGestures(
                                    onDragEnd = { appSettings.setPlayerLyricsTextSize(textSize) }
                                ) { change, _ ->
                                    val fraction = (change.position.y / size.height).coerceIn(0f, 1f)
                                    textSize = 1.8f - fraction
                                }
                            }
                            .pointerInput(Unit) {
                                detectTapGestures { offset ->
                                    val fraction = (offset.y / size.height).coerceIn(0f, 1f)
                                    textSize = 1.8f - fraction
                                    appSettings.setPlayerLyricsTextSize(textSize)
                                }
                            },
                        contentAlignment = Alignment.TopCenter
                    ) {
                        Box(
                            modifier = Modifier
                                .width(6.dp)
                                .height(sliderHeight)
                                .clip(CircleShape)
                                .background(
                                    Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.6f), Color.White.copy(alpha = 0.08f)))
                                )
                        )
                        Box(
                            modifier = Modifier
                                .align(Alignment.TopCenter)
                                .offset(y = sliderHeight * (1.8f - textSize).coerceIn(0f, 1f) - 11.dp)
                                .size(22.dp)
                                .clip(CircleShape)
                                .background(Color.White)
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(horizontal = 18.dp, vertical = 14.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                NeedleRoundButton(onClick = onToggleFavorite) {
                    Icon(
                        icon = if (isFavorite) RhythmIcons.Actions.Favorite else RhythmIcons.Actions.FavoriteOutlined,
                        contentDescription = "Favorite",
                        tint = if (isFavorite) scheme.secondary else Color.White
                    )
                }
                NeedlePill("Edit lyrics", onShowLyricsEditor)
                NeedleRoundButton(
                    onClick = {
                        val plain = lyrics?.plainLyrics
                            ?: Regex("\\[[^\\]]*]").replace(lyricsText, "").trim()
                        if (plain.isNotBlank()) {
                            val send = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_TEXT, plain)
                            }
                            context.startActivity(Intent.createChooser(send, null))
                        }
                    }
                ) {
                    Icon(icon = RhythmIcons.Share, contentDescription = "Share lyrics", tint = Color.White)
                }
            }
        }
    }
}

@Composable
private fun NeedleRoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.size(44.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.16f)).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun NeedlePill(label: String, onClick: () -> Unit) {
    Box(
        modifier = Modifier.clip(CircleShape).background(Color.White.copy(alpha = 0.22f)).clickable { onClick() }.padding(horizontal = 26.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = Color.White)
    }
}

@Composable
private fun NeedleSegment(label: String, selected: Boolean, onClick: () -> Unit) {
    Box(
        modifier = Modifier
            .clip(CircleShape)
            .background(if (selected) Color.White else Color.Transparent)
            .clickable { onClick() }
            .padding(horizontal = 18.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
            color = if (selected) Color(0xFF1B1B1D) else Color.White.copy(alpha = 0.85f)
        )
    }
}
