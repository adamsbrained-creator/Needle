/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.features.streaming.data.repository

import android.content.Context
import android.util.Log
import app.needle.player.core.domain.model.AlbumItem
import app.needle.player.core.domain.model.ArtistItem
import app.needle.player.core.domain.model.PlayableItem
import app.needle.player.core.domain.model.PlaylistItem
import app.needle.player.core.domain.model.SourceType
import app.needle.player.core.utils.NetworkUtils
import app.needle.player.features.streaming.data.provider.JellyfinApiClient
import app.needle.player.features.streaming.data.provider.ProviderConnectionResult
import app.needle.player.features.streaming.data.provider.ProviderAlbum
import app.needle.player.features.streaming.data.provider.ProviderArtist
import app.needle.player.features.streaming.data.provider.ProviderPlaylist
import app.needle.player.features.streaming.data.provider.ProviderSong
import app.needle.player.features.streaming.data.provider.SubsonicApiClient
import app.needle.player.features.streaming.data.provider.UserTrustManager
import app.needle.player.features.streaming.domain.model.BrowseCategory
import app.needle.player.features.streaming.domain.model.StreamingAlbum
import app.needle.player.features.streaming.domain.model.StreamingArtist
import app.needle.player.features.streaming.domain.model.StreamingPlaylist
import app.needle.player.features.streaming.domain.model.StreamingServiceId
import app.needle.player.features.streaming.domain.model.StreamingSong
import app.needle.player.features.streaming.domain.repository.StreamingMusicRepository
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.LyricsData
import app.needle.player.network.NetworkClient
import app.needle.player.network.DeezerApiService
import android.net.Uri
import kotlinx.coroutines.flow.Flow
import app.needle.player.util.ArtistSeparator
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.flow.drop

/**
 * Data model for persisting the streaming catalog to disk.
 */
data class StreamingCatalogCache(
    val serviceId: String,
    val songs: List<StreamingSong> = emptyList(),
    val albums: List<StreamingAlbum> = emptyList(),
    val artists: List<StreamingArtist> = emptyList(),
    val playlists: List<StreamingPlaylist> = emptyList(),
    val likedSongIds: List<String> = emptyList(),
    val lastSyncTimestamp: Long = 0L,
    /** Server library marker the songs were fetched under, or null if not known to be current. */
    val libraryMarker: String? = null
)

/**
 * Provider-backed implementation used by Rhythm GO mode.
 */
class StreamingMusicRepositoryImpl(
    private val context: Context
) : StreamingMusicRepository {

    data class ServiceConnectionInfo(
        val displayName: String,
        val serverUrl: String
    )

    private val appSettings = AppSettings.getInstance(context)

    private val subsonicClient = SubsonicApiClient(context)
    private val jellyfinClient = JellyfinApiClient(context)

    private val songsFlow = MutableStateFlow<List<PlayableItem>>(emptyList())
    private val albumsFlow = MutableStateFlow<List<AlbumItem>>(emptyList())
    private val providerAlbumsFlow = MutableStateFlow<List<StreamingAlbum>>(emptyList())  // Keep provider albums separate
    private val artistsFlow = MutableStateFlow<List<ArtistItem>>(emptyList())
    private val playlistsFlow = MutableStateFlow<List<PlaylistItem>>(emptyList())

    private val likedSongsFlow = MutableStateFlow<List<StreamingSong>>(emptyList())
    private val followedArtistsFlow = MutableStateFlow<List<StreamingArtist>>(emptyList())
    private val savedAlbumsFlow = MutableStateFlow<List<StreamingAlbum>>(emptyList())
    private val downloadedSongsFlow = MutableStateFlow<List<StreamingSong>>(emptyList())

    private val likedSongIds = linkedSetOf<String>()
    private val followedArtistIds = linkedSetOf<String>()
    private val savedAlbumIds = linkedSetOf<String>()
    private val followedPlaylistIds = linkedSetOf<String>()

    private val songCache = LinkedHashMap<String, StreamingSong>()
    // Starred songs from the provider (Subsonic getStarred2), so liked songs outside the synced
    // catalog still show and play.
    private val starredSongCache = LinkedHashMap<String, StreamingSong>()
    // Read from Default/IO dispatchers (catalog grouping, Deezer enrichment) and written from
    // several coroutines, so it must be thread-safe.
    private val artistArtworkCache = java.util.concurrent.ConcurrentHashMap<String, String>()
    private val providerAlbumCache = LinkedHashMap<String, StreamingAlbum>()

    private val downloadDirectory by lazy {
        java.io.File(context.filesDir, "streaming_downloads").apply {
            if (!exists()) {
                mkdirs()
            }
        }
    }

    // Deezer artist-image lookups: cached (memory + disk, with TTL) so each artist is looked up
    // once rather than on every catalog replace/merge; one enrichment pass runs at a time.
    private val deezerArtistImageCache by lazy {
        DeezerArtistImageCache(java.io.File(context.cacheDir, "deezer_artist_images.json"))
    }
    private val deezerEnrichmentMutex = Mutex()
    @Volatile
    private var artistEnrichmentJob: Job? = null

    private val downloadedSongsMap = LinkedHashMap<String, StreamingSong>()
    private val gson = com.google.gson.Gson()
    private val repositoryScope = CoroutineScope(Dispatchers.IO + SupervisorJob())
    private val catalogCacheWriter = CatalogCacheWriter()

    /**
     * A sync or start-up requests several saves within seconds (catalog, liked songs, playlists,
     * artist images); each rewrites the whole cache, tens of MB for a large library. Merge them.
     */
    private val catalogSaveCoalescer = SaveCoalescer(repositoryScope, delayMs = 3_000L)

    /** The catalog cache is loaded on IO, never where the repository is created (main thread). */
    private val initialCatalogLoad: BackgroundLoad

    /**
     * One catalog sync at a time: several triggers (start-up, network changes, screens) can
     * request one together, and a request that arrives during a sync joins it.
     */
    private val catalogSync = SingleFlight<List<StreamingSong>>()

    /** The cold-start library change check ([isCatalogOutdated]) runs once per process. */
    private val coldStartCatalogCheck = OnceGate()

    /** Skips rewriting the catalog cache when its content did not change. */
    private val catalogSaveFilter = CatalogSaveFilter()

    /**
     * Server library marker ([SubsonicApiClient.getLibraryMarker]) of the catalog in memory, or
     * null if that catalog is not known to match the server (partial fetch, scan running, etc.).
     */
    @Volatile
    private var catalogLibraryMarker: String? = null

    init {
        loadDownloadedSongsIndex()
        // Started here, once the fields the load uses are initialized.
        initialCatalogLoad = BackgroundLoad(repositoryScope) { loadCatalogCacheForActiveService() }
        repositoryScope.launch {
            initialCatalogLoad.await()
            // The current service was just loaded; reload only when it changes.
            appSettings.streamingService.drop(1).collect { serviceId ->
                loadCatalogCacheForActiveService(normalizeServiceId(serviceId))
            }
        }
    }

    override suspend fun awaitCatalogCacheLoaded() = initialCatalogLoad.await()

    private fun loadDownloadedSongsIndex() {
        try {
            val indexFile = java.io.File(downloadDirectory, "downloaded_songs.json")
            if (indexFile.exists()) {
                val json = indexFile.readText()
                val type = object : com.google.gson.reflect.TypeToken<List<StreamingSong>>() {}.type
                val list: List<StreamingSong> = gson.fromJson(json, type) ?: emptyList()
                downloadedSongsMap.clear()
                val reconciledList = mutableListOf<StreamingSong>()
                list.forEach { song ->
                    val file = getDownloadFile(song.id)
                    if (file.exists() && file.length() > 0) {
                        val safeSongId = song.id.replace(":", "_").replace("/", "_").replace("\\", "_")
                        val songArtFile = java.io.File(downloadDirectory, "${safeSongId}_art.jpg")
                        val safeAlbumKey = (song.albumId ?: "${song.artist}_${song.album}")
                            .replace(":", "_").replace("/", "_").replace("\\", "_").replace(" ", "_").lowercase()
                        val albumArtFile = java.io.File(downloadDirectory, "${safeAlbumKey}_album_art.jpg")

                        val resolvedArtworkUri = when {
                            albumArtFile.exists() && albumArtFile.length() > 0 -> Uri.fromFile(albumArtFile).toString()
                            songArtFile.exists() && songArtFile.length() > 0 -> Uri.fromFile(songArtFile).toString()
                            song.artworkUri?.startsWith("file:") == true -> song.artworkUri
                            else -> song.artworkUri
                        }

                        val localSong = song.copy(
                            streamingUrl = Uri.fromFile(file).toString(),
                            artworkUri = resolvedArtworkUri
                        )
                        downloadedSongsMap[song.id] = localSong
                        reconciledList.add(localSong)
                    }
                }
                downloadedSongsFlow.value = reconciledList
                if (reconciledList.size != list.size) {
                    saveDownloadedSongsIndex()
                }
            } else {
                downloadedSongsMap.clear()
                downloadedSongsFlow.value = emptyList()
            }
        } catch (e: Exception) {
            Log.e("StreamingMusicRepo", "Error loading downloaded songs index", e)
        }
    }

    private fun saveDownloadedSongsIndex() {
        val list = downloadedSongsMap.values.toList()
        downloadedSongsFlow.value = list
        try {
            val indexFile = java.io.File(downloadDirectory, "downloaded_songs.json")
            val json = gson.toJson(list)
            indexFile.writeText(json)
        } catch (e: Exception) {
            Log.e("StreamingMusicRepo", "Error saving downloaded songs index", e)
        }
    }

    private val audioExtensions = listOf(".mp3", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wav", ".wma", ".webm")

    fun getDownloadFile(songId: String, extension: String = ".mp3"): java.io.File {
        val safeName = songId.replace(":", "_").replace("/", "_").replace("\\", "_")
        val ext = if (extension.startsWith(".")) extension else ".$extension"
        val exactFile = java.io.File(downloadDirectory, "$safeName$ext")
        if (exactFile.exists() && exactFile.length() > 0) return exactFile

        for (candidateExt in audioExtensions) {
            val candidate = java.io.File(downloadDirectory, "$safeName$candidateExt")
            if (candidate.exists() && candidate.length() > 0) {
                return candidate
            }
        }
        return exactFile
    }

    private fun extractExtension(contentDisposition: String?, contentType: String?): String {
        if (!contentDisposition.isNullOrBlank()) {
            val filenameMatch = Regex("""filename\*?=['"]?(?:UTF-\d['"]*)?([^'";\n]+)['"]?""", RegexOption.IGNORE_CASE)
                .find(contentDisposition)
            val filename = filenameMatch?.groupValues?.get(1)?.trim()
            if (!filename.isNullOrBlank() && filename.contains(".")) {
                val ext = "." + filename.substringAfterLast(".").lowercase()
                if (ext in audioExtensions) return ext
            }
        }
        if (!contentType.isNullOrBlank()) {
            val mime = contentType.substringBefore(";").trim().lowercase()
            return when (mime) {
                "audio/flac", "audio/x-flac" -> ".flac"
                "audio/mp4", "audio/x-m4a", "audio/m4a", "audio/aac", "audio/x-aac" -> ".m4a"
                "audio/ogg", "audio/vorbis", "application/ogg" -> ".ogg"
                "audio/opus" -> ".opus"
                "audio/wav", "audio/x-wav", "audio/wave" -> ".wav"
                "audio/webm" -> ".webm"
                "audio/mpeg", "audio/mp3" -> ".mp3"
                else -> ".mp3"
            }
        }
        return ".mp3"
    }

    /**
     * The catalog cache stores Subsonic stream and cover URLs as unsigned references and signs
     * them again with the current credentials when loading (see [CatalogCacheCodec]).
     */
    private fun catalogCacheCodec(serviceId: String): CatalogCacheCodec {
        if (serviceId != StreamingServiceId.SUBSONIC) return CatalogCacheCodec()
        return CatalogCacheCodec(object : CatalogUrlRefs {
            override fun toRef(url: String): String? = subsonicClient.toUrlRef(url)
            override fun resolver(): (String) -> String? = subsonicClient.urlRefResolver()
        })
    }

    fun getCatalogCacheFile(serviceId: String): java.io.File {
        return java.io.File(context.filesDir, "streaming_catalog_${serviceId}.json")
    }

    /** Progress of an interrupted full library fetch (see [ResumableLibraryFetch]). */
    private fun getLibraryFetchCheckpointDir(serviceId: String): java.io.File {
        return java.io.File(context.filesDir, "streaming_catalog_${serviceId}.partial")
    }

    private fun loadCatalogCacheForActiveService(targetServiceId: String? = null) {
        try {
            val serviceId = targetServiceId ?: activeServiceId()
            catalogLibraryMarker = null
            val cacheFile = getCatalogCacheFile(serviceId)
            if (!cacheFile.exists()) return

            val cache = catalogCacheCodec(serviceId).readFile(cacheFile) ?: return
            if (cache.serviceId != serviceId) return

            if (cache.songs.isNotEmpty()) {
                songCache.clear()
                cache.songs.forEach { song ->
                    songCache[song.id] = song
                }
                songsFlow.value = cache.songs
                catalogLibraryMarker = cache.libraryMarker
                catalogSaveFilter.remember(cache)

                if (cache.albums.isNotEmpty()) {
                    providerAlbumCache.clear()
                    cache.albums.forEach { album ->
                        providerAlbumCache[album.id] = album
                    }
                    providerAlbumsFlow.value = cache.albums
                    albumsFlow.value = cache.albums
                } else {
                    albumsFlow.value = buildAlbumItems(serviceId, cache.songs)
                }

                if (cache.artists.isNotEmpty()) {
                    artistsFlow.value = cache.artists
                } else {
                    artistsFlow.value = buildArtistItems(serviceId, cache.songs)
                }

                if (cache.playlists.isNotEmpty()) {
                    playlistsFlow.value = cache.playlists
                }

                if (cache.likedSongIds.isNotEmpty()) {
                    likedSongIds.clear()
                    likedSongIds.addAll(cache.likedSongIds)
                }

                updateLikedSongsFlow()
                updateSavedAlbumsFlow()
                updateFollowedArtistsFlow()
                Log.d("StreamingMusicRepo", "Loaded cached catalog for $serviceId with ${cache.songs.size} songs")
            }
        } catch (e: Exception) {
            Log.e("StreamingMusicRepo", "Error loading streaming catalog cache", e)
        }
    }

    private fun saveCatalogCache(serviceId: String = activeServiceId()) {
        if (appSettings.offlineMode.value) return
        catalogSaveCoalescer.request(serviceId) {
            try {
                var songCount = 0
                // Saves run one at a time and snapshot the catalog inside the writer's lock,
                // so overlapping saves cannot corrupt the file and the last one wins.
                val saved = catalogCacheWriter.write(getCatalogCacheFile(serviceId), snapshot = {
                    val currentSongs = songsFlow.value.filterIsInstance<StreamingSong>()
                    if (currentSongs.isEmpty()) return@write null

                    val currentAlbums = (providerAlbumsFlow.value.ifEmpty { albumsFlow.value })
                        .filterIsInstance<StreamingAlbum>()
                    val currentArtists = artistsFlow.value.filterIsInstance<StreamingArtist>()
                    val currentPlaylists = playlistsFlow.value.filterIsInstance<StreamingPlaylist>()
                    val currentLikedIds = likedSongIds.toList()

                    val cache = StreamingCatalogCache(
                        serviceId = serviceId,
                        songs = currentSongs,
                        albums = currentAlbums,
                        artists = currentArtists,
                        playlists = currentPlaylists,
                        likedSongIds = currentLikedIds,
                        lastSyncTimestamp = System.currentTimeMillis(),
                        libraryMarker = catalogLibraryMarker
                    )
                    // Syncs that change nothing (library unchanged, same playlists and artists)
                    // would otherwise rewrite the whole multi-megabyte cache several times each.
                    if (!catalogSaveFilter.hasChanged(cache)) return@write null
                    songCount = currentSongs.size
                    cache
                }) { cache, out ->
                    catalogCacheCodec(serviceId).write(out, cache)
                    catalogSaveFilter.remember(cache)
                }
                if (saved) {
                    Log.d("StreamingMusicRepo", "Saved streaming catalog cache for $serviceId ($songCount songs)")
                }
            } catch (e: Exception) {
                Log.e("StreamingMusicRepo", "Error saving streaming catalog cache for $serviceId", e)
            }
        }
    }

    override fun hasCachedCatalog(serviceId: String?): Boolean {
        val targetService = serviceId ?: activeServiceId()
        if (songsFlow.value.isNotEmpty() && activeServiceId() == targetService) {
            return true
        }
        val cacheFile = getCatalogCacheFile(targetService)
        return cacheFile.exists() && cacheFile.length() > 0
    }

    override val currentService: SourceType
        get() = serviceToSourceType(activeServiceId())

    suspend fun connect(
        serviceId: String,
        serverUrl: String,
        username: String,
        password: String,
        saveCredentials: Boolean = true
    ): ServiceConnectionInfo {
        val normalizedService = normalizeServiceId(serviceId)

        val result = when (normalizedService) {
            StreamingServiceId.SUBSONIC -> subsonicClient.login(serverUrl, username, password, saveCredentials)
            StreamingServiceId.JELLYFIN -> jellyfinClient.login(serverUrl, username, password, saveCredentials)
            else -> Result.failure(IllegalArgumentException("Unsupported streaming service"))
        }

        val connection = result.getOrElse { throw it }
        // A new login may be another account or server: never resume its predecessor's fetch.
        ResumableLibraryFetch.discard(getLibraryFetchCheckpointDir(normalizedService))
        return ServiceConnectionInfo(
            displayName = connection.displayName,
            serverUrl = connection.serverUrl
        )
    }

    suspend fun disconnect(serviceId: String) {
        val normalized = normalizeServiceId(serviceId)
        when (normalized) {
            StreamingServiceId.SUBSONIC -> subsonicClient.logout()
            StreamingServiceId.JELLYFIN -> jellyfinClient.logout()
        }

        try {
            catalogCacheWriter.delete(getCatalogCacheFile(normalized))
            catalogSaveFilter.remember(null)
            ResumableLibraryFetch.discard(getLibraryFetchCheckpointDir(normalized))
        } catch (e: Exception) {
            Log.e("StreamingMusicRepo", "Error deleting catalog cache on disconnect", e)
        }

        if (activeServiceId() == normalized) {
            clearInMemoryCatalog()
        }
    }

    fun isServiceConnected(serviceId: String): Boolean {
        return when (normalizeServiceId(serviceId)) {
            StreamingServiceId.SUBSONIC -> subsonicClient.isConnected()
            StreamingServiceId.JELLYFIN -> jellyfinClient.isConnected()
            else -> false
        }
    }

    override suspend fun isAuthenticated(): Boolean {
        return isServiceConnected(activeServiceId())
    }

    override suspend fun authenticate(): Boolean {
        return when (activeServiceId()) {
            StreamingServiceId.SUBSONIC -> subsonicClient.ping().isSuccess
            StreamingServiceId.JELLYFIN -> jellyfinClient.ping().isSuccess
            else -> false
        }
    }

    override suspend fun logout() {
        disconnect(activeServiceId())
    }

    override suspend fun getRecommendations(limit: Int): List<StreamingSong> {
        if (appSettings.offlineMode.value) {
            return downloadedSongsMap.values.shuffled().take(limit.coerceAtLeast(1))
        }
        val activePrefix = "${activeServiceId()}::"
        return songCache.values
            .asSequence()
            .filter { it.id.startsWith(activePrefix) }
            .take(limit.coerceAtLeast(1))
            .toList()
    }

    override suspend fun getNewReleases(limit: Int): List<StreamingAlbum> {
        if (appSettings.offlineMode.value) {
            return deriveAlbumsFromSongs(downloadedSongsMap.values.toList(), limit)
        }
        if (!isServiceConnected(activeServiceId())) {
            return emptyList()
        }
        
        return when (activeServiceId()) {
            StreamingServiceId.SUBSONIC -> {
                subsonicClient.getAlbumList("newest", limit).getOrNull() ?: emptyList()
            }
            StreamingServiceId.JELLYFIN -> {
                jellyfinClient.getAlbumList("newest", limit).getOrNull() ?: emptyList()
            }
            else -> emptyList()
        }.mapNotNull { providerAlbum ->
            try {
                mapProviderAlbum(activeServiceId(), providerAlbum)
            } catch (e: Exception) {
                null
            }
        }.let { albums ->
            enrichAlbumsWithTrackCounts(activeServiceId(), albums)
        }
    }

    override suspend fun getFeaturedPlaylists(limit: Int): List<StreamingPlaylist> {
        return playlistsFlow.value
            .filterIsInstance<StreamingPlaylist>()
            .take(limit.coerceAtLeast(1))
    }

    override suspend fun getBrowseCategories(): List<BrowseCategory> {
        return listOf(
            BrowseCategory(id = "recent", name = "Recent"),
            BrowseCategory(id = "favorites", name = "Favorites"),
            BrowseCategory(id = "library", name = "Library")
        )
    }

    override suspend fun getCategoryPlaylists(categoryId: String, limit: Int): List<StreamingPlaylist> {
        val normalizedCategory = categoryId.trim().lowercase()
        val safeLimit = limit.coerceAtLeast(1)
        val playlists = playlistsFlow.value.filterIsInstance<StreamingPlaylist>()

        return when (normalizedCategory) {
            "recent", "library" -> playlists.take(safeLimit)
            "favorites" -> playlists.filter { it.id in followedPlaylistIds }.take(safeLimit)
            else -> playlists.filter {
                it.name.contains(categoryId, ignoreCase = true) ||
                    (it.description?.contains(categoryId, ignoreCase = true) == true)
            }.take(safeLimit).ifEmpty { playlists.take(safeLimit) }
        }
    }

    override suspend fun getTopCharts(limit: Int): List<StreamingSong> {
        return getRecommendations(limit)
    }

    override fun getLikedSongs(): Flow<List<StreamingSong>> = likedSongsFlow.asStateFlow()

    override suspend fun likeSong(songId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decoded = decodeSongId(songId)
        if (decoded != null && isServiceConnected(decoded.first)) {
            val (serviceId, providerId) = decoded
            val success = when (serviceId) {
                StreamingServiceId.SUBSONIC -> subsonicClient.markFavorite(providerId, true).isSuccess
                StreamingServiceId.JELLYFIN -> jellyfinClient.markFavorite(providerId, true).isSuccess
                else -> false
            }
            if (!success) return false
        }
        
        likedSongIds.add(songId)
        updateLikedSongsFlow()
        return true
    }

    override suspend fun unlikeSong(songId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decoded = decodeSongId(songId)
        if (decoded != null && isServiceConnected(decoded.first)) {
            val (serviceId, providerId) = decoded
            val success = when (serviceId) {
                StreamingServiceId.SUBSONIC -> subsonicClient.markFavorite(providerId, false).isSuccess
                StreamingServiceId.JELLYFIN -> jellyfinClient.markFavorite(providerId, false).isSuccess
                else -> false
            }
            if (!success) return false
        }
        
        val removed = likedSongIds.remove(songId)
        updateLikedSongsFlow()
        return removed
    }

    override suspend fun isSongLiked(songId: String): Boolean = likedSongIds.contains(songId)

    override suspend fun followArtist(artistId: String): Boolean {
        followedArtistIds.add(artistId)
        updateFollowedArtistsFlow()
        return true
    }

    override suspend fun unfollowArtist(artistId: String): Boolean {
        val removed = followedArtistIds.remove(artistId)
        updateFollowedArtistsFlow()
        return removed
    }

    override suspend fun isArtistFollowed(artistId: String): Boolean = followedArtistIds.contains(artistId)

    override fun getFollowedArtists(): Flow<List<StreamingArtist>> = followedArtistsFlow.asStateFlow()

    override suspend fun saveAlbum(albumId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decoded = decodeAlbumId(albumId)
        if (decoded != null && isServiceConnected(decoded.serviceId)) {
            val serviceId = decoded.serviceId
            var providerId = decoded.providerAlbumId
            if (providerId.isNullOrBlank()) {
                val matchedAlbum = albumsFlow.value.firstOrNull { it.id == albumId } as? StreamingAlbum
                providerId = matchedAlbum?.externalId
            }
            if (!providerId.isNullOrBlank()) {
                val success = when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.markFavorite(providerId, true).isSuccess
                    StreamingServiceId.JELLYFIN -> jellyfinClient.markFavorite(providerId, true).isSuccess
                    else -> false
                }
                if (!success) return false
            }
        }

        savedAlbumIds.add(albumId)
        updateSavedAlbumsFlow()
        return true
    }

    override suspend fun unsaveAlbum(albumId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decoded = decodeAlbumId(albumId)
        if (decoded != null && isServiceConnected(decoded.serviceId)) {
            val serviceId = decoded.serviceId
            var providerId = decoded.providerAlbumId
            if (providerId.isNullOrBlank()) {
                val matchedAlbum = albumsFlow.value.firstOrNull { it.id == albumId } as? StreamingAlbum
                providerId = matchedAlbum?.externalId
            }
            if (!providerId.isNullOrBlank()) {
                val success = when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.markFavorite(providerId, false).isSuccess
                    StreamingServiceId.JELLYFIN -> jellyfinClient.markFavorite(providerId, false).isSuccess
                    else -> false
                }
                if (!success) return false
            }
        }

        val removed = savedAlbumIds.remove(albumId)
        updateSavedAlbumsFlow()
        return removed
    }

    override fun getSavedAlbums(): Flow<List<StreamingAlbum>> = savedAlbumsFlow.asStateFlow()

    override suspend fun followPlaylist(playlistId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val playlist = getPlaylistById(playlistId) ?: return false
        followedPlaylistIds.add(playlist.id)
        return true
    }

    override suspend fun unfollowPlaylist(playlistId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        return deletePlaylist(playlistId)
    }

    override suspend fun renamePlaylist(playlistId: String, newName: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decodedPlaylist = decodePlaylistId(playlistId) ?: return false
        val serviceId = decodedPlaylist.first
        val providerPlaylistId = decodedPlaylist.second

        if (!isServiceConnected(serviceId)) {
            return false
        }

        val trimmedName = newName.trim()
        if (providerPlaylistId.isBlank() || trimmedName.isBlank()) {
            return false
        }

        return when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.updatePlaylist(providerPlaylistId, name = trimmedName).isSuccess
            StreamingServiceId.JELLYFIN -> jellyfinClient.updatePlaylist(providerPlaylistId, name = trimmedName).isSuccess
            else -> false
        }.also { success ->
            if (success) {
                syncPlaylists()
            }
        }
    }

    override suspend fun deletePlaylist(playlistId: String): Boolean {
        if (appSettings.offlineMode.value) return false
        val decodedPlaylist = decodePlaylistId(playlistId) ?: return false
        val serviceId = decodedPlaylist.first
        val providerPlaylistId = decodedPlaylist.second

        if (!isServiceConnected(serviceId)) {
            return false
        }

        return when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.deletePlaylist(providerPlaylistId).isSuccess
            StreamingServiceId.JELLYFIN -> jellyfinClient.deletePlaylist(providerPlaylistId).isSuccess
            else -> false
        }.also { success ->
            if (success) {
                syncPlaylists()
            }
        }
    }

    override suspend fun createPlaylist(
        name: String,
        description: String?,
        isPublic: Boolean
    ): StreamingPlaylist? {
        if (appSettings.offlineMode.value) return null
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            return null
        }

        val createdPlaylist = when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.createPlaylist(
                name = name,
                songIds = emptyList(),
                description = description,
                isPublic = isPublic
            ).getOrNull()

            StreamingServiceId.SUBSONIC -> subsonicClient.createPlaylist(
                name = name,
                songIds = emptyList()
            ).getOrNull()
            else -> null
        } ?: return null

        val mappedPlaylist = mapProviderPlaylist(serviceId, createdPlaylist)
        playlistsFlow.value = (playlistsFlow.value.filterNot { it.id == mappedPlaylist.id } + mappedPlaylist)
            .sortedBy { it.name.lowercase() }
        return mappedPlaylist
    }

    override suspend fun addSongsToPlaylist(playlistId: String, songIds: List<String>): Boolean {
        if (appSettings.offlineMode.value) return false
        val decodedPlaylist = decodePlaylistId(playlistId) ?: return false
        val serviceId = decodedPlaylist.first
        val providerPlaylistId = decodedPlaylist.second
        val providerSongIds = songIds.mapNotNull { decodeSongId(it)?.second ?: it }.filter { it.isNotBlank() }

        if (providerSongIds.isEmpty() || !isServiceConnected(serviceId)) {
            return false
        }

        val success = when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.addSongsToPlaylist(providerPlaylistId, providerSongIds).isSuccess
            StreamingServiceId.SUBSONIC -> subsonicClient.updatePlaylist(providerPlaylistId, songIdsToAdd = providerSongIds).isSuccess
            else -> false
        }

        if (success) {
            syncPlaylists()
        }

        return success
    }

    override suspend fun removeSongsFromPlaylist(playlistId: String, songIds: List<String>): Boolean {
        if (appSettings.offlineMode.value) return false
        val decodedPlaylist = decodePlaylistId(playlistId) ?: return false
        val serviceId = decodedPlaylist.first
        val providerPlaylistId = decodedPlaylist.second
        val providerSongIds = songIds.mapNotNull { decodeSongId(it)?.second ?: it }.filter { it.isNotBlank() }

        if (providerSongIds.isEmpty() || !isServiceConnected(serviceId)) {
            return false
        }

        val success = when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.removeSongsFromPlaylist(providerPlaylistId, providerSongIds).isSuccess
            StreamingServiceId.SUBSONIC -> {
                val songsResult = subsonicClient.getPlaylistSongs(providerPlaylistId, limit = 1000)
                val songs = songsResult.getOrElse { emptyList() }
                val indexesToRemove = providerSongIds.mapNotNull { id -> 
                    val index = songs.indexOfFirst { it.providerId == id }
                    if (index >= 0) index else null
                }
                if (indexesToRemove.isNotEmpty()) {
                    subsonicClient.updatePlaylist(providerPlaylistId, songIndexesToRemove = indexesToRemove).isSuccess
                } else false
            }
            else -> false
        }

        if (success) {
            syncPlaylists()
        }

        return success
    }

    override suspend fun getStreamingUrl(songId: String): String? {
        val (serviceId, providerId) = decodeSongId(songId) ?: return null
        
        // 1. If downloaded, return the local downloaded file URI
        val localFile = getDownloadFile(songId)
        if (localFile.exists() && localFile.length() > 0) {
            return Uri.fromFile(localFile).toString()
        }

        // 2. Check if offline mode is enabled - fallback to cache or return null
        if (appSettings.offlineMode.value) {
            // In offline mode, only allow cached/downloaded files
            // If not downloaded, but we have a previously cached stream URL, return it
            val cached = songCache[songId]
            return cached?.streamingUrl // May be null if not previously cached
        }

        // Check if streaming is allowed by network settings
        val allowCellular = appSettings.allowCellularStreaming.value
        if (!NetworkUtils.canStream(context, allowCellular)) {
            return null // Network conditions don't allow streaming
        }
        
        // Check if service is connected
        if (!isServiceConnected(serviceId)) {
            return null // Provider is not connected
        }
        
        val bitrate = desiredBitrateKbps()

        val resolved = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.buildStreamUrl(providerId, bitrate)
            StreamingServiceId.JELLYFIN -> jellyfinClient.buildStreamUrl(providerId, bitrate)
            else -> null
        }

        if (!resolved.isNullOrBlank()) {
            val existing = songCache[songId]
            if (existing != null) {
                songCache[songId] = existing.copy(streamingUrl = resolved)
            }
        }

        return resolved
    }

    override suspend fun reportPlaybackStart(songId: String): Boolean {
        val decoded = decodeSongId(songId) ?: return false
        val (serviceId, providerId) = decoded
        if (!isServiceConnected(serviceId)) return false
        
        return when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.reportPlaybackStart(providerId).isSuccess
            StreamingServiceId.SUBSONIC -> true // Subsonic typically only scrobbles during/at the end
            else -> false
        }
    }

    override suspend fun reportPlaybackStop(songId: String, positionMs: Long): Boolean {
        val decoded = decodeSongId(songId) ?: return false
        val (serviceId, providerId) = decoded
        if (!isServiceConnected(serviceId)) return false
        
        return when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.reportPlaybackStop(providerId, positionMs * 10_000L).isSuccess // Convert ms to ticks
            StreamingServiceId.SUBSONIC -> subsonicClient.scrobble(providerId, true).isSuccess
            else -> false
        }
    }

    override suspend fun reportPlaybackProgress(songId: String, positionMs: Long, isPaused: Boolean): Boolean {
        val decoded = decodeSongId(songId) ?: return false
        val (serviceId, providerId) = decoded
        if (!isServiceConnected(serviceId)) return false

        return when (serviceId) {
            StreamingServiceId.JELLYFIN -> jellyfinClient.reportPlaybackProgress(providerId, positionMs * 10_000L, isPaused).isSuccess
            StreamingServiceId.SUBSONIC -> subsonicClient.reportPlaybackProgress(providerId, positionMs, isPaused).isSuccess
            else -> false
        }
    }

    /**
     * Invalidate cached streaming URL for a specific song.
     */
    fun invalidateStreamingUrlCache(songId: String) {
        songCache.remove(songId)
    }

    /**
     * Clear all cached streaming URLs so subsequent requests re-resolve.
     */
    fun invalidateAllStreamingUrlCache() {
        songCache.clear()
    }

    override suspend fun getRelatedTracks(songId: String, limit: Int): List<StreamingSong> {
        if (appSettings.offlineMode.value) {
            val song = downloadedSongsMap[songId] ?: return emptyList()
            return downloadedSongsMap.values.filter { 
                it.artist.equals(song.artist, ignoreCase = true) && it.id != song.id 
            }.take(limit)
        }
        val decodedSong = decodeSongId(songId) ?: return emptyList()
        val serviceId = decodedSong.first
        val providerTracks = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.getRelatedTracks(decodedSong.second, limit)
            StreamingServiceId.JELLYFIN -> jellyfinClient.getRelatedTracks(decodedSong.second, limit)
            else -> Result.success(emptyList())
        }.getOrElse { emptyList() }

        return providerTracks.map { mapProviderSong(serviceId, it) }
            .take(limit.coerceAtLeast(1))
    }

    override suspend fun getArtistTopTracks(artistId: String, limit: Int): List<StreamingSong> {
        val artistName = extractArtistNameFromId(artistId)
        if (artistName.isBlank()) {
            return emptyList()
        }

        val isOnline = NetworkUtils.isNetworkAvailable(context) && !appSettings.offlineMode.value
        if (isOnline) {
            val serviceId = artistId.substringBefore("::", activeServiceId())
            if (isServiceConnected(serviceId)) {
                try {
                    val providerTracksResult = when (serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.getArtistTopTracks(artistName, limit)
                        StreamingServiceId.JELLYFIN -> jellyfinClient.getArtistTopTracks(artistName, limit)
                        else -> Result.success(emptyList())
                    }
                    val providerTracks = providerTracksResult.getOrNull()
                    if (providerTracks != null && providerTracks.isNotEmpty()) {
                        return providerTracks.map { mapProviderSong(serviceId, it) }.take(limit.coerceAtLeast(1))
                    }
                } catch (e: Exception) {
                    Log.w("StreamingMusicRepo", "Network getArtistTopTracks failed, falling back to offline", e)
                }
            }
        }

        // Offline / Failure Fallback:
        return cachedSongsForArtist(artistName).take(limit.coerceAtLeast(1))
    }

    override suspend fun getAlbumSongs(albumId: String): List<StreamingSong> {
        val decodedId = decodeAlbumId(albumId) ?: return emptyList()
        val providerAlbumId = decodedId.providerAlbumId
        val isOnline = NetworkUtils.isNetworkAvailable(context) && !appSettings.offlineMode.value
        
        var resolvedProviderAlbumId = providerAlbumId
        if (resolvedProviderAlbumId == null && isOnline) {
            val albumTitle = decodedId.title
            val albumArtist = decodedId.artist
            if (albumTitle.isNotBlank()) {
                val searchResults = when (decodedId.serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.searchAlbums(albumTitle).getOrNull()
                    StreamingServiceId.JELLYFIN -> jellyfinClient.searchAlbums(albumTitle).getOrNull()
                    else -> null
                }
                val matchedAlbum = searchResults?.firstOrNull {
                    it.title.equals(albumTitle, ignoreCase = true) &&
                    (albumArtist.isBlank() || it.artist.equals(albumArtist, ignoreCase = true))
                } ?: searchResults?.firstOrNull()
                if (matchedAlbum != null) {
                    resolvedProviderAlbumId = matchedAlbum.providerId
                }
            }
        }

        if (isOnline && resolvedProviderAlbumId != null) {
            try {
                val providerSongs = when (decodedId.serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.getAlbumSongs(resolvedProviderAlbumId).getOrNull()
                    StreamingServiceId.JELLYFIN -> jellyfinClient.getAlbumSongs(resolvedProviderAlbumId).getOrNull()
                    else -> null
                }
                if (!providerSongs.isNullOrEmpty()) {
                    return providerSongs.mapNotNull { providerSong ->
                        try {
                            mapProviderSong(decodedId.serviceId, providerSong)
                        } catch (e: Exception) {
                            null
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w("StreamingMusicRepo", "Network getAlbumSongs failed for album $albumId, falling back to offline", e)
            }
        }

        // Artist-track fallback: for singles / song-albums the server may not expose an album
        // object at all; query the artist's tracks and filter by album title instead.
        val albumTitle = decodedId.title
        val albumArtist = decodedId.artist
        if (isOnline && albumTitle.isNotBlank() && albumArtist.isNotBlank()) {
            try {
                val artistTracks = when (decodedId.serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.getArtistTopTracks(albumArtist, limit = 100).getOrNull()
                    StreamingServiceId.JELLYFIN -> jellyfinClient.getArtistTopTracks(albumArtist, limit = 100).getOrNull()
                    else -> null
                }
                if (!artistTracks.isNullOrEmpty()) {
                    val filtered = artistTracks
                        .filter { it.album.equals(albumTitle, ignoreCase = true) }
                        .map { mapProviderSong(decodedId.serviceId, it) }
                    if (filtered.isNotEmpty()) return filtered
                }
            } catch (e: Exception) {
                Log.w("StreamingMusicRepo", "Artist-track fallback failed for album $albumId", e)
            }
        }

        // Offline / Failure Fallback:
        // 1. Try matching exactly by albumId
        val matchesByAlbumId = downloadedSongsMap.values.filter { it.albumId == albumId }
        if (matchesByAlbumId.isNotEmpty()) {
            return matchesByAlbumId
        }
        
        // 2. Try matching by legacy title/artist
        if (albumTitle.isNotBlank()) {
            return downloadedSongsMap.values.filter {
                it.album.equals(albumTitle, ignoreCase = true) &&
                (it.albumArtist.equals(albumArtist, ignoreCase = true) || it.artist.equals(albumArtist, ignoreCase = true))
            }
        }
        
        return emptyList()
    }

    override suspend fun getArtistAlbums(artistId: String): List<StreamingAlbum> {
        val artistName = extractArtistNameFromId(artistId)
        if (artistName.isBlank()) return emptyList()
        
        val isOnline = NetworkUtils.isNetworkAvailable(context) && !appSettings.offlineMode.value
        if (isOnline) {
            val serviceId = activeServiceId()
            if (isServiceConnected(serviceId)) {
                try {
                    val providerResult = when (serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.getArtistAlbums(artistName)
                        StreamingServiceId.JELLYFIN -> jellyfinClient.getArtistAlbums(artistName)
                        else -> Result.success(emptyList())
                    }
                    val albums = providerResult.getOrNull()?.map { mapProviderAlbum(serviceId, it) }
                    if (albums != null) {
                        return enrichAlbumsWithTrackCounts(serviceId, albums)
                    }
                } catch (e: Exception) {
                    Log.w("StreamingMusicRepo", "Network getArtistAlbums failed, falling back to offline", e)
                }
            }
        }

        // Offline / Failure Fallback:
        val artistSongs = cachedSongsForArtist(artistName).ifEmpty {
            downloadedSongsMap.values.filter { it.artist.equals(artistName, ignoreCase = true) }
        }
        return deriveAlbumsFromSongs(artistSongs, 100)
    }
    
    private fun extractArtistNameFromId(artistId: String): String {
        // Handle multiple ID formats:
        // "JELLYFIN::artist::artist_name" -> "artist_name"
        if (artistId.contains("::")) {
            val parts = artistId.split("::") 
            if (parts.size >= 3 && parts[1] == "artist") {
                // Format: "JELLYFIN::artist::artist_name"
                return parts[2].replace("_", " ").trim()
            }
        }
        
        // "derived:JELLYFIN:artist:artist_name" -> "artist_name"
        if (artistId.contains(":artist:")) {
            val afterArtist = artistId.substringAfter(":artist:")
            return afterArtist.replace("_", " ").trim()
        }
        
        // Fallback: assume the whole ID is a name
        return artistId.replace("_", " ").trim()
    }

            private suspend fun resolveProviderArtistId(serviceId: String, artistName: String): String? {
                val providerArtists = when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.searchArtists(artistName, limit = 20)
                    StreamingServiceId.JELLYFIN -> jellyfinClient.searchArtists(artistName, limit = 20)
                    else -> Result.success(emptyList())
                }.getOrElse { emptyList() }

                val exactMatch = providerArtists.firstOrNull { it.name.equals(artistName, ignoreCase = true) }
                return (exactMatch ?: providerArtists.firstOrNull())?.providerId
            }

    override suspend fun getRelatedArtists(artistId: String, limit: Int): List<StreamingArtist> {
        if (appSettings.offlineMode.value) {
            return emptyList()
        }
        val artistName = extractArtistNameFromId(artistId)
        if (artistName.isBlank()) {
            return emptyList()
        }

        val serviceId = artistId.substringBefore("::", activeServiceId())
                val providerArtistId = resolveProviderArtistId(serviceId, artistName) ?: return emptyList()

        val providerArtists = when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.getRelatedArtists(providerArtistId, limit)
                    StreamingServiceId.JELLYFIN -> jellyfinClient.getRelatedArtists(providerArtistId, limit)
            else -> Result.success(emptyList())
        }.getOrElse { emptyList() }

                return mapProviderArtists(serviceId, providerArtists)
    }

    override suspend fun downloadSong(song: StreamingSong): Boolean {
        songCache[song.id] = song
        return downloadSong(song.id)
    }

    override suspend fun downloadSong(songId: String): Boolean = withContext(Dispatchers.IO) {
        if (isDownloaded(songId)) return@withContext true
        
        val (serviceId, providerId) = decodeSongId(songId) ?: return@withContext false
        
        val bitrate = desiredBitrateKbps()
        val primaryDownloadUrl = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.buildDownloadUrl(providerId, format = "raw")
            StreamingServiceId.JELLYFIN -> jellyfinClient.buildDownloadUrl(providerId)
            else -> null
        }
        val fallbackStreamUrl = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.buildStreamUrl(providerId, bitrate)
            StreamingServiceId.JELLYFIN -> jellyfinClient.buildStreamUrl(providerId, bitrate)
            else -> null
        }
        val targetUrl = primaryDownloadUrl ?: fallbackStreamUrl ?: return@withContext false

        var song = songCache[songId]
            ?: songsFlow.value.filterIsInstance<StreamingSong>().firstOrNull { it.id == songId }
            ?: likedSongsFlow.value.firstOrNull { it.id == songId }
            ?: downloadedSongsMap[songId]

        if (song == null) {
            song = (getSongById(songId) as? StreamingSong)
        }
        val finalSong = song ?: return@withContext false

        val client = UserTrustManager.buildUserTrustingHttpClientBuilder()
            .connectTimeout(15, java.util.concurrent.TimeUnit.SECONDS)
            .readTimeout(60, java.util.concurrent.TimeUnit.SECONDS)
            .build()

        fun buildRequest(url: String): okhttp3.Request {
            val reqBuilder = okhttp3.Request.Builder()
                .url(url)
                .header("User-Agent", "Rhythm/${app.needle.player.BuildConfig.VERSION_NAME} (Android)")
            if (serviceId == StreamingServiceId.JELLYFIN) {
                jellyfinClient.getAccessToken()?.let { token ->
                    reqBuilder.header("Authorization", "MediaBrowser Client=\"Rhythm\", Device=\"Rhythm Android\", DeviceId=\"rhythm-android-client\", Version=\"${app.needle.player.BuildConfig.VERSION_NAME}\", Token=\"$token\"")
                    reqBuilder.header("X-Emby-Token", token)
                }
            }
            return reqBuilder.build()
        }

        var downloadedFile: java.io.File? = null
        try {
            var response = client.newCall(buildRequest(targetUrl)).execute()
            if (!response.isSuccessful && primaryDownloadUrl != null && fallbackStreamUrl != null && targetUrl != fallbackStreamUrl) {
                response.close()
                response = client.newCall(buildRequest(fallbackStreamUrl)).execute()
            }

            if (!response.isSuccessful) {
                response.close()
                return@withContext false
            }

            val ext = extractExtension(response.header("Content-Disposition"), response.header("Content-Type"))
            val file = getDownloadFile(songId, ext)
            downloadedFile = file

            response.use { resp ->
                val body = resp.body
                body.byteStream().use { inputStream ->
                    file.outputStream().use { outputStream ->
                        inputStream.copyTo(outputStream)
                    }
                }
            }
            
            // 4. Download and cache the artwork if present and not a local file
            var localArtworkPath: String? = null
            var artworkUri = finalSong.artworkUri
            if (artworkUri.isNullOrBlank()) {
                val albumProviderId = finalSong.albumId?.let { decodeSongId(it)?.second }
                artworkUri = when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.buildCoverArtUrl(albumProviderId ?: providerId)
                    StreamingServiceId.JELLYFIN -> jellyfinClient.buildImageUrl(albumProviderId ?: providerId)
                    else -> null
                }
            }

            val safeSongId = songId.replace(":", "_").replace("/", "_").replace("\\", "_")
            val safeAlbumKey = (finalSong.albumId ?: "${finalSong.artist}_${finalSong.album}")
                .replace(":", "_").replace("/", "_").replace("\\", "_").replace(" ", "_").lowercase()
            val albumArtFile = java.io.File(downloadDirectory, "${safeAlbumKey}_album_art.jpg")
            val songArtFile = java.io.File(downloadDirectory, "${safeSongId}_art.jpg")

            if (albumArtFile.exists() && albumArtFile.length() > 0) {
                localArtworkPath = Uri.fromFile(albumArtFile).toString()
            } else if (songArtFile.exists() && songArtFile.length() > 0) {
                localArtworkPath = Uri.fromFile(songArtFile).toString()
            } else if (!artworkUri.isNullOrBlank() && (artworkUri.startsWith("http://") || artworkUri.startsWith("https://"))) {
                val artRequest = okhttp3.Request.Builder()
                    .url(artworkUri)
                    .header("User-Agent", "Rhythm/${app.needle.player.BuildConfig.VERSION_NAME} (Android)")
                    .build()
                try {
                    client.newCall(artRequest).execute().use { responseArt ->
                        if (responseArt.isSuccessful) {
                            responseArt.body.byteStream().use { artInput ->
                                albumArtFile.outputStream().use { artOutput ->
                                    artInput.copyTo(artOutput)
                                }
                            }
                            if (albumArtFile.exists() && albumArtFile.length() > 0) {
                                localArtworkPath = Uri.fromFile(albumArtFile).toString()
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e("StreamingMusicRepo", "Error downloading artwork for song $songId", e)
                }
            }

            if (localArtworkPath == null) {
                val existingLocalArt = downloadedSongsMap.values.firstOrNull {
                    (it.albumId == finalSong.albumId || it.album.equals(finalSong.album, ignoreCase = true)) &&
                    it.artworkUri?.startsWith("file:") == true
                }?.artworkUri
                if (existingLocalArt != null) {
                    localArtworkPath = existingLocalArt
                }
            }

            // 5. Update metadata index
            val localSongUrl = Uri.fromFile(file).toString()
            val downloadedSong = finalSong.copy(
                streamingUrl = localSongUrl,
                artworkUri = localArtworkPath ?: finalSong.artworkUri
            )
            
            downloadedSongsMap[songId] = downloadedSong
            saveDownloadedSongsIndex()
            true
        } catch (e: Exception) {
            Log.e("StreamingMusicRepo", "Error downloading song $songId", e)
            downloadedFile?.let { if (it.exists()) it.delete() }
            false
        }
    }

    override suspend fun removeDownload(songId: String): Boolean = withContext(Dispatchers.IO) {
        val file = getDownloadFile(songId)
        val deletedFile = if (file.exists()) file.delete() else true

        val safeSongId = songId.replace(":", "_").replace("/", "_").replace("\\", "_")
        for (candidateExt in audioExtensions) {
            val candidate = java.io.File(downloadDirectory, "$safeSongId$candidateExt")
            if (candidate.exists()) {
                candidate.delete()
            }
        }
        
        // Delete song specific artwork if exists
        val songArtFile = java.io.File(downloadDirectory, "${safeSongId}_art.jpg")
        if (songArtFile.exists()) {
            songArtFile.delete()
        }
        
        val removedSong = downloadedSongsMap.remove(songId)
        if (removedSong != null) {
            saveDownloadedSongsIndex()

            val safeAlbumKey = (removedSong.albumId ?: "${removedSong.artist}_${removedSong.album}")
                .replace(":", "_").replace("/", "_").replace("\\", "_").replace(" ", "_").lowercase()
            val anyRemainingInAlbum = downloadedSongsMap.values.any { other ->
                val otherAlbumKey = (other.albumId ?: "${other.artist}_${other.album}")
                    .replace(":", "_").replace("/", "_").replace("\\", "_").replace(" ", "_").lowercase()
                otherAlbumKey == safeAlbumKey
            }
            if (!anyRemainingInAlbum) {
                val albumArtFile = java.io.File(downloadDirectory, "${safeAlbumKey}_album_art.jpg")
                if (albumArtFile.exists()) {
                    albumArtFile.delete()
                }
            }
        }
        
        deletedFile || (removedSong != null)
    }

    override suspend fun isDownloaded(songId: String): Boolean = withContext(Dispatchers.IO) {
        val file = getDownloadFile(songId)
        (file.exists() && file.length() > 0) || downloadedSongsMap.containsKey(songId)
    }

    override fun getDownloadedSongs(): Flow<List<StreamingSong>> = downloadedSongsFlow.asStateFlow()

    override suspend fun getRandomSongs(limit: Int): List<StreamingSong> {
        if (appSettings.offlineMode.value) {
            return downloadedSongsMap.values.shuffled().take(limit.coerceAtLeast(1))
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            return emptyList()
        }

        val providerResult: Result<List<ProviderSong>> = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.getRandomSongs(limit)
            StreamingServiceId.JELLYFIN -> jellyfinClient.getRandomSongs(limit)
            else -> Result.success(emptyList())
        }

        return providerResult.getOrElse { emptyList() }
            .map { mapProviderSong(serviceId, it) }
    }

    override suspend fun getAlbumList(type: String, limit: Int): List<StreamingAlbum> {
        if (!appSettings.offlineMode.value) {
            val serviceId = activeServiceId()
            if (isServiceConnected(serviceId)) {
                try {
                    val providerResult = when (serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.getAlbumList(type, limit)
                        StreamingServiceId.JELLYFIN -> jellyfinClient.getAlbumList(type, limit)
                        else -> Result.success(emptyList())
                    }
                    val albums = providerResult.getOrNull()?.map { mapProviderAlbum(serviceId, it) }
                    if (albums != null) {
                        return enrichAlbumsWithTrackCounts(serviceId, albums)
                    }
                } catch (e: Exception) {
                    Log.w("StreamingMusicRepo", "Network getAlbumList failed, falling back to offline", e)
                }
            }
        }

        // Offline / Failure Fallback:
        return deriveAlbumsFromSongs(downloadedSongsMap.values.toList(), limit)
    }

    private suspend fun enrichAlbumsWithTrackCounts(
        serviceId: String,
        albums: List<StreamingAlbum>
    ): List<StreamingAlbum> {
        return withContext(Dispatchers.IO) {
            albums.map { album ->
                val providerAlbumId = album.externalId
                if (providerAlbumId.isNullOrBlank()) {
                    album
                } else {
                    val providerSongs = when (serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.getAlbumSongs(providerAlbumId).getOrNull()
                        StreamingServiceId.JELLYFIN -> jellyfinClient.getAlbumSongs(providerAlbumId).getOrNull()
                        else -> null
                    }.orEmpty()

                    val tracks = providerSongs.mapNotNull { providerSong ->
                        try {
                            mapProviderSong(serviceId, providerSong)
                        } catch (_: Exception) {
                            null
                        }
                    }

                    album.copy(
                        songCount = tracks.size,
                        tracks = tracks
                    )
                }
            }
        }
    }

    override suspend fun searchSongs(query: String): List<PlayableItem> {
        if (appSettings.offlineMode.value) {
            val results = downloadedSongsMap.values.filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true) ||
                it.album.contains(query, ignoreCase = true)
            }
            mergeCatalog(results)
            return results
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            clearInMemoryCatalog()
            return emptyList()
        }

        val providerResult: Result<List<ProviderSong>> = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.searchSongs(query, SEARCH_LIMIT)
            StreamingServiceId.JELLYFIN -> jellyfinClient.searchSongs(query, SEARCH_LIMIT)
            else -> Result.success(emptyList())
        }

        val mappedSongs = providerResult.getOrElse { emptyList() }
            .map { mapProviderSong(serviceId, it) }

        mergeCatalog(mappedSongs)
        return mappedSongs
    }

    override suspend fun searchAlbums(query: String): List<AlbumItem> {
        if (appSettings.offlineMode.value) {
            return deriveAlbumsFromSongs(downloadedSongsMap.values.toList(), SEARCH_LIMIT).filter {
                it.title.contains(query, ignoreCase = true) ||
                it.artist.contains(query, ignoreCase = true)
            }
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            return emptyList()
        }
        val providerResult = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.searchAlbums(query, SEARCH_LIMIT)
            StreamingServiceId.JELLYFIN -> jellyfinClient.searchAlbums(query, SEARCH_LIMIT)
            else -> Result.success(emptyList())
        }
        return providerResult.getOrElse { emptyList() }.map { 
            mapProviderAlbum(serviceId, it)
        }
    }

    override suspend fun searchArtists(query: String): List<ArtistItem> {
        if (appSettings.offlineMode.value) {
            val songs = searchSongs(query).filterIsInstance<StreamingSong>()
            return buildDerivedArtistItems(activeServiceId(), songs)
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            return emptyList()
        }

        val providerArtists = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.searchArtists(query)
            StreamingServiceId.JELLYFIN -> jellyfinClient.searchArtists(query)
            else -> Result.success(emptyList())
        }.getOrElse { emptyList() }

        if (providerArtists.isNotEmpty()) {
            return mapProviderArtists(serviceId, providerArtists)
        }

        val songs = searchSongs(query).filterIsInstance<StreamingSong>()
        return buildDerivedArtistItems(serviceId, songs)
    }

    override suspend fun searchPlaylists(query: String): List<PlaylistItem> {
        if (appSettings.offlineMode.value) {
            return emptyList()
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            return emptyList()
        }

        val result = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.searchPlaylists(query)
            StreamingServiceId.JELLYFIN -> jellyfinClient.searchPlaylists(query)
            else -> Result.success(emptyList())
        }

        return result.getOrElse { emptyList() }
            .map { providerPlaylist ->
                val tracks = fetchPlaylistTracks(serviceId, providerPlaylist.providerId)
                mapProviderPlaylist(serviceId, providerPlaylist, tracks)
            }
    }

    override fun getSongs(): Flow<List<PlayableItem>> = songsFlow.asStateFlow()

    override fun getAlbums(): Flow<List<AlbumItem>> = albumsFlow.asStateFlow()

    override fun getArtists(): Flow<List<ArtistItem>> = artistsFlow.asStateFlow()

    override fun getPlaylists(): Flow<List<PlaylistItem>> = playlistsFlow.asStateFlow()

    override suspend fun getSongById(id: String): PlayableItem? = songCache[id] ?: starredSongCache[id]

    override suspend fun syncCatalog(
        limit: Int,
        onProgress: ((current: Int, total: Int, songsCount: Int) -> Unit)?
    ): List<StreamingSong> {
        // Never let the cache load finish after (and overwrite) a newly synced catalog.
        initialCatalogLoad.await()
        // Never queue a second sync behind a running one: join it and share its result.
        return catalogSync.run { syncCatalogLocked(limit, onProgress) }
    }

    override suspend fun isCatalogOutdated(): Boolean {
        if (appSettings.offlineMode.value) return false
        // Only Subsonic reports library changes; other services keep using the cache until a
        // manual refresh. A server that cannot vouch for its library (no lastModified, scan
        // running) is treated the same way rather than triggering a full fetch on every start.
        if (activeServiceId() != StreamingServiceId.SUBSONIC || !subsonicClient.isConnected()) return false
        // Once per process: the cached-start path runs on every library screen load, and a
        // sync it starts must not trigger further checks while the marker is still stale.
        if (!coldStartCatalogCheck.tryEnter()) return false
        val serverMarker = subsonicClient.getLibraryMarker() ?: return false
        return serverMarker != catalogLibraryMarker
    }

    private suspend fun syncCatalogLocked(
        limit: Int,
        onProgress: ((current: Int, total: Int, songsCount: Int) -> Unit)?
    ): List<StreamingSong> {
        if (appSettings.offlineMode.value) {
            val downloadedList = downloadedSongsMap.values.toList()
            replaceCatalog(downloadedList)
            return downloadedList
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            clearInMemoryCatalog()
            return emptyList()
        }

        // Sync artists directly from provider first so all artists appear immediately
        syncArtists()

        // Subsonic: skip the full album-by-album fetch while the server library is unchanged
        // since the catalog in memory (from the previous sync or the disk cache) was fetched.
        val libraryMarker = if (serviceId == StreamingServiceId.SUBSONIC) subsonicClient.getLibraryMarker() else null
        if (libraryMarker != null && libraryMarker == catalogLibraryMarker && songsFlow.value.isNotEmpty()) {
            Log.d("StreamingMusicRepo", "Server library unchanged; reusing catalog of ${songsFlow.value.size} songs")
            refreshSubsonicStarredSongs()
            syncPlaylists()
            return songsFlow.value.filterIsInstance<StreamingSong>()
        }

        val fetchComplete = java.util.concurrent.atomic.AtomicBoolean(true)
        val providerSongs = when (serviceId) {
            StreamingServiceId.SUBSONIC -> fetchSubsonicLibraryResumable(limit, onProgress) { fetchComplete.set(false) }
            StreamingServiceId.JELLYFIN -> jellyfinClient.fetchLibrarySongs(limit, onProgress)
            else -> Result.success(emptyList())
        }.getOrElse { emptyList() }

        val mappedSongs = mapProviderSongs(serviceId, providerSongs)
        // A partial fetch (skipped albums) is not marked, so the next sync fetches again.
        replaceCatalog(mappedSongs, libraryMarker?.takeIf { fetchComplete.get() && providerSongs.isNotEmpty() })
        if (serviceId == StreamingServiceId.SUBSONIC) {
            refreshSubsonicStarredSongs()
        }
        
        // Also sync playlists
        syncPlaylists()
        
        saveCatalogCache(serviceId)
        return mappedSongs
    }

    /**
     * Liked songs from one getStarred2 request, complete even when the library sync is partial.
     * On failure the liked ids derived from the synced songs are kept.
     */
    private suspend fun refreshSubsonicStarredSongs() {
        val serviceId = StreamingServiceId.SUBSONIC
        val starred = subsonicClient.getStarredSongs().getOrElse { e ->
            Log.w("StreamingMusicRepo", "getStarred2 failed; liked songs limited to the synced catalog", e)
            return
        }.map { mapProviderSong(serviceId, it) }

        val merged = StarredSongs.mergeLikedIds(likedSongIds, "$serviceId::", starred)
        likedSongIds.clear()
        likedSongIds.addAll(merged)
        starredSongCache.clear()
        starred.forEach { starredSongCache[it.id] = it }
        updateLikedSongsFlow()
        Log.d("StreamingMusicRepo", "Liked songs: ${starred.size} starred, ${starred.count { songCache.containsKey(it.id) }} in the synced catalog")
    }

    /**
     * Full Subsonic fetch that checkpoints its progress after every album page, so a sync cut
     * short (app killed, screen left) continues where it stopped on the next sync instead of
     * starting over, as long as the server library is unchanged.
     */
    private suspend fun fetchSubsonicLibraryResumable(
        limit: Int,
        onProgress: ((current: Int, total: Int, songsCount: Int) -> Unit)?,
        onIncomplete: (() -> Unit)? = null
    ): Result<List<ProviderSong>> {
        val fetch = ResumableLibraryFetch(getLibraryFetchCheckpointDir(StreamingServiceId.SUBSONIC), catalogCacheWriter, gson)
        return fetch.fetch(subsonicClient.getLibraryLastModified(), limit, onProgress) { startAlbumOffset, pageLimit, progress, onPage ->
            subsonicClient.fetchLibrarySongs(pageLimit, progress, onIncomplete, startAlbumOffset, onPage)
        }
    }

    private fun syncLikedSongIdsFromProviderSongs(serviceId: String, providerSongs: List<ProviderSong>) {
        val servicePrefix = "$serviceId::"

        likedSongIds.removeIf { it.startsWith(servicePrefix) }

        providerSongs
            .asSequence()
            .filter { it.isFavorite }
            .map { encodeSongId(serviceId, it.providerId) }
            .forEach { likedSongIds.add(it) }
    }

    override suspend fun syncPlaylists(): List<StreamingPlaylist> {
        if (appSettings.offlineMode.value) {
            playlistsFlow.value = emptyList()
            return emptyList()
        }
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) {
            playlistsFlow.value = emptyList()
            return emptyList()
        }

        val result = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.getPlaylists()
            StreamingServiceId.JELLYFIN -> jellyfinClient.getPlaylists()
            else -> Result.success(emptyList())
        }

        val playlists = coroutineScope {
            result.getOrElse { emptyList() }
                .map { providerPlaylist ->
                    async {
                        val tracks = fetchPlaylistTracks(serviceId, providerPlaylist.providerId)
                        mapProviderPlaylist(serviceId, providerPlaylist, tracks)
                    }
                }.awaitAll()
        }

        playlistsFlow.value = playlists
        saveCatalogCache(serviceId)
        return playlists
    }

    override suspend fun getAlbumById(id: String): AlbumItem? {
        albumsFlow.value.firstOrNull { it.id == id }?.let { return it }

        val decodedId = decodeAlbumId(id) ?: return null
        var providerAlbumId = decodedId.providerAlbumId
        
        val isOnline = NetworkUtils.isNetworkAvailable(context) && !appSettings.offlineMode.value
        if (isOnline) {
            if (providerAlbumId == null) {
                val albumTitle = decodedId.title
                val albumArtist = decodedId.artist
                if (albumTitle.isNotBlank()) {
                    val searchResults = when (decodedId.serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.searchAlbums(albumTitle).getOrNull()
                        StreamingServiceId.JELLYFIN -> jellyfinClient.searchAlbums(albumTitle).getOrNull()
                        else -> null
                    }
                    val matchedAlbum = searchResults?.firstOrNull {
                        it.title.equals(albumTitle, ignoreCase = true) &&
                        (albumArtist.isBlank() || it.artist.equals(albumArtist, ignoreCase = true))
                    } ?: searchResults?.firstOrNull()
                    if (matchedAlbum != null) {
                        providerAlbumId = matchedAlbum.providerId
                    }
                }
            }

            if (providerAlbumId != null) {
                try {
                    val providerResult = when (decodedId.serviceId) {
                        StreamingServiceId.SUBSONIC -> subsonicClient.getAlbumById(providerAlbumId)
                        StreamingServiceId.JELLYFIN -> jellyfinClient.getAlbumById(providerAlbumId)
                        else -> Result.failure(Exception("Unknown service"))
                    }
                    val mapped = providerResult.getOrNull()?.let {
                        mapProviderAlbum(decodedId.serviceId, it)
                    }
                    if (mapped != null) {
                        return mapped
                    }
                } catch (e: Exception) {
                    Log.w("StreamingMusicRepo", "Network getAlbumById failed, falling back to offline", e)
                }
            }
        }

        // Offline / Failure Fallback:
        val derived = deriveAlbumsFromSongs(downloadedSongsMap.values.toList(), 100)
        derived.firstOrNull { it.id == id }?.let { return it }
        
        return derived.firstOrNull { derivedAlbum ->
            val derivedDecoded = decodeAlbumId(derivedAlbum.id)
            derivedDecoded != null && 
            derivedDecoded.title.equals(decodedId.title, ignoreCase = true) &&
            derivedDecoded.artist.equals(decodedId.artist, ignoreCase = true)
        }
    }

    override suspend fun getArtistById(id: String): ArtistItem? {
        artistsFlow.value.firstOrNull { it.id == id }?.let { return it }

        val artistName = extractArtistNameFromId(id)
        val isOnline = NetworkUtils.isNetworkAvailable(context) && !appSettings.offlineMode.value

        if (!isOnline) {
            if (artistName.isBlank()) return null
            val derivedArtists = buildArtistItems(activeServiceId(), downloadedSongsMap.values.toList())
            return derivedArtists.firstOrNull { it.id == id }
                ?: derivedArtists.firstOrNull { it.name.equals(artistName, ignoreCase = true) }
        }

        if (artistName.isBlank()) {
            return null
        }

        val serviceId = id.substringBefore("::", activeServiceId())
        val providerArtists = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.searchArtists(artistName, limit = 20)
            StreamingServiceId.JELLYFIN -> jellyfinClient.searchArtists(artistName, limit = 20)
            else -> Result.success(emptyList())
        }.getOrElse { emptyList() }

        val providerArtist = providerArtists.firstOrNull {
            it.name.equals(artistName, ignoreCase = true)
        } ?: providerArtists.firstOrNull()

        return providerArtist?.let { mapProviderArtist(serviceId, it) }
    }

    override suspend fun getPlaylistById(id: String): PlaylistItem? {
        return playlistsFlow.value.firstOrNull { it.id == id }
    }

    override suspend fun getSongsForAlbum(albumId: String): List<PlayableItem> {
        return getAlbumSongs(albumId)
    }

    override suspend fun getLyrics(songId: String, artist: String?, title: String?): LyricsData? {
        if (appSettings.offlineMode.value) return null
        val decoded = decodeSongId(songId)
        val serviceId = decoded?.first ?: activeServiceId()
        val providerSongId = decoded?.second ?: songId

        if (!isServiceConnected(serviceId)) return null

        return when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.getLyrics(providerSongId, artist, title).getOrNull()
            StreamingServiceId.JELLYFIN -> jellyfinClient.getLyrics(providerSongId, artist, title).getOrNull()
            else -> null
        }
    }

    /**
     * @param libraryMarker server library marker [songs] were fetched under, if known to be the
     *        complete, current library (see [SubsonicApiClient.getLibraryMarker]).
     */
    private suspend fun replaceCatalog(songs: List<StreamingSong>, libraryMarker: String? = null) {
        val serviceId = activeServiceId()
        catalogLibraryMarker = libraryMarker
        // Only populate albumsFlow with derived albums if no provider albums are cached
        val deriveAlbums = providerAlbumCache.isEmpty()
        // Grouping thousands of songs into albums/artists is CPU work; keep it off the caller's
        // (main) dispatcher. Shared caches are still mutated on the caller's thread below.
        val (derivedAlbums, rawArtists) = withContext(Dispatchers.Default) {
            (if (deriveAlbums) buildAlbumItems(serviceId, songs) else null) to
                buildArtistItems(serviceId, songs)
        }

        songCache.clear()
        songs.forEach { song ->
            songCache[song.id] = song
        }

        songsFlow.value = songs
        // Re-check after the suspension: provider albums may have been cached meanwhile, and
        // derived albums must not overwrite them.
        if (derivedAlbums != null && providerAlbumCache.isEmpty()) {
            albumsFlow.value = derivedAlbums
        }
        if (artistsFlow.value.isEmpty() || rawArtists.size >= artistsFlow.value.size) {
            artistsFlow.value = rawArtists
        }

        updateLikedSongsFlow()
        updateSavedAlbumsFlow()
        updateFollowedArtistsFlow()

        saveCatalogCache(serviceId)

        // Asynchronously enrich with Deezer images in background to avoid blocking.
        // A newer catalog change supersedes a running pass (finished lookups stay cached).
        artistEnrichmentJob?.cancel()
        artistEnrichmentJob = repositoryScope.launch {
            try {
                val enriched = enrichArtistsWithDeezerImages(rawArtists)
                if (artistsFlow.value != enriched) {
                    artistsFlow.value = enriched
                    updateFollowedArtistsFlow()
                    saveCatalogCache(serviceId)
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("StreamingMusicRepo", "Background Deezer artist enrichment failed", e)
            }
        }
    }

    private suspend fun mergeCatalog(songs: List<StreamingSong>) {
        if (songs.isEmpty()) {
            return
        }

        val serviceId = activeServiceId()
        songs.forEach { song ->
            songCache[song.id] = song
        }
        trimSongCache()

        val currentSongs = songsFlow.value
        // Merging a search result into a catalog of thousands of songs re-groups every album and
        // artist; do that off the caller's (main) dispatcher, as replaceCatalog() does.
        val deriveAlbums = providerAlbumCache.isEmpty()
        val (mergedSongs, derivedAlbums, rawArtists) = withContext(Dispatchers.Default) {
            val merged = (currentSongs.filterIsInstance<StreamingSong>() + songs).distinctBy { it.id }
            Triple(
                merged,
                if (deriveAlbums) buildAlbumItems(serviceId, merged) else null,
                buildArtistItems(serviceId, merged)
            )
        }

        songsFlow.value = mergedSongs
        // Only populate albumsFlow with derived albums if no provider albums are cached
        if (derivedAlbums != null && providerAlbumCache.isEmpty()) {
            albumsFlow.value = derivedAlbums
        }
        artistsFlow.value = rawArtists
        playlistsFlow.value = emptyList()

        updateLikedSongsFlow()
        updateSavedAlbumsFlow()
        updateFollowedArtistsFlow()

        // Asynchronously enrich with Deezer images in background to avoid blocking.
        // A newer catalog change supersedes a running pass (finished lookups stay cached).
        artistEnrichmentJob?.cancel()
        artistEnrichmentJob = repositoryScope.launch {
            try {
                val enriched = enrichArtistsWithDeezerImages(rawArtists)
                if (artistsFlow.value != enriched) {
                    artistsFlow.value = enriched
                    updateFollowedArtistsFlow()
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("StreamingMusicRepo", "Background Deezer artist enrichment failed", e)
            }
        }
    }

    private fun clearInMemoryCatalog() {
        catalogLibraryMarker = null
        songCache.clear()
        followedPlaylistIds.clear()
        songsFlow.value = emptyList()
        albumsFlow.value = emptyList()
        artistsFlow.value = emptyList()
        playlistsFlow.value = emptyList()
    }

    private fun updateLikedSongsFlow() {
        likedSongsFlow.value = StarredSongs.likedSongs(likedSongIds, songCache, starredSongCache)
    }

    private fun updateSavedAlbumsFlow() {
        savedAlbumsFlow.value = savedAlbumIds.mapNotNull { id ->
            albumsFlow.value.firstOrNull { it.id == id } as? StreamingAlbum
        }
    }

    private fun updateFollowedArtistsFlow() {
        followedArtistsFlow.value = followedArtistIds.mapNotNull { id ->
            artistsFlow.value.firstOrNull { it.id == id } as? StreamingArtist
        }
    }

    /**
     * Maps a batch of provider songs on [Dispatchers.Default]. Each song builds a signed stream
     * URL (salt + MD5 + URL parse), so a full catalog sync of thousands of songs must not run on
     * the caller's dispatcher: callers are ViewModel coroutines on the main thread, and doing it
     * there blocked input for 20+ seconds ("Input dispatching timed out" ANR).
     */
    private suspend fun mapProviderSongs(
        serviceId: String,
        providerSongs: List<ProviderSong>
    ): List<StreamingSong> {
        if (providerSongs.isEmpty()) return emptyList()
        return withContext(Dispatchers.Default) {
            providerSongs.map { mapProviderSong(serviceId, it) }
        }
    }

    private fun mapProviderSong(serviceId: String, providerSong: ProviderSong): StreamingSong {
        val encodedId = encodeSongId(serviceId, providerSong.providerId)
        val sourceType = serviceToSourceType(serviceId)
        val encodedAlbumId = providerSong.albumId
            ?.takeIf { it.isNotBlank() }
            ?.let { encodeAlbumId(serviceId, it) }
        val streamingUrl = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.buildStreamUrl(providerSong.providerId, desiredBitrateKbps())
            StreamingServiceId.JELLYFIN -> jellyfinClient.buildStreamUrl(providerSong.providerId, desiredBitrateKbps())
            else -> null
        }

        return StreamingSong(
            id = encodedId,
            title = providerSong.title,
            artist = providerSong.artist,
            album = providerSong.album,
            duration = providerSong.durationMs,
            artworkUri = providerSong.artworkUrl,
            sourceType = sourceType,
            streamingUrl = streamingUrl,
            previewUrl = null,
            isPlayable = true,
            externalId = providerSong.providerId,
            albumId = encodedAlbumId,
            albumArtist = providerSong.albumArtist,
            isFavorite = providerSong.isFavorite,
            trackNumber = providerSong.trackNumber,
            year = providerSong.year,
            genre = providerSong.genre,
            bitrate = providerSong.bitrate,
            sampleRate = providerSong.sampleRate,
            channels = providerSong.channels,
            codec = providerSong.codec
        )
    }

    private suspend fun fetchPlaylistTracks(serviceId: String, providerPlaylistId: String): List<StreamingSong> {
        val result = when (serviceId) {
            StreamingServiceId.SUBSONIC -> subsonicClient.getPlaylistSongs(providerPlaylistId)
            StreamingServiceId.JELLYFIN -> jellyfinClient.getPlaylistSongs(providerPlaylistId)
            else -> Result.success(emptyList())
        }

        return mapProviderSongs(serviceId, result.getOrElse { emptyList() })
    }

    private fun mapProviderPlaylist(
        serviceId: String,
        providerPlaylist: ProviderPlaylist,
        tracks: List<StreamingSong> = emptyList()
    ): StreamingPlaylist {
        val encodedId = encodePlaylistId(serviceId, providerPlaylist.providerId)
        val resolvedTracks = if (tracks.isNotEmpty()) tracks else emptyList()
        
        return StreamingPlaylist(
            id = encodedId,
            name = providerPlaylist.name,
            description = providerPlaylist.description,
            artworkUri = providerPlaylist.artworkUrl ?: resolvedTracks.firstOrNull()?.artworkUri,
            songCount = providerPlaylist.songCount.takeIf { it > 0 } ?: resolvedTracks.size,
            isEditable = when (serviceId) {
                StreamingServiceId.SUBSONIC -> providerPlaylist.owner?.equals(subsonicClient.getUsername(), ignoreCase = true) == true
                StreamingServiceId.JELLYFIN -> providerPlaylist.owner?.equals(jellyfinClient.getUsername(), ignoreCase = true) == true
                else -> false
            },
            sourceType = serviceToSourceType(serviceId),
            externalId = providerPlaylist.providerId,
            owner = if (providerPlaylist.owner != null) {
                app.needle.player.features.streaming.domain.model.PlaylistOwner(
                    id = normalizeKey(providerPlaylist.owner),
                    displayName = providerPlaylist.owner,
                    imageUrl = null,
                    isCurrentUser = false
                )
            } else null,
            isPublic = providerPlaylist.isPublic,
            isCollaborative = false,
            followers = null,
            snapshotId = null,
            tracks = resolvedTracks
        )
    }

    private fun buildAlbumItems(serviceId: String, songs: List<StreamingSong>): List<StreamingAlbum> {
        return songs
            .filter { it.album.isNotBlank() }
            .groupBy { song -> song.albumId ?: buildLegacyAlbumId(serviceId, song.artist, song.album) }
            .map { (albumKey, tracks) ->
                val firstSong = tracks.first()
                StreamingAlbum(
                    id = albumKey,
                    title = firstSong.album,
                    artist = firstSong.albumArtist?.takeIf { it.isNotBlank() } ?: firstSong.artist,
                    artworkUri = tracks.firstNotNullOfOrNull { it.artworkUri },
                    songCount = tracks.size,
                    year = firstSong.releaseDate?.take(4)?.toIntOrNull(),
                    sourceType = serviceToSourceType(serviceId)
                )
            }
            .sortedWith(compareBy<StreamingAlbum> { it.title.lowercase() }.thenBy { it.artist.lowercase() })
    }

    private fun mapProviderAlbum(serviceId: String, providerAlbum: ProviderAlbum): StreamingAlbum {
        return StreamingAlbum(
            id = encodeAlbumId(serviceId, providerAlbum.providerId),
            title = providerAlbum.title,
            artist = providerAlbum.artist,
            artworkUri = providerAlbum.artworkUrl,
            songCount = providerAlbum.songCount,
            year = providerAlbum.year,
            sourceType = serviceToSourceType(serviceId),
            externalId = providerAlbum.providerId,
            releaseDate = null,
            albumType = app.needle.player.features.streaming.domain.model.AlbumType.ALBUM,
            genres = emptyList(),
            label = null,
            copyright = null,
            isExplicit = false
        )
    }

    private fun buildArtistItems(serviceId: String, songs: List<StreamingSong>): List<StreamingArtist> {
        // Apply artist separator settings to split collaborations, matching ViewModel behavior
        val separatorEnabled = appSettings.artistSeparatorEnabled.value
        val separatorDelimiters = if (separatorEnabled) {
            appSettings.artistSeparatorDelimiters.value.ifBlank { AppSettings.DEFAULT_ARTIST_SEPARATOR_DELIMITERS }
        } else {
            ""
        }
        
        return songs
            .filter { it.artist.isNotBlank() }
            .flatMap { song ->
                val artistNames = ArtistSeparator.splitArtistNames(
                    song.artist,
                    delimiters = separatorDelimiters,
                    enabled = separatorEnabled
                )
                
                if (artistNames.isEmpty()) {
                    listOf(song to song.artist.trim())
                } else {
                    artistNames.mapNotNull { artistName ->
                        artistName.trim().takeIf { it.isNotBlank() }?.let { trimmedName ->
                            song to trimmedName
                        }
                    }
                }
            }
            .groupBy { (song, artistName) -> "${song.sourceType.name}:${artistName.lowercase()}" }
            .values
            .sortedByDescending { artistSongs -> artistSongs.size }
            .map { artistSongs ->
                val firstSong = artistSongs.first().first
                val artistName = artistSongs.first().second
                val tracks = artistSongs.map { it.first }
                val albumCount = tracks.map { it.album }.distinct().size
                
                // Look up enriched artwork from cache, with fallback to song artwork
                val artworkUri = artistArtworkCache[normalizeKey(artistName)] 
                    ?: tracks.firstNotNullOfOrNull { it.artworkUri }
                
                StreamingArtist(
                    id = buildArtistId(serviceId, artistName),
                    name = artistName,
                    artworkUri = artworkUri,
                    songCount = tracks.size,
                    albumCount = albumCount,
                    sourceType = serviceToSourceType(serviceId)
                )
            }
            .sortedBy { it.name.lowercase() }
    }

    private suspend fun buildDerivedArtistItems(
        serviceId: String,
        songs: List<StreamingSong>
    ): List<StreamingArtist> {
        return enrichArtistsWithDeezerImages(buildArtistItems(serviceId, songs))
    }

    /**
     * Maps a provider artist list on [Dispatchers.Default], resolving cached songs through an
     * [ArtistSongIndex] built once for the batch. Scanning the song cache per artist on the
     * caller's (main) dispatcher cost ~2 s per sync and caused "Input dispatching timed out" ANRs
     * from syncArtists()/searchArtists() on large libraries.
     */
    private suspend fun mapProviderArtists(
        serviceId: String,
        providerArtists: List<ProviderArtist>
    ): List<StreamingArtist> {
        if (providerArtists.isEmpty()) return emptyList()
        // Snapshot the shared caches on the caller's thread; they are not thread-safe.
        val candidateSongs = songsFlow.value.filterIsInstance<StreamingSong>() +
            songCache.values.toList() + downloadedSongsMap.values.toList()
        val separatorEnabled = appSettings.artistSeparatorEnabled.value
        val separatorDelimiters = appSettings.artistSeparatorDelimiters.value
            .ifBlank { AppSettings.DEFAULT_ARTIST_SEPARATOR_DELIMITERS }
        return withContext(Dispatchers.Default) {
            val index = ArtistSongIndex(candidateSongs) { artist ->
                ArtistSeparator.splitArtistNames(artist, delimiters = separatorDelimiters, enabled = separatorEnabled)
            }
            providerArtists.map { mapProviderArtist(serviceId, it, index) }
        }
    }

    private fun mapProviderArtist(
        serviceId: String,
        providerArtist: ProviderArtist,
        artistSongIndex: ArtistSongIndex? = null
    ): StreamingArtist {
        // Only needed when the provider omitted artwork or counts.
        val cachedArtistSongs by lazy {
            artistSongIndex?.songsFor(providerArtist.name) ?: cachedSongsForArtist(providerArtist.name)
        }
        val cachedArtist by lazy {
            buildArtistItems(serviceId, cachedArtistSongs)
                .firstOrNull { it.name.equals(providerArtist.name, ignoreCase = true) }
        }

        return StreamingArtist(
            id = buildArtistId(serviceId, providerArtist.name),
            name = providerArtist.name,
            artworkUri = providerArtist.artworkUrl
                ?: artistArtworkCache[normalizeKey(providerArtist.name)]
                ?: cachedArtist?.artworkUri,
            songCount = providerArtist.songCount.takeIf { it > 0 }
                ?: cachedArtist?.songCount
                ?: cachedArtistSongs.size,
            albumCount = providerArtist.albumCount.takeIf { it > 0 }
                ?: cachedArtist?.albumCount
                ?: cachedArtistSongs.map { it.album }.distinct().size,
            sourceType = serviceToSourceType(serviceId),
            externalId = providerArtist.providerId,
            genres = emptyList(),
            followers = null,
            popularity = null,
            bio = providerArtist.description
        )
    }

    private fun artistIdForSong(song: StreamingSong): String {
        val serviceId = decodeSongId(song.id)?.first ?: activeServiceId()
        return buildArtistId(serviceId, song.artist)
    }

    private fun cachedSongsForArtist(artistName: String): List<StreamingSong> {
        if (artistName.isBlank()) {
            return emptyList()
        }

        return (songsFlow.value.filterIsInstance<StreamingSong>() + songCache.values + downloadedSongsMap.values)
            .asSequence()
            .filter { song ->
                if (!song.artist.contains(artistName, ignoreCase = true)) {
                    false
                } else {
                    val artistNames = ArtistSeparator.splitArtistNames(
                        song.artist,
                        delimiters = appSettings.artistSeparatorDelimiters.value.ifBlank { AppSettings.DEFAULT_ARTIST_SEPARATOR_DELIMITERS },
                        enabled = appSettings.artistSeparatorEnabled.value
                    )

                    artistNames.isEmpty() || artistNames.any { it.equals(artistName, ignoreCase = true) }
                }
            }
            .distinctBy { it.id }
            .toList()
    }

    private fun artistIdForAlbum(album: StreamingAlbum): String {
        val serviceId = album.id.substringBefore("::", activeServiceId())
        return buildArtistId(serviceId, album.artist)
    }

    private fun deriveAlbumsFromSongs(
        songs: List<StreamingSong>,
        limit: Int
    ): List<StreamingAlbum> {
        if (songs.isEmpty()) {
            return emptyList()
        }

        return songs
            .filter { it.album.isNotBlank() }
            .groupBy { song -> song.albumId ?: "${song.sourceType.name}:${song.artist.lowercase()}:${song.album.lowercase()}" }
            .values
            .sortedByDescending { albumSongs -> albumSongs.size }
            .take(limit.coerceAtLeast(1))
            .map { albumSongs ->
                val firstSong = albumSongs.first()
                StreamingAlbum(
                    id = firstSong.albumId ?: buildLegacyAlbumId(
                        serviceId = firstSong.sourceType.name,
                        artist = firstSong.artist,
                        album = firstSong.album
                    ),
                    title = firstSong.album,
                    artist = firstSong.albumArtist?.takeIf { it.isNotBlank() } ?: firstSong.artist,
                    artworkUri = albumSongs.firstNotNullOfOrNull { it.artworkUri },
                    songCount = albumSongs.size,
                    year = firstSong.releaseDate?.take(4)?.toIntOrNull(),
                    sourceType = firstSong.sourceType,
                    tracks = albumSongs
                )
            }
    }
    
    /**
     * Legacy matching - kept for backward compatibility with exact ID matching.
     * Use extractArtistNameFromId and match by artist name instead.
     */
    @Deprecated("Use extractArtistNameFromId and match by artist name")
    private fun matchArtistIdByFormat(artistId: String, generatedId: String): Boolean {
        return artistId == generatedId || extractArtistNameFromId(artistId) == extractArtistNameFromId(generatedId)
    }

    override fun buildArtistId(serviceId: String, artist: String): String {
        return "$serviceId::artist::${normalizeKey(artist)}"
    }

    private fun buildLegacyAlbumId(serviceId: String, artist: String, album: String): String {
        return "$serviceId::album::${normalizeKey(artist)}::${normalizeKey(album)}"
    }

    private fun decodeAlbumId(albumId: String): DecodedAlbumId? {
        val marker = "::album::"
        val separatorIndex = albumId.indexOf(marker)
        if (separatorIndex <= 0 || separatorIndex >= albumId.length - marker.length) {
            return null
        }

        val serviceId = albumId.substring(0, separatorIndex)
        val payload = albumId.substring(separatorIndex + marker.length)
        if (payload.isBlank()) {
            return null
        }

        val payloadParts = payload.split("::")
        return if (payloadParts.size >= 2) {
            val artist = payloadParts.first().replace("_", " ").trim()
            val album = payloadParts.drop(1).joinToString("::").replace("_", " ").trim()

            if (artist.isBlank() || album.isBlank()) {
                null
            } else {
                DecodedAlbumId(
                    serviceId = serviceId,
                    providerAlbumId = null,
                    title = album,
                    artist = artist,
                    isLegacy = true
                )
            }
        } else {
            val restoredPayload = payload.replace("_slash_", "/")
            DecodedAlbumId(
                serviceId = serviceId,
                providerAlbumId = restoredPayload,
                title = "",
                artist = "",
                isLegacy = false
            )
        }
    }

    private fun encodeAlbumId(serviceId: String, providerAlbumId: String): String {
        val safeProviderId = providerAlbumId.replace("/", "_slash_")
        return "$serviceId::album::$safeProviderId"
    }

    private fun legacyAlbumIdForSong(song: StreamingSong, fallbackServiceId: String?): String {
        val songServiceId = decodeSongId(song.id)?.first ?: fallbackServiceId ?: activeServiceId()
        return buildLegacyAlbumId(songServiceId, song.artist, song.album)
    }

    private data class DecodedAlbumId(
        val serviceId: String,
        val providerAlbumId: String?,
        val title: String,
        val artist: String,
        val isLegacy: Boolean
    )

    @Deprecated("Use encodeAlbumId(serviceId, providerAlbumId) for streaming album IDs")
    private fun buildAlbumId(serviceId: String, artist: String, album: String): String {
        return buildLegacyAlbumId(serviceId, artist, album)
    }

    @Deprecated("Use decodeAlbumId(albumId) and provider album IDs")
    private fun decodeLegacyAlbumId(albumId: String): Triple<String, String, String>? {
        val decoded = decodeAlbumId(albumId)
        if (decoded == null || !decoded.isLegacy) {
            return null
        }

        return Triple(decoded.serviceId, decoded.title, decoded.artist)
    }

    private fun normalizeKey(value: String): String {
        return value.trim().lowercase().replace(WHITESPACE_REGEX, "_")
    }

    private fun trimSongCache() {
        if (songCache.size <= MAX_CACHE_SIZE) return

        val toRemove = songCache.size - MAX_CACHE_SIZE
        repeat(toRemove) {
            val firstKey = songCache.entries.firstOrNull()?.key ?: return
            songCache.remove(firstKey)
        }
    }

    private fun activeServiceId(): String {
        return normalizeServiceId(appSettings.streamingService.value)
    }

    private fun encodeSongId(serviceId: String, providerId: String): String {
        return "$serviceId::$providerId"
    }

    private fun decodeSongId(songId: String): Pair<String, String>? {
        val separatorIndex = songId.indexOf("::")
        if (separatorIndex <= 0 || separatorIndex >= songId.length - 2) {
            return null
        }

        val serviceId = songId.substring(0, separatorIndex)
        val providerId = songId.substring(separatorIndex + 2)
        return serviceId to providerId
    }

    private fun decodePlaylistId(playlistId: String): Pair<String, String>? {
        val marker = "::playlist::"
        val separatorIndex = playlistId.indexOf(marker)
        if (separatorIndex <= 0 || separatorIndex >= playlistId.length - marker.length) {
            return null
        }

        val serviceId = playlistId.substring(0, separatorIndex)
        val providerId = playlistId.substring(separatorIndex + marker.length)
        if (providerId.isBlank()) {
            return null
        }

        return serviceId to providerId
    }

    private fun encodePlaylistId(serviceId: String, providerId: String): String {
        return "$serviceId::playlist::$providerId"
    }

    private fun desiredBitrateKbps(): Int {
        return when (appSettings.streamingQuality.value.uppercase()) {
            "LOW" -> 96
            "NORMAL" -> 160
            "HIGH" -> 320
            "LOSSLESS" -> 0   // No cap — server streams the original file at native quality
            else -> 0          // Unknown/future values also default to lossless (highest available)
        }
    }
    
    /**
     * Validate if the requested quality is supported by the provider.
     * Some providers may not support all quality levels.
     */
    private fun isSupportedQuality(quality: String): Boolean {
        // All major providers (Subsonic/Navidrome, Jellyfin) support these quality levels
        return quality.uppercase() in listOf("LOW", "NORMAL", "HIGH", "LOSSLESS")
    }
    
    /**
     * Get the fallback quality if the requested one is not supported.
     */
    private fun getFallbackQuality(unsupportedQuality: String): String {
        return when (unsupportedQuality.uppercase()) {
            else -> "HIGH" // Default fallback
        }
    }
    private fun resolveCookieInput(username: String, password: String): String {
        return when {
            looksLikeCookieBlob(password) -> password
            looksLikeCookieBlob(username) -> username
            else -> password
        }
    }

    private fun looksLikeCookieBlob(value: String): Boolean {
        val trimmed = value.trim()
        return trimmed.startsWith("{") || trimmed.contains('=')
    }

    private fun serviceToSourceType(serviceId: String): SourceType {
        return when (serviceId) {
            StreamingServiceId.SUBSONIC -> SourceType.SUBSONIC
            StreamingServiceId.JELLYFIN -> SourceType.JELLYFIN
            else -> SourceType.UNKNOWN
        }
    }

    private fun normalizeServiceId(serviceId: String): String {
        val normalized = serviceId.uppercase()
        return if (StreamingServiceId.all.contains(normalized)) {
            normalized
        } else {
            StreamingServiceId.SUBSONIC
        }
    }

    /**
     * Enrich streaming artists with artwork from Deezer API
     * Call this when loading artists to fill in missing artwork
     */
    suspend fun enrichArtistsWithDeezerImages(artists: List<StreamingArtist>): List<StreamingArtist> {
        return withContext(Dispatchers.IO) {
            try {
                // Check if Deezer API is available and enabled in settings
                val deezerService = NetworkClient.deezerApiService
                if (deezerService == null || !NetworkClient.isDeezerApiEnabled()) {
                    Log.d("StreamingMusicRepo", "Deezer API service not available or disabled in settings, skipping enrichment")
                    return@withContext artists // Return unchanged if API not available/enabled
                }

                val enriched = mutableListOf<StreamingArtist>()
                var lookups = 0

                deezerEnrichmentMutex.withLock {
                    try {
                        for (artist in artists) {
                            // Skip unknown/blank artists
                            if (artist.name.isBlank() || artist.name.equals("Unknown", ignoreCase = true)) {
                                enriched.add(artist)
                                continue
                            }

                            // Prefer the Deezer artist image over album art; look each artist up
                            // at most once per cache TTL.
                            val key = normalizeKey(artist.name)
                            val cached = deezerArtistImageCache.get(key)
                            val imageUrl = if (cached != null) {
                                cached.imageUrl
                            } else {
                                lookups++
                                lookUpDeezerArtistImage(deezerService, artist.name, key)
                            }
                            val enrichedArtist = if (imageUrl != null) artist.copy(artworkUri = imageUrl) else artist

                            // Cache the final artwork (Deezer or original)
                            enrichedArtist.artworkUri?.takeIf { it.isNotBlank() }?.let { cachedUri ->
                                artistArtworkCache[key] = cachedUri
                            }
                            enriched.add(enrichedArtist)
                        }
                    } finally {
                        // Persist finished lookups even if a newer catalog change cancelled this pass.
                        deezerArtistImageCache.flush()
                    }
                }

                if (lookups > 0) {
                    Log.d("StreamingMusicRepo", "Deezer artist enrichment: $lookups lookups for ${artists.size} artists")
                }
                enriched
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                Log.e("StreamingMusicRepo", "Error enriching artists with Deezer images", e)
                artists // Return unchanged on error
            }
        }
    }

    /** Searches Deezer for [artistName]; caches the image URL (or its absence) under [key]. */
    private suspend fun lookUpDeezerArtistImage(
        deezerService: DeezerApiService,
        artistName: String,
        key: String
    ): String? {
        return try {
            val searchResponse = deezerService.searchArtists(artistName, limit = 5)
            val deezerArtist = searchResponse.data.firstOrNull {
                it.name.equals(artistName, ignoreCase = true)
            } ?: searchResponse.data.firstOrNull() // Fallback to best match

            val imageUrl = deezerArtist?.let {
                // Choose best quality image available
                listOf(it.pictureXl, it.pictureBig, it.pictureMedium, it.picture)
                    .firstOrNull { url -> !url.isNullOrEmpty() }
            }
            deezerArtistImageCache.put(key, imageUrl)
            imageUrl
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w("StreamingMusicRepo", "Failed to fetch Deezer image for $artistName: ${e.message}")
            deezerArtistImageCache.markFailed(key)
            null
        }
    }

    /**
     * Update the repository's artistsFlow with enriched artists.
     * This ensures enriched artwork persists across recompositions and navigations.
     */
    fun updateArtistsFlow(enrichedArtists: List<StreamingArtist>) {
        artistsFlow.value = enrichedArtists
    }

    override suspend fun syncArtists(): List<StreamingArtist> {
        val serviceId = activeServiceId()
        if (!isServiceConnected(serviceId)) return emptyList()

        return try {
            // The provider clients parse the response (and sign a cover-art URL per artist) in
            // the calling coroutine, so fetch on IO rather than the caller's main dispatcher.
            val providerArtists = withContext(Dispatchers.IO) {
                when (serviceId) {
                    StreamingServiceId.SUBSONIC -> subsonicClient.getArtists().getOrNull()
                    StreamingServiceId.JELLYFIN -> jellyfinClient.getArtists().getOrNull()
                    else -> null
                }
            }
            providerArtists?.forEach { artist ->
                if (!artist.artworkUrl.isNullOrBlank()) {
                    artistArtworkCache[normalizeKey(artist.name)] = artist.artworkUrl
                }
            }
            if (!providerArtists.isNullOrEmpty()) {
                val directArtists = mapProviderArtists(serviceId, providerArtists)
                artistsFlow.value = directArtists
                updateFollowedArtistsFlow()
                Log.d("StreamingMusicRepo", "Synced ${directArtists.size} artists directly from provider")
                directArtists
            } else {
                emptyList()
            }
        } catch (e: Exception) {
            Log.w("StreamingMusicRepo", "Failed to sync artists from provider", e)
            emptyList()
        }
    }

    private suspend fun syncArtistArtworkCache(serviceId: String) {
        syncArtists()
    }

    private companion object {
        private const val SEARCH_LIMIT = 100
        private const val MAX_CACHE_SIZE = 4000

        /** Compiled once; normalizeKey() runs per artist during catalog mapping. */
        private val WHITESPACE_REGEX = "\\s+".toRegex()
    }
}
