package app.needle.player.features.local.presentation.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * "Latest Moments": a row of round album covers (your newest additions) and one big card.
 * Tap a circle to open its moment, tap the card to flip between the cover and the track list.
 */
@Composable
fun NeedleMomentsSection(
    albums: List<Album>,
    songs: List<Song>,
    onAlbumClick: (Album) -> Unit,
    onSongClick: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val moments = remember(albums) { albums.sortedByDescending { it.dateModified }.take(10) }
    if (moments.isEmpty()) return

    var selected by remember { mutableIntStateOf(0) }
    var flipped by remember { mutableStateOf(false) }
    val seen = remember { mutableStateListOf<String>() }
    val safeIndex = selected.coerceIn(0, moments.size - 1)
    val album = moments[safeIndex]
    val albumSongs = remember(album.id, songs) {
        songs.filter { it.albumId == album.id }.sortedBy { it.trackNumber }
    }

    LaunchedEffect(album.id) {
        if (!seen.contains(album.id)) seen.add(album.id)
        flipped = false
    }

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = "Latest Moments",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold,
            color = scheme.onSurface,
            modifier = Modifier.padding(bottom = 12.dp)
        )

        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            itemsIndexed(moments, key = { _, item -> item.id }) { index, item ->
                val isSelected = index == safeIndex
                val isNew = !seen.contains(item.id)
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    modifier = Modifier.clickable { selected = index }
                ) {
                    AsyncImage(
                        model = ImageRequest.Builder(context).data(item.artworkUri).size(192, 192).build(),
                        contentDescription = item.title,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(62.dp)
                            .clip(CircleShape)
                            .background(scheme.surfaceContainerHigh)
                            .border(2.dp, if (isSelected) scheme.onSurface else Color.Transparent, CircleShape)
                    )
                    Spacer(Modifier.height(6.dp))
                    Box(
                        modifier = Modifier
                            .size(5.dp)
                            .clip(CircleShape)
                            .background(
                                when {
                                    isSelected -> scheme.onSurface
                                    isNew -> scheme.secondary
                                    else -> Color.Transparent
                                }
                            )
                    )
                }
            }
        }

        Spacer(Modifier.height(14.dp))

        Box(
            modifier = Modifier
                .fillMaxWidth()
                .aspectRatio(0.95f)
                .clip(RoundedCornerShape(30.dp))
                .background(scheme.surfaceContainerHigh)
                .clickable { flipped = !flipped }
        ) {
            AsyncImage(
                model = ImageRequest.Builder(context).data(album.artworkUri).crossfade(250).build(),
                contentDescription = album.title,
                contentScale = ContentScale.Crop,
                modifier = Modifier.fillMaxSize()
            )
            if (flipped) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .background(
                            Brush.verticalGradient(
                                listOf(Color.Black.copy(alpha = 0.72f), Color.Black.copy(alpha = 0.88f))
                            )
                        )
                )
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(start = 22.dp, end = 22.dp, top = 24.dp, bottom = 110.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    val lines = if (albumSongs.isNotEmpty()) albumSongs.take(5).map { it.title } else listOf(album.title)
                    lines.forEachIndexed { index, line ->
                        Text(
                            text = line,
                            fontSize = if (index == 0) 28.sp else 22.sp,
                            lineHeight = if (index == 0) 32.sp else 26.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White.copy(alpha = if (index == 0) 1f else 0.42f),
                            maxLines = 2,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Surface(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .fillMaxWidth()
                    .padding(10.dp),
                shape = RoundedCornerShape(22.dp),
                color = Color(0xFF28243C).copy(alpha = 0.62f)
            ) {
                Row(
                    modifier = Modifier.padding(start = 16.dp, end = 10.dp, top = 10.dp, bottom = 10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(
                        modifier = Modifier
                            .weight(1f)
                            .clickable { onAlbumClick(album) }
                    ) {
                        Text(
                            text = album.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                        val count = if (albumSongs.isNotEmpty()) albumSongs.size else album.numberOfSongs
                        val year = if (album.year > 0) " \u00B7 ${album.year}" else ""
                        Text(
                            text = "${album.artist} \u00B7 $count songs$year",
                            style = MaterialTheme.typography.bodySmall,
                            color = Color.White.copy(alpha = 0.75f),
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(Color.White)
                            .clickable { albumSongs.firstOrNull()?.let(onSongClick) ?: onAlbumClick(album) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(modifier = Modifier.size(24.dp), icon = RhythmIcons.Play, contentDescription = "Play", tint = Color(0xFF1B1B1D), size = 24.dp)
                    }
                }
            }
        }
    }
}
