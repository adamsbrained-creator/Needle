/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.shared.presentation.components.player

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Song

@Composable
fun MiniPlayer(
    song: Song?,
    isPlaying: Boolean,
    progress: () -> Float,
    onPlayPause: () -> Unit,
    onPlayerClick: () -> Unit,
    onSkipNext: () -> Unit,
    modifier: Modifier = Modifier,
    onSkipPrevious: () -> Unit = {},
    onDismiss: () -> Unit = {},
    isMediaLoading: Boolean = false,
    verticalDragEnabled: Boolean = true
) {
    val context = LocalContext.current
    val appSettings = remember { AppSettings.getInstance(context) }
    val miniPlayerThemeId by appSettings.miniPlayerThemeId.collectAsState()

    if (miniPlayerThemeId == "EXPRESSIVE") {
        ExpressiveMiniPlayer(
            song = song,
            isPlaying = isPlaying,
            progress = progress,
            onPlayPause = onPlayPause,
            onPlayerClick = onPlayerClick,
            onSkipNext = onSkipNext,
            onSkipPrevious = onSkipPrevious,
            onDismiss = onDismiss,
            isMediaLoading = isMediaLoading,
            verticalDragEnabled = verticalDragEnabled,
            modifier = modifier
        )
    } else {
        MaterialMiniPlayer(
            song = song,
            isPlaying = isPlaying,
            progress = progress,
            onPlayPause = onPlayPause,
            onPlayerClick = onPlayerClick,
            onSkipNext = onSkipNext,
            onSkipPrevious = onSkipPrevious,
            onDismiss = onDismiss,
            isMediaLoading = isMediaLoading,
            verticalDragEnabled = verticalDragEnabled,
            modifier = modifier
        )
    }
}
