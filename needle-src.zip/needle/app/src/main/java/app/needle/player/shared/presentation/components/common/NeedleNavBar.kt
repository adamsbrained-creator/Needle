package app.needle.player.shared.presentation.components.common

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandHorizontally
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.scaleIn
import androidx.compose.animation.scaleOut
import androidx.compose.animation.shrinkHorizontally
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.compositionLocalOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.ui.theme.MusicDimensions
import kotlin.math.abs
import kotlin.math.roundToInt

/** One destination in the Needle navigation pill. */
data class NeedleNavItem(
    val route: String,
    val label: String,
    val selectedIcon: MaterialSymbolIcon,
    val icon: MaterialSymbolIcon,
    val selected: Boolean
)

/**
 * The three looks of Needle's bottom dock, matching the mockup pack:
 *  - PILL: nothing is playing, a plain glass pill with the round nav buttons
 *  - DOCK: the mini player and the nav buttons share one glass card (the card itself is drawn by
 *    [NeedleDockBackdrop], so the pill draws no background of its own)
 *  - SMALL: buttons only, the mini player is folded into a round cover button on the right
 */
enum class NeedleDockMode { PILL, DOCK, SMALL }

/** Lets the mini player fold the dock into [NeedleDockMode.SMALL]. Null when there is no dock. */
class NeedleDockController(
    val small: Boolean,
    val setSmall: (Boolean) -> Unit
)

val LocalNeedleDockController = compositionLocalOf<NeedleDockController?> { null }

/** True while the mini player and the nav pill are drawn together as one glass dock. */
val LocalNeedleDocked = compositionLocalOf { false }

/**
 * Glass look shared by the pill and the dock card: a translucent two-tone fill, a soft sheen from
 * the top, a light rim and a tinted glow. Compose can't blur what is behind a view, so the fill is
 * kept slightly see-through instead. Colors come from the caller so this stays a plain modifier.
 */
private fun Modifier.needleGlass(
    shape: Shape,
    startColor: Color,
    endColor: Color,
    glowColor: Color,
    glow: Dp = 16.dp
): Modifier = this
    .shadow(
        elevation = glow,
        shape = shape,
        ambientColor = glowColor,
        spotColor = glowColor
    )
    .clip(shape)
    .background(Brush.linearGradient(listOf(startColor, endColor)))
    .background(
        Brush.verticalGradient(
            listOf(Color.White.copy(alpha = 0.10f), Color.Transparent),
            endY = 140f
        )
    )
    .border(
        1.dp,
        Brush.linearGradient(
            listOf(Color.White.copy(alpha = 0.24f), Color.White.copy(alpha = 0.05f))
        ),
        shape
    )

/**
 * Needle's floating navigation pill: a row of round icon buttons where the selected one is a
 * bright circle that slides to the new item. The caller decides which items exist and which one
 * is selected, and which [mode] the dock is in.
 */
@Composable
fun NeedleNavPill(
    items: List<NeedleNavItem>,
    onItemClick: (NeedleNavItem) -> Unit,
    modifier: Modifier = Modifier,
    mode: NeedleDockMode = NeedleDockMode.PILL,
    cover: (@Composable () -> Unit)? = null,
    onCoverClick: () -> Unit = {}
) {
    val barHeight = MusicDimensions.bottomNavigationHeight
    val small = mode == NeedleDockMode.SMALL
    val docked = mode == NeedleDockMode.DOCK

    // Sizes follow the mode: the small dock is a little more compact.
    val itemSize by animateDpAsState(
        targetValue = if (small) barHeight - 16.dp else barHeight - 12.dp,
        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "needle_nav_item_size"
    )
    val iconSize by animateDpAsState(
        targetValue = if (small) 22.dp else 24.dp,
        animationSpec = spring(stiffness = Spring.StiffnessMediumLow),
        label = "needle_nav_icon_size"
    )
    val gap = 2.dp

    val selectedIndex = items.indexOfFirst { it.selected }
    var lastIndex by remember { mutableIntStateOf(0) }
    if (selectedIndex >= 0) lastIndex = selectedIndex
    val indicatorIndex by animateFloatAsState(
        targetValue = lastIndex.toFloat(),
        animationSpec = spring(dampingRatio = 0.72f, stiffness = Spring.StiffnessMedium),
        label = "needle_nav_indicator_index"
    )
    val indicatorAlpha by animateFloatAsState(
        targetValue = if (selectedIndex >= 0) 1f else 0f,
        animationSpec = tween(200),
        label = "needle_nav_indicator_alpha"
    )
    val density = LocalDensity.current
    val stride = with(density) { (itemSize + gap).toPx() }
    // The indicator stretches a little while it travels, so it reads as one fluid blob.
    val travel = abs(indicatorIndex - lastIndex).coerceIn(0f, 1f)

    val scheme = MaterialTheme.colorScheme
    val outerModifier = if (docked) {
        modifier.height(barHeight)
    } else {
        modifier
            .height(barHeight)
            .needleGlass(
                shape = CircleShape,
                startColor = scheme.primaryContainer.copy(alpha = 0.88f),
                endColor = scheme.surfaceContainerHigh.copy(alpha = 0.92f),
                glowColor = scheme.primary,
                glow = if (small) 14.dp else 10.dp
            )
    }

    Row(
        modifier = outerModifier
            .animateContentSize(
                animationSpec = spring(dampingRatio = Spring.DampingRatioLowBouncy, stiffness = Spring.StiffnessMediumLow)
            )
            .padding(horizontal = 6.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(2.dp)
    ) {
        Box(contentAlignment = Alignment.CenterStart) {
            // Sliding bright circle behind the selected button
            Box(
                modifier = Modifier
                    .offset { IntOffset((indicatorIndex * stride).roundToInt(), 0) }
                    .size(itemSize)
                    .graphicsLayer {
                        alpha = indicatorAlpha
                        scaleX = 1f + travel * 0.22f
                    }
                    .shadow(
                        elevation = 8.dp,
                        shape = CircleShape,
                        ambientColor = Color.White.copy(alpha = 0.25f),
                        spotColor = Color.White.copy(alpha = 0.25f)
                    )
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.onSurface)
            )
            Row(horizontalArrangement = Arrangement.spacedBy(gap)) {
                items.forEach { item ->
                    val tint by animateColorAsState(
                        targetValue = if (item.selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurfaceVariant,
                        animationSpec = tween(220),
                        label = "needle_nav_tint_" + item.label
                    )
                    Box(
                        modifier = Modifier
                            .size(itemSize)
                            .clip(CircleShape)
                            .clickable { onItemClick(item) },
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            icon = if (item.selected) item.selectedIcon else item.icon,
                            contentDescription = item.label,
                            tint = tint,
                            size = iconSize
                        )
                    }
                }
            }
        }

        // Round cover button that brings the mini player back (small mode only)
        AnimatedVisibility(
            visible = small && cover != null,
            enter = expandHorizontally(spring(stiffness = Spring.StiffnessMediumLow)) +
                fadeIn(tween(200)) + scaleIn(initialScale = 0.6f),
            exit = shrinkHorizontally(spring(stiffness = Spring.StiffnessMediumLow)) +
                fadeOut(tween(150)) + scaleOut(targetScale = 0.6f)
        ) {
            Row {
                Box(modifier = Modifier.width(4.dp))
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .shadow(
                            elevation = 10.dp,
                            shape = CircleShape,
                            ambientColor = MaterialTheme.colorScheme.primary,
                            spotColor = MaterialTheme.colorScheme.primary
                        )
                        .clip(CircleShape)
                        .border(2.dp, Color.White.copy(alpha = 0.75f), CircleShape)
                        .clickable { onCoverClick() },
                    contentAlignment = Alignment.Center
                ) {
                    cover?.invoke()
                }
                Box(modifier = Modifier.width(2.dp))
            }
        }
    }
}

/**
 * The glass card behind the mini player and the nav pill. When it is visible, the mini player and
 * the pill draw without their own backgrounds, so the two read as a single dock. Its height
 * follows the mini player smoothly.
 */
@Composable
fun NeedleDockBackdrop(
    visible: Boolean,
    bottomInset: Dp,
    height: Dp,
    modifier: Modifier = Modifier
) {
    val shape = RoundedCornerShape(34.dp)
    val scheme = MaterialTheme.colorScheme
    val animatedHeight by animateDpAsState(
        targetValue = height,
        animationSpec = spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMediumLow),
        label = "needle_dock_height"
    )
    AnimatedVisibility(
        visible = visible,
        modifier = modifier,
        enter = fadeIn(tween(260)) + scaleIn(initialScale = 0.94f, animationSpec = spring(stiffness = Spring.StiffnessMediumLow)),
        exit = fadeOut(tween(200)) + scaleOut(targetScale = 0.94f)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp)
                .padding(bottom = bottomInset)
                .height(animatedHeight)
                .needleGlass(
                    shape = shape,
                    startColor = scheme.primaryContainer.copy(alpha = 0.90f),
                    endColor = scheme.surfaceContainerHigh.copy(alpha = 0.92f),
                    glowColor = scheme.primary,
                    glow = 16.dp
                )
        )
    }
}
