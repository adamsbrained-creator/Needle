package app.needle.player.shared.presentation.components.common

import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.ui.theme.MusicDimensions

/** One destination in the Needle navigation pill. */
data class NeedleNavItem(
    val route: String,
    val label: String,
    val selectedIcon: MaterialSymbolIcon,
    val icon: MaterialSymbolIcon,
    val selected: Boolean
)

/**
 * Needle's floating navigation pill: a row of round icon buttons where the selected one is a
 * bright circle. The caller decides which items exist and which one is selected.
 */
@Composable
fun NeedleNavPill(
    items: List<NeedleNavItem>,
    onItemClick: (NeedleNavItem) -> Unit,
    modifier: Modifier = Modifier
) {
    val barHeight = MusicDimensions.bottomNavigationHeight
    Surface(
        modifier = modifier.height(barHeight),
        shape = CircleShape,
        color = MaterialTheme.colorScheme.surfaceContainerHigh,
        tonalElevation = 0.dp,
        shadowElevation = 8.dp
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            items.forEach { item ->
                val background by animateColorAsState(
                    targetValue = if (item.selected) MaterialTheme.colorScheme.onSurface else Color.Transparent,
                    animationSpec = tween(250),
                    label = "needle_nav_bg_" + item.label
                )
                val tint by animateColorAsState(
                    targetValue = if (item.selected) MaterialTheme.colorScheme.surface else MaterialTheme.colorScheme.onSurfaceVariant,
                    animationSpec = tween(250),
                    label = "needle_nav_tint_" + item.label
                )
                Box(
                    modifier = Modifier
                        .size(barHeight - 12.dp)
                        .clip(CircleShape)
                        .background(background)
                        .clickable { onItemClick(item) },
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        icon = if (item.selected) item.selectedIcon else item.icon,
                        contentDescription = item.label,
                        tint = tint,
                        size = 24.dp
                    )
                }
            }
        }
    }
}
