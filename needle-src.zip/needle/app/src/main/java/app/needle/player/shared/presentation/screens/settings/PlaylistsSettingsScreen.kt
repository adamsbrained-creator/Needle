/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package app.needle.player.shared.presentation.screens.settings




import app.needle.player.ui.LocalMiniPlayerPadding
import androidx.compose.foundation.layout.PaddingValues
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.Icon

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import app.needle.player.R
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.*
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Slider
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.res.pluralStringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.player.BuildConfig
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Playlist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.data.repository.PlaybackStatsRepository
import app.needle.player.shared.data.repository.StatsTimeRange
import app.needle.player.util.GsonUtils
import app.needle.player.util.HapticUtils
import app.needle.player.util.HapticType
import app.needle.player.util.safeGetQuantityString
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import kotlin.system.exitProcess
import app.needle.player.shared.presentation.components.common.CollapsibleHeaderScreen
import app.needle.player.shared.presentation.components.common.ButtonGroupStyle
import app.needle.player.shared.presentation.components.common.ExpressiveScrollBar
import app.needle.player.shared.presentation.components.common.ExpressiveButtonGroup
import app.needle.player.shared.presentation.components.common.ExpressiveGroupButton
import app.needle.player.shared.presentation.components.bottomsheets.StandardBottomSheetHeader
import app.needle.player.shared.presentation.components.common.StyledProgressBar
import app.needle.player.shared.presentation.components.common.ProgressStyle
import app.needle.player.shared.presentation.components.common.ThumbStyle
import app.needle.player.shared.presentation.components.bottomsheets.LicensesBottomSheet
import app.needle.player.shared.presentation.components.bottomsheets.UpdateBottomSheet
import app.needle.player.ui.utils.LazyListStateSaver
import app.needle.player.features.local.presentation.viewmodel.MusicViewModel
import app.needle.player.shared.presentation.components.common.ExpressiveShapeProvider
import app.needle.player.shared.presentation.components.common.ExpressiveShapes
import app.needle.player.shared.presentation.components.common.buildSplashBackdropShapes
import app.needle.player.shared.presentation.components.common.SplashBackgroundOrbs
import app.needle.player.shared.presentation.viewmodel.AppUpdaterViewModel
import app.needle.player.shared.presentation.viewmodel.AppVersion
import app.needle.player.ui.theme.getFontPreviewStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.io.File
import app.needle.player.utils.FontLoader
import app.needle.player.ui.theme.parseCustomColorScheme
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.TextView
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.core.text.HtmlCompat
import app.needle.player.shared.presentation.components.common.M3FourColorCircularLoader
import app.needle.player.shared.presentation.components.player.PlayingEqIcon
import app.needle.player.shared.presentation.components.dialogs.CreatePlaylistDialog
import app.needle.player.shared.presentation.components.dialogs.BulkPlaylistExportDialog
import app.needle.player.shared.presentation.components.dialogs.PlaylistImportDialog
import app.needle.player.shared.presentation.components.common.rememberExpressiveShape
import app.needle.player.shared.presentation.components.dialogs.PlaylistOperationProgressDialog
import app.needle.player.shared.presentation.components.dialogs.PlaylistOperationResultDialog
import app.needle.player.shared.presentation.components.dialogs.AppRestartDialog
import app.needle.player.shared.presentation.components.player.PlayerChipOrderBottomSheet
import app.needle.player.features.local.presentation.components.settings.HomeSectionOrderBottomSheet
import app.needle.player.features.local.presentation.components.settings.LibraryTabOrderBottomSheet
import app.needle.player.shared.presentation.components.Material3SettingsGroup
import app.needle.player.shared.presentation.components.Material3SettingsItem

import app.needle.player.shared.presentation.screens.settings.TunerSettingRow
import app.needle.player.shared.presentation.screens.settings.TunerAnimatedSwitch
import app.needle.player.shared.presentation.screens.settings.TunerSettingCard
import app.needle.player.shared.presentation.screens.settings.SettingItem
import app.needle.player.shared.presentation.screens.settings.SettingGroup


@Composable
fun PlaylistsSettingsScreen(
    onBackClick: () -> Unit,
    onNavigateTo: (String) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current
    val appSettings = AppSettings.getInstance(context)
    val musicViewModel: MusicViewModel = viewModel()
    val playlists by musicViewModel.playlists.collectAsState()
    val defaultPlaylistsEnabled by appSettings.defaultPlaylistsEnabled.collectAsState()

    val defaultPlaylists = playlists.filter { it.isDefault }
    val userPlaylists = playlists.filter { !it.isDefault }
    val emptyPlaylists = playlists.filter { !it.isDefault && it.songs.isEmpty() }

    var showCreatePlaylistDialog by remember { mutableStateOf(false) }
    var playlistToDelete by remember { mutableStateOf<Playlist?>(null) }
    var showBulkExportDialog by remember { mutableStateOf(false) }
    var showImportDialog by remember { mutableStateOf(false) }
    var showOperationProgress by remember { mutableStateOf(false) }
    var operationProgressText by remember { mutableStateOf("") }
    var showCleanupConfirmDialog by remember { mutableStateOf(false) }
    var showRestartDialog by remember { mutableStateOf(false) }

    val settingGroups = listOf(
        SettingGroup(
            title = context.getString(R.string.settings_playlists_overview),
            items = listOf() // Empty items - we'll add the stat card separately
        ),
        SettingGroup(
            title = context.getString(R.string.settings_playlists_management),
            items = listOf(
                SettingItem(
                    MaterialSymbolIcon("add_circle"),
                    context.getString(R.string.settings_create_new_playlist),
                    context.getString(R.string.settings_create_new_playlist_desc),
                    onClick = {
                        HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                        showCreatePlaylistDialog = true
                    }
                ),
                SettingItem(
                    MaterialSymbolIcon("upload"),
                    context.getString(R.string.settings_import_playlists),
                    context.getString(R.string.settings_import_playlists_desc),
                    onClick = {
                        HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                        showImportDialog = true
                    }
                ),
                SettingItem(
                    RhythmIcons.Download,
                    context.getString(R.string.settings_export_all_playlists),
                    context.getString(R.string.settings_export_all_playlists_desc),
                    onClick = {
                        HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                        showBulkExportDialog = true
                    }
                )
            ) + if (emptyPlaylists.isNotEmpty()) listOf(
                SettingItem(
                    RhythmIcons.Delete,
                    context.getString(R.string.settings_cleanup_empty_playlists),
                    pluralStringResource(R.plurals.settings_cleanup_empty_playlists_desc, emptyPlaylists.size, emptyPlaylists.size),
                    onClick = {
                        HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                        showCleanupConfirmDialog = true
                    }
                )
            ) else emptyList()
        ),
        SettingGroup(
            title = context.getString(R.string.settings_default_playlists),
            items = listOf(
                SettingItem(
                    RhythmIcons.Library,
                    context.getString(R.string.settings_default_playlists),
                    if (defaultPlaylistsEnabled) {
                        "${defaultPlaylists.size} active"
                    } else {
                        context.getString(R.string.status_disabled)
                    },
                    onClick = {
                        HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                        onNavigateTo(SettingsRoutes.DEFAULT_PLAYLISTS)
                    }
                )
            ) + (if (defaultPlaylists.isNotEmpty()) {
                defaultPlaylists.map { playlist ->
                    SettingItem(
                        icon = null,
                        title = playlist.name,
                        description = "${playlist.songs.size} songs",
                        onClick = null,
                        data = playlist.id
                    )
                }
            } else {
                listOf(
                    SettingItem(
                        icon = null,
                        title = context.getString(R.string.settings_no_default_playlists),
                        description = context.getString(R.string.settings_no_default_playlists_desc),
                        onClick = null
                    )
                )
            })
        ),
        SettingGroup(
            title = context.getString(R.string.settings_my_playlists),
            items = if (userPlaylists.isNotEmpty()) {
                userPlaylists.map { playlist ->
                    SettingItem(
                        icon = null,
                        title = playlist.name,
                        description = "${playlist.songs.size} songs",
                        onClick = null,
                        data = playlist.id
                    )
                }
            } else {
                listOf(
                    SettingItem(
                        icon = null,
                        title = context.getString(R.string.settings_no_custom_playlists),
                        description = context.getString(R.string.settings_no_custom_playlists_desc),
                        onClick = {
                            HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                            showCreatePlaylistDialog = true
                        }
                    )
                )
            }
        )
    )

    CollapsibleHeaderScreen(
        title = context.getString(R.string.settings_playlists),
        showBackButton = true,
        onBackClick = {
            HapticUtils.performHapticFeedback(context, haptic, HapticType.HEAVY)
            onBackClick()
        }
    ) { modifier ->
        val lazyListState = rememberSaveable(
            saver = LazyListStateSaver
        ) {
            androidx.compose.foundation.lazy.LazyListState()
        }

        LazyColumn(
            contentPadding = PaddingValues(bottom = 24.dp + LocalMiniPlayerPadding.current.calculateBottomPadding()),
            state = lazyListState,
            modifier = modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Collection Statistics Card
            item {
                Spacer(modifier = Modifier.height(24.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(
                            topStart = 24.dp,
                            bottomStart = 24.dp,
                            topEnd = 6.dp,
                            bottomEnd = 6.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.primaryContainer
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${playlists.size}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = context.getString(R.string.settings_total),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(6.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.secondaryContainer
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${userPlaylists.size}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = context.getString(R.string.settings_custom),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                    Card(
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(
                            topStart = 6.dp,
                            bottomStart = 6.dp,
                            topEnd = 24.dp,
                            bottomEnd = 24.dp
                        ),
                        colors = CardDefaults.cardColors(
                            containerColor = MaterialTheme.colorScheme.tertiaryContainer
                        )
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "${defaultPlaylists.size}",
                                style = MaterialTheme.typography.headlineMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = context.getString(R.string.settings_default),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }
                }
            }

            items(settingGroups.filter { it.title != context.getString(R.string.settings_playlists_overview) }) { group ->
                Spacer(modifier = Modifier.height(24.dp))

                val isDefaultPlaylistGroup =
                    group.title == context.getString(R.string.settings_default_playlists)
                val isPlaylistRowsGroup =
                    isDefaultPlaylistGroup ||
                        group.title == context.getString(R.string.settings_my_playlists)

                val materialItems = if (isPlaylistRowsGroup) {
                    group.items.map { item ->
                        val playlistId = item.data as? String
                        val playlist = playlists.find { it.id == playlistId }

                        if (item.onClick != null || item.toggleState != null || playlistId == null) {
                            toMaterial3SettingsItem(
                                context = context,
                                item = item,
                                hapticFeedback = haptic
                            )
                        } else {
                            Material3SettingsItem(
                                icon = item.icon,
                                title = { Text(item.title) },
                                description = item.description?.let { desc -> { Text(desc) } },
                                trailingContent = if (!isDefaultPlaylistGroup && playlist != null) {
                                    {
                                        IconButton(
                                            onClick = {
                                                HapticUtils.performHapticFeedback(context, haptic, HapticType.HEAVY)
                                                playlistToDelete = playlist
                                            }
                                        ) {
                                            Icon(
                                                imageVector = RhythmIcons.Delete,
                                                contentDescription = context.getString(R.string.dialog_delete),
                                                tint = MaterialTheme.colorScheme.error,
                                                modifier = Modifier.size(20.dp)
                                            )
                                        }
                                    }
                                } else {
                                    null
                                },
                                onClick = item.onClick
                            )
                        }
                    }
                } else {
                    group.items.map { item ->
                        toMaterial3SettingsItem(
                            context = context,
                            item = item,
                            hapticFeedback = haptic
                        )
                    }
                }

                Material3SettingsGroup(
                    title = group.title,
                    items = materialItems,
                    containerColor = MaterialTheme.colorScheme.surfaceContainer
                )
            }
        }
    }

    // Dialogs
    if (showCreatePlaylistDialog) {
        CreatePlaylistDialog(
            onDismiss = { showCreatePlaylistDialog = false },
            onConfirm = { name ->
                musicViewModel.createPlaylist(name)
                showCreatePlaylistDialog = false
            }
        )
    }

    if (showBulkExportDialog) {
        BulkPlaylistExportDialog(
            playlistCount = playlists.size,
            onDismiss = { showBulkExportDialog = false },
            onExport = { format, includeDefault ->
                showBulkExportDialog = false
                showOperationProgress = true
                operationProgressText = context.getString(R.string.operation_exporting_playlists)
                musicViewModel.exportAllPlaylists(format, includeDefault) { result ->
                    showOperationProgress = false
                }
            },
            onExportToCustomLocation = { format, includeDefault, directoryUri ->
                showBulkExportDialog = false
                showOperationProgress = true
                operationProgressText = context.getString(R.string.operation_exporting_playlists_location)
                musicViewModel.exportAllPlaylists(format, includeDefault, directoryUri) { result ->
                    showOperationProgress = false
                }
            }
        )
    }

    if (showImportDialog) {
        PlaylistImportDialog(
            onDismiss = { showImportDialog = false },
            onImport = { uri, onResult, _ ->
                showImportDialog = false
                showOperationProgress = true
                operationProgressText = context.getString(R.string.operation_importing_playlist)
                musicViewModel.importPlaylist(uri, onResult) {
                    // When import completes successfully, show restart dialog
                    showOperationProgress = false
                    showRestartDialog = true
                }
            }
        )
    }

    if (showOperationProgress) {
        PlaylistOperationProgressDialog(
            operation = operationProgressText,
            onDismiss = { /* Cannot dismiss during operation */ }
        )
    }

    if (showCleanupConfirmDialog) {
        val emptyCount = emptyPlaylists.size
        AlertDialog(
            onDismissRequest = { showCleanupConfirmDialog = false },
            icon = {
                Icon(
                    imageVector = RhythmIcons.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = context.getString(R.string.dialog_cleanup_empty_playlists_title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Text(pluralStringResource(R.plurals.dialog_cleanup_empty_playlists_message, emptyCount, emptyCount))
            },
            confirmButton = {
                Button(
                    onClick = {
                        emptyPlaylists.forEach { playlist ->
                            musicViewModel.deletePlaylist(playlist.id)
                        }
                        showCleanupConfirmDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Icon(
                        imageVector = RhythmIcons.Delete,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(context.getString(R.string.dialog_delete))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showCleanupConfirmDialog = false }) {
                    Icon(
                        imageVector = RhythmIcons.Close,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(context.getString(R.string.dialog_cancel))
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }

    // App Restart Dialog for default playlists toggle
    if (showRestartDialog) {
        AppRestartDialog(
            onDismiss = { showRestartDialog = false },
            onRestart = {
                showRestartDialog = false
                app.needle.player.util.AppRestarter.restartApp(context)
            },
            onContinue = {
                showRestartDialog = false
                // Continue without restart
            }
        )
    }

    playlistToDelete?.let { playlist ->
        AlertDialog(
            onDismissRequest = { playlistToDelete = null },
            icon = {
                Icon(
                    imageVector = RhythmIcons.Delete,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.error,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = context.getString(R.string.dialog_delete_playlist_title),
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold
                )
            },
            text = { Text(context.getString(R.string.dialog_delete_playlist_message, playlist.name)) },
            confirmButton = {
                Button(
                    onClick = {
                        musicViewModel.deletePlaylist(playlist.id)
                        playlistToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = MaterialTheme.colorScheme.error,
                        contentColor = MaterialTheme.colorScheme.onError
                    )
                ) {
                    Icon(
                        imageVector = RhythmIcons.Delete,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(context.getString(R.string.dialog_delete))
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { playlistToDelete = null }) {
                    Icon(
                        imageVector = RhythmIcons.Close,
                        contentDescription = null,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(context.getString(R.string.dialog_cancel))
                }
            },
            shape = RoundedCornerShape(24.dp)
        )
    }
}