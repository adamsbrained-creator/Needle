/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

@file:OptIn(ExperimentalMaterial3Api::class, ExperimentalMaterial3ExpressiveApi::class)

package app.needle.player.shared.presentation.screens.settings

import app.needle.player.shared.presentation.components.bottomsheets.AdaptiveSheetScrollContainer
import app.needle.player.shared.presentation.components.bottomsheets.RhythmAdaptiveModalSheet
import app.needle.player.shared.presentation.components.bottomsheets.SheetAdaptiveType
import app.needle.player.shared.presentation.components.bottomsheets.groupedBottomSheetItemShape



import app.needle.player.ui.LocalMiniPlayerPadding
import androidx.compose.foundation.layout.PaddingValues
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.Icon

import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.DocumentsContract
import android.util.Log
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.animation.core.Spring
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import app.needle.player.R
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.GridItemSpan
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.border
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.material3.*
import androidx.compose.material3.CircularWavyProgressIndicator
import androidx.compose.material3.LinearWavyProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3ExpressiveApi
import androidx.compose.material3.Slider
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.runtime.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.luminance
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.graphics.vector.rememberVectorPainter
import androidx.compose.ui.hapticfeedback.HapticFeedback
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import app.needle.player.BuildConfig
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Playlist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.data.repository.PlaybackStatsRepository
import app.needle.player.shared.data.repository.StatsTimeRange
import app.needle.player.util.GsonUtils
import app.needle.player.util.HapticUtils
import app.needle.player.util.HapticType
import coil.compose.AsyncImage
import coil.compose.rememberAsyncImagePainter
import coil.request.ImageRequest
import kotlin.system.exitProcess
import app.needle.player.shared.presentation.components.common.CollapsibleHeaderScreen
import app.needle.player.shared.presentation.components.common.ButtonGroupStyle
import app.needle.player.shared.presentation.components.common.ExpressiveScrollBar
import app.needle.player.shared.presentation.components.common.ExpressiveButtonGroup
import app.needle.player.shared.presentation.components.common.ExpressiveGroupButton
import app.needle.player.shared.presentation.components.bottomsheets.StandardBottomSheetHeader
import app.needle.player.shared.presentation.components.common.StyledProgressBar
import app.needle.player.shared.presentation.components.common.ProgressStyle
import app.needle.player.shared.presentation.components.common.ThumbStyle
import app.needle.player.shared.presentation.components.bottomsheets.LicensesBottomSheet
import app.needle.player.shared.presentation.components.bottomsheets.UpdateBottomSheet
import app.needle.player.ui.utils.LazyListStateSaver
import app.needle.player.features.local.presentation.viewmodel.MusicViewModel
import app.needle.player.shared.presentation.components.common.ExpressiveShapeProvider
import app.needle.player.shared.presentation.components.common.ExpressiveShapes
import app.needle.player.shared.presentation.components.common.buildSplashBackdropShapes
import app.needle.player.shared.presentation.components.common.SplashBackgroundOrbs
import app.needle.player.shared.presentation.viewmodel.AppUpdaterViewModel
import app.needle.player.shared.presentation.viewmodel.AppVersion
import app.needle.player.ui.theme.getFontPreviewStyle
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.MainScope
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.io.File
import app.needle.player.utils.FontLoader
import app.needle.player.ui.theme.parseCustomColorScheme
import androidx.compose.ui.viewinterop.AndroidView
import android.widget.TextView
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.core.text.HtmlCompat
import app.needle.player.shared.presentation.components.common.M3FourColorCircularLoader
import app.needle.player.shared.presentation.components.player.PlayingEqIcon
import app.needle.player.shared.presentation.components.dialogs.CreatePlaylistDialog
import app.needle.player.shared.presentation.components.dialogs.BulkPlaylistExportDialog
import app.needle.player.shared.presentation.components.dialogs.PlaylistImportDialog
import app.needle.player.shared.presentation.components.common.rememberExpressiveShape
import app.needle.player.shared.presentation.components.dialogs.PlaylistOperationProgressDialog
import app.needle.player.shared.presentation.components.dialogs.PlaylistOperationResultDialog
import app.needle.player.shared.presentation.components.dialogs.AppRestartDialog
import app.needle.player.shared.presentation.components.player.PlayerChipOrderBottomSheet
import app.needle.player.features.local.presentation.components.settings.HomeSectionOrderBottomSheet
import app.needle.player.features.local.presentation.components.settings.LibraryTabOrderBottomSheet
import app.needle.player.shared.presentation.components.Material3SettingsGroup
import app.needle.player.shared.presentation.components.Material3SettingsItem

import app.needle.player.shared.presentation.screens.settings.TunerSettingRow
import app.needle.player.shared.presentation.screens.settings.TunerAnimatedSwitch
import app.needle.player.shared.presentation.screens.settings.TunerSettingCard
import app.needle.player.shared.presentation.screens.settings.SettingItem
import app.needle.player.shared.presentation.screens.settings.SettingGroup


// Color Source and Font Source Dialogs for Theme Customization
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ColorSourceDialog(
    showDialog: Boolean,
    onDismiss: () -> Unit,
    selectedColorSource: ColorSource,
    onColorSourceSelected: (ColorSource) -> Unit,
    appSettings: AppSettings,
    context: Context,
    haptic: HapticFeedback
) {
    if (showDialog) {
        val sheetState = rememberBottomSheetState(initialValue = SheetValue.Hidden, enabledValues = setOf(SheetValue.Hidden, SheetValue.Expanded))

        RhythmAdaptiveModalSheet(
            adaptiveType = SheetAdaptiveType.COMPACT_DIALOG,
            modifier = Modifier.widthIn(max = 640.dp).fillMaxWidth(),
            onDismissRequest = onDismiss,
            sheetState = sheetState,
            dragHandle = {
                BottomSheetDefaults.DragHandle(
                    color = MaterialTheme.colorScheme.primary
                )
            },
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ) {
            StandardBottomSheetHeader(
                title = context.getString(R.string.theme_color_source),
                subtitle = context.getString(R.string.theme_color_source_desc),
                visible = true
            )

            val scrollState = rememberScrollState()

            AdaptiveSheetScrollContainer(
                scrollState = scrollState,
                modifier = Modifier.fillMaxWidth()
            ) { endPadding ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(scrollState)
                        .padding(start = 24.dp, end = 24.dp + endPadding, bottom = 24.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    ColorSource.entries.forEachIndexed { index, source ->
                        val isSelected = selectedColorSource == source
                        Card(
                            onClick = {
                                HapticUtils.performHapticFeedback(context, haptic, HapticType.LIGHT)
                                onColorSourceSelected(source)
                                when (source) {
                                    ColorSource.MONET -> {
                                        appSettings.setUseDynamicColors(true)
                                        appSettings.setColorSource("MONET")
                                    }
                                    ColorSource.ALBUM_ART -> {
                                        appSettings.setUseDynamicColors(false)
                                        appSettings.setColorSource("ALBUM_ART")
                                    }
                                    ColorSource.CUSTOM -> {
                                        appSettings.setUseDynamicColors(false)
                                        appSettings.setColorSource("CUSTOM")
                                    }
                                }
                                onDismiss()
                            },
                            colors = CardDefaults.cardColors(
                                containerColor = if (isSelected)
                                    MaterialTheme.colorScheme.primaryContainer
                                else
                                    MaterialTheme.colorScheme.surfaceContainerHigh
                            ),
                            shape = groupedBottomSheetItemShape(index, ColorSource.entries.size),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(20.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = source.icon,
                                    contentDescription = null,
                                    tint = if (isSelected)
                                        MaterialTheme.colorScheme.onPrimaryContainer
                                    else
                                        MaterialTheme.colorScheme.onSurfaceVariant,
                                    modifier = Modifier.size(if (isSelected) 30.dp else 26.dp)
                                )

                                Spacer(modifier = Modifier.width(16.dp))

                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = source.getDisplayName(context),
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isSelected)
                                            MaterialTheme.colorScheme.onPrimaryContainer
                                        else
                                            MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = source.getDescription(context),
                                        style = MaterialTheme.typography.bodySmall,
                                        color = if (isSelected)
                                            MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                                        else
                                            MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }

                                if (isSelected) {
                                    Icon(
                                        imageVector = RhythmIcons.CheckCircle,
                                        contentDescription = stringResource(R.string.streaming_selected),
                                        tint = MaterialTheme.colorScheme.onPrimaryContainer,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}