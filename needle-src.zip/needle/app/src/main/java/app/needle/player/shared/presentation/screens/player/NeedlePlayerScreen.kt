package app.needle.player.shared.presentation.screens.player

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.player.shared.data.model.LyricsData
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import app.needle.player.network.CanvasArtwork
import app.needle.player.shared.presentation.components.player.CanvasArtworkPlayer
import app.needle.player.shared.presentation.components.player.MorphingPlayPauseButton
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlin.math.roundToInt

/**
 * Needle's Now Playing screen: an animated, glowing player on top and a scroll of info cards below
 * (lyrics preview, about the artist, credits, file details, more from your library).
 */
@Composable
fun NeedlePlayerScreen(
    song: Song?,
    isPlaying: Boolean,
    isFavorite: Boolean,
    progress: () -> Float,
    currentTimeStr: String,
    totalTimeStr: String,
    isShuffleEnabled: Boolean,
    repeatMode: Int,
    lyrics: LyricsData?,
    songs: List<Song>,
    isMediaLoading: Boolean,
    onPlayPause: () -> Unit,
    onSeek: (Float) -> Unit,
    onSkipPrevious: () -> Unit,
    onSkipNext: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onQueueClick: () -> Unit,
    onMoreClick: () -> Unit,
    onDeviceClick: () -> Unit,
    onSongInfoClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onOpenFullScreenLyrics: () -> Unit,
    onSongClick: (Song) -> Unit,
    onBack: () -> Unit,
    canvasArtwork: CanvasArtwork? = null,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val scroll = rememberScrollState()
    val stickyVisible by remember { derivedStateOf { scroll.value > 1100 } }

    BoxWithConstraints(modifier = modifier.fillMaxSize().background(scheme.surfaceContainerLowest)) {
        val topHeight = maxHeight - 56.dp
        Column(modifier = Modifier.fillMaxSize().verticalScroll(scroll)) {
            NeedlePlayerTop(
                song = song,
                isPlaying = isPlaying,
                isFavorite = isFavorite,
                progress = progress,
                currentTimeStr = currentTimeStr,
                totalTimeStr = totalTimeStr,
                isShuffleEnabled = isShuffleEnabled,
                repeatMode = repeatMode,
                isMediaLoading = isMediaLoading,
                onPlayPause = onPlayPause,
                onSeek = onSeek,
                onSkipPrevious = onSkipPrevious,
                onSkipNext = onSkipNext,
                onToggleFavorite = onToggleFavorite,
                onToggleShuffle = onToggleShuffle,
                onToggleRepeat = onToggleRepeat,
                onQueueClick = onQueueClick,
                onMoreClick = onMoreClick,
                onDeviceClick = onDeviceClick,
                onAddToPlaylist = onAddToPlaylist,
                onOpenFullScreenLyrics = onOpenFullScreenLyrics,
                onBack = onBack,
                canvasArtwork = canvasArtwork,
                modifier = Modifier.fillMaxWidth().height(topHeight)
            )
            if (song != null) {
                NeedleLyricsCard(song, lyrics, progress, onOpenFullScreenLyrics)
                NeedleArtistCard(song, songs)
                NeedleCreditsCard(song)
                NeedleFileCard(song, onSongInfoClick)
                NeedleLibraryCard(song, songs, onSongClick)
            }
            Spacer(Modifier.height(32.dp).navigationBarsPadding())
        }

        AnimatedVisibility(
            visible = stickyVisible && song != null,
            modifier = Modifier.align(Alignment.TopCenter),
            enter = fadeIn() + slideInVertically { -it },
            exit = fadeOut() + slideOutVertically { -it }
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(scheme.surfaceContainerLow)
                    .statusBarsPadding()
                    .padding(horizontal = 16.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(LocalContext.current).data(song?.artworkUri).size(128, 128).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(40.dp).clip(RoundedCornerShape(10.dp)).background(scheme.surfaceContainerHigh)
                )
                Column(modifier = Modifier.weight(1f)) {
                    Text(song?.title.orEmpty(), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    Text(song?.artist.orEmpty(), style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        icon = if (isFavorite) RhythmIcons.Actions.Favorite else RhythmIcons.Actions.FavoriteOutlined,
                        contentDescription = null,
                        tint = if (isFavorite) scheme.secondary else scheme.onSurface
                    )
                }
                MorphingPlayPauseButton(
                    isPlaying = isPlaying,
                    onClick = onPlayPause,
                    size = 42.dp,
                    isMediaLoading = isMediaLoading,
                    containerColor = scheme.onSurface,
                    contentColor = scheme.surface,
                    morphToCookie = false
                )
            }
        }
    }
}

@Composable
private fun NeedlePlayerTop(
    song: Song?,
    isPlaying: Boolean,
    isFavorite: Boolean,
    progress: () -> Float,
    currentTimeStr: String,
    totalTimeStr: String,
    isShuffleEnabled: Boolean,
    repeatMode: Int,
    isMediaLoading: Boolean,
    onPlayPause: () -> Unit,
    onSeek: (Float) -> Unit,
    onSkipPrevious: () -> Unit,
    onSkipNext: () -> Unit,
    onToggleFavorite: () -> Unit,
    onToggleShuffle: () -> Unit,
    onToggleRepeat: () -> Unit,
    onQueueClick: () -> Unit,
    onMoreClick: () -> Unit,
    onDeviceClick: () -> Unit,
    onAddToPlaylist: () -> Unit,
    onOpenFullScreenLyrics: () -> Unit,
    onBack: () -> Unit,
    canvasArtwork: CanvasArtwork? = null,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val transition = rememberInfiniteTransition(label = "needle_player_glow")
    val drift by transition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
        label = "drift"
    )
    val bob by transition.animateFloat(
        initialValue = 0f,
        targetValue = 14f,
        animationSpec = infiniteRepeatable(tween(3600, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "bob"
    )
    val glowA = scheme.primary
    val glowB = scheme.secondary
    val glowC = scheme.tertiary
    val base = scheme.surfaceContainerLowest
    val top = scheme.primaryContainer

    Box(modifier = modifier) {
        Canvas(modifier = Modifier.fillMaxSize()) {
            val w = size.width
            val h = size.height
            drawRect(brush = Brush.linearGradient(listOf(top.copy(alpha = 0.55f), base), start = Offset(0f, 0f), end = Offset(w, h)))
            val c1 = Offset(w * (0.1f + 0.3f * drift), h * 0.3f)
            drawCircle(brush = Brush.radialGradient(listOf(glowA.copy(alpha = 0.45f), Color.Transparent), center = c1, radius = w * 0.9f), radius = w * 0.9f, center = c1)
            val c2 = Offset(w * (0.95f - 0.3f * drift), h * 0.55f)
            drawCircle(brush = Brush.radialGradient(listOf(glowB.copy(alpha = 0.3f), Color.Transparent), center = c2, radius = w * 0.8f), radius = w * 0.8f, center = c2)
            val c3 = Offset(w * 0.4f, h * (0.85f - 0.1f * drift))
            drawCircle(brush = Brush.radialGradient(listOf(glowC.copy(alpha = 0.25f), Color.Transparent), center = c3, radius = w * 0.7f), radius = w * 0.7f, center = c3)
            drawRect(brush = Brush.verticalGradient(listOf(Color.Transparent, base), startY = h * 0.85f, endY = h))
        }

        Column(
            modifier = Modifier.fillMaxSize().statusBarsPadding().padding(horizontal = 22.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(modifier = Modifier.fillMaxWidth().height(52.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) {
                    Icon(icon = RhythmIcons.ExpandMore, contentDescription = null, tint = scheme.onSurface, size = 28.dp)
                }
                Text(
                    text = song?.album.orEmpty(),
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.labelLarge,
                    color = scheme.onSurface,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    textAlign = TextAlign.Center
                )
                IconButton(onClick = onMoreClick) {
                    Icon(icon = RhythmIcons.More, contentDescription = null, tint = scheme.onSurface)
                }
            }

            Spacer(Modifier.weight(0.6f))
            Box(
                modifier = Modifier
                    .fillMaxWidth(0.82f)
                    .offset { IntOffset(0, -bob.roundToInt()) }
                    .shadow(24.dp, RoundedCornerShape(18.dp), ambientColor = glowA, spotColor = glowA)
                    .clip(RoundedCornerShape(18.dp))
                    .background(scheme.surfaceContainerHigh)
            ) {
                AsyncImage(
                    model = ImageRequest.Builder(context).data(song?.artworkUri).crossfade(300).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.fillMaxWidth().aspectRatio(1f)
                )
                if (canvasArtwork?.preferredAnimationUrl != null) {
                    CanvasArtworkPlayer(
                        primaryUrl = canvasArtwork.animated,
                        fallbackUrl = canvasArtwork.videoUrl,
                        isPlaying = isPlaying,
                        alwaysPlay = true,
                        modifier = Modifier.matchParentSize()
                    )
                }
            }
            Spacer(Modifier.weight(0.6f))

            Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = song?.title.orEmpty(),
                        style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Default, fontWeight = FontWeight.Bold),
                        color = scheme.onSurface,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = song?.artist.orEmpty(),
                        style = MaterialTheme.typography.titleMedium,
                        color = scheme.onSurfaceVariant,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                }
                IconButton(onClick = onDeviceClick) {
                    Icon(icon = RhythmIcons.Devices.Speaker, contentDescription = null, tint = scheme.onSurface)
                }
            }

            NeedleProgress(progress, currentTimeStr, totalTimeStr, onSeek)

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onQueueClick) {
                    Icon(icon = RhythmIcons.Queue, contentDescription = null, tint = scheme.onSurface, size = 26.dp)
                }
                IconButton(onClick = onSkipPrevious) {
                    Icon(icon = RhythmIcons.SkipPrevious, contentDescription = null, tint = scheme.onSurface, size = 34.dp)
                }
                MorphingPlayPauseButton(
                    isPlaying = isPlaying,
                    onClick = onPlayPause,
                    size = 68.dp,
                    isMediaLoading = isMediaLoading,
                    containerColor = scheme.onSurface,
                    contentColor = scheme.surface,
                    morphToCookie = false
                )
                IconButton(onClick = onSkipNext) {
                    Icon(icon = RhythmIcons.SkipNext, contentDescription = null, tint = scheme.onSurface, size = 34.dp)
                }
                IconButton(onClick = onToggleFavorite) {
                    Icon(
                        icon = if (isFavorite) RhythmIcons.Actions.Favorite else RhythmIcons.Actions.FavoriteOutlined,
                        contentDescription = null,
                        tint = if (isFavorite) scheme.secondary else scheme.onSurface,
                        size = 26.dp
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth().padding(top = 6.dp, bottom = 10.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                IconButton(onClick = onAddToPlaylist) {
                    Icon(icon = RhythmIcons.AddToPlaylist, contentDescription = null, tint = scheme.onSurface)
                }
                IconButton(onClick = onToggleRepeat) {
                    Icon(
                        icon = if (repeatMode == 1) RhythmIcons.RepeatOne else RhythmIcons.Repeat,
                        contentDescription = null,
                        tint = if (repeatMode != 0) scheme.primary else scheme.onSurfaceVariant
                    )
                }
                Surface(
                    onClick = onOpenFullScreenLyrics,
                    shape = CircleShape,
                    color = scheme.onSurface.copy(alpha = 0.14f)
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 22.dp, vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(icon = RhythmIcons.Player.Lyrics, contentDescription = null, tint = scheme.onSurface, size = 20.dp)
                        Text("Text", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold, color = scheme.onSurface)
                    }
                }
                IconButton(onClick = onToggleShuffle) {
                    Icon(
                        icon = RhythmIcons.Shuffle,
                        contentDescription = null,
                        tint = if (isShuffleEnabled) scheme.primary else scheme.onSurfaceVariant
                    )
                }
                Spacer(Modifier.width(0.dp))
            }
        }
    }
}

@Composable
private fun NeedleProgress(
    progress: () -> Float,
    currentTimeStr: String,
    totalTimeStr: String,
    onSeek: (Float) -> Unit
) {
    val scheme = MaterialTheme.colorScheme
    var dragging by remember { mutableStateOf(false) }
    var dragValue by remember { mutableFloatStateOf(0f) }
    val value = if (dragging) dragValue else progress().coerceIn(0f, 1f)
    Column(modifier = Modifier.fillMaxWidth()) {
        Slider(
            value = value,
            onValueChange = {
                dragging = true
                dragValue = it
            },
            onValueChangeFinished = {
                onSeek(dragValue)
                dragging = false
            },
            colors = SliderDefaults.colors(
                thumbColor = scheme.onSurface,
                activeTrackColor = scheme.onSurface,
                inactiveTrackColor = scheme.onSurface.copy(alpha = 0.25f)
            )
        )
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 6.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(currentTimeStr, style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
            Text(totalTimeStr, style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun NeedleCard(
    modifier: Modifier = Modifier,
    color: Color = MaterialTheme.colorScheme.surfaceContainer,
    content: @Composable ColumnScope.() -> Unit
) {
    Surface(
        modifier = modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 7.dp),
        shape = RoundedCornerShape(28.dp),
        color = color
    ) {
        Column(modifier = Modifier.padding(18.dp), content = content)
    }
}

@Composable
private fun NeedleLyricsCard(song: Song, lyrics: LyricsData?, progress: () -> Float, onOpen: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val positionMs = (progress().coerceIn(0f, 1f) * song.duration).toLong()
    val preview = needleLyricPreview(lyrics, positionMs)
    val lines = preview.first
    val current = preview.second
    NeedleCard(color = scheme.primaryContainer.copy(alpha = 0.6f)) {
        Text("Lyrics preview", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, color = scheme.onPrimaryContainer)
        Spacer(Modifier.height(12.dp))
        if (lines.isEmpty()) {
            Text(
                "No lyrics for this song yet. Open the lyrics view to add or import them.",
                style = MaterialTheme.typography.bodyMedium,
                color = scheme.onPrimaryContainer.copy(alpha = 0.8f)
            )
        } else {
            lines.forEachIndexed { index, line ->
                val isCurrent = index == current
                Text(
                    text = line,
                    style = if (isCurrent) {
                        MaterialTheme.typography.headlineSmall.copy(fontSize = 26.sp, lineHeight = 30.sp)
                    } else {
                        MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.SemiBold)
                    },
                    color = if (isCurrent) scheme.onPrimaryContainer else scheme.onPrimaryContainer.copy(alpha = 0.5f),
                    modifier = Modifier.padding(vertical = if (isCurrent) 8.dp else 4.dp)
                )
            }
        }
        Spacer(Modifier.height(14.dp))
        Button(
            onClick = onOpen,
            colors = ButtonDefaults.buttonColors(containerColor = scheme.onSurface, contentColor = scheme.surface)
        ) {
            Text("Show lyrics", fontWeight = FontWeight.SemiBold)
        }
    }
}

@Composable
private fun NeedleArtistCard(song: Song, songs: List<Song>) {
    val scheme = MaterialTheme.colorScheme
    val byArtist = remember(song.artist, songs) { songs.filter { it.artist.equals(song.artist, ignoreCase = true) } }
    val albumCount = remember(byArtist) { byArtist.map { it.album }.distinct().size }
    NeedleCard {
        Text("About the artist", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
        Spacer(Modifier.height(6.dp))
        Text(song.artist, style = MaterialTheme.typography.headlineMedium, color = scheme.onSurface)
        Spacer(Modifier.height(6.dp))
        Text(
            "${byArtist.size} songs in ${albumCount} albums on this phone",
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurfaceVariant
        )
    }
}

@Composable
private fun NeedleCreditsCard(song: Song) {
    NeedleCard {
        Text("Credits", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(8.dp))
        NeedleInfoRow("Artist", song.artist)
        song.albumArtist?.takeIf { it.isNotBlank() && !it.equals(song.artist, ignoreCase = true) }?.let { NeedleInfoRow("Album artist", it) }
        NeedleInfoRow("Album", song.album)
        song.genre?.takeIf { it.isNotBlank() }?.let { NeedleInfoRow("Genre", it) }
        if (song.year > 0) NeedleInfoRow("Year", song.year.toString())
        if (song.trackNumber > 0) NeedleInfoRow("Track", song.trackNumber.toString())
    }
}

@Composable
private fun NeedleFileCard(song: Song, onSongInfoClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    NeedleCard {
        Row(modifier = Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("File details", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, modifier = Modifier.weight(1f))
            Text(
                "All info",
                style = MaterialTheme.typography.labelLarge,
                color = scheme.primary,
                modifier = Modifier.clickable { onSongInfoClick() }
            )
        }
        Spacer(Modifier.height(8.dp))
        val format = song.codec?.takeIf { it.isNotBlank() }
            ?: song.path?.substringAfterLast('.', "")?.uppercase()?.takeIf { it.isNotBlank() }
        format?.let { NeedleInfoRow("Format", it) }
        song.bitrate?.takeIf { it > 0 }?.let { NeedleInfoRow("Bitrate", "${it / 1000} kbps") }
        song.sampleRate?.takeIf { it > 0 }?.let { NeedleInfoRow("Sample rate", String.format("%.1f kHz", it / 1000f)) }
        song.channels?.takeIf { it > 0 }?.let { NeedleInfoRow("Channels", if (it == 1) "Mono" else if (it == 2) "Stereo" else it.toString()) }
        val totalSeconds = song.duration / 1000
        NeedleInfoRow("Length", String.format("%d:%02d", totalSeconds / 60, totalSeconds % 60))
        song.path?.takeIf { it.isNotBlank() }?.let { NeedleInfoRow("File", it.substringAfterLast('/')) }
    }
}

@Composable
private fun NeedleInfoRow(label: String, value: String) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = scheme.onSurfaceVariant)
        Spacer(Modifier.width(16.dp))
        Text(
            value,
            style = MaterialTheme.typography.bodyMedium,
            color = scheme.onSurface,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
    }
}

@Composable
private fun NeedleLibraryCard(song: Song, songs: List<Song>, onSongClick: (Song) -> Unit) {
    val moreFromArtist = remember(song.id, songs) {
        songs.filter { it.id != song.id && it.artist.equals(song.artist, ignoreCase = true) }.take(12)
    }
    val sameGenre = remember(song.id, songs) {
        val genre = song.genre
        if (genre.isNullOrBlank()) emptyList() else songs.filter { it.id != song.id && it.genre.equals(genre, ignoreCase = true) }.take(12)
    }
    if (moreFromArtist.isEmpty() && sameGenre.isEmpty()) return
    NeedleCard {
        Text("From your library", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        if (moreFromArtist.isNotEmpty()) {
            NeedleShelf("More from ${song.artist}", moreFromArtist, onSongClick)
        }
        if (sameGenre.isNotEmpty()) {
            NeedleShelf("More ${song.genre}", sameGenre, onSongClick)
        }
    }
}

@Composable
private fun NeedleShelf(title: String, items: List<Song>, onSongClick: (Song) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    Spacer(Modifier.height(14.dp))
    Text(title, style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
    Spacer(Modifier.height(8.dp))
    Row(modifier = Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        items.forEach { item ->
            Column(modifier = Modifier.width(112.dp).clickable { onSongClick(item) }) {
                AsyncImage(
                    model = ImageRequest.Builder(context).data(item.artworkUri).size(256, 256).build(),
                    contentDescription = null,
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.size(112.dp).clip(RoundedCornerShape(20.dp)).background(scheme.surfaceContainerHigh)
                )
                Text(item.title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
                Text(item.artist, style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
    }
}

private val needleLrcStamp = Regex("\\[(\\d{1,2}):(\\d{2})(?:[.:](\\d{1,3}))?]")

/** Returns the lines to show and which of them is current (-1 when the lyrics are not synced). */
private fun needleLyricPreview(lyrics: LyricsData?, positionMs: Long): Pair<List<String>, Int> {
    val synced = lyrics?.syncedLyrics
    if (!synced.isNullOrBlank()) {
        val entries = ArrayList<Pair<Long, String>>()
        synced.lines().forEach { raw ->
            val stamps = needleLrcStamp.findAll(raw).toList()
            if (stamps.isNotEmpty()) {
                val text = raw.substring(stamps.last().range.last + 1).trim()
                if (text.isNotEmpty()) {
                    stamps.forEach { m ->
                        val minutes = m.groupValues[1].toLong()
                        val seconds = m.groupValues[2].toLong()
                        val fraction = m.groupValues[3]
                        val millis = if (fraction.isEmpty()) 0L else fraction.padEnd(3, '0').take(3).toLong()
                        entries.add(((minutes * 60 + seconds) * 1000 + millis) to text)
                    }
                }
            }
        }
        if (entries.isNotEmpty()) {
            entries.sortBy { it.first }
            var index = entries.indexOfLast { it.first <= positionMs }
            if (index < 0) index = 0
            val from = (index - 2).coerceAtLeast(0)
            val to = (index + 3).coerceAtMost(entries.size)
            return entries.subList(from, to).map { it.second } to (index - from)
        }
    }
    val plain = lyrics?.plainLyrics
    if (!plain.isNullOrBlank()) {
        val lines = plain.lines().map { it.trim() }.filter { it.isNotEmpty() }.take(6)
        return lines to -1
    }
    return emptyList<String>() to -1
}
