package app.needle.player.features.local.presentation.screens

import android.net.Uri
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyListScope
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.player.features.local.presentation.components.NeedleMomentsSection
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Artist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Needle's own Home, built after the mockups: a header, five pills (New, Popular, Moments,
 * Most played, Singles) and shelves made from what is on this phone.
 */
@Composable
fun NeedleHomeScreen(
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    recentlyPlayed: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onNavigateToStats: () -> Unit,
    onViewAllAlbums: () -> Unit,
    onViewAllArtists: () -> Unit,
    onViewAllSongs: () -> Unit,
    modifier: Modifier = Modifier,
    onEditAlbumTags: (Album) -> Unit = onAlbumClick,
    onFixTags: () -> Unit = onViewAllSongs
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val appSettings = remember { AppSettings.getInstance(context) }
    val playCounts by appSettings.songPlayCounts.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(1) }
    val pills = listOf("New", "Popular", "Moments", "Most played", "Singles")

    val songsByAlbum = remember(songs) { songs.groupBy { it.albumId } }
    val albumById = remember(albums) { albums.associateBy { it.id } }
    val albumAddedMillis = remember(songsByAlbum) {
        { album: Album ->
            songsByAlbum[album.id]?.maxOfOrNull { needleMillis(it.dateAdded) } ?: needleMillis(album.dateModified)
        }
    }
    val newestAlbums = remember(albums, songsByAlbum) { albums.sortedByDescending { albumAddedMillis(it) } }
    val needTagsNew = remember(songs) {
        val monthAgo = System.currentTimeMillis() - 30L * 86_400_000L
        songs.count { needleMillis(it.dateAdded) >= monthAgo && (it.genre.isNullOrBlank() || it.artworkUri == null) }
    }
    val singles = remember(songs, songsByAlbum) {
        songsByAlbum.filter { it.value.size == 1 }.values.map { it.first() }.sortedByDescending { it.dateAdded }
    }
    val playedAlbumRatio = remember(albums, songsByAlbum, playCounts) {
        albums.associate { album ->
            val list = songsByAlbum[album.id].orEmpty()
            album.id to Pair(list.count { (playCounts[it.id] ?: 0) > 0 }, list.size)
        }
    }
    val progressAlbums = remember(albums, playedAlbumRatio) {
        albums.filter { (playedAlbumRatio[it.id]?.second ?: 0) > 0 }
            .sortedByDescending { playedAlbumRatio[it.id]?.first ?: 0 }.take(8)
    }
    val rediscover = remember(albums, playedAlbumRatio) {
        albums.filter { (playedAlbumRatio[it.id]?.first ?: 0) == 0 }.take(10)
    }
    val bigCards = remember(recentlyPlayed, albumById, newestAlbums, rediscover) {
        val fromPlays = recentlyPlayed.distinctBy { it.albumId }.mapNotNull { song ->
            albumById[song.albumId]?.let { album ->
                val genre = song.genre?.substringBefore(',')?.trim()?.takeIf { it.isNotBlank() }
                album to (if (genre != null) "Because you play $genre" else "Because you played ${song.artist}")
            }
        }.take(5)
        val seen = fromPlays.map { it.first.id }.toSet()
        val again = rediscover.filter { it.id !in seen }.take(3).map { it to "Rediscover" }
        (fromPlays + again).ifEmpty { newestAlbums.map { it to "New in your library" } }.take(8)
    }
    val favoriteJson by appSettings.favoriteSongs.collectAsState()
    val favoriteIds = remember(favoriteJson) { needleParseIds(favoriteJson) }
    val totalPlays = remember(playCounts) { playCounts.values.sum() }
    val playedSongs = remember(songs, playCounts) { songs.filter { (playCounts[it.id] ?: 0) > 0 } }
    val listenedMs = remember(playedSongs, playCounts) {
        playedSongs.sumOf { (playCounts[it.id] ?: 0).toLong() * it.duration }
    }
    val topGenre = remember(playedSongs, playCounts) {
        playedSongs.filter { !it.genre.isNullOrBlank() }.groupBy { it.genre!!.substringBefore(',').trim() }
            .maxByOrNull { entry -> entry.value.sumOf { playCounts[it.id] ?: 0 } }?.key ?: "None yet"
    }
    val mostPlayed = remember(playedSongs, playCounts) {
        playedSongs.sortedByDescending { playCounts[it.id] ?: 0 }.take(20)
    }
    val maxCount = remember(mostPlayed, playCounts) { mostPlayed.maxOfOrNull { playCounts[it.id] ?: 0 } ?: 1 }

    fun playAlbum(album: Album) {
        val first = songsByAlbum[album.id].orEmpty().minByOrNull { it.trackNumber }
        if (first != null) onSongClick(first) else onAlbumClick(album)
    }

    // The New and Popular pages lay out their own 18dp margins so its shelves can run to the screen edge
    val newTab = tab <= 1 // New and Popular
    val sidePad = if (newTab) 0.dp else 18.dp
    val bleed = if (newTab) 18.dp else 0.dp

    LazyColumn(
        modifier = modifier.fillMaxSize().background(scheme.surfaceContainerLowest).needleHomeGlow(),
        contentPadding = PaddingValues(start = sidePad, end = sidePad, bottom = 220.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(horizontal = bleed, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NeedleRoundButton(onClick = onSearchClick) {
                    Icon(icon = RhythmIcons.Search, contentDescription = "Search", tint = scheme.onSurface, modifier = Modifier.size(22.dp), size = 22.dp)
                }
                Text(
                    text = "Needle",
                    modifier = Modifier.weight(1f),
                    style = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 21.sp),
                    color = scheme.onSurface,
                    textAlign = TextAlign.Center
                )
                NeedleRoundButton(onClick = onSettingsClick) {
                    Icon(icon = RhythmIcons.Settings, contentDescription = "Settings", tint = scheme.onSurface, modifier = Modifier.size(22.dp), size = 22.dp)
                }
            }
        }

        item {
            LazyRow(
                modifier = Modifier.padding(top = 14.dp, bottom = if (newTab) 0.dp else 6.dp),
                contentPadding = PaddingValues(horizontal = bleed),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pills.size) { index ->
                    val selected = index == tab
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) Color.White else scheme.surfaceContainerHigh)
                            .clickable { tab = index }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(
                            text = pills[index],
                            fontSize = 14.sp,
                            fontWeight = if (selected) FontWeight.SemiBold else FontWeight.Normal,
                            color = if (selected) Color(0xFF111111) else scheme.onSurface,
                            maxLines = 1
                        )
                    }
                }
            }
        }

        when (tab) {
            0 -> needleNewTab(
                newestAlbums = newestAlbums,
                singles = singles,
                needTagsNew = needTagsNew,
                currentSong = currentSong,
                trackCount = { album -> songsByAlbum[album.id].orEmpty().size.coerceAtLeast(album.numberOfSongs) },
                addedMillis = albumAddedMillis,
                isUnplayed = { album -> (playedAlbumRatio[album.id]?.first ?: 0) == 0 },
                onPlayAlbum = { album -> playAlbum(album) },
                onAlbumClick = onAlbumClick,
                onEditTags = onEditAlbumTags,
                onSongClick = onSongClick,
                onViewAllAlbums = onViewAllAlbums,
                onViewAllSongs = onViewAllSongs,
                onFixTags = onFixTags
            )
            1 -> needlePopularTab(
                bigCards = bigCards,
                progressAlbums = progressAlbums,
                rediscover = rediscover,
                tracksPlayed = { album -> playedAlbumRatio[album.id] ?: Pair(0, 1) },
                genreOf = { album ->
                    songsByAlbum[album.id].orEmpty()
                        .firstNotNullOfOrNull { it.genre?.substringBefore(',')?.trim()?.takeIf { g -> g.isNotBlank() } } ?: "Album"
                },
                isFavorite = { album -> songsByAlbum[album.id].orEmpty().any { it.id in favoriteIds } },
                listened = needleListened(listenedMs),
                totalPlays = totalPlays,
                topGenre = topGenre,
                onPlayAlbum = { album -> playAlbum(album) },
                onAlbumClick = onAlbumClick,
                onNavigateToStats = onNavigateToStats,
                onViewAllAlbums = onViewAllAlbums
            )
            2 -> {
                item {
                    NeedleMomentsSection(
                        albums = albums,
                        songs = songs,
                        onAlbumClick = onAlbumClick,
                        onSongClick = onSongClick,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
            3 -> {
                if (mostPlayed.isEmpty()) {
                    item { NeedleEmptyNote("Play a few songs and your most played will appear here.") }
                } else {
                    item { NeedleShelfTitle("Most played", "Counted on this phone") }
                    items(mostPlayed.size) { index ->
                        val song = mostPlayed[index]
                        val count = playCounts[song.id] ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text((index + 1).toString(), modifier = Modifier.width(26.dp), style = MaterialTheme.typography.titleMedium, color = if (index == 0) scheme.secondary else scheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            NeedleCover(song.artworkUri, song.title, Modifier.size(50.dp), RoundedCornerShape(13.dp), 160)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (currentSong?.id == song.id) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Box(modifier = Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(scheme.onSurface.copy(alpha = 0.1f))) {
                                    Box(modifier = Modifier.fillMaxWidth(count.toFloat() / maxCount.toFloat()).height(5.dp).background(Brush.horizontalGradient(listOf(scheme.primary, scheme.secondary))))
                                }
                            }
                            Text("$count", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
                        }
                    }
                }
            }
            else -> {
                if (singles.isEmpty()) {
                    item { NeedleEmptyNote("No singles found. Songs that are alone in their album show up here.") }
                } else {
                    item { NeedleShelfTitle("Singles", "${singles.size} songs released on their own") }
                    items(singles.chunked(2)) { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            pair.forEach { song ->
                                Column(modifier = Modifier.weight(1f).clickable { onSongClick(song) }) {
                                    Box {
                                        NeedleCover(song.artworkUri, song.title, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(22.dp), 400)
                                        Box(modifier = Modifier.align(Alignment.BottomStart).padding(10.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                                            Text("Single", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                        }
                                    }
                                    Text(song.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                                    Text(song.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

private fun needleParseIds(json: String?): Set<String> {
    if (json.isNullOrBlank()) return emptySet()
    return try {
        val array = org.json.JSONArray(json)
        buildSet {
            for (i in 0 until array.length()) {
                when (val item = array.get(i)) {
                    is org.json.JSONObject -> add(item.optString("id"))
                    else -> add(item.toString())
                }
            }
        }
    } catch (_: Exception) {
        emptySet()
    }
}

private fun needleListened(ms: Long): String {
    val hours = ms / 3_600_000L
    return if (hours >= 1) "$hours h" else "${(ms / 60_000L).coerceAtLeast(0)} min"
}

private fun needleMillis(value: Long): Long = if (value in 1..99_999_999_999L) value * 1000L else value

private fun needleRelativeDay(dateAdded: Long): String {
    val millis = needleMillis(dateAdded)
    val days = ((System.currentTimeMillis() - millis) / 86_400_000L).toInt()
    return when {
        days <= 0 -> "Today"
        days == 1 -> "Yesterday"
        days < 30 -> "$days days ago"
        days < 365 -> "${days / 30} months ago"
        else -> "${days / 365} years ago"
    }
}

@Composable
private fun NeedleCover(uri: Uri?, seed: String, modifier: Modifier, shape: Shape, size: Int = 360) {
    val hue = remember(seed) { ((seed.hashCode().toLong() and 0x7fffffffL) % 360L).toFloat() }
    val brush = remember(hue) {
        Brush.linearGradient(listOf(Color.hsv(hue, 0.45f, 0.55f), Color.hsv((hue + 40f) % 360f, 0.6f, 0.22f)))
    }
    Box(modifier = modifier.clip(shape).background(brush)) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(uri).size(size, size).crossfade(200).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun NeedleRoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.size(42.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun NeedleShelfTitle(title: String, subtitle: String? = null, action: String? = null, onAction: () -> Unit = {}) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium, color = scheme.onSurface)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        if (action != null) {
            Text(action, style = MaterialTheme.typography.labelLarge, color = scheme.primary, modifier = Modifier.clickable { onAction() })
        }
    }
}

@Composable
private fun NeedleEmptyNote(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp),
        textAlign = TextAlign.Center
    )
}

// ============================================================================
// NEW page, built to the mockup's exact measurements
// ============================================================================

private val NeedlePurple = Color(0xFFAF65F5)
private val NeedlePink = Color(0xFFEF42B8)
private val NeedleGreen = Color(0xFF5C875C)

/** The two soft glows behind the Home page: green top-left, purple on the right edge. */
private fun Modifier.needleHomeGlow(): Modifier = this.drawBehind {
    fun glow(cx: Float, cy: Float, color: Color, stop: Float) {
        val center = Offset(size.width * cx, size.height * cy)
        val farthest = kotlin.math.hypot(
            maxOf(center.x, size.width - center.x),
            maxOf(center.y, size.height - center.y)
        )
        drawRect(
            Brush.radialGradient(
                colors = listOf(color, Color.Transparent),
                center = center,
                radius = farthest * stop
            )
        )
    }
    glow(0.10f, 0.06f, NeedleGreen.copy(alpha = 0.40f), 0.40f)
    glow(0.95f, 0.40f, NeedlePurple.copy(alpha = 0.35f), 0.50f)
}

/** Glass chip used on the hero: light diagonal fill and a rim that is brighter at the top. */
private fun Modifier.needleGlassChip(shape: Shape): Modifier = this
    .clip(shape)
    .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.16f), Color.White.copy(alpha = 0.05f))))
    .border(
        1.dp,
        Brush.verticalGradient(listOf(Color.White.copy(alpha = 0.30f), Color.White.copy(alpha = 0.10f))),
        shape
    )

private fun LazyListScope.needleNewTab(
    newestAlbums: List<Album>,
    singles: List<Song>,
    needTagsNew: Int,
    currentSong: Song?,
    trackCount: (Album) -> Int,
    addedMillis: (Album) -> Long,
    isUnplayed: (Album) -> Boolean,
    onPlayAlbum: (Album) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onEditTags: (Album) -> Unit,
    onSongClick: (Song) -> Unit,
    onViewAllAlbums: () -> Unit,
    onViewAllSongs: () -> Unit,
    onFixTags: () -> Unit
) {
    val hero = newestAlbums.firstOrNull()
    if (hero == null) {
        item { NeedleEmptyNote("Nothing new yet. Songs you add to this phone will show up here.") }
        return
    }

    item {
        NeedleNewHero(
            album = hero,
            trackCount = trackCount(hero),
            addedMillis = addedMillis(hero),
            onPlay = { onPlayAlbum(hero) },
            onOpen = { onAlbumClick(hero) },
            onEditTags = { onEditTags(hero) }
        )
    }

    val rest = newestAlbums.drop(1)
    val weekAgo = System.currentTimeMillis() - 7L * 86_400_000L
    val thisWeek = rest.filter { addedMillis(it) >= weekAgo }
    val shelf = (if (thisWeek.isNotEmpty()) thisWeek else rest).take(14)
    if (shelf.isNotEmpty()) {
        item { NeedleSectionTitle(if (thisWeek.isNotEmpty()) "Added this week" else "Added recently", "View all", onViewAllAlbums) }
        item {
            LazyRow(
                // bottom room so the colored cover shadows are not cut off by the row
                contentPadding = PaddingValues(start = 18.dp, end = 18.dp, bottom = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(shelf, key = { it.id }) { album ->
                    NeedleNewAlbumCard(album, isUnplayed(album)) { onAlbumClick(album) }
                }
            }
        }
    }

    val newSingles = singles.take(3)
    if (newSingles.isNotEmpty()) {
        // the cover row above already reserves 14dp for its shadows
        item { NeedleSectionTitle("New singles", "View all", onViewAllSongs, topPadding = if (shelf.isNotEmpty()) 8.dp else 22.dp) }
        items(newSingles, key = { it.id }) { song ->
            NeedleNewSingleRow(song, isCurrent = currentSong?.id == song.id) { onSongClick(song) }
        }
    }

    if (needTagsNew > 0) {
        item { NeedleFixTagsCard(needTagsNew, onFixTags) }
    }
}

@Composable
private fun NeedleNewHero(
    album: Album,
    trackCount: Int,
    addedMillis: Long,
    onPlay: () -> Unit,
    onOpen: () -> Unit,
    onEditTags: () -> Unit
) {
    val context = LocalContext.current
    val shape = RoundedCornerShape(30.dp)
    val glow = Color(0xFF7850FF).copy(alpha = 0.55f)
    val days = ((System.currentTimeMillis() - addedMillis) / 86_400_000L).toInt()
    val label = if (days <= 7) "Just added" else "Latest"
    val subtitle = "${album.artist} \u00B7 $trackCount tracks \u00B7 added ${needleRelativeDay(addedMillis).lowercase()}"

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 14.dp)
            .height(268.dp)
            .shadow(20.dp, shape, ambientColor = glow, spotColor = glow)
            .clip(shape)
            .clickable { onOpen() }
    ) {
        NeedleCover(album.artworkUri, album.title, Modifier.fillMaxSize(), shape, 700)
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    colorStops = arrayOf(
                        0f to Color.Transparent,
                        0.35f to Color.Transparent,
                        1f to Color.Black.copy(alpha = 0.6f)
                    )
                )
            )
        )

        // "Just added" label: top 16, left 16, 12sp, padding 6/12
        Box(
            modifier = Modifier
                .align(Alignment.TopStart)
                .padding(start = 16.dp, top = 16.dp)
                .clip(CircleShape)
                .background(NeedlePurple)
                .padding(horizontal = 12.dp, vertical = 6.dp)
        ) {
            Text(label, fontSize = 12.sp, fontWeight = FontWeight.SemiBold, color = Color.White, maxLines = 1)
        }

        // Title: 32sp serif, bottom edge 78 from the bottom
        Text(
            text = album.title,
            style = TextStyle(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Medium, fontSize = 32.sp, lineHeight = 32.sp),
            color = Color.White,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 78.dp)
        )
        // Subtitle: 12.5sp, bottom edge 56 from the bottom
        Text(
            text = subtitle,
            style = TextStyle(fontSize = 12.5.sp, lineHeight = 16.sp),
            color = Color(0xFFE6E6EA),
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 56.dp)
        )

        // Play: left 12, bottom 12, height 40
        NeedleMockButton("Play", onPlay, Modifier.align(Alignment.BottomStart).padding(start = 12.dp, bottom = 12.dp))

        // Share: glass circle, left 126, bottom 12, 40x40
        Box(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 126.dp, bottom = 12.dp)
                .size(40.dp)
                .needleGlassChip(CircleShape)
                .clickable {
                    val send = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "${album.title} \u2014 ${album.artist}")
                    }
                    context.startActivity(Intent.createChooser(send, null).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon = RhythmIcons.Share, contentDescription = "Share", tint = Color.White, modifier = Modifier.size(18.dp), size = 18.dp)
        }

        // Edit tags: glass pill, right 12, bottom 12, height 40, padding 0/14, icon 16, gap 6, 12.5sp
        Row(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 12.dp, bottom = 12.dp)
                .height(40.dp)
                .needleGlassChip(CircleShape)
                .clickable { onEditTags() }
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            Icon(icon = MaterialSymbolIcon("sell"), contentDescription = null, tint = Color.White, modifier = Modifier.size(16.dp), size = 16.dp)
            Text("Edit tags", fontSize = 12.5.sp, color = Color.White, maxLines = 1)
        }
    }
}

/** White pill, 14sp semibold, 22dp side padding, 40dp tall (the size the hero and the fix card use). */
@Composable
private fun NeedleMockButton(label: String, onClick: () -> Unit, modifier: Modifier = Modifier, sidePadding: Dp = 22.dp) {
    Box(
        modifier = modifier.height(40.dp).clip(CircleShape).background(Color.White).clickable { onClick() }.padding(horizontal = sidePadding),
        contentAlignment = Alignment.Center
    ) {
        Text(label, fontSize = 14.sp, fontWeight = FontWeight.SemiBold, color = Color(0xFF111111), maxLines = 1)
    }
}

/** Section header: padding 22/18/10, 18sp title, 12sp "View all", aligned on the text baseline. */
@Composable
private fun NeedleSectionTitle(title: String, action: String?, onAction: () -> Unit = {}, topPadding: Dp = 22.dp) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = topPadding, bottom = 10.dp)) {
        Text(title, fontSize = 18.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, modifier = Modifier.weight(1f).alignByBaseline())
        if (action != null) {
            Text(action, fontSize = 12.sp, color = scheme.onSurface.copy(alpha = 0.85f), modifier = Modifier.alignByBaseline().clickable { onAction() })
        }
    }
}

/** Album card: 112dp wide, 112dp cover with 22dp corners and a colored shadow, pink dot if unplayed. */
@Composable
private fun NeedleNewAlbumCard(album: Album, unplayed: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val shape = RoundedCornerShape(22.dp)
    val tint = remember(album.title) {
        Color.hsv(((album.title.hashCode().toLong() and 0x7fffffffL) % 360L).toFloat(), 0.5f, 0.75f)
    }
    Column(modifier = Modifier.width(112.dp).clickable { onClick() }) {
        Box(modifier = Modifier.size(112.dp)) {
            NeedleCover(
                album.artworkUri,
                album.title,
                Modifier.fillMaxSize().shadow(12.dp, shape, ambientColor = tint, spotColor = tint),
                shape,
                336
            )
            if (unplayed) {
                Box(
                    modifier = Modifier
                        .align(Alignment.TopEnd)
                        .padding(top = 8.dp, end = 8.dp)
                        .size(9.dp)
                        .shadow(5.dp, CircleShape, ambientColor = NeedlePink, spotColor = NeedlePink)
                        .background(NeedlePink, CircleShape)
                )
            }
        }
        Text(album.title, fontSize = 13.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(album.artist, fontSize = 11.5.sp, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Single row: padding 7/18, gap 12, 50dp thumb with 13dp corners, 38dp play circle. */
@Composable
private fun NeedleNewSingleRow(song: Song, isCurrent: Boolean, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onClick() }.padding(horizontal = 18.dp, vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        NeedleCover(song.artworkUri, song.title, Modifier.size(50.dp), RoundedCornerShape(13.dp), 160)
        Column(modifier = Modifier.weight(1f)) {
            Text(song.title, fontSize = 14.5.sp, fontWeight = FontWeight.SemiBold, color = if (isCurrent) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text("${song.artist} \u00B7 ${needleRelativeDay(song.dateAdded)}", fontSize = 12.sp, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(
            modifier = Modifier.size(38.dp).clip(CircleShape).background(scheme.surfaceContainerHigh).clickable { onClick() },
            contentAlignment = Alignment.Center
        ) {
            Icon(icon = RhythmIcons.Play, contentDescription = "Play", tint = scheme.onSurface, modifier = Modifier.size(16.dp), size = 16.dp)
        }
    }
}

/** "N new songs need tags" card: margin 20/18, 26dp corners, padding 16, white to purple gradient. */
@Composable
private fun NeedleFixTagsCard(count: Int, onFix: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(start = 18.dp, end = 18.dp, top = 20.dp)
            .clip(shape)
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = 0.07f), NeedlePurple.copy(alpha = 0.45f))))
            .border(1.dp, Color.White.copy(alpha = 0.10f), shape)
            .padding(16.dp)
    ) {
        Text(
            if (count == 1) "1 new song needs tags" else "$count new songs need tags",
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )
        Text(
            "They're missing a genre or cover art, so they won't show up in your recommendations yet.",
            style = TextStyle(fontSize = 12.5.sp, lineHeight = 17.5.sp),
            color = Color(0xFFD8D8DE),
            modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)
        )
        NeedleMockButton("Fix tags", onFix)
    }
}

// ============================================================================
// POPULAR page, built to the mockup's exact measurements
// ============================================================================

private fun LazyListScope.needlePopularTab(
    bigCards: List<Pair<Album, String>>,
    progressAlbums: List<Album>,
    rediscover: List<Album>,
    tracksPlayed: (Album) -> Pair<Int, Int>,
    genreOf: (Album) -> String,
    isFavorite: (Album) -> Boolean,
    listened: String,
    totalPlays: Int,
    topGenre: String,
    onPlayAlbum: (Album) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onNavigateToStats: () -> Unit,
    onViewAllAlbums: () -> Unit
) {
    if (bigCards.isNotEmpty()) {
        item {
            LazyRow(
                modifier = Modifier.padding(top = 14.dp),
                contentPadding = PaddingValues(horizontal = 18.dp),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(bigCards, key = { it.first.id }) { entry ->
                    NeedleBigCard(entry.first, entry.second, isFavorite(entry.first), { onPlayAlbum(entry.first) }) { onAlbumClick(entry.first) }
                }
            }
        }
    }

    if (progressAlbums.isNotEmpty()) {
        item { NeedleSectionTitle("Your albums", "View all", onViewAllAlbums, topPadding = 20.dp) }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(progressAlbums, key = { it.id }) { album ->
                    val ratio = tracksPlayed(album)
                    NeedleProgressCard(album.title, genreOf(album), ratio.first, ratio.second) { onAlbumClick(album) }
                }
            }
        }
    }

    item { NeedleSectionTitle("Your listening", "Stats", onNavigateToStats, topPadding = 20.dp) }
    item {
        LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            item { NeedleStatTile(listened, "Listened") }
            item { NeedleStatTile("$totalPlays", "Plays") }
            item { NeedleStatTile(topGenre, "Top genre") }
        }
    }

    if (rediscover.isNotEmpty()) {
        item { NeedleSectionTitle("Rediscover", "View all", onViewAllAlbums, topPadding = 20.dp) }
        item {
            LazyRow(contentPadding = PaddingValues(horizontal = 18.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(rediscover, key = { it.id }) { album ->
                    val scheme = MaterialTheme.colorScheme
                    Column(modifier = Modifier.width(96.dp).clickable { onAlbumClick(album) }) {
                        NeedleCover(album.artworkUri, album.title, Modifier.size(96.dp), RoundedCornerShape(20.dp), 288)
                        Text(album.title, fontSize = 12.5.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
                        Text("Not played yet", fontSize = 11.sp, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}

/** Big card: 196 x 262dp, 26dp corners, title 21sp at the top, Play now bottom-left, heart bottom-right. */
@Composable
private fun NeedleBigCard(album: Album, reason: String, favorite: Boolean, onPlay: () -> Unit, onOpen: () -> Unit) {
    val shape = RoundedCornerShape(26.dp)
    Box(modifier = Modifier.width(196.dp).height(262.dp).clip(shape).clickable { onOpen() }) {
        NeedleCover(album.artworkUri, album.title, Modifier.fillMaxSize(), shape, 520)
        // keeps the white title readable on bright covers
        Box(
            modifier = Modifier.fillMaxSize().background(
                Brush.verticalGradient(
                    colorStops = arrayOf(0f to Color.Black.copy(alpha = 0.45f), 0.45f to Color.Transparent, 1f to Color.Transparent)
                )
            )
        )
        Column(modifier = Modifier.align(Alignment.TopStart).padding(start = 14.dp, top = 14.dp, end = 14.dp)) {
            Text(
                album.title,
                style = TextStyle(fontSize = 21.sp, fontWeight = FontWeight.SemiBold, lineHeight = 23.sp),
                color = Color.White,
                maxLines = 2,
                overflow = TextOverflow.Ellipsis
            )
            Text(reason, fontSize = 11.5.sp, color = Color.White.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 6.dp))
        }
        NeedleMockButton("Play now", onPlay, Modifier.align(Alignment.BottomStart).padding(start = 10.dp, bottom = 10.dp), sidePadding = 20.dp)
        if (favorite) {
            Box(
                modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 10.dp).size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.45f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(icon = RhythmIcons.Favorite, contentDescription = "Liked", tint = Color.White, modifier = Modifier.size(20.dp), size = 20.dp)
            }
        }
    }
}

/** Album progress card: 152dp wide, 22dp corners, padding 14, genre chip, 22sp count and a 5dp bar. */
@Composable
private fun NeedleProgressCard(title: String, genre: String, played: Int, total: Int, onClick: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    val chip = remember(genre) {
        listOf(NeedlePurple, NeedleGreen, NeedlePink)[((genre.hashCode().toLong() and 0x7fffffffL) % 3L).toInt()]
    }
    Column(
        modifier = Modifier
            .width(152.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(scheme.surfaceContainer)
            .clickable { onClick() }
            .padding(14.dp)
    ) {
        Text(title, fontSize = 14.sp, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Box(modifier = Modifier.padding(top = 6.dp, bottom = 16.dp).clip(CircleShape).background(chip).padding(horizontal = 10.dp, vertical = 4.dp)) {
            Text(genre, fontSize = 11.sp, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Row {
            Text("$played", fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, modifier = Modifier.alignByBaseline())
            Text(" / $total tracks", fontSize = 12.sp, color = scheme.onSurfaceVariant, modifier = Modifier.alignByBaseline())
        }
        Box(modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(scheme.onSurface.copy(alpha = 0.22f))) {
            Box(modifier = Modifier.fillMaxWidth(played.toFloat() / total.coerceAtLeast(1).toFloat()).height(5.dp).background(scheme.onSurface))
        }
    }
}

/** Stat tile: 104dp wide, 22dp corners, padding 14/12, 24sp value, 11.5sp label. */
@Composable
private fun NeedleStatTile(value: String, label: String) {
    val scheme = MaterialTheme.colorScheme
    Column(
        modifier = Modifier
            .width(104.dp)
            .clip(RoundedCornerShape(22.dp))
            .background(scheme.surfaceContainer)
            .padding(horizontal = 12.dp, vertical = 14.dp)
    ) {
        Text(value, fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, fontSize = 11.5.sp, color = scheme.onSurfaceVariant)
    }
}
