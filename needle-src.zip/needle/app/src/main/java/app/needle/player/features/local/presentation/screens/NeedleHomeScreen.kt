package app.needle.player.features.local.presentation.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.needle.player.features.local.presentation.components.NeedleMomentsSection
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Artist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Needle's own Home: a header with search and settings, four pills (For you, New, Most played,
 * Singles) and shelves built from what is on this phone.
 */
@Composable
fun NeedleHomeScreen(
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    recentlyPlayed: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onNavigateToStats: () -> Unit,
    onViewAllAlbums: () -> Unit,
    onViewAllArtists: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val appSettings = remember { AppSettings.getInstance(context) }
    val playCounts by appSettings.songPlayCounts.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(0) }
    val pills = listOf("For you", "New", "Most played", "Singles")

    val newestAlbums = remember(albums) { albums.sortedByDescending { it.dateModified }.take(12) }
    val recentDistinct = remember(recentlyPlayed) { recentlyPlayed.distinctBy { it.id }.take(12) }
    val topArtists = remember(artists) { artists.sortedByDescending { it.numberOfTracks }.take(12) }
    val singles = remember(songs) {
        songs.groupBy { it.albumId }.filter { it.value.size == 1 }.values.map { it.first() }
            .sortedByDescending { it.dateAdded }
    }
    val mostPlayed = remember(songs, playCounts) {
        songs.filter { (playCounts[it.id] ?: 0) > 0 }.sortedByDescending { playCounts[it.id] ?: 0 }.take(20)
    }
    val maxCount = remember(mostPlayed, playCounts) { mostPlayed.maxOfOrNull { playCounts[it.id] ?: 0 } ?: 1 }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(scheme.surfaceContainerLowest),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 220.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NeedleCircleButton(onClick = onSearchClick) {
                    Icon(icon = RhythmIcons.Search, contentDescription = "Search", tint = scheme.onSurface)
                }
                Text(
                    text = "Needle",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif),
                    color = scheme.onSurface,
                    textAlign = androidx.compose.ui.text.style.TextAlign.Center
                )
                NeedleCircleButton(onClick = onSettingsClick) {
                    Icon(icon = RhythmIcons.Settings, contentDescription = "Settings", tint = scheme.onSurface)
                }
            }
        }

        item {
            LazyRow(
                modifier = Modifier.padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(pills.size) { index ->
                    val selected = index == tab
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) scheme.onSurface else scheme.surfaceContainerHigh)
                            .clickable { tab = index }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(
                            text = pills[index],
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) scheme.surface else scheme.onSurface
                        )
                    }
                }
            }
        }

        when (tab) {
            0 -> {
                item {
                    NeedleMomentsSection(
                        albums = albums,
                        songs = songs,
                        onAlbumClick = onAlbumClick,
                        onSongClick = onSongClick,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }
                if (recentDistinct.isNotEmpty()) {
                    item { NeedleShelfTitle("Recently played", "Pick up where you left off") }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(recentDistinct, key = { it.id }) { song ->
                                NeedleSongTile(song, currentSong?.id == song.id && isPlaying, onSongClick)
                            }
                        }
                    }
                }
                if (topArtists.isNotEmpty()) {
                    item { NeedleShelfTitle("Artists", "Most songs on this phone", "View all", onViewAllArtists) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                            items(topArtists, key = { it.id }) { artist ->
                                Column(
                                    modifier = Modifier.width(88.dp).clickable { onArtistClick(artist) },
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context).data(artist.artworkUri).size(240, 240).build(),
                                        contentDescription = artist.name,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.size(88.dp).clip(CircleShape).background(scheme.primaryContainer)
                                    )
                                    Text(
                                        artist.name,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = scheme.onSurface,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.padding(top = 6.dp)
                                    )
                                }
                            }
                        }
                    }
                }
                item { NeedleShelfTitle("Your library", "A quick look", "Stats", onNavigateToStats) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        NeedleStatCard("${songs.size}", "Songs", scheme.primaryContainer, scheme.onPrimaryContainer, Modifier.weight(1f))
                        NeedleStatCard("${albums.size}", "Albums", scheme.secondaryContainer, scheme.onSecondaryContainer, Modifier.weight(1f))
                        NeedleStatCard("${artists.size}", "Artists", scheme.tertiaryContainer, scheme.onTertiaryContainer, Modifier.weight(1f))
                    }
                }
            }
            1 -> {
                val hero = newestAlbums.firstOrNull()
                if (hero != null) {
                    item { NeedleHeroCard(hero, onAlbumClick) }
                }
                if (newestAlbums.size > 1) {
                    item { NeedleShelfTitle("Added recently", "Your newest albums", "View all", onViewAllAlbums) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(newestAlbums.drop(1), key = { it.id }) { album ->
                                NeedleAlbumTile(album, onAlbumClick)
                            }
                        }
                    }
                }
                if (singles.isNotEmpty()) {
                    item { NeedleShelfTitle("New singles", "One song, on its own") }
                    items(singles.take(5), key = { it.id }) { song ->
                        NeedleSongRow(song, currentSong?.id == song.id, onSongClick)
                    }
                }
                if (newestAlbums.isEmpty()) {
                    item { NeedleEmptyNote("Nothing new yet. Songs you add to this phone will show up here.") }
                }
            }
            2 -> {
                if (mostPlayed.isEmpty()) {
                    item { NeedleEmptyNote("Play a few songs and your most played will appear here.") }
                } else {
                    item { NeedleShelfTitle("Most played", "Counted on this phone") }
                    items(mostPlayed.size) { index ->
                        val song = mostPlayed[index]
                        val count = playCounts[song.id] ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(
                                (index + 1).toString(),
                                modifier = Modifier.width(26.dp),
                                style = MaterialTheme.typography.titleMedium,
                                color = if (index == 0) scheme.secondary else scheme.onSurfaceVariant,
                                textAlign = androidx.compose.ui.text.style.TextAlign.Center
                            )
                            AsyncImage(
                                model = ImageRequest.Builder(context).data(song.artworkUri).size(160, 160).build(),
                                contentDescription = null,
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.size(50.dp).clip(RoundedCornerShape(13.dp)).background(scheme.surfaceContainerHigh)
                            )
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (currentSong?.id == song.id) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Box(
                                    modifier = Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(scheme.onSurface.copy(alpha = 0.1f))
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .fillMaxWidth(count.toFloat() / maxCount.toFloat())
                                            .height(5.dp)
                                            .background(Brush.horizontalGradient(listOf(scheme.primary, scheme.secondary)))
                                    )
                                }
                            }
                            Text("$count", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
                        }
                    }
                }
            }
            else -> {
                if (singles.isEmpty()) {
                    item { NeedleEmptyNote("No singles found. Songs that are alone in their album show up here.") }
                } else {
                    item { NeedleShelfTitle("Singles", "${singles.size} songs released on their own") }
                    items(singles.chunked(2)) { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            pair.forEach { song ->
                                Column(modifier = Modifier.weight(1f).clickable { onSongClick(song) }) {
                                    AsyncImage(
                                        model = ImageRequest.Builder(context).data(song.artworkUri).size(400, 400).build(),
                                        contentDescription = song.title,
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxWidth().aspectRatio(1f).clip(RoundedCornerShape(22.dp)).background(scheme.surfaceContainerHigh)
                                    )
                                    Text(song.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                                    Text(song.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun NeedleCircleButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun NeedleShelfTitle(title: String, subtitle: String? = null, action: String? = null, onAction: () -> Unit = {}) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = scheme.onSurface)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        if (action != null) {
            Text(action, style = MaterialTheme.typography.labelLarge, color = scheme.primary, modifier = Modifier.clickable { onAction() })
        }
    }
}

@Composable
private fun NeedleSongTile(song: Song, active: Boolean, onSongClick: (Song) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(modifier = Modifier.width(136.dp).clickable { onSongClick(song) }) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(song.artworkUri).size(360, 360).build(),
            contentDescription = song.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(136.dp).clip(RoundedCornerShape(24.dp)).background(scheme.surfaceContainerHigh)
        )
        Text(song.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = if (active) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(song.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun NeedleAlbumTile(album: Album, onAlbumClick: (Album) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Column(modifier = Modifier.width(136.dp).clickable { onAlbumClick(album) }) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(album.artworkUri).size(360, 360).build(),
            contentDescription = album.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(136.dp).clip(RoundedCornerShape(24.dp)).background(scheme.surfaceContainerHigh)
        )
        Text(album.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
        Text(album.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

@Composable
private fun NeedleHeroCard(album: Album, onAlbumClick: (Album) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 6.dp)
            .aspectRatio(1.1f)
            .clip(RoundedCornerShape(30.dp))
            .background(scheme.surfaceContainerHigh)
            .clickable { onAlbumClick(album) }
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(album.artworkUri).crossfade(250).build(),
            contentDescription = album.title,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
        Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)), startY = 200f)))
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(20.dp)) {
            Box(modifier = Modifier.clip(CircleShape).background(scheme.primary).padding(horizontal = 12.dp, vertical = 5.dp)) {
                Text("Just added", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold, color = scheme.onPrimary)
            }
            Text(album.title, style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 10.dp))
            Text("${album.artist} \u00B7 ${album.numberOfSongs.coerceAtLeast(album.songs.size)} songs", style = MaterialTheme.typography.bodyMedium, color = Color.White.copy(alpha = 0.8f))
        }
    }
}

@Composable
private fun NeedleSongRow(song: Song, active: Boolean, onSongClick: (Song) -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Row(
        modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 7.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(song.artworkUri).size(160, 160).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.size(52.dp).clip(RoundedCornerShape(13.dp)).background(scheme.surfaceContainerHigh)
        )
        Column(modifier = Modifier.weight(1f)) {
            Text(song.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (active) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(song.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
        }
        Box(modifier = Modifier.clip(CircleShape).background(scheme.surfaceContainerHigh).padding(horizontal = 12.dp, vertical = 5.dp)) {
            Text("Single", style = MaterialTheme.typography.labelSmall, color = scheme.onSurface)
        }
    }
}

@Composable
private fun NeedleStatCard(value: String, label: String, container: Color, content: Color, modifier: Modifier = Modifier) {
    Column(modifier = modifier.clip(RoundedCornerShape(24.dp)).background(container).padding(16.dp)) {
        Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif), color = content)
        Text(label, style = MaterialTheme.typography.bodyMedium, color = content.copy(alpha = 0.85f))
    }
}

@Composable
private fun NeedleEmptyNote(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp),
        textAlign = androidx.compose.ui.text.style.TextAlign.Center
    )
}
