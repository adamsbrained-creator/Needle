package app.needle.player.features.local.presentation.screens

import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.player.features.local.presentation.components.NeedleMomentsSection
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Artist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.icons.RhythmIcons
import coil.compose.AsyncImage
import coil.request.ImageRequest

/**
 * Needle's own Home, built after the mockups: a header, five pills (New, Popular, Moments,
 * Most played, Singles) and shelves made from what is on this phone.
 */
@Composable
fun NeedleHomeScreen(
    songs: List<Song>,
    albums: List<Album>,
    artists: List<Artist>,
    recentlyPlayed: List<Song>,
    currentSong: Song?,
    isPlaying: Boolean,
    onSongClick: (Song) -> Unit,
    onAlbumClick: (Album) -> Unit,
    onArtistClick: (Artist) -> Unit,
    onSearchClick: () -> Unit,
    onSettingsClick: () -> Unit,
    onNavigateToStats: () -> Unit,
    onViewAllAlbums: () -> Unit,
    onViewAllArtists: () -> Unit,
    onViewAllSongs: () -> Unit,
    modifier: Modifier = Modifier
) {
    val scheme = MaterialTheme.colorScheme
    val context = LocalContext.current
    val appSettings = remember { AppSettings.getInstance(context) }
    val playCounts by appSettings.songPlayCounts.collectAsState()
    var tab by rememberSaveable { mutableIntStateOf(1) }
    val pills = listOf("New", "Popular", "Moments", "Most played", "Singles")

    val songsByAlbum = remember(songs) { songs.groupBy { it.albumId } }
    val albumById = remember(albums) { albums.associateBy { it.id } }
    val newestAlbums = remember(albums) { albums.sortedByDescending { it.dateModified } }
    val singles = remember(songs, songsByAlbum) {
        songsByAlbum.filter { it.value.size == 1 }.values.map { it.first() }.sortedByDescending { it.dateAdded }
    }
    val playedAlbumRatio = remember(albums, songsByAlbum, playCounts) {
        albums.associate { album ->
            val list = songsByAlbum[album.id].orEmpty()
            album.id to Pair(list.count { (playCounts[it.id] ?: 0) > 0 }, list.size)
        }
    }
    val bigCards = remember(recentlyPlayed, albumById, newestAlbums) {
        val fromPlays = recentlyPlayed.distinctBy { it.albumId }.mapNotNull { song ->
            albumById[song.albumId]?.let { album -> album to "Because you played ${song.artist}" }
        }
        (fromPlays.ifEmpty { newestAlbums.map { it to "New in your library" } }).take(8)
    }
    val progressAlbums = remember(albums, playedAlbumRatio) {
        albums.filter { (playedAlbumRatio[it.id]?.second ?: 0) > 0 }
            .sortedByDescending { playedAlbumRatio[it.id]?.first ?: 0 }.take(8)
    }
    val rediscover = remember(albums, playedAlbumRatio) {
        albums.filter { (playedAlbumRatio[it.id]?.first ?: 0) == 0 }.take(10)
    }
    val totalPlays = remember(playCounts) { playCounts.values.sum() }
    val playedSongs = remember(songs, playCounts) { songs.filter { (playCounts[it.id] ?: 0) > 0 } }
    val artistsHeard = remember(playedSongs) { playedSongs.map { it.artist }.distinct().size }
    val topGenre = remember(playedSongs, playCounts) {
        playedSongs.filter { !it.genre.isNullOrBlank() }.groupBy { it.genre!!.substringBefore(',').trim() }
            .maxByOrNull { entry -> entry.value.sumOf { playCounts[it.id] ?: 0 } }?.key ?: "None yet"
    }
    val needTags = remember(songs) {
        songs.count { it.genre.isNullOrBlank() || it.artworkUri == null || it.artist.contains("unknown", ignoreCase = true) }
    }
    val mostPlayed = remember(playedSongs, playCounts) {
        playedSongs.sortedByDescending { playCounts[it.id] ?: 0 }.take(20)
    }
    val maxCount = remember(mostPlayed, playCounts) { mostPlayed.maxOfOrNull { playCounts[it.id] ?: 0 } ?: 1 }

    fun playAlbum(album: Album) {
        val first = songsByAlbum[album.id].orEmpty().minByOrNull { it.trackNumber }
        if (first != null) onSongClick(first) else onAlbumClick(album)
    }

    LazyColumn(
        modifier = modifier.fillMaxSize().background(scheme.surfaceContainerLowest),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = 220.dp)
    ) {
        item {
            Row(
                modifier = Modifier.fillMaxWidth().statusBarsPadding().padding(top = 8.dp, bottom = 6.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                NeedleRoundButton(onClick = onSearchClick) {
                    Icon(icon = RhythmIcons.Search, contentDescription = "Search", tint = scheme.onSurface, modifier = Modifier.size(22.dp), size = 22.dp)
                }
                Text(
                    text = "Needle",
                    modifier = Modifier.weight(1f),
                    style = MaterialTheme.typography.headlineSmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold),
                    color = scheme.onSurface,
                    textAlign = TextAlign.Center
                )
                NeedleRoundButton(onClick = onSettingsClick) {
                    Icon(icon = RhythmIcons.Settings, contentDescription = "Settings", tint = scheme.onSurface, modifier = Modifier.size(22.dp), size = 22.dp)
                }
            }
        }

        item {
            LazyRow(modifier = Modifier.padding(top = 8.dp, bottom = 6.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(pills.size) { index ->
                    val selected = index == tab
                    Box(
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(if (selected) scheme.onSurface else scheme.surfaceContainerHigh)
                            .clickable { tab = index }
                            .padding(horizontal = 18.dp, vertical = 11.dp)
                    ) {
                        Text(
                            text = pills[index],
                            style = MaterialTheme.typography.labelLarge,
                            fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                            color = if (selected) scheme.surface else scheme.onSurface
                        )
                    }
                }
            }
        }

        when (tab) {
            0 -> {
                val hero = newestAlbums.firstOrNull()
                if (hero != null) {
                    item {
                        NeedleHeroCard(hero, songsByAlbum[hero.id].orEmpty().size, onPlay = { playAlbum(hero) }, onOpen = { onAlbumClick(hero) })
                    }
                    if (newestAlbums.size > 1) {
                        item { NeedleShelfTitle("Added recently", null, "View all", onViewAllAlbums) }
                        item {
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                items(newestAlbums.drop(1).take(14), key = { it.id }) { album ->
                                    val unplayed = (playedAlbumRatio[album.id]?.first ?: 0) == 0
                                    Column(modifier = Modifier.width(112.dp).clickable { onAlbumClick(album) }) {
                                        Box {
                                            NeedleCover(album.artworkUri, album.title, Modifier.size(112.dp), RoundedCornerShape(22.dp))
                                            if (unplayed) {
                                                Box(
                                                    modifier = Modifier.align(Alignment.TopEnd).padding(8.dp).size(9.dp).clip(CircleShape).background(scheme.secondary)
                                                )
                                            }
                                        }
                                        Text(album.title, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                                        Text(album.artist, style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                }
                            }
                        }
                    }
                } else {
                    item { NeedleEmptyNote("Nothing new yet. Songs you add to this phone will show up here.") }
                }
                if (singles.isNotEmpty()) {
                    item { NeedleShelfTitle("New singles", null) }
                    items(singles.take(5), key = { it.id }) { song ->
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            NeedleCover(song.artworkUri, song.title, Modifier.size(50.dp), RoundedCornerShape(13.dp), 160)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (currentSong?.id == song.id) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Text("${song.artist} \u00B7 ${needleRelativeDay(song.dateAdded)}", style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            }
                            Box(
                                modifier = Modifier.size(38.dp).clip(CircleShape).background(scheme.surfaceContainerHigh).clickable { onSongClick(song) },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(icon = RhythmIcons.Play, contentDescription = "Play", tint = scheme.onSurface, modifier = Modifier.size(18.dp), size = 18.dp)
                            }
                        }
                    }
                }
                if (needTags > 0) {
                    item {
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(top = 22.dp)
                                .clip(RoundedCornerShape(26.dp))
                                .background(Brush.linearGradient(listOf(scheme.surfaceContainerHigh, scheme.primaryContainer)))
                                .padding(18.dp)
                        ) {
                            Text("$needTags songs need tags", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = scheme.onSurface)
                            Text(
                                "They are missing a genre, cover art or an artist, so they will not show up in your recommendations yet.",
                                style = MaterialTheme.typography.bodySmall,
                                color = scheme.onSurface.copy(alpha = 0.8f),
                                modifier = Modifier.padding(top = 6.dp, bottom = 14.dp)
                            )
                            NeedleWhitePill("Review songs", onViewAllSongs)
                        }
                    }
                }
            }
            1 -> {
                item {
                    LazyRow(modifier = Modifier.padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        items(bigCards, key = { it.first.id }) { entry ->
                            val album = entry.first
                            Box(
                                modifier = Modifier
                                    .width(196.dp)
                                    .height(262.dp)
                                    .clip(RoundedCornerShape(26.dp))
                                    .clickable { onAlbumClick(album) }
                            ) {
                                NeedleCover(album.artworkUri, album.title, Modifier.fillMaxSize(), RoundedCornerShape(26.dp), 520)
                                Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Black.copy(alpha = 0.45f), Color.Transparent, Color.Black.copy(alpha = 0.6f)))))
                                Column(modifier = Modifier.align(Alignment.TopStart).padding(16.dp)) {
                                    Text(album.title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
                                    Text(entry.second, style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.8f), maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
                                }
                                Row(
                                    modifier = Modifier.align(Alignment.BottomStart).fillMaxWidth().padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    NeedleWhitePill("Play now", { playAlbum(album) }, Modifier.weight(1f, fill = false))
                                    Spacer(Modifier.weight(1f))
                                    Box(
                                        modifier = Modifier.size(40.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).clickable { onAlbumClick(album) },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(icon = RhythmIcons.Music.AlbumOutlined, contentDescription = "Open album", tint = Color.White, modifier = Modifier.size(20.dp), size = 20.dp)
                                    }
                                }
                            }
                        }
                    }
                }
                if (progressAlbums.isNotEmpty()) {
                    item { NeedleShelfTitle("Your albums", null, "View all", onViewAllAlbums) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            items(progressAlbums, key = { it.id }) { album ->
                                val ratio = playedAlbumRatio[album.id] ?: Pair(0, 1)
                                val genre = songsByAlbum[album.id].orEmpty().firstNotNullOfOrNull { it.genre?.substringBefore(',')?.trim()?.takeIf { g -> g.isNotBlank() } } ?: "Album"
                                val chip = remember(genre) { Color.hsv(((genre.hashCode().toLong() and 0x7fffffffL) % 360L).toFloat(), 0.5f, 0.6f) }
                                Column(
                                    modifier = Modifier
                                        .width(158.dp)
                                        .clip(RoundedCornerShape(22.dp))
                                        .background(scheme.surfaceContainer)
                                        .clickable { onAlbumClick(album) }
                                        .padding(14.dp)
                                ) {
                                    Text(album.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    Box(modifier = Modifier.padding(top = 6.dp, bottom = 16.dp).clip(CircleShape).background(chip).padding(horizontal = 10.dp, vertical = 3.dp)) {
                                        Text(genre, style = MaterialTheme.typography.labelSmall, color = Color.White, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                    }
                                    Row(verticalAlignment = Alignment.Bottom) {
                                        Text("${ratio.first}", fontSize = 24.sp, fontWeight = FontWeight.SemiBold, color = scheme.onSurface)
                                        Text(" / ${ratio.second} tracks", style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant, modifier = Modifier.padding(bottom = 3.dp))
                                    }
                                    Box(modifier = Modifier.padding(top = 8.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(scheme.onSurface.copy(alpha = 0.14f))) {
                                        Box(modifier = Modifier.fillMaxWidth(ratio.first.toFloat() / ratio.second.coerceAtLeast(1).toFloat()).height(5.dp).background(scheme.onSurface))
                                    }
                                }
                            }
                        }
                    }
                }
                item { NeedleShelfTitle("This week", null, "Stats", onNavigateToStats) }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                        NeedleStatTile("$totalPlays", "Plays", Modifier.weight(1f))
                        NeedleStatTile("$artistsHeard", "Artists", Modifier.weight(1f))
                        NeedleStatTile(topGenre, "Top genre", Modifier.weight(1f))
                    }
                }
                if (rediscover.isNotEmpty()) {
                    item { NeedleShelfTitle("Rediscover", "Albums you have not played yet", "View all", onViewAllAlbums) }
                    item {
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                            items(rediscover, key = { it.id }) { album ->
                                Column(modifier = Modifier.width(96.dp).clickable { onAlbumClick(album) }) {
                                    NeedleCover(album.artworkUri, album.title, Modifier.size(96.dp), RoundedCornerShape(20.dp), 288)
                                    Text(album.title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Medium, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 7.dp))
                                    Text("Not played yet", style = MaterialTheme.typography.labelSmall, color = scheme.onSurfaceVariant, maxLines = 1)
                                }
                            }
                        }
                    }
                }
            }
            2 -> {
                item {
                    NeedleMomentsSection(
                        albums = albums,
                        songs = songs,
                        onAlbumClick = onAlbumClick,
                        onSongClick = onSongClick,
                        modifier = Modifier.padding(top = 10.dp)
                    )
                }
            }
            3 -> {
                if (mostPlayed.isEmpty()) {
                    item { NeedleEmptyNote("Play a few songs and your most played will appear here.") }
                } else {
                    item { NeedleShelfTitle("Most played", "Counted on this phone") }
                    items(mostPlayed.size) { index ->
                        val song = mostPlayed[index]
                        val count = playCounts[song.id] ?: 0
                        Row(
                            modifier = Modifier.fillMaxWidth().clickable { onSongClick(song) }.padding(vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text((index + 1).toString(), modifier = Modifier.width(26.dp), style = MaterialTheme.typography.titleMedium, color = if (index == 0) scheme.secondary else scheme.onSurfaceVariant, textAlign = TextAlign.Center)
                            NeedleCover(song.artworkUri, song.title, Modifier.size(50.dp), RoundedCornerShape(13.dp), 160)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(song.title, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.SemiBold, color = if (currentSong?.id == song.id) scheme.primary else scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                Box(modifier = Modifier.padding(top = 6.dp).fillMaxWidth().height(5.dp).clip(CircleShape).background(scheme.onSurface.copy(alpha = 0.1f))) {
                                    Box(modifier = Modifier.fillMaxWidth(count.toFloat() / maxCount.toFloat()).height(5.dp).background(Brush.horizontalGradient(listOf(scheme.primary, scheme.secondary))))
                                }
                            }
                            Text("$count", style = MaterialTheme.typography.labelLarge, color = scheme.onSurfaceVariant)
                        }
                    }
                }
            }
            else -> {
                if (singles.isEmpty()) {
                    item { NeedleEmptyNote("No singles found. Songs that are alone in their album show up here.") }
                } else {
                    item { NeedleShelfTitle("Singles", "${singles.size} songs released on their own") }
                    items(singles.chunked(2)) { pair ->
                        Row(horizontalArrangement = Arrangement.spacedBy(12.dp), modifier = Modifier.fillMaxWidth().padding(bottom = 12.dp)) {
                            pair.forEach { song ->
                                Column(modifier = Modifier.weight(1f).clickable { onSongClick(song) }) {
                                    Box {
                                        NeedleCover(song.artworkUri, song.title, Modifier.fillMaxWidth().aspectRatio(1f), RoundedCornerShape(22.dp), 400)
                                        Box(modifier = Modifier.align(Alignment.BottomStart).padding(10.dp).clip(CircleShape).background(Color.Black.copy(alpha = 0.5f)).padding(horizontal = 10.dp, vertical = 4.dp)) {
                                            Text("Single", style = MaterialTheme.typography.labelSmall, color = Color.White)
                                        }
                                    }
                                    Text(song.title, style = MaterialTheme.typography.bodyMedium, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 8.dp))
                                    Text(song.artist, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                            }
                            if (pair.size == 1) Spacer(Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}

private fun needleRelativeDay(dateAdded: Long): String {
    val millis = if (dateAdded in 1..99_999_999_999L) dateAdded * 1000L else dateAdded
    val days = ((System.currentTimeMillis() - millis) / 86_400_000L).toInt()
    return when {
        days <= 0 -> "Today"
        days == 1 -> "Yesterday"
        days < 30 -> "$days days ago"
        days < 365 -> "${days / 30} months ago"
        else -> "${days / 365} years ago"
    }
}

@Composable
private fun NeedleCover(uri: Uri?, seed: String, modifier: Modifier, shape: Shape, size: Int = 360) {
    val hue = remember(seed) { ((seed.hashCode().toLong() and 0x7fffffffL) % 360L).toFloat() }
    val brush = remember(hue) {
        Brush.linearGradient(listOf(Color.hsv(hue, 0.45f, 0.55f), Color.hsv((hue + 40f) % 360f, 0.6f, 0.22f)))
    }
    Box(modifier = modifier.clip(shape).background(brush)) {
        AsyncImage(
            model = ImageRequest.Builder(LocalContext.current).data(uri).size(size, size).crossfade(200).build(),
            contentDescription = null,
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize()
        )
    }
}

@Composable
private fun NeedleRoundButton(onClick: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier.size(44.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceContainerHigh).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { content() }
}

@Composable
private fun NeedleWhitePill(label: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.height(40.dp).clip(CircleShape).background(Color.White).clickable { onClick() }.padding(horizontal = 20.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold, color = Color(0xFF111111), maxLines = 1)
    }
}

@Composable
private fun NeedleShelfTitle(title: String, subtitle: String? = null, action: String? = null, onAction: () -> Unit = {}) {
    val scheme = MaterialTheme.colorScheme
    Row(modifier = Modifier.fillMaxWidth().padding(top = 22.dp, bottom = 10.dp), verticalAlignment = Alignment.Bottom) {
        Column(modifier = Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Medium, color = scheme.onSurface)
            if (subtitle != null) Text(subtitle, style = MaterialTheme.typography.bodySmall, color = scheme.onSurfaceVariant)
        }
        if (action != null) {
            Text(action, style = MaterialTheme.typography.labelLarge, color = scheme.primary, modifier = Modifier.clickable { onAction() })
        }
    }
}

@Composable
private fun NeedleHeroCard(album: Album, trackCount: Int, onPlay: () -> Unit, onOpen: () -> Unit) {
    val scheme = MaterialTheme.colorScheme
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .padding(top = 10.dp)
            .height(268.dp)
            .clip(RoundedCornerShape(30.dp))
            .clickable { onOpen() }
    ) {
        NeedleCover(album.artworkUri, album.title, Modifier.fillMaxSize(), RoundedCornerShape(30.dp), 700)
        Box(modifier = Modifier.fillMaxSize().background(Brush.verticalGradient(listOf(Color.Transparent, Color.Black.copy(alpha = 0.72f)), startY = 220f)))
        Box(modifier = Modifier.align(Alignment.TopStart).padding(16.dp).clip(CircleShape).background(scheme.primary).padding(horizontal = 12.dp, vertical = 6.dp)) {
            Text("Just added", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = scheme.onPrimary)
        }
        Column(modifier = Modifier.align(Alignment.BottomStart).padding(start = 16.dp, end = 16.dp, bottom = 66.dp)) {
            Text(album.title, style = MaterialTheme.typography.headlineMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.SemiBold), color = Color.White, maxLines = 2, overflow = TextOverflow.Ellipsis)
            val count = trackCount.coerceAtLeast(album.numberOfSongs)
            Text("${album.artist} \u00B7 $count tracks", style = MaterialTheme.typography.bodySmall, color = Color.White.copy(alpha = 0.85f))
        }
        Row(modifier = Modifier.align(Alignment.BottomStart).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            NeedleWhitePill("Play", onPlay)
            Box(
                modifier = Modifier.height(40.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f)).clickable { onOpen() }.padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) {
                Text("Open album", style = MaterialTheme.typography.labelLarge, color = Color.White)
            }
        }
    }
}

@Composable
private fun NeedleStatTile(value: String, label: String, modifier: Modifier = Modifier) {
    val scheme = MaterialTheme.colorScheme
    Column(modifier = modifier.clip(RoundedCornerShape(22.dp)).background(scheme.surfaceContainer).padding(horizontal = 14.dp, vertical = 16.dp)) {
        Text(value, fontSize = 22.sp, fontWeight = FontWeight.SemiBold, color = scheme.onSurface, maxLines = 1, overflow = TextOverflow.Ellipsis)
        Text(label, style = MaterialTheme.typography.labelMedium, color = scheme.onSurfaceVariant)
    }
}

@Composable
private fun NeedleEmptyNote(text: String) {
    Text(
        text,
        style = MaterialTheme.typography.bodyLarge,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.fillMaxWidth().padding(vertical = 40.dp, horizontal = 12.dp),
        textAlign = TextAlign.Center
    )
}
