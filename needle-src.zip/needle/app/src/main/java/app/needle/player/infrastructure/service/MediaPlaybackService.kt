/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.infrastructure.service

import android.app.PendingIntent
import android.content.Intent
import android.content.IntentFilter
import android.content.BroadcastReceiver
import android.content.Context
import android.widget.Toast
import android.media.AudioDeviceInfo
import android.media.AudioManager
import android.media.AudioMixerAttributes
import android.net.Uri
import android.os.Bundle
import android.util.Log
import androidx.annotation.OptIn
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.PlaybackException
import androidx.media3.common.Timeline
import androidx.media3.common.Player
import androidx.media3.common.ForwardingPlayer
import app.needle.player.shared.data.model.TransitionSettings
import app.needle.player.shared.data.model.TransitionMode
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.DefaultRenderersFactory
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.ExoPlaybackException
import androidx.media3.session.CommandButton
import androidx.media3.session.MediaController
import androidx.media3.session.MediaLibraryService
import androidx.media3.session.MediaSession
import androidx.media3.session.SessionCommand
import androidx.media3.session.SessionError
import androidx.media3.session.SessionResult
import app.needle.player.activities.MainActivity
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Song
import app.needle.player.infrastructure.service.player.RhythmPlayerEngine
import app.needle.player.infrastructure.service.player.TransitionController
import app.needle.player.infrastructure.service.player.PreloadController
import app.needle.player.infrastructure.service.player.replaygain.ReplayGainCache
import app.needle.player.infrastructure.service.player.MissingLocalMediaClassifier
import app.needle.player.infrastructure.service.util.RhythmBitmapLoader
import app.needle.player.infrastructure.widget.WidgetUpdater
import com.google.common.collect.ImmutableList
import com.google.common.util.concurrent.Futures
import com.google.common.util.concurrent.ListenableFuture
import java.util.concurrent.ConcurrentHashMap
import java.util.Locale
import kotlinx.coroutines.*
import android.app.NotificationChannel
import android.app.NotificationManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.media3.common.AudioAttributes as ExoAudioAttributes
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import app.needle.player.util.GsonUtils
import app.needle.player.shared.data.model.Playlist
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import app.needle.player.shared.data.repository.PlaybackStatsRepository
import app.needle.player.shared.data.repository.StatsTimeRange
import app.needle.player.shared.presentation.screens.settings.rhythmGuardFormatDurationFromMinutes
import app.needle.player.activities.RhythmGuardTimeoutActivity
import androidx.core.net.toUri

@OptIn(UnstableApi::class)
class MediaPlaybackService : MediaLibraryService(), Player.Listener {
    private var mediaSession: MediaLibrarySession? = null
    private lateinit var player: Player
    private lateinit var customCommands: List<CommandButton>
    private lateinit var preloadController: PreloadController

    private var controller: MediaController? = null
    
    // Service-scoped coroutine scope for background operations
    private val serviceScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    
    // Track current custom layout state to avoid unnecessary updates
    private var lastShuffleState: Boolean? = null
    private var lastRepeatMode: Int? = null
    private var lastFavoriteState: Boolean? = null
    private var lastWidgetSnapshotKey: String? = null
    private var lastHandledPlayerTransitionMediaId: String? = null
    private var lastHandledControllerTransitionMediaId: String? = null
    
    // Debounce custom layout updates to prevent flickering
    private var updateLayoutJob: Job? = null
    
    // Rhythm player engine (dual-player crossfade) and transition controller
    private lateinit var rhythmPlayerEngine: RhythmPlayerEngine
    private lateinit var transitionController: TransitionController
    
    // Sleep Timer functionality
    private var sleepTimerJob: Job? = null
    private var sleepTimerDurationMs: Long = 0L
    private var sleepTimerStartTime: Long = 0L
    private var fadeOutEnabled: Boolean = true
    private var pauseOnlyEnabled: Boolean = false
    private var lastVolumeExtendTimeMs: Long = 0L
    private var pausedByZeroVolume: Boolean = false
    
    // Audio effects (for equalizer integration)
    private var equalizer: android.media.audiofx.Equalizer? = null
    
    // Rhythm audio processors (replaced Android BassBoost and Spatializer for better quality)
    private var rhythmBassBoostProcessor: app.needle.player.infrastructure.audio.RhythmBassBoostProcessor? = null
    private var rhythmSpatializationProcessor: app.needle.player.infrastructure.audio.RhythmSpatializationProcessor? = null
    private var rhythmMonoAudioProcessor: app.needle.player.infrastructure.audio.RhythmMonoAudioProcessor? = null
    
    private var virtualizerStrength: Short = 0 // Store strength for virtualizer
    private var isInitializingAudioEffects: Boolean = false // Prevent concurrent initialization
    private var audioEffectsInitialized: Boolean = false // Track if effects have been successfully initialized
    private var isBassBoostAvailable: Boolean = true // Rhythm bass boost is always available
    private val audioEffectsInitMutex = Mutex()
    private var audioEffectsInitJob: Job? = null
    private var equalizerVolumeTransitionJob: Job? = null
    private var equalizerVolumeRestoreTarget: Float? = null
    @Volatile
    private var pendingAudioEffectsSessionId: Int = 0
    @Volatile
    private var currentAudioEffectsSessionId: Int = 0
    @Volatile
    private var pendingEqualizerLevels: FloatArray? = null
    
    // Player listener reference for proper cleanup
    private var playerListener: Player.Listener? = null
    
    // BroadcastReceiver to listen for favorite changes from ViewModel
    private val favoriteChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            when (intent?.action) {
                "app.needle.player.action.FAVORITE_CHANGED" -> {
                    Log.d(TAG, "Received favorite change notification from ViewModel")
                    // Update notification custom layout
                    scheduleCustomLayoutUpdate(250) // Longer delay for external changes
                    // Also update widget
                    updateWidgetFromMediaItem(player.currentMediaItem)
                }
            }
        }
    }

    private var wasPlayingBeforeTimeout = false

    private val volumeChangeReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.media.VOLUME_CHANGED_ACTION") {
                val streamType = intent.getIntExtra("android.media.EXTRA_VOLUME_STREAM_TYPE", -1)
                if (streamType == AudioManager.STREAM_MUSIC) {
                    checkAndClampVolumeForRhythmGuard()
                    checkAndPauseOnZeroSystemVolume()
                    extendSleepTimer()
                }
            }
        }
    }

    private var btInfo: app.needle.player.util.BtCodecInfo? = null
    private var btProxy: app.needle.player.util.BtCodecInfo.Companion.Proxy? = null

    var currentLyricTexts: List<String> = emptyList()
    var currentLyricTranslations: List<String> = emptyList()
    var currentLyricRomanizations: List<String> = emptyList()
    var currentLyricTimestamps: LongArray = longArrayOf()
    var currentPlainLyricsLines: List<String> = emptyList()
    var currentLyricIndex: Int = -1

    private fun getProcessedLyricTexts(): List<String> {
        val showTranslation = appSettings.showLyricsTranslation.value
        val showRomanization = appSettings.showLyricsRomanization.value
        
        return currentLyricTexts.mapIndexed { index, text ->
            val translation = currentLyricTranslations.getOrNull(index)
            val romanization = currentLyricRomanizations.getOrNull(index)
            
            buildString {
                append(text)
                if (showTranslation && !translation.isNullOrBlank()) {
                    append("\n")
                    append(translation)
                }
                if (showRomanization && !romanization.isNullOrBlank()) {
                    append("\n")
                    append(romanization)
                }
            }
        }
    }

    private fun clearLyricsState() {
        currentLyricTexts = emptyList()
        currentLyricTranslations = emptyList()
        currentLyricRomanizations = emptyList()
        currentLyricTimestamps = longArrayOf()
        currentPlainLyricsLines = emptyList()
        currentLyricIndex = -1
        app.needle.player.infrastructure.widget.glance.GlanceWidgetUpdater.updateLyrics(this, emptyList(), -1)
    }

    private val btReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "android.bluetooth.a2dp.profile.action.CODEC_CONFIG_CHANGED" &&
                Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
            ) {
                val codecStatus = intent.getParcelableExtra("android.bluetooth.extra.CODEC_STATUS", android.bluetooth.BluetoothCodecStatus::class.java)
                val newBtInfo = app.needle.player.util.BtCodecInfo.fromCodecConfig(codecStatus?.codecConfig)
                if (newBtInfo != null && newBtInfo != btInfo) {
                    btInfo = newBtInfo
                    Log.d(TAG, "New Bluetooth codec config: $btInfo")
                    if (appSettings.codecMonitoringEnabled.value && appSettings.showCodecNotifications.value) {
                        showCodecNotification(newBtInfo)
                    }
                }
            }
        }
    }

    private fun showCodecNotification(info: app.needle.player.util.BtCodecInfo) {
        val codecName = info.codec ?: "Unknown"
        val sampleRate = info.sampleRateHz?.let { "$it Hz" } ?: "Unknown Rate"
        val bits = info.bitsPerSample?.let { "$it bits" } ?: ""
        val quality = info.quality?.let { " ($it)" } ?: ""
        val message = "Bluetooth Codec: $codecName, $sampleRate, $bits$quality"
        Toast.makeText(this, message, Toast.LENGTH_LONG).show()
    }

    /**
     * When "Pause on Zero Volume" is enabled and system-volume mode is active,
     * pause playback as soon as the system music stream reaches 0.
     * Also broadcasts ACTION_ZERO_VOLUME_PAUSE so the UI can show the dialog
     * regardless of whether MaterialPlayerScreen is currently in composition.
     */
    private fun checkAndPauseOnZeroSystemVolume() {
        try {
            if (!::appSettings.isInitialized) return
            if (!appSettings.useSystemVolume.value) return
            if (!appSettings.stopPlaybackOnZeroVolume.value) return

            val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
            val current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)

            // Auto-resume when system volume rises above 0 after a zero-volume pause
            if (current > 0 && pausedByZeroVolume && !player.isPlaying) {
                Log.d(TAG, "System volume rose above 0 — resuming from zero-volume pause")
                pausedByZeroVolume = false
                player.play()
                val broadcastIntent = Intent(ACTION_ZERO_VOLUME_RESUME).apply {
                    `package` = packageName
                }
                sendBroadcast(broadcastIntent)
                return
            }

            if (current == 0 && player.isPlaying) {
                Log.d(TAG, "System volume hit 0 while playing — pausing (pause-on-zero active)")
                pausedByZeroVolume = true
                player.pause()
                val broadcastIntent = Intent(ACTION_ZERO_VOLUME_PAUSE).apply {
                    `package` = packageName
                }
                sendBroadcast(broadcastIntent)
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error in checkAndPauseOnZeroSystemVolume", e)
        }
    }

    private fun checkAndClampVolumeForRhythmGuard() {
        try {
            if (!::appSettings.isInitialized) return
            val mode = appSettings.rhythmGuardMode.value
            if (mode == AppSettings.RHYTHM_GUARD_MODE_AUTO) {
                val age = appSettings.rhythmGuardAge.value
                val policy = appSettings.getRhythmGuardPolicy(age)
                val activeThreshold = policy.maxVolumeThreshold
                
                val audioManager = getSystemService(Context.AUDIO_SERVICE) as? AudioManager ?: return
                val isSpeaker = isSpeakerOutputActive(audioManager)
                val applyVolumeLimitOnSpeaker = appSettings.rhythmGuardApplyVolumeLimitOnSpeaker.value
                val shouldApply = applyVolumeLimitOnSpeaker || !isSpeaker
                
                if (shouldApply) {
                    val currentVolume = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC)
                    val maxVolume = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC)
                    val currentVolumeFraction = if (maxVolume > 0) currentVolume.toFloat() / maxVolume.toFloat() else 0f
                    
                    val volumeOvershoot = currentVolumeFraction - activeThreshold
                    if (volumeOvershoot > 0.01f) {
                        val targetVolume = Math.round(activeThreshold * maxVolume).coerceIn(0, maxVolume)
                        audioManager.setStreamVolume(AudioManager.STREAM_MUSIC, targetVolume, 0)
                        Log.d(TAG, "Rhythm Guard Auto: clamped system volume from $currentVolumeFraction to $activeThreshold")
                    }
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error clamping volume in background", e)
        }
    }

    private fun isSpeakerOutputActive(audioManager: AudioManager): Boolean {
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        return devices.any { it.type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER } &&
                !devices.any {
                    (it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
                     it.type == AudioDeviceInfo.TYPE_BLUETOOTH_SCO ||
                     it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
                     it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
                     it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                     it.type == AudioDeviceInfo.TYPE_USB_HEADSET) &&
                    it.isSink
                }
    }

    private fun showRhythmGuardAlertNotification(title: String, text: String, riskLevel: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureRhythmGuardNotificationChannels(notificationManager)

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_player", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            8101,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val priority = when (riskLevel) {
            "SEVERE", "HIGH" -> NotificationCompat.PRIORITY_HIGH
            "MODERATE" -> NotificationCompat.PRIORITY_DEFAULT
            else -> NotificationCompat.PRIORITY_LOW
        }

        val notification = NotificationCompat.Builder(this, "rhythm_guard_alerts")
            .setSmallIcon(app.needle.player.R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(NotificationCompat.BigTextStyle().bigText(text))
            .setCategory(NotificationCompat.CATEGORY_ALARM)
            .setPriority(priority)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(1301, notification)
    }

    private fun showRhythmGuardTimerNotification(title: String, text: String, remainingSeconds: Long, totalSeconds: Long) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        ensureRhythmGuardNotificationChannels(notificationManager)

        val safeTotal = totalSeconds.coerceAtLeast(1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val safeRemaining = remainingSeconds.coerceIn(0L, safeTotal.toLong()).toInt()
        val completed = (safeTotal - safeRemaining).coerceIn(0, safeTotal)

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("open_player", true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            8102,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(this, "rhythm_guard_timers")
            .setSmallIcon(app.needle.player.R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(
                NotificationCompat.BigTextStyle().bigText(
                    "$text\n${getString(app.needle.player.R.string.settings_rhythm_guard_notification_tap_open)}"
                )
            )
            .setProgress(safeTotal, completed, false)
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setAutoCancel(true)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setContentIntent(pendingIntent)
            .build()

        notificationManager.notify(1302, notification)
    }

    private fun ensureRhythmGuardNotificationChannels(notificationManager: NotificationManager) {

        val alertChannel = NotificationChannel(
            "rhythm_guard_alerts",
            getString(app.needle.player.R.string.service_rhythm_guard_alerts),
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = getString(app.needle.player.R.string.service_rhythm_guard_alerts_desc)
            enableVibration(true)
        }

        val timerChannel = NotificationChannel(
            "rhythm_guard_timers",
            getString(app.needle.player.R.string.service_rhythm_guard_timers),
            NotificationManager.IMPORTANCE_DEFAULT
        ).apply {
            description = getString(app.needle.player.R.string.service_rhythm_guard_timers_desc)
            enableVibration(false)
            setShowBadge(false)
        }

        notificationManager.createNotificationChannel(alertChannel)
        notificationManager.createNotificationChannel(timerChannel)
    }

    private fun cancelRhythmGuardTimerNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(1302)
    }

    private fun cancelRhythmGuardAlertNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(1301)
    }


    private val repeatCommand: CommandButton
        get() = when (val mode = controller?.repeatMode ?: Player.REPEAT_MODE_OFF) {
            Player.REPEAT_MODE_OFF -> customCommands[2]
            Player.REPEAT_MODE_ALL -> customCommands[3]
            Player.REPEAT_MODE_ONE -> customCommands[4]
            else -> customCommands[2] // Fallback to REPEAT_MODE_OFF command
        }

    private val shuffleCommand: CommandButton
        get() = if (controller?.shuffleModeEnabled == true) {
            customCommands[1]
        } else {
            customCommands[0]
        }

    private fun getCurrentFavoriteCommand(): CommandButton {
        return if (isCurrentSongFavorite()) {
            customCommands[6] // Remove from favorites (filled heart)
        } else {
            customCommands[5] // Add to favorites (heart outline)
        }
    }

    // Track external files that have been played
    private val externalUriCache = ConcurrentHashMap<String, MediaItem>()

    // Settings manager
    private lateinit var appSettings: AppSettings
    
    // Status broadcaster for Tasker, KWGT, and other automation apps
    private lateinit var statusBroadcaster: app.needle.player.utils.StatusBroadcaster
    
    // SharedPreferences keys
    companion object {
        var instanceForWidgetAndLyricsOnly: MediaPlaybackService? = null
        private const val TAG = "MediaPlaybackService"
        private const val NOTIFICATION_ID = 1001
        private const val CHANNEL_ID = "RhythmMediaPlayback"
        private const val SLEEP_TIMER_NOTIFICATION_ID = 1002
        private const val SLEEP_TIMER_CHANNEL_ID = "RhythmSleepTimer"
        private const val EQ_TOGGLE_DUCK_FACTOR = 0.12f
        private const val EQ_TOGGLE_SETTLE_DELAY_MS = 45L
        private const val EQ_TOGGLE_RAMP_STEPS = 6
        private const val EQ_TOGGLE_RAMP_STEP_DELAY_MS = 22L

        private const val PREF_NAME = "rhythm_preferences"
        private const val PREF_GAPLESS_PLAYBACK = "gapless_playback"
        private const val PREF_CROSSFADE = "crossfade"
        private const val PREF_CROSSFADE_DURATION = "crossfade_duration"
        private const val PREF_AUDIO_NORMALIZATION = "audio_normalization"
        private const val PREF_REPLAY_GAIN = "replay_gain"
        
        // Intent action for updating settings
        const val ACTION_UPDATE_SETTINGS = "app.needle.player.action.UPDATE_SETTINGS"
        
        // Intent action for playing external files
        const val ACTION_PLAY_EXTERNAL_FILE = "app.needle.player.action.PLAY_EXTERNAL_FILE"
        
        // Intent action for initializing the service
        const val ACTION_INIT_SERVICE = "app.needle.player.action.INIT_SERVICE"
        
        // Intent actions for sleep timer
        const val ACTION_START_SLEEP_TIMER = "app.needle.player.action.START_SLEEP_TIMER"
        const val ACTION_STOP_SLEEP_TIMER = "app.needle.player.action.STOP_SLEEP_TIMER"
        const val ACTION_EXTEND_SLEEP_TIMER = "app.needle.player.action.EXTEND_SLEEP_TIMER"
        
        // Intent actions for equalizer
        const val ACTION_SET_EQUALIZER_ENABLED = "app.needle.player.action.SET_EQUALIZER_ENABLED"
        const val ACTION_SET_EQUALIZER_BAND = "app.needle.player.action.SET_EQUALIZER_BAND"
        const val ACTION_SET_BASS_BOOST = "app.needle.player.action.SET_BASS_BOOST"
        const val ACTION_SET_VIRTUALIZER = "app.needle.player.action.SET_VIRTUALIZER"
        const val ACTION_SET_MONO_AUDIO = "app.needle.player.action.SET_MONO_AUDIO"
        const val ACTION_APPLY_EQUALIZER_PRESET = "app.needle.player.action.APPLY_EQUALIZER_PRESET"
        const val ACTION_GET_EQUALIZER_DIAGNOSTICS = "app.needle.player.action.GET_EQUALIZER_DIAGNOSTICS"
        
        // Widget control actions
        const val ACTION_PLAY_PAUSE = "app.needle.player.action.PLAY_PAUSE"
        const val ACTION_SKIP_NEXT = "app.needle.player.action.SKIP_NEXT"
        const val ACTION_SKIP_PREVIOUS = "app.needle.player.action.SKIP_PREVIOUS"
        const val ACTION_TOGGLE_FAVORITE = "app.needle.player.action.TOGGLE_FAVORITE"
        const val ACTION_TOGGLE_SHUFFLE = "app.needle.player.action.TOGGLE_SHUFFLE"
        const val ACTION_TOGGLE_REPEAT = "app.needle.player.action.TOGGLE_REPEAT"
        
        // Broadcast actions for status updates
        const val BROADCAST_SLEEP_TIMER_STATUS = "app.needle.player.broadcast.SLEEP_TIMER_STATUS"
        const val EXTRA_TIMER_ACTIVE = "timer_active"
        const val EXTRA_REMAINING_TIME = "remaining_time"
        const val EXTRA_TOTAL_TIME = "total_time"

        // Broadcast actions for shuffle updates
        const val ACTION_SHUFFLE_STATE_CHANGED = "app.needle.player.action.SHUFFLE_STATE_CHANGED"
        const val EXTRA_SHUFFLE_ENABLED = "shuffle_enabled"
        
        // Audio session ID
        const val ACTION_GET_AUDIO_SESSION_ID = "app.needle.player.action.GET_AUDIO_SESSION_ID"
        const val BROADCAST_AUDIO_SESSION_ID = "app.needle.player.broadcast.AUDIO_SESSION_ID"
        const val EXTRA_AUDIO_SESSION_ID = "audio_session_id"
        
        // Mute/Unmute actions (Media3 1.9.0 feature)
        const val ACTION_MUTE = "app.needle.player.action.MUTE"
        const val ACTION_UNMUTE = "app.needle.player.action.UNMUTE"
        const val ACTION_TOGGLE_MUTE = "app.needle.player.action.TOGGLE_MUTE"

        // Zero-volume pause/resume broadcasts — sent by service, received by UI to show/dismiss dialog
        const val ACTION_ZERO_VOLUME_PAUSE = "app.needle.player.action.ZERO_VOLUME_PAUSE"
        const val ACTION_ZERO_VOLUME_RESUME = "app.needle.player.action.ZERO_VOLUME_RESUME"

        // Playback custom commands
        const val REPEAT_MODE_ALL = "repeat_all"
        const val REPEAT_MODE_ONE = "repeat_one"
        const val REPEAT_MODE_OFF = "repeat_off"
        const val SHUFFLE_MODE_ON = "shuffle_on"
        const val SHUFFLE_MODE_OFF = "shuffle_off"
        const val FAVORITE_ON = "favorite_on"
        const val FAVORITE_OFF = "favorite_off"

        private const val METADATA_EXTRA_ORIGINAL_TITLE = "app.needle.player.extra.original_title"
        private const val METADATA_EXTRA_ORIGINAL_ARTIST = "app.needle.player.extra.original_artist"
        private const val METADATA_EXTRA_ORIGINAL_ALBUM = "app.needle.player.extra.original_album"
    }

    override fun onCreate() {
        super.onCreate()
        instanceForWidgetAndLyricsOnly = this
        Log.d(TAG, "Service created")

        setMediaNotificationProvider(
            androidx.media3.session.DefaultMediaNotificationProvider(this).apply {
                setSmallIcon(app.needle.player.R.drawable.ic_notification)
            }
        )

        // Create notification channel first (required for Android 8.0+)
        createNotificationChannel()

        // Initialize settings manager (fast operation)
        appSettings = AppSettings.getInstance(applicationContext)
        
        // Initialize preloader
        preloadController = PreloadController(applicationContext, appSettings)
        
        // Initialize Rhythm audio processors early (before player creation)
        try {
            rhythmBassBoostProcessor = app.needle.player.infrastructure.audio.RhythmBassBoostProcessor().apply {
                setEnabled(appSettings.bassBoostEnabled.value)
                setStrength(appSettings.bassBoostStrength.value.toShort())
            }
            rhythmSpatializationProcessor = app.needle.player.infrastructure.audio.RhythmSpatializationProcessor().apply {
                setEnabled(appSettings.virtualizerEnabled.value)
                setStrength(appSettings.virtualizerStrength.value.toShort())
            }
            rhythmMonoAudioProcessor = app.needle.player.infrastructure.audio.RhythmMonoAudioProcessor().apply {
                setEnabled(appSettings.monoAudioEnabled.value)
            }
            isBassBoostAvailable = true
            appSettings.setBassBoostAvailable(true)
            Log.d(TAG, "Rhythm audio processors initialized early with saved settings (mono=${appSettings.monoAudioEnabled.value}, bass=${appSettings.bassBoostEnabled.value}, spatial=${appSettings.virtualizerEnabled.value})")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize Rhythm processors", e)
            rhythmBassBoostProcessor = null
            rhythmSpatializationProcessor = null
            rhythmMonoAudioProcessor = null
            isBassBoostAvailable = false
            appSettings.setBassBoostAvailable(false)
        }
        
        // Initialize status broadcaster for Tasker/KWGT
        statusBroadcaster = app.needle.player.utils.StatusBroadcaster(applicationContext)

        // Register BroadcastReceiver for favorite changes
        androidx.core.content.ContextCompat.registerReceiver(
            this,
            favoriteChangeReceiver,
            IntentFilter("app.needle.player.action.FAVORITE_CHANGED"),
            androidx.core.content.ContextCompat.RECEIVER_NOT_EXPORTED
        )

        val volumeFilter = IntentFilter("android.media.VOLUME_CHANGED_ACTION")
        androidx.core.content.ContextCompat.registerReceiver(
            this,
            volumeChangeReceiver,
            volumeFilter,
            androidx.core.content.ContextCompat.RECEIVER_EXPORTED
        )

        try {
            val btFilter = IntentFilter("android.bluetooth.a2dp.profile.action.CODEC_CONFIG_CHANGED")
            androidx.core.content.ContextCompat.registerReceiver(
                this,
                btReceiver,
                btFilter,
                androidx.core.content.ContextCompat.RECEIVER_EXPORTED
            )

btProxy = app.needle.player.util.BtCodecInfo.getCodec(this) { info ->
    if (info != null) {
        btInfo = info
        Log.d(TAG, "First Bluetooth codec config: $btInfo")
    }
}
        } catch (e: Exception) {
            Log.e(TAG, "Error setting up Bluetooth codec monitoring", e)
        }

        try {
            // Initialize core components on main thread (required for media service)
            initializePlayer()
            createCustomCommands()

            // Create the media session (required synchronously)
            mediaSession = createMediaSession()

            // Initialize controller asynchronously to avoid blocking
            createController()

            // Rhythm Guard background check loop (every 10 seconds)
            serviceScope.launch {
                val statsRepository = PlaybackStatsRepository.getInstance(applicationContext)
                while (isActive) {
                    try {
                        val mode = appSettings.rhythmGuardMode.value
                        if (mode != AppSettings.RHYTHM_GUARD_MODE_OFF) {
                            val now = System.currentTimeMillis()
                            val timeoutUntil = appSettings.rhythmGuardTimeoutUntilMs.value
                            val cooldownUntil = appSettings.rhythmGuardTimeoutCooldownUntilMs.value
                            if (timeoutUntil > 0L && now >= timeoutUntil && cooldownUntil <= 0L) {
                                val cooldownMinutes = appSettings.rhythmGuardPostTimeoutCooldownMinutes.value.coerceIn(1, 60)
                                val cooldownUntilMs = now + cooldownMinutes.toLong() * 60_000L
                                
                                val todaySummary = runCatching {
                                    statsRepository.loadSummary(StatsTimeRange.TODAY)
                                }.getOrNull()
                                val dbDurationMs = todaySummary?.totalDurationMs ?: 0L
                                val currentPositionMs = player.currentPosition
                                val totalMs = dbDurationMs + currentPositionMs
                                val currentMinutes = (totalMs / 60000L).toInt().coerceAtLeast(0)
                                
                                appSettings.setRhythmGuardTimeoutCooldownWithLimit(cooldownUntilMs, currentMinutes + 15)
                                appSettings.clearRhythmGuardListeningTimeout()
                                cancelRhythmGuardTimerNotification()
                                if (wasPlayingBeforeTimeout) {
                                    wasPlayingBeforeTimeout = false
                                    withContext(Dispatchers.Main) {
                                        player.play()
                                    }
                                }
                            } else if (now < timeoutUntil) {
                                // Timeout is active, ensure playback is paused
                                if (player.isPlaying) {
                                    wasPlayingBeforeTimeout = true
                                    withContext(Dispatchers.Main) {
                                        player.pause()
                                    }
                                }
                            } else if (now < cooldownUntil) {
                                // Cooldown is active, do not trigger a new timeout
                            } else {
                                if (cooldownUntil > 0L) {
                                    appSettings.clearRhythmGuardTimeoutCooldown()
                                }
                                if (player.isPlaying) {
                                    // Check active daily exposure limit
                                    val age = appSettings.rhythmGuardAge.value
                                    val policy = appSettings.getRhythmGuardPolicy(age)
                                    val alertThresholdMinutes = appSettings.rhythmGuardAlertThresholdMinutes.value
                                    val effectiveLimitMinutes = if (mode == AppSettings.RHYTHM_GUARD_MODE_AUTO) {
                                        policy.recommendedDailyMinutes
                                    } else if (alertThresholdMinutes > 0) {
                                        alertThresholdMinutes
                                    } else {
                                        policy.recommendedDailyMinutes
                                    }

                                    val todaySummary = runCatching {
                                        statsRepository.loadSummary(StatsTimeRange.TODAY)
                                    }.getOrNull()
                                    val dbDurationMs = todaySummary?.totalDurationMs ?: 0L
                                    val currentPositionMs = player.currentPosition
                                    val totalMs = dbDurationMs + currentPositionMs
                                    val currentMinutes = (totalMs / 60000L).toInt().coerceAtLeast(0)

                                    // If listening minutes are below the daily limit (e.g., new day), reset the next allowed limit
                                    if (currentMinutes <= effectiveLimitMinutes) {
                                        if (appSettings.rhythmGuardNextAllowedLimitMinutes.value != 0) {
                                            appSettings.setRhythmGuardNextAllowedLimitMinutes(0)
                                        }
                                    }

                                    val nextAllowedLimit = appSettings.rhythmGuardNextAllowedLimitMinutes.value
                                    val activeLimit = if (nextAllowedLimit > effectiveLimitMinutes) {
                                        nextAllowedLimit
                                    } else {
                                        effectiveLimitMinutes
                                    }

                                    if (currentMinutes > activeLimit) {
                                        val breakResumeMinutes = appSettings.rhythmGuardBreakResumeMinutes.value.coerceIn(1, 180)
                                        val newTimeoutUntilMs = now + breakResumeMinutes * 60_000L
                                        val formattedToday = rhythmGuardFormatDurationFromMinutes(currentMinutes)
                                        val formattedLimit = rhythmGuardFormatDurationFromMinutes(effectiveLimitMinutes)
                                        val timeoutReason = getString(
                                            app.needle.player.R.string.settings_rhythm_guard_timeout_reason_auto,
                                            formattedToday,
                                            formattedLimit
                                        )

                                        appSettings.setRhythmGuardListeningTimeout(
                                            untilEpochMs = newTimeoutUntilMs,
                                            reason = timeoutReason,
                                            startedAtEpochMs = now
                                        )

                                        if (appSettings.rhythmGuardAlertNotificationsEnabled.value) {
                                            showRhythmGuardAlertNotification(
                                                title = getString(app.needle.player.R.string.settings_rhythm_guard_notification_alert_title),
                                                text = timeoutReason,
                                                riskLevel = "HIGH"
                                            )
                                        }

                                        if (appSettings.rhythmGuardTimerNotificationsEnabled.value) {
                                            showRhythmGuardTimerNotification(
                                                title = getString(app.needle.player.R.string.settings_rhythm_guard_notification_timer_active_title),
                                                text = getString(
                                                    app.needle.player.R.string.settings_rhythm_guard_notification_timer_active_text,
                                                    rhythmGuardFormatDurationFromMinutes(breakResumeMinutes)
                                                ),
                                                remainingSeconds = breakResumeMinutes.toLong() * 60L,
                                                totalSeconds = breakResumeMinutes.toLong() * 60L
                                            )
                                        }

                                        withContext(Dispatchers.Main) {
                                            val wasPlaying = player.isPlaying
                                            if (wasPlaying) {
                                                wasPlayingBeforeTimeout = true
                                                player.pause()
                                            }
                                            try {
                                                RhythmGuardTimeoutActivity.start(
                                                    context = applicationContext,
                                                    reason = timeoutReason,
                                                    timeoutUntilMs = newTimeoutUntilMs,
                                                    timeoutStartedAtMs = now
                                                )
                                            } catch (e: Exception) {
                                                Log.w(TAG, "Failed to start RhythmGuardTimeoutActivity from background", e)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error in Rhythm Guard background loop", e)
                    }
                    delay(10000L)
                }
            }

            updateForegroundNotification(
                getString(app.needle.player.R.string.service_rhythm_music),
                getString(app.needle.player.R.string.service_ready)
            )

            Log.d(TAG, "Service initialized successfully")
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing service", e)
            updateForegroundNotification(
                getString(app.needle.player.R.string.service_rhythm_music),
                getString(app.needle.player.R.string.service_init_failed)
            )
        }
    }
    
    private fun createNotificationChannel() {
val channel = NotificationChannel(
    CHANNEL_ID,
    getString(app.needle.player.R.string.media3_notification_channel_name),
    NotificationManager.IMPORTANCE_LOW
).apply {
    description = getString(app.needle.player.R.string.media3_notification_channel_description)
    setShowBadge(false)
}

val sleepTimerChannel = NotificationChannel(
    SLEEP_TIMER_CHANNEL_ID,
    getString(app.needle.player.R.string.notification_sleep_timer_channel_name),
    NotificationManager.IMPORTANCE_DEFAULT
).apply {
    description = getString(app.needle.player.R.string.notification_sleep_timer_channel_desc)
    setShowBadge(false)
    enableVibration(false)
}

val notificationManager = getSystemService(NotificationManager::class.java)
notificationManager.createNotificationChannel(channel)
notificationManager.createNotificationChannel(sleepTimerChannel)
    }
    
    private fun startForegroundWithNotification(title: String = "Rhythm Music", content: String = "Rhythm is starting.") {
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(app.needle.player.R.drawable.ic_notification)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        // CRITICAL: startForeground() MUST be called within 5 seconds when service is
        // started via startForegroundService(), or Android will ANR the app.
        // Even if an exception occurs, we must attempt the call.
        var foregroundStartSucceeded = false
        
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                super.startForeground(NOTIFICATION_ID, notification, android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                super.startForeground(NOTIFICATION_ID, notification)
            }
            foregroundStartSucceeded = true
            Log.d(TAG, "Started foreground service: $title - $content")
        } catch (e: Exception) {
            Log.e(TAG, "startForeground() failed with exception: ${e.javaClass.simpleName}: ${e.message}", e)
            
            // Check if this is a background restriction issue
            val isForegroundRestricted = Build.VERSION.SDK_INT >= Build.VERSION_CODES.S &&
                e.javaClass.name.contains("ForegroundServiceStartNotAllowedException")
            
            if (isForegroundRestricted) {
                Log.w(TAG, "Foreground service start blocked by system (background restriction). Service will run with standard notification.")
                // In this case, we can't satisfy the startForegroundService() contract,
                // but we'll continue anyway and show a regular notification.
                // This is not ideal but better than crashing.
            } else {
                // For other exceptions, log them but try to continue
                Log.w(TAG, "Unexpected exception during startForeground(), will attempt notification fallback.", e)
            }
            
            // Attempt to show notification as fallback (will not satisfy startForegroundService contract)
            try {
                val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
                notificationManager.notify(NOTIFICATION_ID, notification)
                Log.w(TAG, "Posted notification as fallback. Service may experience issues on some Android versions.")
            } catch (notifyError: Exception) {
                Log.e(TAG, "Failed to post fallback notification", notifyError)
            }
        }
        
        if (!foregroundStartSucceeded) {
            Log.w(TAG, "WARNING: startForeground() was not successfully called. This service may be terminated if it stays in background.")
        }
    }

    private fun updateForegroundNotification(title: String, content: String) {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val notification = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(title)
            .setContentText(content)
            .setSmallIcon(app.needle.player.R.drawable.ic_notification)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_SERVICE)
            .build()

        notificationManager.notify(NOTIFICATION_ID, notification)
        Log.d(TAG, "Updated foreground notification: $title - $content")
    }
    
    private fun initializePlayer() {
        // Initialize RhythmPlayerEngine for crossfade support
        val audioRoutingMode = appSettings.audioRoutingMode.value
        Log.d(TAG, "Initializing player (routing: $audioRoutingMode)")
        rhythmPlayerEngine = RhythmPlayerEngine(
            this, 
            bassBoostProcessor = rhythmBassBoostProcessor,
            spatializationProcessor = rhythmSpatializationProcessor,
            monoProcessor = rhythmMonoAudioProcessor
        )
        rhythmPlayerEngine.initialize()
        applyUsbExclusiveRoutingPreference()
        
        // The master player is exposed to MediaSession and used everywhere
        player = wrapPlayer(rhythmPlayerEngine.masterPlayer)
        
        // Restore saved shuffle and repeat states on startup
        if (appSettings.shuffleModePersistence.value) {
            val savedShuffle = appSettings.savedShuffleState.value
            val useExoPlayerShuffle = appSettings.shuffleUsesExoplayer.value
            player.shuffleModeEnabled = savedShuffle && useExoPlayerShuffle
            Log.d(TAG, "Restored player shuffle mode: ${player.shuffleModeEnabled} (useExoPlayerShuffle=$useExoPlayerShuffle)")
        }
        if (appSettings.repeatModePersistence.value) {
            player.repeatMode = appSettings.savedRepeatMode.value
            Log.d(TAG, "Restored player repeat mode: ${player.repeatMode}")
        }
        
        // Register player swap listener for crossfade transitions
        rhythmPlayerEngine.addPlayerSwapListener { newPlayer ->
            Log.d(TAG, "Player swapped during crossfade transition")
            val oldPlayer = player
            val wrappedNewPlayer = wrapPlayer(newPlayer)
            player = wrappedNewPlayer
            
            // Move the service-level player listener to the new player
            playerListener?.let { listener ->
                oldPlayer.removeListener(listener)
                wrappedNewPlayer.addListener(listener)
            }
            
            // Update the MediaSession to use the new player
            mediaSession?.player = wrappedNewPlayer
            
            // Force custom layout update for the new player
            scheduleCustomLayoutUpdate(50)
            
            // Update widget with current song info
            updateWidgetFromMediaItem(newPlayer.currentMediaItem)
            
            // Reinitialize audio effects with new session ID if session changed
            val newSessionId = (newPlayer as? ExoPlayer)?.audioSessionId ?: 0
            if (newSessionId != 0 && (!audioEffectsInitialized || currentAudioEffectsSessionId != newSessionId)) {
                initializeAudioEffects()
            }
        }
            
        // Add listener to initialize audio effects when session ID is ready and handle errors
        // Store reference for proper cleanup in onDestroy
        playerListener = object : Player.Listener {
            override fun onTimelineChanged(timeline: androidx.media3.common.Timeline, reason: Int) {
                if (::preloadController.isInitialized) {
                    val mediaItems = mutableListOf<MediaItem>()
                    for (i in 0 until player.mediaItemCount) {
                        mediaItems.add(player.getMediaItemAt(i))
                    }
                    preloadController.addOrUpdateQueue(mediaItems)
                }
            }

            override fun onPlaybackStateChanged(playbackState: Int) {
                if (playbackState == Player.STATE_READY && getPlayerAudioSessionId() != 0) {
                    val currentSessionId = getPlayerAudioSessionId()
                    val needsInit = !audioEffectsInitialized || currentAudioEffectsSessionId != currentSessionId
                    if (needsInit) {
                        val previouslyEnabled = getEqualizerEnabledSafe()
                        Log.d(TAG, "Player ready with new session ID $currentSessionId, initializing effects (EQ was: $previouslyEnabled)")
                        initializeAudioEffects()
                        
                        // Reload effects settings and re-apply processors after audio pipeline is ready
                        serviceScope.launch {
                            delay(200)
                            Log.d(TAG, "Force-reloading audio effects settings after player ready")
                            loadSavedAudioEffects()
                            
                            delay(100)
                            Log.d(TAG, "Re-applying Rhythm processor settings for cold boot fix")
                            
                            if (appSettings.bassBoostEnabled.value && rhythmBassBoostProcessor != null) {
                                rhythmBassBoostProcessor?.setEnabled(true)
                                rhythmBassBoostProcessor?.setStrength(appSettings.bassBoostStrength.value.toShort())
                                Log.d(TAG, "Cold boot: Re-applied bass boost - enabled=true, strength=${appSettings.bassBoostStrength.value}")
                            }
                            
                            if (appSettings.virtualizerEnabled.value && rhythmSpatializationProcessor != null) {
                                rhythmSpatializationProcessor?.setEnabled(true)
                                rhythmSpatializationProcessor?.setStrength(appSettings.virtualizerStrength.value.toShort())
                                Log.d(TAG, "Cold boot: Re-applied spatial audio - enabled=true, strength=${appSettings.virtualizerStrength.value}")
                            }

                            if (appSettings.monoAudioEnabled.value && rhythmMonoAudioProcessor != null) {
                                rhythmMonoAudioProcessor?.setEnabled(true)
                                Log.d(TAG, "Cold boot: Re-applied mono audio - enabled=true")
                            }
                        }
                        
                        // Verify equalizer state was preserved after reinitialization
                        if (appSettings.equalizerEnabled.value) {
                            val currentlyEnabled = getEqualizerEnabledSafe()
                            if (previouslyEnabled != currentlyEnabled) {
                                Log.w(TAG, "Equalizer state changed after reinitialization! Was: $previouslyEnabled, Now: $currentlyEnabled, Expected: true")
                                setEqualizerEnabled(true)
                            }
                        }
                    }
                }
            }

            override fun onPlayWhenReadyChanged(playWhenReady: Boolean, reason: Int) {
                if (playWhenReady) {
                    val now = System.currentTimeMillis()
                    if (appSettings.rhythmGuardTimeoutUntilMs.value > now) {
                        Log.d(TAG, "Blocking player start due to active Rhythm Guard timeout")
                        try {
                            // Force pause to prevent playback
                            player.pause()
                        } catch (e: Exception) {
                            Log.w(TAG, "Failed to pause player while enforcing Rhythm Guard", e)
                        }
                    }
                }
            }
            
            override fun onPlayerError(error: PlaybackException) {
                handlePlaybackError(error)
            }
            
            override fun onIsPlayingChanged(isPlaying: Boolean) {
                
                // Broadcast status for Tasker/KWGT/automation apps
                if (appSettings.broadcastStatusEnabled.value) {
                    statusBroadcaster.broadcastPlaystateChanged(isPlaying, player.currentPosition)
                }

                // Persist playback position when paused and queue persistence is enabled
                if (!isPlaying && appSettings.queuePersistenceEnabled.value) {
                    val currentIndex = player.currentMediaItemIndex
                    if (currentIndex != androidx.media3.common.C.INDEX_UNSET) {
                        appSettings.setSavedQueueIndex(currentIndex)
                        appSettings.setSavedPlaybackPosition(player.currentPosition)
                        Log.d(TAG, "Persisted queue index $currentIndex and position ${player.currentPosition} on pause")
                    }
                }
            }
            
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                if (::preloadController.isInitialized) {
                    val currentIndex = player.currentMediaItemIndex
                    if (currentIndex != androidx.media3.common.C.INDEX_UNSET) {
                        preloadController.setPlayingIndex(currentIndex)
                    }
                }

                if (appSettings.queuePersistenceEnabled.value) {
                    val currentIndex = player.currentMediaItemIndex
                    if (currentIndex != androidx.media3.common.C.INDEX_UNSET) {
                        appSettings.setSavedQueueIndex(currentIndex)
                        // Reset position to 0L only when transitioning automatically to the next track.
                        // Do NOT wipe saved position on playlist change or seek (e.g. queue restoration).
                        if (reason == Player.MEDIA_ITEM_TRANSITION_REASON_AUTO) {
                            appSettings.setSavedPlaybackPosition(0L)
                        }
                        Log.d(TAG, "Persisted queue index $currentIndex on track transition (reason=$reason)")
                    }
                }
                
                val transitionMediaId = mediaItem?.mediaId
                if (
                    reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED &&
                    transitionMediaId != null &&
                    transitionMediaId == lastHandledPlayerTransitionMediaId
                ) {
                    Log.d(TAG, "Ignoring metadata-only player transition for mediaId=$transitionMediaId")
                    return
                }

                if (transitionMediaId != null && ::rhythmPlayerEngine.isInitialized) {
                    val cachedTags = ReplayGainCache.get(transitionMediaId)
                    if (cachedTags != null) {
                        rhythmPlayerEngine.getActiveReplayGainProcessor()?.setTags(cachedTags)
                    }
                }


                
                // Broadcast status for Tasker/KWGT/automation apps
                if (appSettings.broadcastStatusEnabled.value && mediaItem != null) {
                    try {
                        val song = convertMediaItemToSong(mediaItem)
                        if (song != null) {
                            statusBroadcaster.broadcastNowPlaying(
                                song,
                                player.isPlaying,
                                player.currentPosition,
                                player.mediaItemCount,
                                player.currentMediaItemIndex,
                                bluetoothLyricsMode = appSettings.bluetoothLyricsEnabled.value
                            )
                        }
                    } catch (e: Exception) {
                        Log.e(TAG, "Error broadcasting status on track change", e)
                    }
                }
                
                // Update widget when media item changes
                serviceScope.launch {
                    updateWidgetFromMediaItem(mediaItem)
                }

                lastHandledPlayerTransitionMediaId = transitionMediaId
            }
            
            // NEW in Media3 1.9.0: Monitor audio capabilities changes
            override fun onAudioSessionIdChanged(audioSessionId: Int) {
                Log.d(TAG, "Audio session ID changed: $audioSessionId")
                // Reinitialize audio effects with new session
                if (audioSessionId != 0) {
                    initializeAudioEffects()
                }
            }

            override fun onTracksChanged(tracks: androidx.media3.common.Tracks) {
                applyUsbExclusiveRoutingPreference()
            }
        }
        playerListener?.let { player.addListener(it) }
        
        // Initialize transition controller for crossfade scheduling
        transitionController = TransitionController(rhythmPlayerEngine, appSettings)
        transitionController.initialize()
        
        // Apply current settings
        applyPlayerSettings()
        
        // Try to initialize audio effects (might fail if session ID not ready)
        initializeAudioEffects()
        serviceScope.launch {
            appSettings.audioRoutingMode.collect { routingMode ->
                applyUsbExclusiveRoutingPreference()
                if (routingMode == "app") {
                    Log.i(TAG, "Bit-Perfect audio routing activated: disabling audio DSP effects")
                    withEqualizerSafe("bit-perfect flat EQ", Unit) { eq ->
                        val numberOfBands = eq.numberOfBands.toInt()
                        for (i in 0 until numberOfBands) {
                            eq.setBandLevel(i.toShort(), 0)
                        }
                    }
                    setEqualizerEnabledSafe(false)
                    rhythmBassBoostProcessor?.setEnabled(false)
                    rhythmSpatializationProcessor?.setEnabled(false)
                    rhythmMonoAudioProcessor?.setEnabled(false)
                    if (::rhythmPlayerEngine.isInitialized) {
                        rhythmPlayerEngine.applyReplayGainSettings(false)
                        rhythmPlayerEngine.setSkipSilenceEnabled(false)
                    }
                } else {
                    Log.i(TAG, "Standard audio routing restored: re-applying user audio effects")
                    loadSavedAudioEffects()
                    if (::rhythmPlayerEngine.isInitialized) {
                        rhythmPlayerEngine.applyReplayGainSettings(appSettings.replayGain.value)
                        rhythmPlayerEngine.setSkipSilenceEnabled(appSettings.skipSilenceEnabled.value)
                    }
                }
            }
        }

        // Collect replayGain setting reactively
        serviceScope.launch {
            kotlinx.coroutines.flow.combine(
                appSettings.replayGain,
                appSettings.replayGainMode,
                appSettings.replayGainDrc,
                appSettings.replayGainPreamp,
                appSettings.replayGainPreampUntagged
            ) { enabled, _, _, _, _ ->
                enabled
            }.collect { enabled ->
                if (appSettings.audioRoutingMode.value != "app") {
                    rhythmPlayerEngine.applyReplayGainSettings(enabled)
                }
            }
        }

        serviceScope.launch {
            appSettings.skipSilenceEnabled.collect { enabled ->
                val isBitPerfect = appSettings.audioRoutingMode.value == "app"
                if (::rhythmPlayerEngine.isInitialized) {
                    rhythmPlayerEngine.setSkipSilenceEnabled(if (isBitPerfect) false else enabled)
                }
            }
        }

        // Collect widget lyrics settings reactively
        serviceScope.launch {
            kotlinx.coroutines.flow.combine(
                appSettings.showLyricsTranslation,
                appSettings.showLyricsRomanization
            ) { _, _ -> }.collect {
                if (currentLyricTexts.isNotEmpty()) {
                    app.needle.player.infrastructure.widget.glance.GlanceWidgetUpdater.updateLyrics(
                        this@MediaPlaybackService,
                        getProcessedLyricTexts(),
                        currentLyricIndex
                    )
                }
            }
        }
    }

    private inline fun <T> withEqualizerSafe(
        operation: String,
        defaultValue: T,
        block: (android.media.audiofx.Equalizer) -> T
    ): T {
        val eq = equalizer ?: return defaultValue
        return try {
            block(eq)
        } catch (e: IllegalStateException) {
            Log.w(TAG, "Skipping equalizer $operation because effect is not initialized", e)
            defaultValue
        } catch (e: Exception) {
            Log.w(TAG, "Equalizer $operation failed", e)
            defaultValue
        }
    }

    private fun getEqualizerEnabledSafe(): Boolean {
        return withEqualizerSafe("enabled state read", false) { it.enabled }
    }

    private fun setEqualizerEnabledSafe(enabled: Boolean): Boolean {
        return withEqualizerSafe("enabled state write", false) { eq ->
            eq.enabled = enabled
            eq.enabled
        }
    }

    private fun setEqualizerEnabledWithVolumeGuard(enabled: Boolean): Boolean {
        if (!::player.isInitialized || !player.isPlaying) {
            if (!enabled) {
                // When disabling: just zero bands — don't toggle hardware EQ to avoid DSP burst
                withEqualizerSafe("set flat bands on disable", Unit) { eq ->
                    val numberOfBands = eq.numberOfBands.toInt()
                    for (i in 0 until numberOfBands) {
                        eq.setBandLevel(i.toShort(), 0)
                    }
                }
                return false
            }
            return setEqualizerEnabledSafe(true)
        }

        val restoreVolume = equalizerVolumeRestoreTarget ?: player.volume
        if (restoreVolume <= 0f) {
            if (!enabled) {
                withEqualizerSafe("set flat bands on disable", Unit) { eq ->
                    val numberOfBands = eq.numberOfBands.toInt()
                    for (i in 0 until numberOfBands) {
                        eq.setBandLevel(i.toShort(), 0)
                    }
                }
                return false
            }
            return setEqualizerEnabledSafe(true)
        }

        equalizerVolumeTransitionJob?.cancel()
        equalizerVolumeRestoreTarget = restoreVolume

        // Flag internal volume adjustment so engine doesn't overwrite userVolume with ducked values
        rhythmPlayerEngine.isInternalVolumeAdjustment = true

        // 1. Duck the player volume to 0.0f to completely silence any transient audio during the hardware transition
        player.volume = 0.0f
        var actualState = enabled

        equalizerVolumeTransitionJob = serviceScope.launch(Dispatchers.Main.immediate) {
            try {
                // If disabling, set the band levels to 0 (flat) first before waiting,
                // so the DSP coefficients transition smoothly in the background.
                if (!enabled) {
                    withEqualizerSafe("set flat bands on disable", Unit) { eq ->
                        val numberOfBands = eq.numberOfBands.toInt()
                        for (i in 0 until numberOfBands) {
                            eq.setBandLevel(i.toShort(), 0)
                        }
                    }
                }

                // 2. Wait for the silent/ducked volume state to propagate and the audio track's buffer to clear
                // Use a longer delay (300ms) when disabling to ensure the audio buffer is completely drained
                val drainDelay = if (enabled) 120L else 300L
                delay(drainDelay)
                
                // 3. Safely toggle the hardware equalizer enabled state while fully silent
                // When disabling: don't toggle hardware EQ — zeroing bands avoids AudioFlinger DSP reset bursts
                if (enabled) {
                    actualState = setEqualizerEnabledSafe(true)
                } else {
                    actualState = false
                }
                
                // 4. Settle delay to allow Android AudioFlinger / hardware DSP to fully transition
                // Extend deactivation settle delay to 550ms so driver pops finish in complete silence before volume ramps up
                val settleDelay = if (enabled) 45L else 550L
                delay(settleDelay)
                
                // 5. Smoothly ramp the volume back up to the original target from 0.0f
                val startVolume = player.volume
                repeat(EQ_TOGGLE_RAMP_STEPS) { step ->
                    val fraction = (step + 1).toFloat() / EQ_TOGGLE_RAMP_STEPS.toFloat()
                    player.volume = startVolume + (restoreVolume - startVolume) * fraction
                    delay(EQ_TOGGLE_RAMP_STEP_DELAY_MS)
                }
            } finally {
                if (equalizerVolumeRestoreTarget == restoreVolume) {
                    equalizerVolumeRestoreTarget = null
                }
                rhythmPlayerEngine.isInternalVolumeAdjustment = false
            }
        }

        return actualState
    }
    
    private fun handlePlaybackError(error: PlaybackException) {
        if (skipMissingLocalItem(error)) return

        val message = when (error.errorCode) {
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED ->
                "Audio codec not supported on this device"
            PlaybackException.ERROR_CODE_IO_UNSPECIFIED ->
                "Cannot read audio file"
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED ->
                "Audio format not supported"
            PlaybackException.ERROR_CODE_IO_FILE_NOT_FOUND ->
                "Audio file not found"
            PlaybackException.ERROR_CODE_IO_NO_PERMISSION ->
                "Permission denied to access audio file"
            else -> "Playback error: ${error.message}"
        }
        Log.e(TAG, "Playback error: $message", error)
        
        // Prevent auto skip and looping loading on corrupted songs by pausing/stopping the player
        if (appSettings.trackErrorCheckerEnabled.value) {
            try {
                player.pause()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to pause player on error", e)
            }
        }
    }

    /**
     * A local item whose file/MediaStore entry no longer exists (deleted or re-scanned
     * under a new id) can never play. Remove it from the queue and continue with the
     * next item instead of leaving the player stopped in the error state.
     *
     * @return true if the error was handled by skipping the item.
     */
    private fun skipMissingLocalItem(error: PlaybackException): Boolean {
        val currentPlayer = player
        val index = resolveErrorItemIndex(currentPlayer, error)
        if (index == C.INDEX_UNSET || index !in 0 until currentPlayer.mediaItemCount) return false

        val item = currentPlayer.getMediaItemAt(index)
        val uri = item.localConfiguration?.uri ?: return false
        if (!MissingLocalMediaClassifier.isMissingLocalItem(error.errorCode, error.cause, uri.scheme)) {
            return false
        }

        Log.w(TAG, "Skipping missing local item ${item.mediaId} ($uri) and removing it from the queue: ${error.errorCodeName}")
        return try {
            currentPlayer.removeMediaItem(index)
            if (currentPlayer.mediaItemCount > 0) {
                // Clears the error state; playWhenReady is preserved, so playback continues.
                currentPlayer.prepare()
            }
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to skip missing local item ${item.mediaId}", e)
            false
        }
    }

    /** Index of the item that caused [error]: its media period if known, else the current item. */
    private fun resolveErrorItemIndex(currentPlayer: Player, error: PlaybackException): Int {
        val periodUid = (error as? ExoPlaybackException)?.mediaPeriodId?.periodUid
        if (periodUid != null) {
            val timeline = currentPlayer.currentTimeline
            val periodIndex = timeline.getIndexOfPeriod(periodUid)
            if (periodIndex != C.INDEX_UNSET) {
                return timeline.getPeriod(periodIndex, Timeline.Period()).windowIndex
            }
        }
        return currentPlayer.currentMediaItemIndex
    }

    private fun createController() {
        // Build the controller asynchronously to avoid blocking the main thread
        val controllerFuture = MediaController.Builder(this, mediaSession!!.token)
            .buildAsync()
        
        controllerFuture.addListener({
            try {
                controller = controllerFuture.get()
                controller?.addListener(this)
                // Only set custom layout if controller is properly initialized
                controller?.let {
                    forceCustomLayoutUpdate() // Use force update for initial setup
                }
                Log.d(TAG, "MediaController initialized successfully")
            } catch (e: Exception) {
                Log.e(TAG, "Error initializing MediaController", e)
            }
        }, androidx.core.content.ContextCompat.getMainExecutor(this))
    }

    private fun createCustomCommands() {
        customCommands = listOf(
            CommandButton.Builder(CommandButton.ICON_SHUFFLE_OFF)
                .setDisplayName("Shuffle mode")
                .setSessionCommand(
                    SessionCommand(SHUFFLE_MODE_ON, Bundle.EMPTY)
                )
                .build(),
            CommandButton.Builder(CommandButton.ICON_SHUFFLE_ON)
                .setDisplayName("Shuffle mode")
                .setSessionCommand(
                    SessionCommand(SHUFFLE_MODE_OFF, Bundle.EMPTY)
                )
                .build(),
            CommandButton.Builder(CommandButton.ICON_REPEAT_OFF)
                .setDisplayName("Repeat mode")
                .setSessionCommand(
                    SessionCommand(REPEAT_MODE_ALL, Bundle.EMPTY)
                )
                .build(),
            CommandButton.Builder(CommandButton.ICON_REPEAT_ALL)
                .setDisplayName("Repeat mode")
                .setSessionCommand(
                    SessionCommand(REPEAT_MODE_ONE, Bundle.EMPTY)
                )
                .build(),
            CommandButton.Builder(CommandButton.ICON_REPEAT_ONE)
                .setDisplayName("Repeat mode")
                .setSessionCommand(
                    SessionCommand(REPEAT_MODE_OFF, Bundle.EMPTY)
                )
                .build(),
            // Favorite commands - use custom icons via extras bundle
            createCustomIconButton(
                "Add to favorites",
                FAVORITE_ON,
                app.needle.player.R.drawable.ic_favorite_border
            ),
            createCustomIconButton(
                "Remove from favorites",
                FAVORITE_OFF,
                app.needle.player.R.drawable.ic_favorite_filled
            )
        )
    }

    private fun createCustomIconButton(displayName: String, commandAction: String, iconResId: Int): CommandButton {
        val extras = Bundle().apply {
            putInt("iconResId", iconResId)
        }
        return CommandButton.Builder(CommandButton.ICON_UNDEFINED)
            .setDisplayName(displayName)
            .setSessionCommand(SessionCommand(commandAction, extras))
            .setExtras(extras)
            .build()
    }

    private fun createMediaSession(): MediaLibrarySession {
        // PendingIntent that launches MainActivity when user taps media controls
        val sessionIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            this,
            0,
            sessionIntent,
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )

        val rhythmBitmapLoader = RhythmBitmapLoader(this)

        return MediaLibrarySession.Builder(
            this,
            player,
            MediaSessionCallback()
        ).setSessionActivity(pendingIntent)
            .setBitmapLoader(rhythmBitmapLoader)
            .build()
    }
    
    private fun isCurrentSongFavorite(): Boolean {
        val currentMediaItem = player.currentMediaItem
        return if (currentMediaItem != null) {
            // Get favorite songs from settings
            val favoriteSongsJson = appSettings.favoriteSongs.value
            if (favoriteSongsJson != null && favoriteSongsJson.isNotEmpty()) {
                try {
                    val type = object : TypeToken<Set<String>>() {}.type
                    val favoriteSongs: Set<String> = GsonUtils.gson.fromJson(favoriteSongsJson, type)
                    favoriteSongs.contains(currentMediaItem.mediaId)
                } catch (e: Exception) {
                    Log.e(TAG, "Error parsing favorite songs", e)
                    false
                }
            } else {
                false
            }
        } else {
            false
        }
    }
    
    private fun toggleCurrentSongFavorite() {
        val currentMediaItem = player.currentMediaItem
        val songId = currentMediaItem?.mediaId?.takeIf { it.isNotEmpty() } ?: run {
            // FALLBACK: Read song_id from widget preferences if player has no active song
            val prefs = getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)
            val id = prefs.getString("song_id", null)
            if (id.isNullOrEmpty()) null else id
        }

        if (songId != null) {
            try {
                val favoriteSongsJson = appSettings.favoriteSongs.value
                val currentFavorites = if (favoriteSongsJson != null && favoriteSongsJson.isNotEmpty()) {
                    try {
                        val type = object : TypeToken<Set<String>>() {}.type
                        GsonUtils.gson.fromJson<Set<String>>(favoriteSongsJson, type).toMutableSet()
                    } catch (e: Exception) {
                        Log.e(TAG, "Error parsing favorite songs", e)
                        mutableSetOf<String>()
                    }
                } else {
                    mutableSetOf<String>()
                }

                val isAdding = !currentFavorites.contains(songId)

                if (isAdding) {
                    currentFavorites.add(songId)
                    Log.d(TAG, "Added song to favorites via widget/notification: $songId")
                } else {
                    currentFavorites.remove(songId)
                    Log.d(TAG, "Removed song from favorites via widget/notification: $songId")
                }

                appSettings.setFavoriteSongs(GsonUtils.gson.toJson(currentFavorites))
                
                // Fetch song details from mediaItem or construct fallback Song using preferences
                val song = if (currentMediaItem != null) {
                    convertMediaItemToSong(currentMediaItem)
                } else {
                    val prefs = getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)
                    Song(
                        id = songId,
                        title = prefs.getString("song_title", "Rhythm") ?: "Rhythm",
                        artist = prefs.getString("artist_name", "") ?: "",
                        album = prefs.getString("album_name", "") ?: "",
                        uri = Uri.EMPTY,
                        artworkUri = prefs.getString("artwork_uri", null)?.let { 
                            try { (it).toUri() } catch (_: Exception) { null } 
                        },
                        duration = 0L,
                        trackNumber = 0,
                        year = 0,
                        genre = "",
                        albumId = ""
                    )
                }
                updateFavoritesPlaylist(songId = songId, song = song, isAdding = isAdding)

                val notifyIntent = Intent("app.needle.player.action.FAVORITE_CHANGED").apply {
                    setPackage(packageName)
                }
                sendBroadcast(notifyIntent)
                Log.d(TAG, "Sent FAVORITE_CHANGED broadcast to notify ViewModel")

                scheduleCustomLayoutUpdate(120)
            } catch (e: Exception) {
                Log.e(TAG, "Error toggling favorite", e)
            }
        }
    }

    private fun updateFavoritesPlaylist(songId: String, song: Song?, isAdding: Boolean) {
        try {
            val playlistsJson = appSettings.playlists.value
            if (playlistsJson.isNullOrEmpty()) return
            
            val type = object : TypeToken<List<Playlist>>() {}.type
            val playlists: MutableList<Playlist> = GsonUtils.gson.fromJson(playlistsJson, type)
            
            val favoritesPlaylist = playlists.find { it.id == "1" && it.name == "Liked" } ?: return
            val existingSongs = favoritesPlaylist.songs
            val updatedSongs = when {
                isAdding && song != null && existingSongs.none { it.id == songId } -> existingSongs + song
                isAdding -> existingSongs
                else -> existingSongs.filterNot { it.id == songId }
            }

            if (updatedSongs == existingSongs) return

            val updatedPlaylist = favoritesPlaylist.copy(
                songs = updatedSongs,
                dateModified = System.currentTimeMillis()
            )

            val updatedPlaylists = playlists.map { if (it.id == "1") updatedPlaylist else it }
            appSettings.setPlaylists(GsonUtils.gson.toJson(updatedPlaylists))
            Log.d(TAG, "Updated Liked playlist: ${if (isAdding) "added" else "removed"} song $songId")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating favorites playlist", e)
        }
    }
    
    private fun updateCustomLayout() {
        try {
            // Create a new instance of the favorite command to avoid reference issues
            val currentFavoriteCommand = getCurrentFavoriteCommand()
            val currentShuffleCommand = shuffleCommand
            val currentRepeatCommand = repeatCommand
            
            mediaSession?.setCustomLayout(ImmutableList.of(currentShuffleCommand, currentRepeatCommand))
            
            // Update state tracking after successful update
            lastShuffleState = controller?.shuffleModeEnabled ?: false
            lastRepeatMode = controller?.repeatMode ?: Player.REPEAT_MODE_OFF
            lastFavoriteState = isCurrentSongFavorite()
            
            val currentMediaItem = player.currentMediaItem
            Log.d(TAG, "Updated custom layout - Song: ${currentMediaItem?.mediaMetadata?.title}, " +
                      "Favorite state: ${lastFavoriteState}, " +
                      "Shuffle: ${lastShuffleState}, " +
                      "Repeat: ${lastRepeatMode}")
        } catch (e: Exception) {
            Log.e(TAG, "Error updating custom layout", e)
        }
    }
    
    private fun updateCustomLayoutSmart() {
        // Only update if layout actually needs to change
        // This helps prevent unnecessary recreations and flickering
        mediaSession?.let { session ->
            try {
                val currentShuffleState = controller?.shuffleModeEnabled ?: false
                val currentRepeatMode = controller?.repeatMode ?: Player.REPEAT_MODE_OFF
                val currentFavoriteState = isCurrentSongFavorite()
                
                // Check if anything actually changed
                if (currentShuffleState == lastShuffleState &&
                    currentRepeatMode == lastRepeatMode &&
                    currentFavoriteState == lastFavoriteState) {
                    Log.d(TAG, "Custom layout state unchanged, skipping update")
                    return
                }
                
                // Update state tracking
                lastShuffleState = currentShuffleState
                lastRepeatMode = currentRepeatMode
                lastFavoriteState = currentFavoriteState
                
                val currentFavoriteCommand = getCurrentFavoriteCommand()
                val currentShuffleCommand = shuffleCommand
                val currentRepeatCommand = repeatCommand
                
                // Create the layout
                session.setCustomLayout(ImmutableList.of(currentShuffleCommand, currentRepeatCommand))
                
                Log.d(TAG, "Smart updated custom layout - Favorite: $currentFavoriteState, " +
                          "Shuffle: $currentShuffleState, Repeat: $currentRepeatMode")
            } catch (e: Exception) {
                Log.e(TAG, "Error in smart custom layout update", e)
            }
        }
    }
    
    private fun scheduleCustomLayoutUpdate(delayMs: Long = 150) {
        // Cancel any pending update
        updateLayoutJob?.cancel()
        
        // Schedule a new update with debouncing
        updateLayoutJob = serviceScope.launch {
            kotlinx.coroutines.delay(delayMs)
            updateCustomLayoutSmart()
        }
    }
    
    private fun forceCustomLayoutUpdate() {
        // Force an immediate update without debouncing (for initial setup)
        serviceScope.launch {
            updateCustomLayout()
        }
    }

    /**
     * Requests Android 14+ preferred mixer attributes for USB output when app routing is selected.
     * This is the platform-side requirement for exclusive/bit-perfect mixer behavior when available.
     */
    private fun applyUsbExclusiveRoutingPreference() {
        if (!::rhythmPlayerEngine.isInitialized) {
            return
        }
        val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val usbOutput = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .firstOrNull {
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }

        if (appSettings.audioRoutingMode.value != "app") {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                val mediaAttributes = android.media.AudioAttributes.Builder()
                    .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                    .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
                clearUsbPreferredMixerAttributes(audioManager, mediaAttributes)
            }
            if (::rhythmPlayerEngine.isInitialized) {
                rhythmPlayerEngine.setPreferredAudioDevice(null)
            }
            return
        }

        if (usbOutput == null) {
            Log.i(TAG, "App routing enabled but no USB output device is connected")
            if (::rhythmPlayerEngine.isInitialized) {
                rhythmPlayerEngine.setPreferredAudioDevice(null)
            }
            return
        }

        rhythmPlayerEngine.setPreferredAudioDevice(usbOutput)

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            return
        }

        val mediaAttributes = android.media.AudioAttributes.Builder()
            .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
            .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
            .build()

        try {
            val supportedMixerAttributes = audioManager.getSupportedMixerAttributes(usbOutput)
            val bitPerfectMixers = supportedMixerAttributes.filter {
                it.mixerBehavior == AudioMixerAttributes.MIXER_BEHAVIOR_BIT_PERFECT
            }

            if (bitPerfectMixers.isEmpty()) {
                Log.w(TAG, "USB device does not expose a bit-perfect mixer profile")
                return
            }

            val currentFormat = (rhythmPlayerEngine.masterPlayer as? ExoPlayer)?.audioFormat
            val bitPerfectMixer = if (currentFormat != null && currentFormat.sampleRate > 0) {
                bitPerfectMixers.firstOrNull { mixer ->
                    mixer.format.sampleRate == currentFormat.sampleRate &&
                        (currentFormat.channelCount <= 2 || mixer.format.channelCount == currentFormat.channelCount)
                } ?: bitPerfectMixers.firstOrNull()
            } else {
                bitPerfectMixers.firstOrNull()
            }

            if (bitPerfectMixer != null) {
                audioManager.setPreferredMixerAttributes(mediaAttributes, usbOutput, bitPerfectMixer)
                Log.i(TAG, "Requested bit-perfect USB mixer attributes for app routing mode: ${bitPerfectMixer.format}")
            }
        } catch (e: Exception) {
            Log.w(TAG, "Failed to request USB preferred mixer attributes", e)
        }
    }

    private fun clearUsbPreferredMixerAttributes(
        audioManager: AudioManager,
        mediaAttributes: android.media.AudioAttributes
    ) {
        if (::rhythmPlayerEngine.isInitialized) {
            rhythmPlayerEngine.setPreferredAudioDevice(null)
        }
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            return
        }

        audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
            .filter {
                it.type == AudioDeviceInfo.TYPE_USB_DEVICE ||
                    it.type == AudioDeviceInfo.TYPE_USB_HEADSET
            }
            .forEach { device ->
                try {
                    audioManager.clearPreferredMixerAttributes(mediaAttributes, device)
                } catch (e: Exception) {
                    Log.w(TAG, "Failed to clear preferred mixer attributes for USB device", e)
                }
            }
    }
    
    private fun applyPlayerSettings() {
        if (!::rhythmPlayerEngine.isInitialized || !::player.isInitialized) {
            return
        }
        applyUsbExclusiveRoutingPreference()
        val isBitPerfect = appSettings.audioRoutingMode.value == "app"
        player.apply {
            // Audio normalization - NOT IMPLEMENTED
            // if (appSettings.audioNormalization.value) {
            //     volume = 1.0f
            // }
        }

        // Apply Replay Gain settings
        rhythmPlayerEngine.applyReplayGainSettings(if (isBitPerfect) false else appSettings.replayGain.value)

        // Apply gapless playback setting
        rhythmPlayerEngine.setGaplessPlayback(appSettings.gaplessPlayback.value)

        // Apply skip silence setting
        rhythmPlayerEngine.setSkipSilenceEnabled(if (isBitPerfect) false else appSettings.skipSilenceEnabled.value)

        // Crossfade is now managed by TransitionController + RhythmPlayerEngine
        // Settings are read reactively from AppSettings by the controller

        Log.d(TAG, "Applied player settings: " +
                "Gapless=${appSettings.gaplessPlayback.value}, " +
                "SkipSilence=${appSettings.skipSilenceEnabled.value}, " +
                "Crossfade=${appSettings.crossfade.value} (${appSettings.crossfadeDuration.value}s)")
                // Normalization and ReplayGain removed as not implemented
    }
    
    // Crossfade is now handled by RhythmPlayerEngine + TransitionController
    // See: infrastructure/service/player/RhythmPlayerEngine.kt
    // See: infrastructure/service/player/TransitionController.kt

    // Skip debounce state for widget actions
    private var lastServiceSkipTime = 0L
    private val SERVICE_SKIP_DEBOUNCE_MS = 400L

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        Log.d(TAG, "Service started with command: ${intent?.action}")
        
        when (intent?.action) {
            ACTION_UPDATE_SETTINGS -> {
                Log.d(TAG, "Updating service settings")
                applyPlayerSettings()
            }
            ACTION_PLAY_EXTERNAL_FILE -> {
                intent.data?.let { uri ->
                    playExternalFile(uri)
                }
            }
            ACTION_INIT_SERVICE -> {
                Log.d(TAG, "Service initialization requested")
                // Load and apply settings when service starts
                applyPlayerSettings()
            }
            ACTION_START_SLEEP_TIMER -> {
                val durationMs = intent.getLongExtra("duration", 0L)
                val fadeOut = intent.getBooleanExtra("fadeOut", true)
                val pauseOnly = intent.getBooleanExtra("pauseOnly", false)
                if (durationMs > 0) {
                    startSleepTimer(durationMs, fadeOut, pauseOnly)
                }
            }
            ACTION_STOP_SLEEP_TIMER -> {
                stopSleepTimer()
            }
            ACTION_EXTEND_SLEEP_TIMER -> {
                extendSleepTimer()
            }
            ACTION_SET_EQUALIZER_ENABLED -> {
                val enabled = intent.getBooleanExtra("enabled", false)
                Log.d(TAG, "Received intent to set equalizer enabled: $enabled")
                setEqualizerEnabled(enabled)
                
                // Broadcast current state back for UI verification
                val actualState = getEqualizerEnabledSafe()
                if (actualState != enabled) {
                    if (enabled) {
                        Log.w(TAG, "Equalizer state verification failed. Requested: $enabled, Actual: $actualState")
                    } else {
                        Log.d(TAG, "Equalizer hardware kept enabled (software off) to avoid DSP burst")
                    }
                }
            }
            ACTION_SET_EQUALIZER_BAND -> {
                val band = intent.getShortExtra("band", 0)
                val level = intent.getShortExtra("level", 0)
                setEqualizerBandLevel(band, level)
            }
            ACTION_SET_BASS_BOOST -> {
                val enabled = intent.getBooleanExtra("enabled", false)
                val strength = intent.getShortExtra("strength", 0)
                Log.d(TAG, "Received intent to set bass boost - enabled: $enabled, strength: $strength")
                
                if (rhythmBassBoostProcessor == null) {
                    Log.d(TAG, "Rhythm bass boost processor is null, attempting initialization")
                    initializeRhythmProcessors()
                }
                
                setBassBoostEnabled(enabled)
                if (enabled && strength > 0) {
                    setBassBoostStrength(strength)
                }
            }
            ACTION_SET_VIRTUALIZER -> {
                val enabled = intent.getBooleanExtra("enabled", false)
                val strength = intent.getShortExtra("strength", 0)
                Log.d(TAG, "Received intent to set virtualizer - enabled: $enabled, strength: $strength")
                
                if (rhythmSpatializationProcessor == null) {
                    Log.d(TAG, "Rhythm spatialization processor is null, attempting initialization")
                    initializeRhythmProcessors()
                }
                
                setVirtualizerEnabled(enabled)
                if (enabled && strength > 0) {
                    setVirtualizerStrength(strength)
                }
            }
            ACTION_SET_MONO_AUDIO -> {
                val enabled = intent.getBooleanExtra("enabled", false)
                Log.d(TAG, "Received intent to set mono audio - enabled: $enabled")
                
                if (rhythmMonoAudioProcessor == null) {
                    Log.d(TAG, "Rhythm mono audio processor is null, attempting initialization")
                    initializeRhythmProcessors()
                }
                
                setMonoAudioEnabled(enabled)
            }
            ACTION_APPLY_EQUALIZER_PRESET -> {
                val preset = intent.getStringExtra("preset") ?: ""
                val levels = intent.getFloatArrayExtra("levels")
                if (levels != null) {
                    applyEqualizerPreset(levels)
                    Log.d(TAG, "Applied equalizer preset intent: $preset with ${levels.size} bands")
                }
            }
            ACTION_GET_EQUALIZER_DIAGNOSTICS -> {
                val diagnostics = getEqualizerDiagnostics()
                Log.i(TAG, diagnostics)
            }
            ACTION_PLAY_PAUSE -> {
                Log.d(TAG, "Widget play/pause action")
                if (player.isPlaying) {
                    player.pause()
                } else {
                    player.play()
                }
                // Update widget immediately after action
                updateWidgetFromMediaItem(player.currentMediaItem)
            }
            ACTION_SKIP_NEXT -> {
                Log.d(TAG, "Widget skip next action")
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastServiceSkipTime >= SERVICE_SKIP_DEBOUNCE_MS) {
                    lastServiceSkipTime = currentTime
                    player.seekToNext()
                    // Update widget immediately after action
                    serviceScope.launch {
                        kotlinx.coroutines.delay(100) // Small delay for track change
                        updateWidgetFromMediaItem(player.currentMediaItem)
                    }
                }
            }
            ACTION_SKIP_PREVIOUS -> {
                Log.d(TAG, "Widget skip previous action")
                val currentTime = System.currentTimeMillis()
                if (currentTime - lastServiceSkipTime >= SERVICE_SKIP_DEBOUNCE_MS) {
                    lastServiceSkipTime = currentTime
                    player.seekToPrevious()
                    // Update widget immediately after action
                    serviceScope.launch {
                        kotlinx.coroutines.delay(100) // Small delay for track change
                        updateWidgetFromMediaItem(player.currentMediaItem)
                    }
                }
            }
            ACTION_TOGGLE_FAVORITE -> {
                Log.d(TAG, "Widget toggle favorite action")
                toggleCurrentSongFavorite()
                val currentMediaItem = player.currentMediaItem
                if (currentMediaItem != null) {
                    updateWidgetFromMediaItem(currentMediaItem)
                } else {
                    // Update only the favorite state in the widget without clearing it!
                    val prefs = getSharedPreferences("widget_prefs", Context.MODE_PRIVATE)
                    val songId = prefs.getString("song_id", null)
                    if (songId != null && songId.isNotEmpty()) {
                        val favoriteSongsJson = appSettings.favoriteSongs.value
                        val currentFavorites = if (favoriteSongsJson != null && favoriteSongsJson.isNotEmpty()) {
                            try {
                                val type = object : TypeToken<Set<String>>() {}.type
                                GsonUtils.gson.fromJson<Set<String>>(favoriteSongsJson, type)
                            } catch (e: Exception) {
                                emptySet()
                            }
                        } else {
                            emptySet()
                        }
                        val isFavorite = currentFavorites.contains(songId)
                        
                        val song = Song(
                            id = songId,
                            title = prefs.getString("song_title", "Rhythm") ?: "Rhythm",
                            artist = prefs.getString("artist_name", "") ?: "",
                            album = prefs.getString("album_name", "") ?: "",
                            uri = Uri.EMPTY,
                            artworkUri = prefs.getString("artwork_uri", null)?.let { 
                                try { (it).toUri() } catch (_: Exception) { null }
                            },
                            duration = 0L,
                            trackNumber = 0,
                            year = 0,
                            genre = "",
                            albumId = ""
                        )
                        val isPlaying = prefs.getBoolean("is_playing", false)
                        val hasPrevious = prefs.getBoolean("has_previous", false)
                        val hasNext = prefs.getBoolean("has_next", false)
                        val isShuffleEnabled = prefs.getBoolean("is_shuffle", false)
                        val repeatMode = prefs.getInt("repeat_mode", 0)
                        
                        WidgetUpdater.updateWidget(this, song, isPlaying, hasPrevious, hasNext, isFavorite, isShuffleEnabled, repeatMode)
                    }
                }
            }
            ACTION_TOGGLE_SHUFFLE -> {
                Log.d(TAG, "Widget toggle shuffle action")
                if (::player.isInitialized) {
                    player.shuffleModeEnabled = !player.shuffleModeEnabled
                    updateWidgetFromMediaItem(player.currentMediaItem)
                }
            }
            ACTION_TOGGLE_REPEAT -> {
                Log.d(TAG, "Widget toggle repeat action")
                if (::player.isInitialized) {
                    val nextRepeatMode = when (player.repeatMode) {
                        Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                        Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                        Player.REPEAT_MODE_ONE -> Player.REPEAT_MODE_OFF
                        else -> Player.REPEAT_MODE_OFF
                    }
                    player.repeatMode = nextRepeatMode
                    updateWidgetFromMediaItem(player.currentMediaItem)
                }
            }
            ACTION_MUTE -> {
                Log.d(TAG, "Mute action")
                mutePlayer()
            }
            ACTION_UNMUTE -> {
                Log.d(TAG, "Unmute action")
                unmutePlayer()
            }
            ACTION_TOGGLE_MUTE -> {
                Log.d(TAG, "Toggle mute action")
                toggleMute()
            }
        }
        
        // If an external trigger (such as widget or tile) started this service via startForegroundService
        // while playback is paused or stopped, satisfy the Android OS contract to avoid ForegroundServiceDidNotStartInTimeException.
        if (::player.isInitialized && !player.isPlaying) {
            when (intent?.action) {
                ACTION_PLAY_PAUSE, ACTION_SKIP_NEXT, ACTION_SKIP_PREVIOUS,
                ACTION_TOGGLE_FAVORITE, ACTION_TOGGLE_SHUFFLE, ACTION_TOGGLE_REPEAT -> {
                    try {
                        startForegroundWithNotification(
                            getString(app.needle.player.R.string.service_rhythm_music),
                            getString(app.needle.player.R.string.service_ready)
                        )
                        androidx.core.app.ServiceCompat.stopForeground(this, androidx.core.app.ServiceCompat.STOP_FOREGROUND_REMOVE)
                    } catch (e: Exception) {
                        Log.w(TAG, "Could not satisfy foreground contract for action: ${intent.action}", e)
                    }
                }
            }
        }

        // We make sure to call the super implementation
        return super.onStartCommand(intent, flags, startId)
    }
    
    private fun wrapPlayer(rawPlayer: Player): Player {
        return object : ForwardingPlayer(rawPlayer) {
            override fun seekToNext() {
                if (!skipWithCrossfade(toNext = true)) {
                    super.seekToNext()
                }
            }

            override fun seekToNextMediaItem() {
                if (!skipWithCrossfade(toNext = true)) {
                    super.seekToNextMediaItem()
                }
            }

            override fun seekToPrevious() {
                if (!skipWithCrossfade(toNext = false)) {
                    super.seekToPrevious()
                }
            }

            override fun seekToPreviousMediaItem() {
                if (!skipWithCrossfade(toNext = false)) {
                    super.seekToPreviousMediaItem()
                }
            }

            override fun seekToDefaultPosition(mediaItemIndex: Int) {
                if (mediaItemIndex != currentMediaItemIndex && mediaItemIndex in 0 until mediaItemCount) {
                    if (skipWithCrossfadeToIndex(mediaItemIndex)) {
                        return
                    }
                }
                super.seekToDefaultPosition(mediaItemIndex)
            }

            override fun seekTo(mediaItemIndex: Int, positionMs: Long) {
                if (mediaItemIndex != currentMediaItemIndex && mediaItemIndex in 0 until mediaItemCount) {
                    if (skipWithCrossfadeToIndex(mediaItemIndex, positionMs)) {
                        return
                    }
                }
                super.seekTo(mediaItemIndex, positionMs)
            }
        }
    }

    private var lastGlobalSkipTime = 0L
    private val GLOBAL_SKIP_DEBOUNCE_MS = 600L

    private fun skipWithCrossfadeToIndex(
        targetIndex: Int,
        positionMs: Long = C.TIME_UNSET,
        isSkipPrevious: Boolean = false
    ): Boolean {
        try {
            if (!appSettings.crossfade.value || !appSettings.crossfadeOnSkip.value) {
                return false
            }

            // Rate-limiting check to prevent ExoPlayer looper lockup under rapid spam clicks
            val currentTime = System.currentTimeMillis()
            if (currentTime - lastGlobalSkipTime < GLOBAL_SKIP_DEBOUNCE_MS) {
                Log.d(TAG, "Ignored rapid skipWithCrossfade to prevent lockup. Falling back to standard skip.")
                return false
            }
            lastGlobalSkipTime = currentTime

            if (rhythmPlayerEngine.isTransitionRunning()) {
                Log.d(TAG, "Transition is running during skip request. Force completing it first and falling back to standard skip.")
                rhythmPlayerEngine.snapCompleteTransition()
                if (::transitionController.isInitialized) {
                    transitionController.cancelPendingTransition()
                }
                return false
            }

            val playerToUse = rhythmPlayerEngine.masterPlayer
            if (!playerToUse.isPlaying) {
                Log.d(TAG, "Player is not playing, skipping instant without crossfade")
                return false
            }

            val currentWindowIndex = playerToUse.currentMediaItemIndex
            val timeline = playerToUse.currentTimeline

            if (timeline.isEmpty || targetIndex < 0 || targetIndex >= playerToUse.mediaItemCount || targetIndex == currentWindowIndex) {
                return false
            }

            val nextMediaItem = playerToUse.getMediaItemAt(targetIndex)
            Log.d(TAG, "Skipping with crossfade to index $targetIndex: ${nextMediaItem.mediaId}")

            // Cancel any pending transitions
            if (::transitionController.isInitialized) {
                transitionController.cancelPendingTransition()
            }

            val startPos = if (positionMs != C.TIME_UNSET && positionMs > 0L) positionMs else 0L
            val fullQueue = (0 until playerToUse.mediaItemCount).map { playerToUse.getMediaItemAt(it) }
            val shuffleIndices = if (playerToUse.shuffleModeEnabled) {
                rhythmPlayerEngine.extractShuffleIndices(playerToUse)
            } else {
                null
            }
            rhythmPlayerEngine.prepareNext(
                mediaItem = nextMediaItem,
                targetIndex = targetIndex,
                fullQueue = fullQueue,
                shuffleIndices = shuffleIndices,
                startPositionMs = startPos
            )

            val computedSkipPrevious = if (isSkipPrevious) true else targetIndex < currentWindowIndex
            val skipDuration = (appSettings.crossfadeDuration.value * 1000).toInt().coerceIn(500, 2000)
            val settings = TransitionSettings(
                mode = TransitionMode.OVERLAP,
                durationMs = skipDuration,
                isManualSkip = true,
                isSkipPrevious = computedSkipPrevious
            )

            if (::transitionController.isInitialized) {
                transitionController.setManualTransitioning()
            }

            rhythmPlayerEngine.performTransition(settings)
            return true
        } catch (e: Exception) {
            Log.e(TAG, "Error performing skip with crossfade, falling back to standard skip", e)
            return false
        }
    }

    private fun skipWithCrossfade(toNext: Boolean): Boolean {
        val playerToUse = rhythmPlayerEngine.masterPlayer
        if (!playerToUse.isPlaying) {
            return false
        }

        if (!toNext && playerToUse.currentPosition > 5000) {
            Log.d(TAG, "Previous skip past 5s, restarting track")
            return false
        }

        val repeatMode = playerToUse.repeatMode
        val currentWindowIndex = playerToUse.currentMediaItemIndex
        val timeline = playerToUse.currentTimeline
        if (timeline.isEmpty || currentWindowIndex == C.INDEX_UNSET) {
            return false
        }

        val nextIndex = if (toNext) {
            timeline.getNextWindowIndex(
                currentWindowIndex,
                repeatMode,
                playerToUse.shuffleModeEnabled
            )
        } else {
            timeline.getPreviousWindowIndex(
                currentWindowIndex,
                repeatMode,
                playerToUse.shuffleModeEnabled
            )
        }

        if (nextIndex == C.INDEX_UNSET) {
            return false
        }

        return skipWithCrossfadeToIndex(nextIndex, isSkipPrevious = !toNext)
    }

    /**
     * Play an external audio file
     */
    private fun playExternalFile(uri: Uri) {
        Log.d(TAG, "Playing external file: $uri")

        // Use service-scoped coroutine to handle operations without blocking the main thread
        serviceScope.launch {
            try {
                // Respect Rhythm Guard timeout: do not start external playback if a timeout is active
                val now = System.currentTimeMillis()
                if (appSettings.rhythmGuardTimeoutUntilMs.value > now) {
                    Log.d(TAG, "Refusing to play external file due to active Rhythm Guard timeout: $uri")
                    return@launch
                }
                // Check if we've seen this URI before (on main thread - quick cache lookup)
                val cachedItem = externalUriCache[uri.toString()]
                if (cachedItem != null) {
                    Log.d(TAG, "Using cached media item for URI: $uri")
                    
                    // Clear the player first to avoid conflicts with existing items
                    player.clearMediaItems()
                    
                    // Play the media item
                    player.setMediaItem(cachedItem)
                    player.prepare()
                    player.play()
                    
                    return@launch
                }
                
                // Add a small delay before processing to allow previous operations to complete
                delay(500)
                
                // Extract metadata from the audio file in a background thread
                val mediaItem = withContext(Dispatchers.IO) {
                    val resolvedMimeType = app.needle.player.util.MediaUtils.getMediaMimeType(this@MediaPlaybackService, uri)
                    try {
                        val song = app.needle.player.util.MediaUtils.extractMetadataFromUri(this@MediaPlaybackService, uri)
                        Log.d(TAG, "Extracted metadata for external file: ${song.title} by ${song.artist}")
                        
                        // Create a media item with the extracted metadata
                        MediaItem.Builder()
                            .setUri(uri)
                            .setMediaId(uri.toString())
                            .apply {
                                if (resolvedMimeType != null) {
                                    setMimeType(resolvedMimeType)
                                }
                            }
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(song.title)
                                    .setArtist(song.artist)
                                    .setAlbumTitle(song.album)
                                    .setArtworkUri(song.artworkUri)
                                    .build()
                            )
                            .build()
                            
                    } catch (e: Exception) {
                        Log.e(TAG, "Error extracting metadata from external file", e)
                        
                        // Fall back to basic playback if metadata extraction fails
                        Log.d(TAG, "Falling back to basic playback with mime type: $resolvedMimeType")
                        
                        MediaItem.Builder()
                            .setUri(uri)
                            .apply {
                                if (resolvedMimeType != null) {
                                    setMimeType(resolvedMimeType)
                                }
                            }
                            .setMediaMetadata(
                                MediaMetadata.Builder()
                                    .setTitle(uri.lastPathSegment ?: "Unknown")
                                    .build()
                            )
                            .build()
                    }
                }
                
                // Back on main thread - set up playback
                player.clearMediaItems()
                player.setMediaItem(mediaItem)
                player.prepare()
                player.play()
                
                // Cache the media item
                externalUriCache[uri.toString()] = mediaItem
                
                // Force a recheck of playback state in case it doesn't start
                player.addListener(object : Player.Listener {
                    override fun onPlaybackStateChanged(playbackState: Int) {
                        if (playbackState == Player.STATE_READY) {
                            Log.d(TAG, "Playback ready, ensuring play is called")
                            player.play()
                            player.removeListener(this)
                        }
                    }
                })
                
            } catch (e: Exception) {
                Log.e(TAG, "Error in playExternalFile coroutine", e)
            }
        }
    }

    override fun onDestroy() {
        instanceForWidgetAndLyricsOnly = null
        Log.d(TAG, "Service being destroyed")

        // Persist final playback position and index on destroy
        if (::player.isInitialized && appSettings.queuePersistenceEnabled.value) {
            val currentIndex = player.currentMediaItemIndex
            if (currentIndex != androidx.media3.common.C.INDEX_UNSET) {
                appSettings.setSavedQueueIndex(currentIndex)
                appSettings.setSavedPlaybackPosition(player.currentPosition)
                Log.d(TAG, "Persisted queue index $currentIndex and position ${player.currentPosition} on service destroy")
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
            val audioManager = getSystemService(Context.AUDIO_SERVICE) as AudioManager
            val mediaAttributes = android.media.AudioAttributes.Builder()
                .setUsage(android.media.AudioAttributes.USAGE_MEDIA)
                .setContentType(android.media.AudioAttributes.CONTENT_TYPE_MUSIC)
                .build()
            clearUsbPreferredMixerAttributes(audioManager, mediaAttributes)
        }
        
        // Unregister BroadcastReceiver
        try {
            unregisterReceiver(favoriteChangeReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering favorite change receiver", e)
        }
        try {
            unregisterReceiver(btReceiver)
        } catch (_: Exception) {}
        btProxy = null
        try {
            unregisterReceiver(volumeChangeReceiver)
        } catch (e: Exception) {
            Log.w(TAG, "Error unregistering volume change receiver", e)
        }
        
        // Cancel all coroutines and pending jobs
        updateLayoutJob?.cancel()
        sleepTimerJob?.cancel()
        audioEffectsInitJob?.cancel()
        cancelSleepTimerProgressNotification()
        serviceScope.cancel()
        
        // Release preloader
        if (::preloadController.isInitialized) {
            preloadController.release()
        }
        
        // Release crossfade engine and transition controller
        if (::transitionController.isInitialized) {
            transitionController.release()
        }
        if (::rhythmPlayerEngine.isInitialized) {
            rhythmPlayerEngine.release()
        }
        
        // Release audio effects
        releaseAudioEffects()
        
        // Remove player listener before releasing player
        if (::player.isInitialized) {
            playerListener?.let { player.removeListener(it) }
        }
        playerListener = null
        
        // Remove service as listener from controller
        controller?.removeListener(this)
        
        mediaSession?.run {
            player.release()
            controller?.release()
            release()
            mediaSession = null
        }
        super.onDestroy()
    }

    override fun onGetSession(controllerInfo: MediaSession.ControllerInfo): MediaLibrarySession? = mediaSession
    
    @OptIn(UnstableApi::class)
    override fun onUpdateNotification(session: MediaSession, startInForegroundRequired: Boolean) {
        // Let Media3 handle notification updates but ensure our icon is used
        super.onUpdateNotification(session, startInForegroundRequired)
    }

    private inner class MediaSessionCallback : MediaLibrarySession.Callback {
        @OptIn(UnstableApi::class)
        override fun onConnect(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ): MediaSession.ConnectionResult {
            Log.d(TAG, "onConnect: ${controller.packageName}")
            val availableCommands = MediaSession.ConnectionResult.DEFAULT_SESSION_AND_LIBRARY_COMMANDS
                .buildUpon()
            if (session.isMediaNotificationController(controller) ||
                session.isAutoCompanionController(controller) ||
                session.isAutomotiveController(controller)
            ) {
                for (commandButton in customCommands) {
                    commandButton.sessionCommand?.let { availableCommands.add(it) }
                }
            }
            availableCommands.add(SessionCommand("UPDATE_ACTIVE_LYRIC", Bundle.EMPTY))
            availableCommands.add(SessionCommand("UPDATE_LYRICS_DATA", Bundle.EMPTY))
            return MediaSession.ConnectionResult.accept(
                availableCommands.build(),
                MediaSession.ConnectionResult.DEFAULT_PLAYER_COMMANDS
            )
        }

        @OptIn(UnstableApi::class)
        override fun onCustomCommand(
            session: MediaSession,
            controller: MediaSession.ControllerInfo,
            customCommand: SessionCommand,
            args: Bundle
        ): ListenableFuture<SessionResult> {
            val serviceController = this@MediaPlaybackService.controller
            if (serviceController == null) {
                Log.w(TAG, "Controller not ready for custom command: ${customCommand.customAction}")
                return Futures.immediateFuture(SessionResult(SessionError.ERROR_SESSION_DISCONNECTED))
            }
            
            return Futures.immediateFuture(
                when (customCommand.customAction) {
                    "UPDATE_LYRICS_DATA" -> {
                        val texts = args.getStringArrayList("lyric_texts")
                        val translations = args.getStringArrayList("lyric_translations")
                        val romanizations = args.getStringArrayList("lyric_romanizations")
                        val timestamps = args.getLongArray("lyric_timestamps")
                        currentLyricTexts = texts ?: emptyList()
                        currentLyricTranslations = translations ?: emptyList()
                        currentLyricRomanizations = romanizations ?: emptyList()
                        currentLyricTimestamps = timestamps ?: longArrayOf()
                        
                        val plainLyrics = args.getString("plain_lyrics")
                        currentPlainLyricsLines = if (!plainLyrics.isNullOrBlank()) {
                            plainLyrics.split("\n").map { it.trim() }.filter { it.isNotEmpty() }
                        } else {
                            emptyList()
                        }
                        
                        currentLyricIndex = -1
                        app.needle.player.infrastructure.widget.glance.GlanceWidgetUpdater.updateLyrics(this@MediaPlaybackService, getProcessedLyricTexts(), -1)
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    "UPDATE_ACTIVE_LYRIC" -> {
                        val lyricLine = args.getString("lyric_line")
                        val lyricIndex = args.getInt("lyric_index", -1)
                        currentLyricIndex = lyricIndex
                        
                        // Update widgets
                        app.needle.player.infrastructure.widget.glance.GlanceWidgetUpdater.updateLyrics(this@MediaPlaybackService, getProcessedLyricTexts(), lyricIndex)
                        
                        // Update Bluetooth metadata lyrics
                        if (appSettings.bluetoothLyricsEnabled.value) {
                            val currentMediaItem = player.currentMediaItem
                            if (currentMediaItem != null) {
                                val song = convertMediaItemToSong(currentMediaItem)
                                if (song != null) {
                                    statusBroadcaster.broadcastNowPlaying(
                                        song = song,
                                        isPlaying = player.isPlaying,
                                        position = player.currentPosition,
                                        queueSize = player.mediaItemCount,
                                        queuePosition = player.currentMediaItemIndex,
                                        bluetoothLyricsMode = true,
                                        currentLyricLine = lyricLine
                                    )
                                }
                            }
                        }
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    SHUFFLE_MODE_ON -> {
                        serviceController.shuffleModeEnabled = true
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    SHUFFLE_MODE_OFF -> {
                        serviceController.shuffleModeEnabled = false
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    REPEAT_MODE_OFF -> {
                        serviceController.repeatMode = Player.REPEAT_MODE_OFF
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    REPEAT_MODE_ONE -> {
                        serviceController.repeatMode = Player.REPEAT_MODE_ONE
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    REPEAT_MODE_ALL -> {
                        serviceController.repeatMode = Player.REPEAT_MODE_ALL
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    FAVORITE_ON -> {
                        // Add current song to favorites
                        Log.d(TAG, "Favorite ON command received")
                        toggleCurrentSongFavorite()
                        // Immediate UI feedback for responsive feel
                        serviceScope.launch {
                            kotlinx.coroutines.delay(50) // Very short delay for immediate response
                            updateCustomLayoutSmart()
                        }
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    FAVORITE_OFF -> {
                        // Remove current song from favorites  
                        Log.d(TAG, "Favorite OFF command received")
                        toggleCurrentSongFavorite()
                        // Immediate UI feedback for responsive feel
                        serviceScope.launch {
                            kotlinx.coroutines.delay(50) // Very short delay for immediate response
                            updateCustomLayoutSmart()
                        }
                        SessionResult(SessionResult.RESULT_SUCCESS)
                    }

                    else -> {
                        SessionResult(SessionError.ERROR_NOT_SUPPORTED)
                    }
                })
        }

        // NOTE: we avoid overriding onPlay directly because MediaLibrarySession callback
        // signatures vary across Media3 versions. Instead we enforce Rhythm Guard at the
        // player level via the Player.Listener implementation (see onPlayWhenReadyChanged).

        override fun onDisconnected(
            session: MediaSession,
            controller: MediaSession.ControllerInfo
        ) {
            Log.d(TAG, "onDisconnected: ${controller.packageName}")
            super.onDisconnected(session, controller)
        }
        
        override fun onAddMediaItems(
            mediaSession: MediaSession,
            controller: MediaSession.ControllerInfo,
            mediaItems: List<MediaItem>
        ): ListenableFuture<List<MediaItem>> {
            Log.d(TAG, "onAddMediaItems: ${mediaItems.size} items")
            
            val updatedMediaItems = mediaItems.map { mediaItem ->
                if (mediaItem.requestMetadata.searchQuery != null) {
                    // This is a search request
                    Log.d(TAG, "Search request: ${mediaItem.requestMetadata.searchQuery}")
                    mediaItem
                } else if (mediaItem.mediaId.isNotEmpty()) {
                    // Check if this is an external URI that we've cached
                    val cachedItem = externalUriCache[mediaItem.mediaId]
                    cachedItem ?: mediaItem
                } else {
                    mediaItem
                }
            }
            
            return Futures.immediateFuture(updatedMediaItems)
        }
        
        override fun onGetLibraryRoot(
            session: MediaLibrarySession,
            browser: MediaSession.ControllerInfo,
            params: LibraryParams?
        ): ListenableFuture<androidx.media3.session.LibraryResult<MediaItem>> {
            Log.d(TAG, "onGetLibraryRoot from ${browser.packageName}")
            
            // Create a root media item
            val rootItem = MediaItem.Builder()
                .setMediaId("root")
                .setMediaMetadata(
                    MediaMetadata.Builder()
                        .setTitle("Rhythm Music Library")
                        .setMediaType(MediaMetadata.MEDIA_TYPE_FOLDER_MIXED)
                        .setIsPlayable(false)
                        .setIsBrowsable(true)
                        .build()
                )
                .build()
                
            return Futures.immediateFuture(androidx.media3.session.LibraryResult.ofItem(rootItem, params))
        }
    }

    override fun onShuffleModeEnabledChanged(shuffleModeEnabled: Boolean) {
        super.onShuffleModeEnabledChanged(shuffleModeEnabled)
        Log.d(TAG, "Shuffle mode changed to: $shuffleModeEnabled")

        // Broadcast explicit shuffle state updates so UI can reconcile queue order immediately.
        val intent = Intent(ACTION_SHUFFLE_STATE_CHANGED).apply {
            setPackage(packageName)
            putExtra(EXTRA_SHUFFLE_ENABLED, shuffleModeEnabled)
        }
        sendBroadcast(intent)

        // Use debounced update to prevent rapid UI changes
        scheduleCustomLayoutUpdate(100)
    }

    override fun onRepeatModeChanged(repeatMode: Int) {
        super<Player.Listener>.onRepeatModeChanged(repeatMode)
        Log.d(TAG, "Repeat mode changed to: $repeatMode")
        // Use debounced update to prevent rapid UI changes
        scheduleCustomLayoutUpdate(100)
    }
    
    // Mute state tracking
    private var volumeBeforeMute: Float = 1.0f
    private var isMuted: Boolean = false
    
    /**
     * Mute the player while preserving the volume level
     * Manual implementation since mute()/unmute() require newer Media3 version
     */
    private fun mutePlayer() {
        if (!isMuted) {
            volumeBeforeMute = player.volume
            player.volume = 0f
            isMuted = true
            Log.d(TAG, "Player muted (volume $volumeBeforeMute preserved)")
        }
    }
    
    /**
     * Unmute the player and restore the previous volume
     */
    private fun unmutePlayer() {
        if (isMuted) {
            player.volume = volumeBeforeMute
            isMuted = false
            Log.d(TAG, "Player unmuted (volume $volumeBeforeMute restored)")
        }
    }
    
    /**
     * Toggle mute state
     */
    private fun toggleMute() {
        if (isMuted) {
            unmutePlayer()
        } else {
            mutePlayer()
        }
    }

    override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
        super.onMediaItemTransition(mediaItem, reason)
        clearLyricsState()
        val transitionMediaId = mediaItem?.mediaId
        if (
            reason == Player.MEDIA_ITEM_TRANSITION_REASON_PLAYLIST_CHANGED &&
            transitionMediaId != null &&
            transitionMediaId == lastHandledControllerTransitionMediaId
        ) {
            Log.d(TAG, "Ignoring metadata-only controller transition for mediaId=$transitionMediaId")
            return
        }

        Log.d(TAG, "Media item transitioned: ${mediaItem?.mediaMetadata?.title}, reason=$reason")
        
        // Update custom layout when song changes to reflect correct favorite state
        scheduleCustomLayoutUpdate(50) // Shorter delay for song transitions
        
        // Update widget with new song info
        updateWidgetFromMediaItem(mediaItem)

        lastHandledControllerTransitionMediaId = transitionMediaId
    }
    
    override fun onIsPlayingChanged(isPlaying: Boolean) {
        super.onIsPlayingChanged(isPlaying)
        Log.d(TAG, "Is playing changed: $isPlaying")
        // Update widget when play/pause state changes
        updateWidgetFromMediaItem(player.currentMediaItem)
    }
    
    /**
     * Helper function to convert MediaItem to Song for scrobbling and widgets
     */
    private fun convertMediaItemToSong(mediaItem: MediaItem): Song? {
        return try {
            val extras = mediaItem.mediaMetadata.extras
            val canonicalTitle = extras?.getString(METADATA_EXTRA_ORIGINAL_TITLE)
            val canonicalArtist = extras?.getString(METADATA_EXTRA_ORIGINAL_ARTIST)
            val canonicalAlbum = extras?.getString(METADATA_EXTRA_ORIGINAL_ALBUM)

            Song(
                id = mediaItem.mediaId,
                title = canonicalTitle
                    ?.takeIf { it.isNotBlank() }
                    ?: mediaItem.mediaMetadata.title?.toString()
                    ?: "Unknown",
                artist = canonicalArtist
                    ?.takeIf { it.isNotBlank() }
                    ?: mediaItem.mediaMetadata.artist?.toString()
                    ?: "Unknown",
                album = canonicalAlbum
                    ?.takeIf { it.isNotBlank() }
                    ?: mediaItem.mediaMetadata.albumTitle?.toString()
                    ?: "",
                uri = mediaItem.requestMetadata.mediaUri ?: Uri.EMPTY,
                artworkUri = mediaItem.mediaMetadata.artworkUri,
                duration = player.duration.takeIf { it > 0 } ?: 0L,
                trackNumber = 0,
                year = 0,
                genre = "",
                albumId = "",
                albumArtist = mediaItem.mediaMetadata.albumArtist?.toString()
            )
        } catch (e: Exception) {
            Log.e(TAG, "Error converting MediaItem to Song", e)
            null
        }
    }
    
    private fun updateWidgetFromMediaItem(mediaItem: MediaItem?) {
        if (!appSettings.widgetAutoUpdate.value) {
            return
        }
        if (mediaItem != null) {
            val song = convertMediaItemToSong(mediaItem)
            if (song != null) {
                val isFavorite = isCurrentSongFavorite()
                val hasPrevious = player.hasPreviousMediaItem()
                val hasNext = player.hasNextMediaItem()
                val isShuffleEnabled = player.shuffleModeEnabled
                val repeatMode = player.repeatMode
                val snapshotKey = buildString {
                    append(song.id)
                    append('|')
                    append(player.isPlaying)
                    append('|')
                    append(hasPrevious)
                    append('|')
                    append(hasNext)
                    append('|')
                    append(isFavorite)
                    append('|')
                    append(isShuffleEnabled)
                    append('|')
                    append(repeatMode)
                }

                if (snapshotKey == lastWidgetSnapshotKey) {
                    return
                }
                lastWidgetSnapshotKey = snapshotKey

                WidgetUpdater.updateWidget(this, song, player.isPlaying, hasPrevious, hasNext, isFavorite, isShuffleEnabled, repeatMode)
            } else {
                if (lastWidgetSnapshotKey == "empty|false") {
                    return
                }
                lastWidgetSnapshotKey = "empty|false"
                WidgetUpdater.updateWidget(this, null, false)
            }
        } else {
            if (lastWidgetSnapshotKey == "empty|false") {
                return
            }
            lastWidgetSnapshotKey = "empty|false"
            WidgetUpdater.updateWidget(this, null, false)
        }
    }

    private fun playRandomFromCurrentQueue() {
        val queueSize = player.mediaItemCount
        if (queueSize <= 0) {
            Log.w(TAG, "Cannot start explore playback: queue is empty")
            return
        }

        val randomIndex = if (queueSize == 1) 0 else kotlin.random.Random.nextInt(queueSize)
        player.seekTo(randomIndex, 0L)
        player.playWhenReady = true
        player.play()

        serviceScope.launch {
            delay(120)
            updateWidgetFromMediaItem(player.currentMediaItem)
        }
    }

    // Sleep Timer functionality
    private var sleepTimerOriginalVolume: Float? = null

    private fun launchTimerCoroutine(startTime: Long, durationMs: Long, fadeOut: Boolean, pauseOnly: Boolean): Job {
        return serviceScope.launch {
            val localStartTime = startTime
            val localFadeOut = fadeOut
            val localPauseOnly = pauseOnly

            try {
                if (localFadeOut && durationMs > 10000) {
                    var remainingTime = durationMs
                    while (remainingTime > 10000) {
                        delay(1000)
                        remainingTime = durationMs - (System.currentTimeMillis() - localStartTime)
                        if (remainingTime <= 0) break
                        broadcastSleepTimerStatus()
                    }

                    val originalVolume = player.volume
                    sleepTimerOriginalVolume = originalVolume
                    rhythmPlayerEngine.isInternalVolumeAdjustment = true
                    val fadeSteps = 100
                    val fadeInterval = 10000L / fadeSteps

                    for (i in fadeSteps downTo 0) {
                        val volume = originalVolume * (i.toFloat() / fadeSteps)
                        player.volume = volume
                        delay(fadeInterval)
                        if (i % 10 == 0) {
                            broadcastSleepTimerStatus()
                        }
                    }
                } else {
                    var remainingTime = durationMs
                    while (remainingTime > 0) {
                        delay(1000)
                        remainingTime = durationMs - (System.currentTimeMillis() - localStartTime)
                        if (remainingTime <= 0) break
                        broadcastSleepTimerStatus()
                    }
                }

                if (localPauseOnly) {
                    player.pause()
                    Log.d(TAG, "Sleep timer paused playback")
                } else {
                    player.stop()
                    Log.d(TAG, "Sleep timer stopped playback")
                }

                if (localFadeOut) {
                    sleepTimerOriginalVolume?.let { player.volume = it }
                }
                rhythmPlayerEngine.isInternalVolumeAdjustment = false

                resetSleepTimer()

            } catch (e: CancellationException) {
                Log.d(TAG, "Sleep timer was cancelled")
                rhythmPlayerEngine.isInternalVolumeAdjustment = false
            } catch (e: Exception) {
                Log.e(TAG, "Error in sleep timer", e)
                rhythmPlayerEngine.isInternalVolumeAdjustment = false
                resetSleepTimer()
            } finally {
                rhythmPlayerEngine.isInternalVolumeAdjustment = false
                broadcastSleepTimerStatus()
            }
        }
    }

    fun startSleepTimer(durationMs: Long, fadeOut: Boolean = true, pauseOnly: Boolean = false) {
        Log.d(TAG, "Starting sleep timer: ${durationMs}ms, fadeOut: $fadeOut, pauseOnly: $pauseOnly")
        stopSleepTimer()

        if (durationMs <= 0) {
            Log.e(TAG, "Invalid sleep timer duration: $durationMs")
            return
        }

        sleepTimerDurationMs = durationMs
        sleepTimerStartTime = System.currentTimeMillis()
        fadeOutEnabled = fadeOut
        pauseOnlyEnabled = pauseOnly

        broadcastSleepTimerStatus()

        sleepTimerJob = launchTimerCoroutine(sleepTimerStartTime, durationMs, fadeOut, pauseOnly)
        Log.d(TAG, "Sleep timer job started for ${durationMs}ms")
    }

    fun extendSleepTimer() {
        if (sleepTimerDurationMs <= 0L || sleepTimerStartTime <= 0L) return

        val now = System.currentTimeMillis()
        if (now - lastVolumeExtendTimeMs < 3000) return
        lastVolumeExtendTimeMs = now

        Log.d(TAG, "Extending sleep timer due to volume change")

        val duration = sleepTimerDurationMs
        val fadeOut = fadeOutEnabled
        val pauseOnly = pauseOnlyEnabled

        sleepTimerJob?.cancel()
        sleepTimerJob = null
        rhythmPlayerEngine.isInternalVolumeAdjustment = false

        sleepTimerStartTime = now
        sleepTimerJob = launchTimerCoroutine(now, duration, fadeOut, pauseOnly)
        broadcastSleepTimerStatus()
        Log.d(TAG, "Sleep timer extended for ${duration}ms")
    }

    fun stopSleepTimer() {
        sleepTimerJob?.cancel()
        sleepTimerJob = null

        if (fadeOutEnabled) {
            sleepTimerOriginalVolume?.let { player.volume = it }
        }
        rhythmPlayerEngine.isInternalVolumeAdjustment = false

        resetSleepTimer()
        broadcastSleepTimerStatus()
        Log.d(TAG, "Sleep timer stopped")
    }

    fun getRemainingTimeMs(): Long {
        if (sleepTimerDurationMs <= 0L || sleepTimerStartTime <= 0L) {
            return 0L
        }

        val elapsed = System.currentTimeMillis() - sleepTimerStartTime
        return maxOf(0L, sleepTimerDurationMs - elapsed)
    }

    private fun resetSleepTimer() {
        sleepTimerDurationMs = 0L
        sleepTimerStartTime = 0L
        fadeOutEnabled = true
        pauseOnlyEnabled = false
    }
    
    private fun broadcastSleepTimerStatus() {
        val timerActive = isSleepTimerActive()
        val remainingTimeMs = getRemainingTimeMs()

        val intent = Intent(BROADCAST_SLEEP_TIMER_STATUS).apply {
            putExtra(EXTRA_TIMER_ACTIVE, timerActive)
            putExtra(EXTRA_REMAINING_TIME, remainingTimeMs)
            putExtra(EXTRA_TOTAL_TIME, sleepTimerDurationMs)
            setPackage(packageName)
        }
        sendBroadcast(intent)

        if (timerActive && sleepTimerDurationMs > 0L) {
            updateSleepTimerProgressNotification(
                remainingMs = remainingTimeMs,
                totalMs = sleepTimerDurationMs,
                pauseOnly = pauseOnlyEnabled
            )
        } else {
            cancelSleepTimerProgressNotification()
        }
    }

    private fun updateSleepTimerProgressNotification(
        remainingMs: Long,
        totalMs: Long,
        pauseOnly: Boolean
    ) {
        val safeTotalSeconds = (totalMs / 1000L).coerceAtLeast(1L).coerceAtMost(Int.MAX_VALUE.toLong()).toInt()
        val remainingSeconds = (remainingMs / 1000L).coerceIn(0L, safeTotalSeconds.toLong()).toInt()
        val completedSeconds = (safeTotalSeconds - remainingSeconds).coerceIn(0, safeTotalSeconds)

        val openAppIntent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra(MainActivity.EXTRA_OPEN_PLAYER, true)
        }

        val pendingIntent = PendingIntent.getActivity(
            this,
            2001,
            openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val title = getString(app.needle.player.R.string.notification_sleep_timer_title)
        val timeText = formatSleepTimerDuration(remainingMs)
        val content = if (pauseOnly) {
            getString(app.needle.player.R.string.notification_sleep_timer_pause_in, timeText)
        } else {
            getString(app.needle.player.R.string.notification_sleep_timer_stop_in, timeText)
        }

        val notification = NotificationCompat.Builder(this, SLEEP_TIMER_CHANNEL_ID)
            .setSmallIcon(app.needle.player.R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(content)
            .setStyle(NotificationCompat.BigTextStyle().bigText(content))
            .setCategory(NotificationCompat.CATEGORY_REMINDER)
            .setPriority(NotificationCompat.PRIORITY_LOW)
            .setOnlyAlertOnce(true)
            .setSilent(true)
            .setOngoing(true)
            .setAutoCancel(false)
            .setProgress(safeTotalSeconds, completedSeconds, false)
            .setContentIntent(pendingIntent)
            .build()

        val appSettings = app.needle.player.shared.data.model.AppSettings.getInstance(this)
        if (!appSettings.sleepTimerNotificationsEnabled.value) {
            return
        }

        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.notify(SLEEP_TIMER_NOTIFICATION_ID, notification)
    }

    private fun cancelSleepTimerProgressNotification() {
        val notificationManager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        notificationManager.cancel(SLEEP_TIMER_NOTIFICATION_ID)
    }

    private fun formatSleepTimerDuration(milliseconds: Long): String {
        val totalSeconds = (milliseconds / 1000L).coerceAtLeast(0L)
        val hours = totalSeconds / 3600L
        val minutes = (totalSeconds % 3600L) / 60L
        val seconds = totalSeconds % 60L

        return if (hours > 0L) {
            String.format(Locale.ROOT, "%d:%02d:%02d", hours, minutes, seconds)
        } else {
            String.format(Locale.ROOT, "%02d:%02d", minutes, seconds)
        }
    }
    
    private fun getPlayerAudioSessionId(): Int {
        return if (::rhythmPlayerEngine.isInitialized) rhythmPlayerEngine.getAudioSessionId() else 0
    }

    // Audio Effects (Equalizer) functionality
    fun getAudioSessionId(): Int {
        return try {
            getPlayerAudioSessionId()
        } catch (e: Exception) {
            Log.e(TAG, "Error getting audio session ID", e)
            0
        }
    }
    
    private fun initializeRhythmProcessors() {
        if (rhythmBassBoostProcessor == null) {
            Log.w(TAG, "Rhythm bass boost processor is null, creating new instance")
            try {
                rhythmBassBoostProcessor = app.needle.player.infrastructure.audio.RhythmBassBoostProcessor()
                isBassBoostAvailable = true
                appSettings.setBassBoostAvailable(true)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create bass boost processor", e)
                isBassBoostAvailable = false
                appSettings.setBassBoostAvailable(false)
            }
        }
        
        if (rhythmSpatializationProcessor == null) {
            Log.w(TAG, "Rhythm spatialization processor is null, creating new instance")
            try {
                rhythmSpatializationProcessor = app.needle.player.infrastructure.audio.RhythmSpatializationProcessor()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create spatialization processor", e)
            }
        }
        
        if (rhythmMonoAudioProcessor == null) {
            Log.w(TAG, "Rhythm mono audio processor is null, creating new instance")
            try {
                rhythmMonoAudioProcessor = app.needle.player.infrastructure.audio.RhythmMonoAudioProcessor()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to create mono audio processor", e)
            }
        }
    }

    fun initializeAudioEffects() {
        // Initialize Rhythm processors unconditionally, they don't need session IDs
        initializeRhythmProcessors()

        val requestedSessionId = try {
            getPlayerAudioSessionId()
        } catch (e: Exception) {
            Log.e(TAG, "Error reading audio session ID", e)
            0
        }

        if (requestedSessionId == 0) {
            Log.w(TAG, "Invalid audio session ID (0), skipping effects initialization")
            return
        }

        pendingAudioEffectsSessionId = requestedSessionId

        if (audioEffectsInitJob?.isActive == true) {
            Log.d(TAG, "Audio effects initialization already in progress; queued latest session: $requestedSessionId")
            return
        }

        audioEffectsInitJob = serviceScope.launch(Dispatchers.Default) {
            while (isActive) {
                val audioSessionId = pendingAudioEffectsSessionId
                pendingAudioEffectsSessionId = 0
                if (audioSessionId == 0) {
                    break
                }

                audioEffectsInitMutex.withLock {
                    initializeAudioEffectsInternal(audioSessionId)
                }
            }
        }
    }

    private suspend fun initializeAudioEffectsInternal(audioSessionId: Int) {
        try {
            isInitializingAudioEffects = true
            val shouldEnableEqualizer = appSettings.equalizerEnabled.value
            Log.d(TAG, "Initializing audio effects with session ID: $audioSessionId (current: $currentAudioEffectsSessionId, EQ enabled: $shouldEnableEqualizer)")

            if (equalizer == null || currentAudioEffectsSessionId != audioSessionId) {
                try {
                    equalizer?.release()
                    equalizer = null
                    currentAudioEffectsSessionId = 0
                    delay(50)
                } catch (e: Exception) {
                    Log.w(TAG, "Error releasing existing equalizer: ${e.message}")
                }

                try {
                    equalizer = android.media.audiofx.Equalizer(0, audioSessionId).apply {
                        enabled = true
                    }
                    currentAudioEffectsSessionId = audioSessionId
                    Log.d(TAG, "Equalizer initialized with ${equalizer?.numberOfBands} bands for session $audioSessionId")
                } catch (e: Exception) {
                    Log.w(TAG, "Equalizer is not available on this device: ${e.message}")
                    equalizer = null
                    currentAudioEffectsSessionId = 0
                }
            } else {
                Log.d(TAG, "Equalizer already active for session $audioSessionId, skipping recreation")
            }

            loadSavedAudioEffects()

            audioEffectsInitialized = true
            Log.d(TAG, "Audio effects initialization completed successfully")

        } catch (e: Exception) {
            Log.e(TAG, "Error initializing audio effects", e)
            audioEffectsInitialized = false
        } finally {
            isInitializingAudioEffects = false
        }
    }
    
    private fun loadSavedAudioEffects() {
        try {
            if (appSettings.audioRoutingMode.value == "app") {
                Log.i(TAG, "Bit-perfect mode active, setting flat EQ and bypassing DSP audio effects")
                withEqualizerSafe("bit-perfect flat EQ", Unit) { eq ->
                    val numberOfBands = eq.numberOfBands.toInt()
                    for (i in 0 until numberOfBands) {
                        eq.setBandLevel(i.toShort(), 0)
                    }
                }
                setEqualizerEnabledSafe(false)
                rhythmBassBoostProcessor?.setEnabled(false)
                rhythmSpatializationProcessor?.setEnabled(false)
                rhythmMonoAudioProcessor?.setEnabled(false)
                return
            }

            if (equalizer != null) {
                val shouldBeEnabled = appSettings.equalizerEnabled.value
                Log.d(TAG, "Loading saved effects - EQ should be enabled: $shouldBeEnabled")
                
                if (shouldBeEnabled) {
                    val pending = pendingEqualizerLevels
                    if (pending != null) {
                        pendingEqualizerLevels = null
                        applyEqualizerPreset(pending)
                    } else {
                        val bandLevelsString = appSettings.equalizerBandLevels.value
                        val bandLevels = bandLevelsString.split(",").mapNotNull { it.toFloatOrNull() }
                        if (bandLevels.isNotEmpty()) {
                            applyEqualizerPreset(bandLevels.toFloatArray())
                        }
                    }
                    // Enable equalizer AFTER applying levels to avoid audio glitches
                    setEqualizerEnabledSafe(true)
                } else {
                    pendingEqualizerLevels = null
                    // Zero all bands — don't disable hardware EQ to avoid AudioFlinger DSP burst
                    withEqualizerSafe("set flat bands on load", Unit) { eq ->
                        val numberOfBands = eq.numberOfBands.toInt()
                        for (i in 0 until numberOfBands) {
                            eq.setBandLevel(i.toShort(), 0)
                        }
                    }
                    // Keep hardware EQ enabled — software controls the "off" state via flat bands
                    setEqualizerEnabledSafe(true)
                }
                
                val actualState = getEqualizerEnabledSafe()
                if (!actualState) {
                    Log.w(TAG, "EQ was unexpectedly disabled after load, re-enabling")
                    setEqualizerEnabledSafe(true)
                }
            } else {
                Log.w(TAG, "Cannot load saved equalizer settings: equalizer is null")
            }
            
            // Load Rhythm bass boost settings
            val bassBoostShouldBeEnabled = appSettings.bassBoostEnabled.value
            if (rhythmBassBoostProcessor != null) {
                rhythmBassBoostProcessor?.setEnabled(bassBoostShouldBeEnabled)
                if (bassBoostShouldBeEnabled) {
                    rhythmBassBoostProcessor?.setStrength(appSettings.bassBoostStrength.value.toShort())
                }
                Log.d(TAG, "Rhythm bass boost loaded: enabled=$bassBoostShouldBeEnabled, strength=${rhythmBassBoostProcessor?.getStrength()}")
            } else {
                Log.w(TAG, "Cannot load bass boost settings: Rhythm processor is null")
            }
            
            // Load Rhythm spatialization settings
            val virtualizerEnabled = appSettings.virtualizerEnabled.value
            virtualizerStrength = appSettings.virtualizerStrength.value.toShort()
            if (rhythmSpatializationProcessor != null) {
                rhythmSpatializationProcessor?.setEnabled(virtualizerEnabled)
                rhythmSpatializationProcessor?.setStrength(virtualizerStrength)
                Log.d(TAG, "Rhythm spatialization loaded: enabled=$virtualizerEnabled, strength=$virtualizerStrength")
            } else {
                Log.d(TAG, "Cannot load spatialization settings: Rhythm processor is null")
            }

            // Load Rhythm mono audio settings
            val monoAudioEnabled = appSettings.monoAudioEnabled.value
            if (rhythmMonoAudioProcessor != null) {
                rhythmMonoAudioProcessor?.setEnabled(monoAudioEnabled)
                Log.d(TAG, "Rhythm mono audio loaded: enabled=$monoAudioEnabled")
            }
            
            Log.d(TAG, "Loaded saved audio effects - EQ: ${appSettings.equalizerEnabled.value}, Bass: ${appSettings.bassBoostEnabled.value}, Virtualizer: ${appSettings.virtualizerEnabled.value}, Mono: ${appSettings.monoAudioEnabled.value}")
            if (::rhythmPlayerEngine.isInitialized) {
                rhythmPlayerEngine.updateTrackSelectionParameters()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error loading saved audio effects", e)
        }
    }
    
    fun setEqualizerEnabled(enabled: Boolean) {
        if (enabled && appSettings.audioRoutingMode.value == "app") {
            Log.i(TAG, "Cannot enable equalizer: Bit-Perfect mode is active")
            return
        }

        if (enabled && equalizer == null) {
            Log.w(TAG, "Attempting to enable equalizer but equalizer is null. Will reinitialize.")
            // Try to initialize if we have a valid session ID
            if (getPlayerAudioSessionId() != 0) {
                initializeAudioEffects()
            } else {
                Log.e(TAG, "Cannot enable equalizer: invalid audio session ID")
                return
            }
        }
        
        if (enabled) {
            // Restore saved band levels first before enabling to avoid dynamic transition glitch
            val bandLevelsString = appSettings.equalizerBandLevels.value
            val bandLevels = bandLevelsString.split(",").mapNotNull { it.toFloatOrNull() }
            if (bandLevels.isNotEmpty()) {
                applyEqualizerPreset(bandLevels.toFloatArray())
            }
            
            val actualState = setEqualizerEnabledWithVolumeGuard(true)
            Log.d(TAG, "Equalizer enabled: true, actual state: $actualState")
            if (!actualState) {
                Log.e(TAG, "Equalizer state mismatch! Requested: true, Actual: false")
            }
        } else {
            val actualState = setEqualizerEnabledWithVolumeGuard(false)
            Log.d(TAG, "Equalizer disabled (hardware kept enabled with flat bands to avoid DSP burst)")
        }
    }
    
    fun setEqualizerBandLevel(band: Short, level: Short) {
        try {
            val bandLevelsString = appSettings.equalizerBandLevels.value
            val bandLevels = bandLevelsString.split(",").mapNotNull { it.toFloatOrNull() }
            
            if (bandLevels.isNotEmpty()) {
                applyEqualizerPreset(bandLevels.toFloatArray())
                Log.d(TAG, "Re-applied equalizer preset with headroom after band $band change")
            } else {
                equalizer?.let { eq ->
                    val range = eq.bandLevelRange
                    val clamped = level.coerceIn(range[0], range[1])
                    withEqualizerSafe("setBandLevel", Unit) {
                        it.setBandLevel(band, clamped)
                    }
                    Log.d(TAG, "Set equalizer band $band to level $clamped")
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error setting equalizer band level", e)
        }
    }
    
    fun getEqualizerBandLevel(band: Short): Short {
        return withEqualizerSafe("band level read", 0) { it.getBandLevel(band) }
    }
    
    fun getNumberOfBands(): Short {
        return withEqualizerSafe("band count read", 0) { it.numberOfBands }
    }
    
    fun getBandFreqRange(band: Short): IntArray? {
        return withEqualizerSafe("band frequency range read", null) { it.getBandFreqRange(band) }
    }
    
    fun isEqualizerSupported(): Boolean {
        // All devices now support equalizer with software implementation
        return true
    }
    
    /**
     * Get diagnostic information about audio effects state for debugging
     */
    fun getEqualizerDiagnostics(): String {
        return buildString {
            appendLine("=== Audio Effects Diagnostics ===")
            appendLine("Audio effects initialized: $audioEffectsInitialized")
            appendLine("Currently initializing: $isInitializingAudioEffects")
            appendLine("Audio session ID: ${getPlayerAudioSessionId()}")
            appendLine("")
            appendLine("--- Equalizer ---")
            appendLine("Equalizer object: ${if (equalizer != null) "initialized" else "null"}")
            equalizer?.let { eq ->
                appendLine("Enabled state: ${withEqualizerSafe("diagnostics enabled read", false) { it.enabled }}")
                val bandCount = withEqualizerSafe("diagnostics band count read", 0) { it.numberOfBands.toInt() }
                appendLine("Number of bands: $bandCount")
                appendLine("Band levels: ${(0 until bandCount).map { bandIndex -> withEqualizerSafe("diagnostics band level read", 0) { it.getBandLevel(bandIndex.toShort()) } }}")
            }
            appendLine("Settings - Enabled: ${appSettings.equalizerEnabled.value}")
            appendLine("Settings - Preset: ${appSettings.equalizerPreset.value}")
            appendLine("Settings - AutoEQ: ${appSettings.autoEQProfile.value}")
            appendLine("Settings - Band levels: ${appSettings.equalizerBandLevels.value}")
            appendLine("")
            appendLine("--- Rhythm Bass Boost ---")
            appendLine("Processor: ${if (rhythmBassBoostProcessor != null) "initialized" else "null"}")
            rhythmBassBoostProcessor?.let { bb ->
                appendLine("Enabled state: ${bb.isEnabled()}")
                appendLine("Strength: ${bb.getStrength()}")
            }
            appendLine("Settings - Enabled: ${appSettings.bassBoostEnabled.value}")
            appendLine("Settings - Strength: ${appSettings.bassBoostStrength.value}")
            appendLine("Available: $isBassBoostAvailable")
            appendLine("")
            appendLine("--- Rhythm Spatialization ---")
            appendLine("Processor: ${if (rhythmSpatializationProcessor != null) "initialized" else "null"}")
            rhythmSpatializationProcessor?.let { sp ->
                appendLine("Enabled state: ${sp.isEnabled()}")
                appendLine("Strength: ${sp.getStrength()}")
            }
            appendLine("Settings - Enabled: ${appSettings.virtualizerEnabled.value}")
            appendLine("Settings - Strength: ${appSettings.virtualizerStrength.value}")
        }
    }
    
    fun isBassBoostSupported(): Boolean {
        return isBassBoostAvailable
    }
    
    fun applyEqualizerPreset(levels: FloatArray) {
        try {
            if (equalizer == null) {
                Log.w(TAG, "Equalizer is null when applying preset, queuing pending levels and ensuring init")
                pendingEqualizerLevels = levels.copyOf()
                if (getPlayerAudioSessionId() != 0) {
                    initializeAudioEffects()
                }
                return
            }
            
            equalizer?.let { eq ->
                val numberOfBands = eq.numberOfBands.toInt()
                val inputBands = levels.size
                val bandRange = eq.bandLevelRange
                
                val interpolatedLevels = if (inputBands == numberOfBands) {
                    levels.copyOf()
                } else {
                    interpolateBands(levels, numberOfBands, eq)
                }

                val maxGain = interpolatedLevels.maxOrNull() ?: 0f
                val headroom = if (maxGain > 0f) maxGain else 0f

                for (i in 0 until numberOfBands) {
                    val effectiveLevelDb = interpolatedLevels[i] - headroom
                    val rawLevel = (effectiveLevelDb * 100).toInt().toShort()
                    val level = rawLevel.coerceIn(bandRange[0], bandRange[1])
                    eq.setBandLevel(i.toShort(), level)
                }
                Log.d(TAG, "Applied equalizer preset: ${levels.size} UI bands -> $numberOfBands hardware bands (headroom: -${headroom}dB)")
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error applying equalizer preset", e)
        }
    }
    
    /**
     * Interpolates 10-band EQ settings to the available hardware bands.
     * Uses logarithmic frequency mapping based on actual hardware center frequencies when available.
     * 
     * Standard 10-band frequencies: 31Hz, 62Hz, 125Hz, 250Hz, 500Hz, 1kHz, 2kHz, 4kHz, 8kHz, 16kHz
     */
    private fun interpolateBands(inputLevels: FloatArray, outputBands: Int, eq: android.media.audiofx.Equalizer? = null): FloatArray {
        if (outputBands <= 0 || inputLevels.isEmpty()) return FloatArray(outputBands.coerceAtLeast(0))
        if (outputBands == 1) {
            return FloatArray(1) { inputLevels.average().toFloat() }
        }
        
        val result = FloatArray(outputBands)
        val inputBands = inputLevels.size
        val standard10Freqs = floatArrayOf(31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)

        if (inputBands == 10 && eq != null) {
            try {
                val hwFreqs = FloatArray(outputBands) { b ->
                    (eq.getCenterFreq(b.toShort()) / 1000f).coerceAtLeast(20f)
                }
                for (i in 0 until outputBands) {
                    val targetFreq = hwFreqs[i]
                    val logTarget = kotlin.math.ln(targetFreq.toDouble())
                    if (targetFreq <= standard10Freqs.first()) {
                        result[i] = inputLevels.first()
                    } else if (targetFreq >= standard10Freqs.last()) {
                        result[i] = inputLevels.last()
                    } else {
                        var idx = 0
                        while (idx < standard10Freqs.size - 1 && standard10Freqs[idx + 1] < targetFreq) {
                            idx++
                        }
                        val logLow = kotlin.math.ln(standard10Freqs[idx].toDouble())
                        val logHigh = kotlin.math.ln(standard10Freqs[idx + 1].toDouble())
                        val fraction = ((logTarget - logLow) / (logHigh - logLow)).toFloat().coerceIn(0f, 1f)
                        result[i] = inputLevels[idx] * (1f - fraction) + inputLevels[idx + 1] * fraction
                    }
                }
                return result
            } catch (e: Exception) {
                Log.w(TAG, "Failed to query hardware center frequencies, falling back to heuristic interpolation", e)
            }
        }
        
        if (outputBands == 5 && inputBands == 10) {
            result[0] = (inputLevels[0] * 0.25f + inputLevels[1] * 0.5f + inputLevels[2] * 0.25f)
            result[1] = (inputLevels[3] * 0.5f + inputLevels[4] * 0.5f)
            result[2] = (inputLevels[5] * 0.5f + inputLevels[6] * 0.5f)
            result[3] = (inputLevels[7] * 0.5f + inputLevels[8] * 0.5f)
            result[4] = (inputLevels[8] * 0.25f + inputLevels[9] * 0.75f)
        } else {
            // General linear interpolation for other cases
            val ratio = (inputBands - 1).toFloat() / (outputBands - 1).toFloat()
            for (i in 0 until outputBands) {
                val srcPos = i * ratio
                val lowerIndex = srcPos.toInt().coerceIn(0, inputBands - 1)
                val upperIndex = (lowerIndex + 1).coerceIn(0, inputBands - 1)
                val fraction = srcPos - lowerIndex
                result[i] = inputLevels[lowerIndex] * (1 - fraction) + inputLevels[upperIndex] * fraction
            }
        }
        
        return result
    }
    
    fun setBassBoostEnabled(enabled: Boolean) {
        if (rhythmBassBoostProcessor == null) {
            Log.w(TAG, "Attempting to enable bass boost but Rhythm processor is null. Reinitializing.")
            initializeRhythmProcessors()
        }
        
        val actualEnabled = if (appSettings.audioRoutingMode.value == "app") false else enabled
        rhythmBassBoostProcessor?.setEnabled(actualEnabled)
        Log.d(TAG, "Rhythm bass boost enabled: $actualEnabled (applies to next audio buffer)")
        if (::rhythmPlayerEngine.isInitialized) {
            rhythmPlayerEngine.updateTrackSelectionParameters()
        }
    }
    
    fun setBassBoostStrength(strength: Short) {
        try {
            if (rhythmBassBoostProcessor == null) {
                Log.w(TAG, "Cannot set bass boost strength: Rhythm processor is null")
                return
            }
            rhythmBassBoostProcessor?.setStrength(strength)
            Log.d(TAG, "Rhythm bass boost strength set to $strength (applies to next audio buffer)")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting bass boost strength", e)
        }
    }
    
    fun getBassBoostStrength(): Short {
        return rhythmBassBoostProcessor?.getStrength() ?: 0
    }
    
    fun setVirtualizerEnabled(enabled: Boolean) {
        if (rhythmSpatializationProcessor == null) {
            Log.w(TAG, "Rhythm spatialization processor is null, reinitializing")
            initializeRhythmProcessors()
        }
        
        val actualEnabled = if (appSettings.audioRoutingMode.value == "app") false else enabled
        rhythmSpatializationProcessor?.setEnabled(actualEnabled)
        virtualizerStrength = if (actualEnabled) virtualizerStrength else 0
        Log.d(TAG, "Rhythm spatialization enabled: $actualEnabled (applies to next audio buffer)")
        if (::rhythmPlayerEngine.isInitialized) {
            rhythmPlayerEngine.updateTrackSelectionParameters()
        }
    }
    
    fun setVirtualizerStrength(strength: Short) {
        try {
            virtualizerStrength = strength
            rhythmSpatializationProcessor?.setStrength(strength)
            Log.d(TAG, "Rhythm spatialization strength set to $strength (applies to next audio buffer)")
        } catch (e: Exception) {
            Log.e(TAG, "Error setting virtualizer strength", e)
        }
    }
    
    fun getVirtualizerStrength(): Short {
        return rhythmSpatializationProcessor?.getStrength() ?: virtualizerStrength
    }
    
    fun isSpatializationAvailable(): Boolean {
        // Rhythm spatialization is always available
        return rhythmSpatializationProcessor != null
    }
    
    fun getSpatializationStatus(): String {
        return when {
            rhythmSpatializationProcessor == null -> "Not initialized"
            !rhythmSpatializationProcessor!!.isEnabled() -> "Available (Rhythm-based)"
            else -> "Active (Rhythm-based)"
        }
    }

    fun setMonoAudioEnabled(enabled: Boolean) {
        if (rhythmMonoAudioProcessor == null) {
            Log.w(TAG, "Attempting to enable mono audio but Rhythm processor is null. Reinitializing.")
            initializeRhythmProcessors()
        }
        
        val actualEnabled = if (appSettings.audioRoutingMode.value == "app") false else enabled
        rhythmMonoAudioProcessor?.setEnabled(actualEnabled)
        Log.d(TAG, "Rhythm mono audio enabled: $actualEnabled (applies to next audio buffer)")
        if (::rhythmPlayerEngine.isInitialized) {
            rhythmPlayerEngine.updateTrackSelectionParameters()
        }
    }

    
    // Public methods for external access
    fun getMediaSession(): MediaLibrarySession? = mediaSession
    
    fun getSleepTimerRemainingTime(): Long = sleepTimerDurationMs - (System.currentTimeMillis() - sleepTimerStartTime)
    
    fun isSleepTimerActive(): Boolean =
        sleepTimerDurationMs > 0L && sleepTimerStartTime > 0L && getRemainingTimeMs() > 0L
    
    private fun releaseAudioEffects() {
        try {
            equalizer?.release()
            equalizer = null
            currentAudioEffectsSessionId = 0
            audioEffectsInitialized = false
            
            // Reset Rhythm processors
            rhythmBassBoostProcessor?.reset()
            rhythmSpatializationProcessor?.reset()
            rhythmMonoAudioProcessor?.reset()
            rhythmBassBoostProcessor = null
            rhythmSpatializationProcessor = null
            rhythmMonoAudioProcessor = null
            
            Log.d(TAG, "Audio effects released")
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing audio effects", e)
        }
    }
    
    /**
     * Called when the app is removed from recents (swiped away).
     * Implements the "stop playback on app close" setting.
     */
    override fun onTaskRemoved(rootIntent: Intent?) {
        val shouldStopPlayback = appSettings.stopPlaybackOnAppClose.value
        
        Log.d(TAG, "onTaskRemoved called - stopPlaybackOnAppClose: $shouldStopPlayback")
        
        if (shouldStopPlayback) {
            // User wants playback to stop when app is closed
            player.apply {
                playWhenReady = false
                stop()
                clearMediaItems()
            }
            stopForeground(STOP_FOREGROUND_REMOVE)
            stopSelf()
            super.onTaskRemoved(rootIntent)
            return
        }
        
        // If not stopping on close, check if we should keep the service alive
        // Only keep alive if actually playing or has media
        if (!player.playWhenReady || player.mediaItemCount == 0 || player.playbackState == Player.STATE_ENDED) {
            // Nothing playing, stop the service
            Log.d(TAG, "No active playback, stopping service")
            stopSelf()
        } else {
            Log.d(TAG, "Continuing playback in background")
        }
        
        super.onTaskRemoved(rootIntent)
    }
}
