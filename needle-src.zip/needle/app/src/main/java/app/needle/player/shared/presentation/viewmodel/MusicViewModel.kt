/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.viewmodel

// Type alias for backward compatibility
// MusicViewModel has been moved to features.local.presentation.viewmodel
typealias MusicViewModel = app.needle.player.features.local.presentation.viewmodel.MusicViewModel
