/*
 * SPDX-FileCopyrightText: 2024-2026 Anjishnu Nandi <https://github.com/cromaguy>
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

package app.needle.player.shared.presentation.screens

import app.needle.player.shared.presentation.components.bottomsheets.AdaptiveSheetScrollContainer
import app.needle.player.shared.presentation.components.bottomsheets.RhythmAdaptiveModalSheet
import app.needle.player.shared.presentation.components.bottomsheets.SheetAdaptiveType

import app.needle.player.shared.presentation.components.icons.RhythmIcons
import app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon
import app.needle.player.shared.presentation.components.icons.Icon
import app.needle.player.shared.presentation.components.common.ExpressiveCookieEmptyState
import app.needle.player.shared.presentation.components.common.MarqueeText
import app.needle.player.shared.presentation.components.common.horizontalEdgeBlend
import app.needle.player.shared.presentation.components.common.rememberExpressiveShape
import app.needle.player.shared.presentation.components.common.rememberExpressiveShapeFor
import app.needle.player.shared.presentation.components.common.ExpressiveShapeTarget
import app.needle.player.shared.presentation.components.common.M3CircularLoader

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import android.net.Uri
import app.needle.player.R
import app.needle.player.shared.presentation.components.bottomsheets.AddToPlaylistBottomSheet
import app.needle.player.shared.presentation.components.bottomsheets.SongInfoBottomSheet
import app.needle.player.shared.presentation.components.bottomsheets.SongOverflowBottomSheet
import app.needle.player.shared.presentation.components.dialogs.CreatePlaylistDialog
import app.needle.player.features.local.presentation.viewmodel.MusicViewModel
import app.needle.player.shared.data.model.findAlbumForSong
import app.needle.player.shared.presentation.components.common.CollapsibleHeaderScreen
import app.needle.player.features.streaming.domain.model.StreamingAlbum
import app.needle.player.features.streaming.domain.model.StreamingArtist
import app.needle.player.features.streaming.domain.model.StreamingPlaylist
import app.needle.player.features.streaming.domain.model.StreamingSong
import app.needle.player.features.streaming.presentation.viewmodel.StreamingMusicViewModel
import app.needle.player.shared.data.model.Album
import app.needle.player.shared.data.model.AppSettings
import app.needle.player.shared.data.model.Artist
import app.needle.player.shared.data.model.Playlist
import app.needle.player.shared.data.model.Song
import app.needle.player.shared.presentation.components.Material3SettingsGroup
import app.needle.player.shared.presentation.components.Material3SettingsItem
import app.needle.player.shared.presentation.components.SettingScope
import app.needle.player.shared.presentation.components.common.M3PlaceholderType
import app.needle.player.shared.presentation.components.dialogs.SwitchModeDialog
import app.needle.player.ui.LocalMiniPlayerPadding
import app.needle.player.util.GenreUtils
import app.needle.player.util.HapticUtils
import app.needle.player.util.HapticType
import app.needle.player.util.ImageUtils
import app.needle.player.util.M3ImageUtils
import coil.compose.AsyncImage
import coil.request.ImageRequest
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.res.stringResource
import androidx.core.net.toUri
import app.needle.player.util.windowScreenWidthDp
import app.needle.player.util.windowScreenHeightDp

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UniversalSearchScreen(
    localViewModel: MusicViewModel = viewModel(),
    streamingViewModel: StreamingMusicViewModel = viewModel(),
    onLocalSongClick: (Song) -> Unit = {},
    onLocalAlbumClick: (Album) -> Unit = {},
    onLocalArtistClick: (Artist) -> Unit = {},
    onLocalPlaylistClick: (Playlist) -> Unit = {},
    onStreamingSongClick: (StreamingSong) -> Unit = {},
    onStreamingAlbumClick: (StreamingAlbum) -> Unit = {},
    onStreamingArtistClick: (StreamingArtist) -> Unit = {},
    onStreamingPlaylistClick: (StreamingPlaylist) -> Unit = {},
    onBack: () -> Unit = {}
) {
    val context = LocalContext.current
    val appSettings = AppSettings.getInstance(context)
    val appMode by appSettings.appMode.collectAsState()
    val showKeyboardOnSearchOpen by appSettings.showKeyboardOnSearchOpen.collectAsState()

    DisposableEffect(context) {
        val activity = context as? android.app.Activity
        val originalMode = activity?.window?.attributes?.softInputMode
        activity?.window?.setSoftInputMode(16 /* WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE */)
        onDispose {
            if (originalMode != null) {
                activity.window?.setSoftInputMode(originalMode)
            }
        }
    }

    val focusManager = LocalFocusManager.current
    val haptics = LocalHapticFeedback.current
    val coroutineScope = rememberCoroutineScope()
    val isTablet = windowScreenWidthDp() >= 600
    val isLandscapeTablet = isTablet && windowScreenWidthDp() > windowScreenHeightDp()
    val horizontalPadding = if (isTablet) 32.dp else 24.dp

    var query by remember { mutableStateOf("") }
    val focusRequester = remember { FocusRequester() }

    LaunchedEffect(Unit) {
        if (showKeyboardOnSearchOpen) {
            delay(300)
            try {
                focusRequester.requestFocus()
            } catch (e: Exception) {
                // Ignore focus request failure in unexpected states
            }
        }
    }

    var showFilters by remember { mutableStateOf(false) }
    var filterSongs by remember { mutableStateOf(true) }
    var filterAlbums by remember { mutableStateOf(true) }
    var filterArtists by remember { mutableStateOf(true) }
    var filterPlaylists by remember { mutableStateOf(true) }

    var showSwitchDialog by remember { mutableStateOf(false) }
    var pendingAction: (() -> Unit)? by remember { mutableStateOf(null) }
    var targetModeForPendingAction by remember { mutableStateOf("") }

    var showAllSongsPage by remember { mutableStateOf(false) }
    var showSongOptionsSheet by remember { mutableStateOf(false) }
    var selectedSongForOptions by remember { mutableStateOf<Any?>(null) }

    var showAddToPlaylistSheet by remember { mutableStateOf(false) }
    var selectedSongForPlaylist by remember { mutableStateOf<Song?>(null) }
    var showSongInfoSheet by remember { mutableStateOf(false) }
    var showSongInfoInEditMode by remember { mutableStateOf(false) }
    var selectedSongForInfo by remember { mutableStateOf<Song?>(null) }
    var isSongInfoStreaming by remember { mutableStateOf(false) }
    var showCreatePlaylistDialog by remember { mutableStateOf(false) }

    var pendingMetadataEditCompleteCallback by remember { mutableStateOf<((Boolean) -> Unit)?>(null) }

    val writePermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartIntentSenderForResult()
    ) { result ->
        if (result.resultCode == android.app.Activity.RESULT_OK) {
            localViewModel.completeMetadataWriteAfterPermission(
                onSuccess = {
                    Toast.makeText(context, R.string.localnavigation_metadata_saved_successfully, Toast.LENGTH_SHORT).show()
                    pendingMetadataEditCompleteCallback?.invoke(true)
                    pendingMetadataEditCompleteCallback = null
                },
                onError = { errorMessage ->
                    Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                    pendingMetadataEditCompleteCallback?.invoke(false)
                    pendingMetadataEditCompleteCallback = null
                }
            )
        } else {
            localViewModel.cancelPendingMetadataWrite()
            pendingMetadataEditCompleteCallback?.invoke(false)
            pendingMetadataEditCompleteCallback = null
            Toast.makeText(context, R.string.localnavigation_permission_denied_changes_saved, Toast.LENGTH_LONG).show()
        }
    }

    val localSongs by localViewModel.filteredSongs.collectAsState()
    val fullLocalAlbums by localViewModel.filteredAlbums.collectAsState()
    val localArtists by localViewModel.filteredArtists.collectAsState()
    val localPlaylists by localViewModel.playlists.collectAsState()
    val searchHistory by localViewModel.searchHistory.collectAsState()
    val favoriteSongs by localViewModel.favoriteSongs.collectAsState()

    val streamingQuery by streamingViewModel.searchQuery.collectAsState()
    val streamingResults by streamingViewModel.searchResults.collectAsState()
    val isStreamingLoading by streamingViewModel.isLoading.collectAsState()
    val streamingLikedSongs by streamingViewModel.likedSongs.collectAsState()

    val isGenreDetectionComplete by localViewModel.isGenreDetectionComplete.collectAsState()
    val streamingBrowseCategories by streamingViewModel.browseCategories.collectAsState()

    val genres = remember(localSongs, streamingBrowseCategories, streamingResults.songs) {
        val localGenres = localSongs
            .flatMap { song -> GenreUtils.splitGenres(song.genre) }
        val streamingGenres = streamingBrowseCategories.map { it.name } +
            streamingResults.songs.flatMap { song -> GenreUtils.splitGenres(song.genre) }
        (localGenres + streamingGenres)
            .distinctBy { it.lowercase() }
            .sortedBy { it.lowercase() }
    }

    val genreSongCounts = remember(genres, localSongs, streamingResults.songs) {
        genres.associateWith { genre ->
            localSongs.count { song -> GenreUtils.matchesGenre(song.genre, genre) } +
                streamingResults.songs.count { song -> GenreUtils.matchesGenre(song.genre, genre) }
        }
    }

    LaunchedEffect(query) {
        if (query.isNotBlank() && streamingQuery != query) {
            streamingViewModel.search(query)
        }
    }

    val matchedLocalSongs = remember(query, localSongs, filterSongs) {
        if (!filterSongs || query.isBlank()) emptyList()
        else {
            val lowerQuery = query.lowercase()
            localSongs.filter {
                it.title.lowercase().contains(lowerQuery) ||
                        it.artist.lowercase().contains(lowerQuery) ||
                        it.album.lowercase().contains(lowerQuery) ||
                        GenreUtils.matchesGenreQuery(it.genre, lowerQuery)
            }
        }
    }
    val matchedLocalAlbums = remember(query, fullLocalAlbums, filterAlbums) {
        if (!filterAlbums || query.isBlank()) emptyList()
        else {
            val lowerQuery = query.lowercase()
            fullLocalAlbums.filter { album ->
                album.title.contains(query, true) ||
                album.artist.contains(query, true) ||
                album.songs.any { it.title.lowercase().contains(lowerQuery) }
            }
        }
    }
    val matchedLocalArtists = remember(query, localArtists, filterArtists) {
        if (!filterArtists || query.isBlank()) emptyList()
        else localArtists.filter { it.name.contains(query, true) }
    }
    val matchedLocalPlaylists = remember(query, localPlaylists, filterPlaylists) {
        if (!filterPlaylists || query.isBlank()) emptyList()
        else localPlaylists.filter { it.name.contains(query, true) }
    }

    val matchedStreamingSongs = if (filterSongs) streamingResults.songs else emptyList()
    val matchedStreamingAlbums = if (filterAlbums) streamingResults.albums else emptyList()
    val matchedStreamingArtists = if (filterArtists) streamingResults.artists else emptyList()
    val matchedStreamingPlaylists = if (filterPlaylists) streamingResults.playlists else emptyList()

    val hasResults = matchedLocalSongs.isNotEmpty() || matchedStreamingSongs.isNotEmpty() ||
            matchedLocalAlbums.isNotEmpty() || matchedStreamingAlbums.isNotEmpty() ||
            matchedLocalArtists.isNotEmpty() || matchedStreamingArtists.isNotEmpty() ||
            matchedLocalPlaylists.isNotEmpty() || matchedStreamingPlaylists.isNotEmpty()

    val handleAction = { itemMode: String, action: () -> Unit ->
        if (itemMode == appMode) {
            action()
        } else {
            targetModeForPendingAction = itemMode
            pendingAction = action
            showSwitchDialog = true
        }
    }

    val handleBack = {
        if (showAllSongsPage) {
            showAllSongsPage = false
        } else if (query.isNotEmpty() || showFilters) {
            query = ""
            showFilters = false
            focusManager.clearFocus()
        } else {
            onBack()
        }
    }

    BackHandler { handleBack() }

    if (showSwitchDialog) {
        SwitchModeDialog(
            targetMode = targetModeForPendingAction,
            onDismissRequest = {
                showSwitchDialog = false
                pendingAction = null
            },
            onConfirm = {
                appSettings.setAppMode(targetModeForPendingAction)
                pendingAction?.invoke()
                showSwitchDialog = false
                pendingAction = null
            }
        )
    }

    val statusBarsTop = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    val navigationBarsBottom = WindowInsets.navigationBars.asPaddingValues().calculateBottomPadding()
    val searchBarHeightPadding = 88.dp + (if (showFilters) 48.dp else 0.dp)
    val totalBottomPadding = searchBarHeightPadding + navigationBarsBottom + 16.dp

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        AnimatedContent(
            targetState = query.isBlank(),
            transitionSpec = {
                if (targetState) {
                    (slideInVertically(initialOffsetY = { -it / 6 }) + fadeIn(animationSpec = tween(300)))
                        .togetherWith(slideOutVertically(targetOffsetY = { it / 6 }) + fadeOut(animationSpec = tween(250)))
                } else {
                    (slideInVertically(initialOffsetY = { it / 6 }) + fadeIn(animationSpec = tween(300)))
                        .togetherWith(slideOutVertically(targetOffsetY = { -it / 6 }) + fadeOut(animationSpec = tween(250)))
                }
            },
            label = "SearchTransition",
            modifier = Modifier.fillMaxSize()
        ) { isBlank ->
            if (isBlank) {
                if (isLandscapeTablet && searchHistory.isNotEmpty()) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = horizontalPadding),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        LazyColumn(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight(),
                            contentPadding = PaddingValues(
                                top = statusBarsTop + 16.dp,
                                bottom = totalBottomPadding
                            ),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item(key = "history_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp, bottom = 8.dp)
                                        .animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = context.getString(R.string.search_recent_searches),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    TextButton(
                                        onClick = {
                                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                            localViewModel.clearSearchHistory()
                                        },
                                        colors = ButtonDefaults.textButtonColors(
                                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            contentColor = MaterialTheme.colorScheme.error
                                        ),
                                        shape = CircleShape,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(RhythmIcons.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Text(stringResource(R.string.ui_clear_all), style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
                                        }
                                    }
                                }
                            }
                            item(key = "history_list") {
                                val historyItems = searchHistory.take(8).map { item ->
                                    Material3SettingsItem(
                                        icon = MaterialSymbolIcon("history", filled = true),
                                        iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        iconBackgroundTint = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.16f),
                                        iconShape = RoundedCornerShape(12.dp),
                                        title = { Text(item, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                        scope = SettingScope.BOTH,
                                        trailingContent = {
                                            IconButton(
                                                onClick = {
                                                    HapticUtils.performHapticFeedback(context, haptics, HapticType.HEAVY)
                                                    localViewModel.removeSearchQuery(item)
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .background(MaterialTheme.colorScheme.surfaceContainerHighest, CircleShape)
                                            ) {
                                                Icon(MaterialSymbolIcon("clear", filled = true), contentDescription = stringResource(R.string.universalsearchscreen_remove_search), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                            }
                                        },
                                        onClick = {
                                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                            query = item
                                        }
                                    )
                                }
                                Box(modifier = Modifier.animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))) {
                                    Material3SettingsGroup(items = historyItems)
                                }
                            }
                        }

                        LazyColumn(
                            modifier = Modifier
                                .weight(1.2f)
                                .fillMaxHeight(),
                            contentPadding = PaddingValues(
                                top = statusBarsTop + 16.dp,
                                bottom = totalBottomPadding
                            ),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            item(key = "genre_browse") {
                                UniversalGenreBrowseSection(
                                    genres = genres,
                                    genreSongCounts = genreSongCounts,
                                    isGenreDetectionComplete = isGenreDetectionComplete,
                                    onGenreClick = { genre ->
                                        HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                        query = genre
                                    }
                                )
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = horizontalPadding),
                        contentPadding = PaddingValues(
                            top = statusBarsTop + 16.dp,
                            bottom = totalBottomPadding
                        ),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (searchHistory.isNotEmpty()) {
                            item(key = "history_header") {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(top = 8.dp, bottom = 8.dp)
                                        .animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = context.getString(R.string.search_recent_searches),
                                        style = MaterialTheme.typography.labelLarge,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    TextButton(
                                        onClick = {
                                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                            localViewModel.clearSearchHistory()
                                        },
                                        colors = ButtonDefaults.textButtonColors(
                                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                                            contentColor = MaterialTheme.colorScheme.error
                                        ),
                                        shape = CircleShape,
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        modifier = Modifier.height(32.dp)
                                    ) {
                                        Row(
                                            verticalAlignment = Alignment.CenterVertically,
                                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            Icon(RhythmIcons.Delete, contentDescription = null, modifier = Modifier.size(14.dp))
                                            Text(stringResource(R.string.ui_clear_all), style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.SemiBold))
                                        }
                                    }
                                }
                            }
                            item(key = "history_list") {
                                val historyItems = searchHistory.take(8).map { item ->
                                    Material3SettingsItem(
                                        icon = MaterialSymbolIcon("history", filled = true),
                                        iconTint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        iconBackgroundTint = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.16f),
                                        iconShape = RoundedCornerShape(12.dp),
                                        title = { Text(item, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                        scope = SettingScope.BOTH,
                                        trailingContent = {
                                            IconButton(
                                                onClick = {
                                                    HapticUtils.performHapticFeedback(context, haptics, HapticType.HEAVY)
                                                    localViewModel.removeSearchQuery(item)
                                                },
                                                modifier = Modifier
                                                    .size(32.dp)
                                                    .background(MaterialTheme.colorScheme.surfaceContainerHighest, CircleShape)
                                            ) {
                                                Icon(MaterialSymbolIcon("clear", filled = true), contentDescription = stringResource(R.string.universalsearchscreen_remove_search), tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f), modifier = Modifier.size(16.dp))
                                            }
                                        },
                                        onClick = {
                                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                            query = item
                                        }
                                    )
                                }
                                Box(modifier = Modifier.animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))) {
                                    Material3SettingsGroup(items = historyItems)
                                }
                            }
                        }

                        if (searchHistory.isEmpty()) {
                            item(key = "empty_prompt") {
                                val cookieShape = rememberExpressiveShape("COOKIE_12")
                                val smallCookieShape = rememberExpressiveShape("COOKIE_6")
                                val containerColor = MaterialTheme.colorScheme.secondaryContainer
                                val contentColor = MaterialTheme.colorScheme.onSecondaryContainer

                                Column(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 48.dp)
                                        .animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow)),
                                    horizontalAlignment = Alignment.CenterHorizontally,
                                    verticalArrangement = Arrangement.Center
                                ) {
                                    Box(
                                        modifier = Modifier.size(132.dp),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Surface(
                                            shape = smallCookieShape,
                                            color = containerColor.copy(alpha = 0.45f),
                                            modifier = Modifier
                                                .size(42.dp)
                                                .align(Alignment.TopStart)
                                                .offset(x = (-6).dp, y = 10.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                                Icon(
                                                    imageVector = RhythmIcons.MusicNote,
                                                    contentDescription = null,
                                                    tint = contentColor.copy(alpha = 0.55f),
                                                    modifier = Modifier.size(18.dp)
                                                )
                                            }
                                        }
                                        Surface(
                                            shape = smallCookieShape,
                                            color = containerColor.copy(alpha = 0.45f),
                                            modifier = Modifier
                                                .size(34.dp)
                                                .align(Alignment.BottomEnd)
                                                .offset(x = 8.dp, y = (-6).dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                                Icon(
                                                    imageVector = RhythmIcons.Tune,
                                                    contentDescription = null,
                                                    tint = contentColor.copy(alpha = 0.55f),
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }
                                        }
                                        Surface(
                                            shape = cookieShape,
                                            color = containerColor,
                                            shadowElevation = 6.dp,
                                            modifier = Modifier.size(96.dp)
                                        ) {
                                            Box(contentAlignment = Alignment.Center, modifier = Modifier.fillMaxSize()) {
                                                Icon(
                                                    imageVector = RhythmIcons.Search,
                                                    contentDescription = null,
                                                    tint = contentColor,
                                                    modifier = Modifier.size(44.dp)
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(20.dp))

                                    Text(
                                        text = stringResource(R.string.universalsearchscreen_search_across_local_streaming),
                                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.SemiBold),
                                        color = MaterialTheme.colorScheme.onSurface,
                                        textAlign = TextAlign.Center,
                                        modifier = Modifier.padding(horizontal = 32.dp)
                                    )
                                }
                            }
                        }

                        item(key = "genre_browse") {
                            UniversalGenreBrowseSection(
                                genres = genres,
                                genreSongCounts = genreSongCounts,
                                isGenreDetectionComplete = isGenreDetectionComplete,
                                onGenreClick = { genre ->
                                    HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                    query = genre
                                }
                            )
                        }
                    }
                }
            } else {
                if (!hasResults && !isStreamingLoading) {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = horizontalPadding),
                        contentPadding = PaddingValues(
                            top = statusBarsTop + 16.dp,
                            bottom = totalBottomPadding
                        ),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        item(key = "no_results") {
                            ExpressiveCookieEmptyState(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 48.dp)
                                    .animateItem(),
                                title = stringResource(R.string.no_results_found),
                                subtitle = stringResource(R.string.search_no_results_query_format, query),
                                mainIcon = RhythmIcons.Search,
                                accentIcon = RhythmIcons.Search,
                                cornerIcon = RhythmIcons.MusicNote,
                                containerColor = MaterialTheme.colorScheme.primaryContainer,
                                contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                    }
                } else if (isLandscapeTablet) {
                    Row(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = horizontalPadding),
                        horizontalArrangement = Arrangement.spacedBy(24.dp)
                    ) {
                        // Left Column (Songs + Playlists)
                        LazyColumn(
                            modifier = Modifier
                                .weight(1.1f)
                                .fillMaxHeight(),
                            contentPadding = PaddingValues(
                                top = statusBarsTop + 16.dp,
                                bottom = totalBottomPadding
                            ),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            if (isStreamingLoading && !hasResults) {
                                item(key = "loading_left") {
                                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp), contentAlignment = Alignment.Center) {
                                        M3CircularLoader(modifier = Modifier.size(48.dp), strokeWidth = 4f)
                                    }
                                }
                            } else {
                                val allSongs = buildList {
                                    matchedLocalSongs.take(3).forEach { song ->
                                        add(SongSearchItem("LOCAL", song.title, "${song.artist} • ${song.album}", song.artworkUri, song) {
                                            if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                            handleAction("LOCAL") { onLocalSongClick(song) }
                                        })
                                    }
                                    matchedStreamingSongs.take(3).forEach { song ->
                                        add(SongSearchItem("STREAMING", song.title, "${song.artist} • ${song.album}", song.artworkUri, song) {
                                            if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                            handleAction("STREAMING") { onStreamingSongClick(song) }
                                        })
                                    }
                                }

                                if (allSongs.isNotEmpty()) {
                                    item(key = "songs_group") {
                                        Column(
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
                                        ) {
                                            Text(
                                                text = stringResource(R.string.settings_tab_songs),
                                                style = MaterialTheme.typography.labelLarge,
                                                color = MaterialTheme.colorScheme.primary,
                                                modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
                                            )

                                            Column(
                                                modifier = Modifier.padding(horizontal = 4.dp),
                                                verticalArrangement = Arrangement.spacedBy(4.dp)
                                            ) {
                                                allSongs.forEachIndexed { index, item ->
                                                    UniversalSearchSongItem(
                                                        title = item.title,
                                                        subtitle = item.subtitle,
                                                        artworkUri = item.artworkUri,
                                                        mode = item.mode,
                                                        onClick = item.onClick,
                                                        onMoreClick = {
                                                            selectedSongForOptions = item.originalSong
                                                            showSongOptionsSheet = true
                                                        },
                                                        haptics = haptics,
                                                        index = index,
                                                        totalCount = allSongs.size
                                                    )
                                                }
                                            }

                                            val totalSongs = matchedLocalSongs.size + matchedStreamingSongs.size
                                            if (totalSongs > allSongs.size) {
                                                Spacer(modifier = Modifier.height(12.dp))
                                                Card(
                                                    colors = CardDefaults.cardColors(
                                                        containerColor = MaterialTheme.colorScheme.secondaryContainer
                                                    ),
                                                    shape = RoundedCornerShape(16.dp),
                                                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(horizontal = 4.dp)
                                                        .clickable {
                                                            HapticUtils.performHapticFeedback(context, haptics, HapticType.HEAVY)
                                                            showAllSongsPage = true
                                                        }
                                                ) {
                                                    Row(
                                                        modifier = Modifier
                                                            .fillMaxWidth()
                                                            .padding(16.dp),
                                                        horizontalArrangement = Arrangement.SpaceBetween,
                                                        verticalAlignment = Alignment.CenterVertically
                                                    ) {
                                                        Column {
                                                            Text(
                                                                text = context.getString(R.string.search_view_all_songs),
                                                                style = MaterialTheme.typography.titleMedium,
                                                                fontWeight = FontWeight.Medium,
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer
                                                            )
                                                            Text(
                                                                text = stringResource(R.string.search_view_all_count_format, totalSongs),
                                                                style = MaterialTheme.typography.bodyMedium,
                                                                color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                                            )
                                                        }
                                                        Icon(
                                                            imageVector = RhythmIcons.Back,
                                                            contentDescription = stringResource(R.string.cd_view_all),
                                                            tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                            modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = 180f }
                                                        )
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }

                                val allPlaylists = buildList {
                                    matchedLocalPlaylists.take(5).forEach { playlist ->
                                        add(Triple("LOCAL", playlist.name, "Local Playlist") to {
                                            if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                            handleAction("LOCAL") { onLocalPlaylistClick(playlist) }
                                        })
                                    }
                                    matchedStreamingPlaylists.take(5).forEach { playlist ->
                                        add(Triple("STREAMING", playlist.name, "Streaming Playlist") to {
                                            if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                            handleAction("STREAMING") { onStreamingPlaylistClick(playlist) }
                                        })
                                    }
                                }
                                if (allPlaylists.isNotEmpty()) {
                                    item(key = "playlists_group") {
                                        val playlistItems = allPlaylists.map { (info, action) ->
                                            val (mode, title, subtitle) = info
                                            Material3SettingsItem(
                                                icon = if (mode == "STREAMING") MaterialSymbolIcon("cloud", filled = true) else RhythmIcons.Playlist,
                                                scope = if (mode == "STREAMING") SettingScope.STREAMING else SettingScope.LOCAL,
                                                iconBackgroundTint = if (mode == "STREAMING") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                                                title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                                description = { Text(subtitle) },
                                                onClick = {
                                                    HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                                    action()
                                                }
                                            )
                                        }
                                        Box(modifier = Modifier.animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))) {
                                            Material3SettingsGroup(title = stringResource(R.string.settings_tab_playlists), items = playlistItems)
                                        }
                                    }
                                }
                            }
                        }

                        // Right Column (Albums + Artists)
                        LazyColumn(
                            modifier = Modifier
                                .weight(0.9f)
                                .fillMaxHeight(),
                            contentPadding = PaddingValues(
                                top = statusBarsTop + 16.dp,
                                bottom = totalBottomPadding
                            ),
                            verticalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            val allAlbums = buildList {
                                matchedLocalAlbums.take(6).forEach { album ->
                                    add(SearchGridItem("LOCAL", album.title, album.artist, album.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalAlbumClick(album) }
                                    })
                                }
                                matchedStreamingAlbums.take(6).forEach { album ->
                                    add(SearchGridItem("STREAMING", album.title, album.artist, album.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingAlbumClick(album) }
                                    })
                                }
                            }
                            if (allAlbums.isNotEmpty()) {
                                item(key = "albums_header") {
                                    Text(stringResource(R.string.settings_tab_albums), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp).animateItem())
                                }
                                item(key = "albums_grid") {
                                    val searchAlbumsRowState = rememberLazyListState()
                                    LazyRow(
                                        state = searchAlbumsRowState,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier
                                            .animateItem()
                                            .horizontalEdgeBlend(lazyListState = searchAlbumsRowState, fadeWidth = 12.dp)
                                    ) {
                                        items(allAlbums.size, key = { i -> "album_${allAlbums[i].title}_$i" }) { i ->
                                            SearchGridCard(item = allAlbums[i], haptics = haptics, context = context, isAlbum = true)
                                        }
                                    }
                                }
                            }

                            val allArtists = buildList {
                                matchedLocalArtists.take(6).forEach { artist ->
                                    add(SearchGridItem("LOCAL", artist.name, "${artist.numberOfTracks} tracks", artist.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalArtistClick(artist) }
                                    })
                                }
                                matchedStreamingArtists.take(6).forEach { artist ->
                                    add(SearchGridItem("STREAMING", artist.name, "Streaming Artist", artist.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingArtistClick(artist) }
                                    })
                                }
                            }
                            if (allArtists.isNotEmpty()) {
                                item(key = "artists_header") {
                                    Text(stringResource(R.string.settings_tab_artists), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp).animateItem())
                                }
                                item(key = "artists_grid") {
                                    val searchArtistsRowState = rememberLazyListState()
                                    LazyRow(
                                        state = searchArtistsRowState,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier
                                            .animateItem()
                                            .horizontalEdgeBlend(lazyListState = searchArtistsRowState, fadeWidth = 12.dp)
                                    ) {
                                        items(allArtists.size, key = { i -> "artist_${allArtists[i].title}_$i" }) { i ->
                                            SearchGridCard(item = allArtists[i], haptics = haptics, context = context, isAlbum = false)
                                        }
                                    }
                                }
                            }

                            if (isStreamingLoading) {
                                item(key = "streaming_loading_right") {
                                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp).animateItem(), contentAlignment = Alignment.Center) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                            M3CircularLoader(modifier = Modifier.size(20.dp), strokeWidth = 2.5f)
                                            Text(stringResource(R.string.universalsearchscreen_loading_streaming_results), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(horizontal = horizontalPadding),
                        contentPadding = PaddingValues(
                            top = statusBarsTop + 16.dp,
                            bottom = totalBottomPadding
                        ),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        if (isStreamingLoading && !hasResults) {
                            item(key = "loading") {
                                Box(modifier = Modifier.fillMaxWidth().padding(vertical = 48.dp).animateItem(), contentAlignment = Alignment.Center) {
                                    M3CircularLoader(modifier = Modifier.size(48.dp), strokeWidth = 4f)
                                }
                            }
                        } else {
                            val allSongs = buildList {
                                matchedLocalSongs.take(3).forEach { song ->
                                    add(SongSearchItem("LOCAL", song.title, "${song.artist} • ${song.album}", song.artworkUri, song) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalSongClick(song) }
                                    })
                                }
                                matchedStreamingSongs.take(3).forEach { song ->
                                    add(SongSearchItem("STREAMING", song.title, "${song.artist} • ${song.album}", song.artworkUri, song) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingSongClick(song) }
                                    })
                                }
                            }

                            if (allSongs.isNotEmpty()) {
                                item(key = "songs_group") {
                                    Column(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))
                                    ) {
                                        Text(
                                            text = stringResource(R.string.settings_tab_songs),
                                            style = MaterialTheme.typography.labelLarge,
                                            color = MaterialTheme.colorScheme.primary,
                                            modifier = Modifier.padding(top = 8.dp, bottom = 8.dp)
                                        )

                                        Column(
                                            modifier = Modifier.padding(horizontal = 4.dp),
                                            verticalArrangement = Arrangement.spacedBy(4.dp)
                                        ) {
                                            allSongs.forEachIndexed { index, item ->
                                                UniversalSearchSongItem(
                                                    title = item.title,
                                                    subtitle = item.subtitle,
                                                    artworkUri = item.artworkUri,
                                                    mode = item.mode,
                                                    onClick = item.onClick,
                                                    onMoreClick = {
                                                        selectedSongForOptions = item.originalSong
                                                        showSongOptionsSheet = true
                                                    },
                                                    haptics = haptics,
                                                    index = index,
                                                    totalCount = allSongs.size
                                                )
                                            }
                                        }

                                        val totalSongs = matchedLocalSongs.size + matchedStreamingSongs.size
                                        if (totalSongs > allSongs.size) {
                                            Spacer(modifier = Modifier.height(12.dp))
                                            Card(
                                                colors = CardDefaults.cardColors(
                                                    containerColor = MaterialTheme.colorScheme.secondaryContainer
                                                ),
                                                shape = RoundedCornerShape(16.dp),
                                                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
                                                modifier = Modifier
                                                    .fillMaxWidth()
                                                    .padding(horizontal = 4.dp)
                                                    .clickable {
                                                        HapticUtils.performHapticFeedback(context, haptics, HapticType.HEAVY)
                                                        showAllSongsPage = true
                                                    }
                                            ) {
                                                Row(
                                                    modifier = Modifier
                                                        .fillMaxWidth()
                                                        .padding(16.dp),
                                                    horizontalArrangement = Arrangement.SpaceBetween,
                                                    verticalAlignment = Alignment.CenterVertically
                                                ) {
                                                    Column {
                                                        Text(
                                                            text = context.getString(R.string.search_view_all_songs),
                                                            style = MaterialTheme.typography.titleMedium,
                                                            fontWeight = FontWeight.Medium,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer
                                                        )
                                                        Text(
                                                            text = stringResource(R.string.search_view_all_count_format, totalSongs),
                                                            style = MaterialTheme.typography.bodyMedium,
                                                            color = MaterialTheme.colorScheme.onSecondaryContainer.copy(alpha = 0.8f)
                                                        )
                                                    }
                                                    Icon(
                                                        imageVector = RhythmIcons.Back,
                                                        contentDescription = stringResource(R.string.cd_view_all),
                                                        tint = MaterialTheme.colorScheme.onSecondaryContainer,
                                                        modifier = Modifier.size(24.dp).graphicsLayer { rotationZ = 180f }
                                                    )
                                                }
                                            }
                                        }
                                    }
                                }
                            }

                            val allAlbums = buildList {
                                matchedLocalAlbums.take(6).forEach { album ->
                                    add(SearchGridItem("LOCAL", album.title, album.artist, album.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalAlbumClick(album) }
                                    })
                                }
                                matchedStreamingAlbums.take(6).forEach { album ->
                                    add(SearchGridItem("STREAMING", album.title, album.artist, album.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingAlbumClick(album) }
                                    })
                                }
                            }
                            if (allAlbums.isNotEmpty()) {
                                item(key = "albums_header") {
                                    Text(stringResource(R.string.settings_tab_albums), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp).animateItem())
                                }
                                item(key = "albums_grid") {
                                    val searchAlbumsRowState = rememberLazyListState()
                                    LazyRow(
                                        state = searchAlbumsRowState,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier
                                            .animateItem()
                                            .horizontalEdgeBlend(lazyListState = searchAlbumsRowState, fadeWidth = 12.dp)
                                    ) {
                                        items(allAlbums.size, key = { i -> "album_${allAlbums[i].title}_$i" }) { i ->
                                            SearchGridCard(item = allAlbums[i], haptics = haptics, context = context, isAlbum = true)
                                        }
                                    }
                                }
                            }

                            val allArtists = buildList {
                                matchedLocalArtists.take(6).forEach { artist ->
                                    add(SearchGridItem("LOCAL", artist.name, "${artist.numberOfTracks} tracks", artist.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalArtistClick(artist) }
                                    })
                                }
                                matchedStreamingArtists.take(6).forEach { artist ->
                                    add(SearchGridItem("STREAMING", artist.name, "Streaming Artist", artist.artworkUri) {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingArtistClick(artist) }
                                    })
                                }
                            }
                            if (allArtists.isNotEmpty()) {
                                item(key = "artists_header") {
                                    Text(stringResource(R.string.settings_tab_artists), style = MaterialTheme.typography.labelLarge, color = MaterialTheme.colorScheme.primary, modifier = Modifier.padding(top = 8.dp).animateItem())
                                }
                                item(key = "artists_grid") {
                                    val searchArtistsRowState = rememberLazyListState()
                                    LazyRow(
                                        state = searchArtistsRowState,
                                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                                        modifier = Modifier
                                            .animateItem()
                                            .horizontalEdgeBlend(lazyListState = searchArtistsRowState, fadeWidth = 12.dp)
                                    ) {
                                        items(allArtists.size, key = { i -> "artist_${allArtists[i].title}_$i" }) { i ->
                                            SearchGridCard(item = allArtists[i], haptics = haptics, context = context, isAlbum = false)
                                        }
                                    }
                                }
                            }

                            val allPlaylists = buildList {
                                matchedLocalPlaylists.take(5).forEach { playlist ->
                                    add(Triple("LOCAL", playlist.name, "Local Playlist") to {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("LOCAL") { onLocalPlaylistClick(playlist) }
                                    })
                                }
                                matchedStreamingPlaylists.take(5).forEach { playlist ->
                                    add(Triple("STREAMING", playlist.name, "Streaming Playlist") to {
                                        if (query.isNotBlank()) localViewModel.addSearchQuery(query)
                                        handleAction("STREAMING") { onStreamingPlaylistClick(playlist) }
                                    })
                                }
                            }
                            if (allPlaylists.isNotEmpty()) {
                                item(key = "playlists_group") {
                                    val playlistItems = allPlaylists.map { (info, action) ->
                                        val (mode, title, subtitle) = info
                                        Material3SettingsItem(
                                            icon = if (mode == "STREAMING") MaterialSymbolIcon("cloud", filled = true) else RhythmIcons.Playlist,
                                            scope = if (mode == "STREAMING") SettingScope.STREAMING else SettingScope.LOCAL,
                                            iconBackgroundTint = if (mode == "STREAMING") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer,
                                            title = { Text(title, maxLines = 1, overflow = TextOverflow.Ellipsis) },
                                            description = { Text(subtitle) },
                                            onClick = {
                                                HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                                action()
                                            }
                                        )
                                    }
                                    Box(modifier = Modifier.animateItem(spring(dampingRatio = Spring.DampingRatioMediumBouncy, stiffness = Spring.StiffnessLow))) {
                                        Material3SettingsGroup(title = stringResource(R.string.settings_tab_playlists), items = playlistItems)
                                    }
                                }
                            }

                            if (isStreamingLoading) {
                                item(key = "streaming_loading") {
                                    Box(modifier = Modifier.fillMaxWidth().padding(vertical = 16.dp).animateItem(), contentAlignment = Alignment.Center) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                                            M3CircularLoader(modifier = Modifier.size(20.dp), strokeWidth = 2.5f)
                                            Text(stringResource(R.string.universalsearchscreen_loading_streaming_results), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Bottom Search Bar & Controls Area
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .align(Alignment.BottomCenter)
                .background(
                    brush = Brush.verticalGradient(
                        colorStops = arrayOf(
                            0f to Color.Transparent,
                            0.18f to MaterialTheme.colorScheme.background.copy(alpha = 0.93f),
                            1f to MaterialTheme.colorScheme.background
                        )
                    )
                )
                .navigationBarsPadding()
                .imePadding()
        ) {
        Column(
            modifier = Modifier
                .then(
                    if (isTablet) {
                        Modifier.widthIn(max = 680.dp).align(Alignment.BottomCenter)
                    } else {
                        Modifier.fillMaxWidth()
                    }
                )
                .padding(horizontal = horizontalPadding)
                .padding(top = 16.dp, bottom = 12.dp)
                .animateContentSize(spring(dampingRatio = Spring.DampingRatioNoBouncy, stiffness = Spring.StiffnessMedium))
                .align(Alignment.BottomCenter)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    shape = CircleShape,
                    color = MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    IconButton(onClick = handleBack) {
                        Icon(
                            RhythmIcons.Back,
                            contentDescription = stringResource(R.string.cd_back),
                            tint = MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                }

                Card(
                    modifier = Modifier.weight(1f).height(52.dp),
                    shape = CircleShape,
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceContainerHighest)
                ) {
                    Row(
                        modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(RhythmIcons.Search, contentDescription = null, modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                        Spacer(modifier = Modifier.width(8.dp))
                        BasicTextField(
                            value = query,
                            onValueChange = { query = it },
                            modifier = Modifier.weight(1f).focusRequester(focusRequester),
                            textStyle = TextStyle(color = MaterialTheme.colorScheme.onSurface, fontSize = 16.sp, fontWeight = FontWeight.Medium),
                            singleLine = true,
                            cursorBrush = SolidColor(MaterialTheme.colorScheme.primary),
                            decorationBox = { innerTextField ->
                                Box(contentAlignment = Alignment.CenterStart) {
                                    if (query.isEmpty()) {
                                        Text(stringResource(R.string.universalsearchscreen_search_everywhere), style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }
                                    innerTextField()
                                }
                            }
                        )
                        if (query.isNotEmpty()) {
                            IconButton(onClick = {
                                HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                                query = ""
                            }, modifier = Modifier.size(32.dp)) {
                                Icon(MaterialSymbolIcon("clear", filled = true), contentDescription = stringResource(R.string.ui_clear), modifier = Modifier.size(18.dp), tint = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                Surface(
                    shape = CircleShape,
                    color = if (showFilters) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surfaceContainerHigh
                ) {
                    IconButton(onClick = {
                        HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                        showFilters = !showFilters
                    }) {
                        Icon(
                            RhythmIcons.FilterList,
                            contentDescription = stringResource(R.string.cd_filters),
                            tint = if (showFilters) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface,
                            modifier = Modifier.size(25.dp)
                        )
                    }
                }
            }

            AnimatedVisibility(
                visible = showFilters,
                enter = expandVertically() + fadeIn(),
                exit = shrinkVertically() + fadeOut()
            ) {
                val filterChipsScrollState = rememberScrollState()
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(filterChipsScrollState)
                        .padding(top = 12.dp)
                        .horizontalEdgeBlend(scrollState = filterChipsScrollState, fadeWidth = 16.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val songsCornerRadius by animateDpAsState(
                        targetValue = if (filterSongs) 24.dp else 12.dp,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "songsCornerRadius"
                    )
                    FilterChip(
                        selected = filterSongs,
                        onClick = {
                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                            filterSongs = !filterSongs
                        },
                        label = { Text(stringResource(R.string.settings_tab_songs), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold) },
                        leadingIcon = if (filterSongs) {
                            {
                                Icon(
                                    imageVector = RhythmIcons.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                                )
                            }
                        } else null,
                        shape = RoundedCornerShape(songsCornerRadius),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        border = null
                    )
                    val albumsCornerRadius by animateDpAsState(
                        targetValue = if (filterAlbums) 24.dp else 12.dp,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "albumsCornerRadius"
                    )
                    FilterChip(
                        selected = filterAlbums,
                        onClick = {
                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                            filterAlbums = !filterAlbums
                        },
                        label = { Text(stringResource(R.string.settings_tab_albums), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold) },
                        leadingIcon = if (filterAlbums) {
                            {
                                Icon(
                                    imageVector = RhythmIcons.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                                )
                            }
                        } else null,
                        shape = RoundedCornerShape(albumsCornerRadius),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        border = null
                    )
                    val artistsCornerRadius by animateDpAsState(
                        targetValue = if (filterArtists) 24.dp else 12.dp,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "artistsCornerRadius"
                    )
                    FilterChip(
                        selected = filterArtists,
                        onClick = {
                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                            filterArtists = !filterArtists
                        },
                        label = { Text(stringResource(R.string.settings_tab_artists), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold) },
                        leadingIcon = if (filterArtists) {
                            {
                                Icon(
                                    imageVector = RhythmIcons.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                                )
                            }
                        } else null,
                        shape = RoundedCornerShape(artistsCornerRadius),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        border = null
                    )
                    val playlistsCornerRadius by animateDpAsState(
                        targetValue = if (filterPlaylists) 24.dp else 12.dp,
                        animationSpec = spring(dampingRatio = Spring.DampingRatioMediumBouncy),
                        label = "playlistsCornerRadius"
                    )
                    FilterChip(
                        selected = filterPlaylists,
                        onClick = {
                            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
                            filterPlaylists = !filterPlaylists
                        },
                        label = { Text(stringResource(R.string.settings_tab_playlists), style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.Bold) },
                        leadingIcon = if (filterPlaylists) {
                            {
                                Icon(
                                    imageVector = RhythmIcons.Check,
                                    contentDescription = null,
                                    modifier = Modifier.size(FilterChipDefaults.IconSize)
                                )
                            }
                        } else null,
                        shape = RoundedCornerShape(playlistsCornerRadius),
                        colors = FilterChipDefaults.filterChipColors(
                            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh,
                            selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                            labelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            iconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                            selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
                            selectedLeadingIconColor = MaterialTheme.colorScheme.onPrimaryContainer
                        ),
                        border = null
                    )
                }
            }
        }
    }

        AnimatedVisibility(
            visible = showAllSongsPage,
            enter = fadeIn(animationSpec = tween(300)) + slideInVertically(
                initialOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            ),
            exit = fadeOut(animationSpec = tween(250)) + slideOutVertically(
                targetOffsetY = { it },
                animationSpec = spring(
                    dampingRatio = Spring.DampingRatioNoBouncy,
                    stiffness = Spring.StiffnessMedium
                )
            )
        ) {
            UniversalAllSongsPage(
                localSongs = matchedLocalSongs,
                streamingSongs = matchedStreamingSongs,
                onBack = { showAllSongsPage = false },
                onOptionsClick = { songObj ->
                    selectedSongForOptions = songObj
                    showSongOptionsSheet = true
                },
                onLocalSongClick = { song -> handleAction("LOCAL") { onLocalSongClick(song) } },
                onStreamingSongClick = { song -> handleAction("STREAMING") { onStreamingSongClick(song) } },
                haptics = haptics
            )
        }

        if (showSongOptionsSheet && selectedSongForOptions != null) {
            val songObj = selectedSongForOptions!!
            val localSong = songObj as? Song
            val streamingSong = songObj as? StreamingSong
            val isLocal = localSong != null
            val targetSong = remember(songObj) {
                localSong ?: streamingSong!!.toLocalSong()
            }
            val isFavorite = if (localSong != null) {
                favoriteSongs.contains(localSong.id)
            } else {
                streamingLikedSongs.any { it.id == streamingSong?.id }
            }

            SongOverflowBottomSheet(
                song = targetSong,
                onDismiss = { showSongOptionsSheet = false },
                onPlay = {
                    handleAction(if (isLocal) "LOCAL" else "STREAMING") {
                        if (localSong != null) {
                            onLocalSongClick(localSong)
                        } else if (streamingSong != null) {
                            onStreamingSongClick(streamingSong)
                        }
                    }
                    showSongOptionsSheet = false
                },
                onPlayNext = {
                    handleAction(if (isLocal) "LOCAL" else "STREAMING") {
                        if (localSong != null) {
                            localViewModel.playNext(localSong)
                        } else if (streamingSong != null) {
                            streamingViewModel.playNext(streamingSong, localViewModel)
                        }
                    }
                    showSongOptionsSheet = false
                },
                onAddToQueue = {
                    handleAction(if (isLocal) "LOCAL" else "STREAMING") {
                        if (localSong != null) {
                            localViewModel.addSongToQueue(localSong)
                        } else if (streamingSong != null) {
                            streamingViewModel.addSongToQueue(streamingSong, localViewModel)
                        }
                    }
                    showSongOptionsSheet = false
                },
                onAddToPlaylist = {
                    selectedSongForPlaylist = localSong ?: streamingSong?.toLocalSong()
                    showAddToPlaylistSheet = true
                    showSongOptionsSheet = false
                },
                onToggleFavorite = {
                    if (localSong != null) {
                        localViewModel.toggleFavorite(localSong)
                    } else if (streamingSong != null) {
                        val isCurrentlyLiked = streamingLikedSongs.any { it.id == streamingSong.id }
                        if (isCurrentlyLiked) {
                            streamingViewModel.unlikeSong(streamingSong)
                            Toast.makeText(context, R.string.universalsearchscreen_removed_from_streaming_favorites, Toast.LENGTH_SHORT).show()
                        } else {
                            streamingViewModel.likeSong(streamingSong)
                            Toast.makeText(context, R.string.universalsearchscreen_added_to_streaming_favorites, Toast.LENGTH_SHORT).show()
                        }
                    }
                    showSongOptionsSheet = false
                },
                isFavorite = isFavorite,
                onShowSongInfo = {
                    selectedSongForInfo = targetSong
                    isSongInfoStreaming = !isLocal
                    showSongInfoInEditMode = false
                    showSongInfoSheet = true
                    showSongOptionsSheet = false
                },
                onEditSong = if (localSong != null) {
                    {
                        selectedSongForInfo = targetSong
                        isSongInfoStreaming = false
                        showSongInfoInEditMode = true
                        showSongInfoSheet = true
                        showSongOptionsSheet = false
                    }
                } else null,
                onGoToAlbum = {
                    showSongOptionsSheet = false
                    if (localSong != null) {
                        val allLocalAlbums = localViewModel.albums.value.ifEmpty { localViewModel.filteredAlbums.value }
                        val album = allLocalAlbums.findAlbumForSong(localSong)
                            ?: localSong.album.trim().takeIf { it.isNotBlank() }?.let { albumTitle ->
                                Album(
                                    id = localSong.albumId.ifBlank { "unknown_$albumTitle" },
                                    title = albumTitle,
                                    artist = localSong.albumArtist?.takeIf { it.isNotBlank() } ?: localSong.artist,
                                    artworkUri = localSong.artworkUri
                                )
                            }
                        if (album != null) {
                            handleAction("LOCAL") { onLocalAlbumClick(album) }
                        } else Toast.makeText(context, R.string.universalsearchscreen_album_not_found, Toast.LENGTH_SHORT).show()
                    } else if (streamingSong != null) {
                        if (streamingSong.albumId != null) {
                            val streamingAlbum = StreamingAlbum(
                                id = streamingSong.albumId,
                                title = streamingSong.album,
                                artist = streamingSong.artist,
                                artworkUri = streamingSong.artworkUri,
                                songCount = 0,
                                year = null,
                                sourceType = streamingSong.sourceType
                            )
                            handleAction("STREAMING") { onStreamingAlbumClick(streamingAlbum) }
                        } else {
                            Toast.makeText(context, R.string.universalsearchscreen_album_not_found, Toast.LENGTH_SHORT).show()
                        }
                    }
                },
                onGoToArtist = {
                    showSongOptionsSheet = false
                    if (localSong != null) {
                        val separatorEnabled = appSettings.artistSeparatorEnabled.value
                        val delimiters = appSettings.artistSeparatorDelimiters.value.ifBlank { AppSettings.DEFAULT_ARTIST_SEPARATOR_DELIMITERS }
                        val songArtistNames = app.needle.player.util.ArtistSeparator.splitArtistNames(
                            artistName = localSong.artist,
                            delimiters = delimiters,
                            enabled = separatorEnabled
                        )
                        val artist = songArtistNames.firstNotNullOfOrNull { name ->
                            localArtists.find { it.name.equals(name, ignoreCase = true) }
                        } ?: songArtistNames.firstOrNull()?.trim()?.takeIf { it.isNotBlank() }?.let { name ->
                            Artist(id = name, name = name)
                        } ?: localSong.artist.trim().takeIf { it.isNotBlank() }?.let { name ->
                            Artist(id = name, name = name)
                        }
                        if (artist != null) {
                            handleAction("LOCAL") { onLocalArtistClick(artist) }
                        } else Toast.makeText(context, R.string.universalsearchscreen_artist_not_found, Toast.LENGTH_SHORT).show()
                    } else if (streamingSong != null) {
                        val streamingArtist = StreamingArtist(
                            id = streamingSong.albumArtist ?: streamingSong.artist,
                            name = streamingSong.artist,
                            artworkUri = streamingSong.artworkUri,
                            songCount = 0,
                            albumCount = 0,
                            sourceType = streamingSong.sourceType
                        )
                        handleAction("STREAMING") { onStreamingArtistClick(streamingArtist) }
                    }
                },
                onAddToBlacklist = if (localSong != null) {
                    {
                        handleAction("LOCAL") {
                            appSettings.addToBlacklist(localSong.id)
                            Toast.makeText(context, context.getString(R.string.song_added_to_blacklist_format, localSong.title), Toast.LENGTH_SHORT).show()
                        }
                        showSongOptionsSheet = false
                    }
                } else null,
                onDeleteSong = if (localSong != null) {
                    {
                        handleAction("LOCAL") {
                            localViewModel.deleteSong(localSong)
                        }
                        showSongOptionsSheet = false
                    }
                } else null,
                isStreaming = !isLocal
            )
        }

        if (showAddToPlaylistSheet && selectedSongForPlaylist != null) {
            AddToPlaylistBottomSheet(
                song = selectedSongForPlaylist!!,
                playlists = localPlaylists,
                onDismissRequest = { showAddToPlaylistSheet = false },
                onAddToPlaylist = { playlist ->
                    localViewModel.addSongToPlaylist(selectedSongForPlaylist!!, playlist.id) { msg ->
                        Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                    }
                    showAddToPlaylistSheet = false
                },
                onCreateNewPlaylist = {
                    showAddToPlaylistSheet = false
                    showCreatePlaylistDialog = true
                }
            )
        }

        if (showSongInfoSheet && selectedSongForInfo != null) {
            SongInfoBottomSheet(
                song = selectedSongForInfo,
                onDismiss = {
                    showSongInfoSheet = false
                    showSongInfoInEditMode = false
                },
                startInEditMode = showSongInfoInEditMode,
                appSettings = appSettings,
                isStreamingMode = isSongInfoStreaming,
                onEditSong = { title, artist, album, genre, year, trackNumber, artworkUri, removeArtwork, albumArtist, composer, discNumber, onComplete ->
                    pendingMetadataEditCompleteCallback = onComplete
                    try {
                        localViewModel.saveMetadataChanges(
                            song = selectedSongForInfo!!,
                            title = title,
                            artist = artist,
                            album = album,
                            genre = genre,
                            year = year,
                            trackNumber = trackNumber,
                            artworkUri = artworkUri,
                            removeArtwork = removeArtwork,
                            albumArtist = albumArtist,
                            composer = composer,
                            discNumber = discNumber,
                            onSuccess = { fileWriteSucceeded ->
                                if (fileWriteSucceeded) {
                                    Toast.makeText(context, R.string.localnavigation_metadata_saved_successfully_to, Toast.LENGTH_SHORT).show()
                                }
                                pendingMetadataEditCompleteCallback?.invoke(true)
                                pendingMetadataEditCompleteCallback = null
                            },
                            onError = { errorMessage ->
                                Toast.makeText(context, errorMessage, Toast.LENGTH_LONG).show()
                                pendingMetadataEditCompleteCallback?.invoke(false)
                                pendingMetadataEditCompleteCallback = null
                            },
                            onPermissionRequired = { pendingRequest ->
                                try {
                                    val intentSenderRequest = androidx.activity.result.IntentSenderRequest.Builder(
                                        pendingRequest.intentSender
                                    ).build()
                                    writePermissionLauncher.launch(intentSenderRequest)
                                } catch (e: Exception) {
                                    Toast.makeText(context, context.getString(R.string.failed_to_request_permission, e.message ?: ""), Toast.LENGTH_LONG).show()
                                    localViewModel.cancelPendingMetadataWrite()
                                    pendingMetadataEditCompleteCallback?.invoke(false)
                                    pendingMetadataEditCompleteCallback = null
                                }
                            }
                        )
                    } catch (e: Exception) {
                        Toast.makeText(context, context.getString(R.string.unexpected_error, e.message ?: ""), Toast.LENGTH_LONG).show()
                        android.util.Log.w("UniversalSearchScreen", "Metadata update failed for song: ${selectedSongForInfo!!.title}", e)
                        pendingMetadataEditCompleteCallback?.invoke(false)
                        pendingMetadataEditCompleteCallback = null
                    }
                },
                onShowLyricsEditor = { }
            )
        }

        if (showCreatePlaylistDialog) {
            CreatePlaylistDialog(
                onDismiss = { showCreatePlaylistDialog = false },
                song = selectedSongForPlaylist,
                onConfirm = { name ->
                    localViewModel.createPlaylist(name)
                    showCreatePlaylistDialog = false
                },
                onConfirmWithSong = { name ->
                    selectedSongForPlaylist?.let { song ->
                        localViewModel.createPlaylist(name, listOf(song)) { msg ->
                            Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
                        }
                    } ?: run {
                        localViewModel.createPlaylist(name)
                    }
                    showCreatePlaylistDialog = false
                }
            )
        }
    }
}

private fun StreamingSong.toLocalSong(): Song {
    return Song(
        id = this.id,
        title = this.title,
        artist = this.artist,
        album = this.album,
        albumId = this.albumId ?: "",
        duration = this.duration,
        uri = (this.streamingUrl ?: this.previewUrl ?: "").toUri(),
        artworkUri = this.artworkUri?.let { (it).toUri() },
        trackNumber = 0,
        year = 0,
        genre = null,
        albumArtist = this.albumArtist
    )
}

data class SearchGridItem(
    val mode: String,
    val title: String,
    val subtitle: String,
    val artworkUrl: Any?,
    val onClick: () -> Unit
)

data class SongSearchItem(
    val mode: String,
    val title: String,
    val subtitle: String,
    val artworkUri: Any?,
    val originalSong: Any,
    val onClick: () -> Unit
)

private fun groupedSongItemShape(index: Int, totalCount: Int): RoundedCornerShape {
    return when {
        totalCount <= 1 -> RoundedCornerShape(24.dp)
        index == 0 -> RoundedCornerShape(
            topStart = 24.dp,
            topEnd = 24.dp,
            bottomStart = 6.dp,
            bottomEnd = 6.dp
        )
        index == totalCount - 1 -> RoundedCornerShape(
            topStart = 6.dp,
            topEnd = 6.dp,
            bottomStart = 24.dp,
            bottomEnd = 24.dp
        )
        else -> RoundedCornerShape(6.dp)
    }
}

@Composable
fun UniversalSearchSongItem(
    title: String,
    subtitle: String,
    artworkUri: Any?,
    mode: String,
    onClick: () -> Unit,
    onMoreClick: () -> Unit,
    haptics: androidx.compose.ui.hapticfeedback.HapticFeedback,
    index: Int = 0,
    totalCount: Int = 1
) {
    val context = LocalContext.current
    Card(
        onClick = {
            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
            onClick()
        },
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainerHigh
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = groupedSongItemShape(index, totalCount),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            M3ImageUtils.TrackImage(
                imageUrl = artworkUri,
                trackName = title,
                modifier = Modifier.size(48.dp),
                applyExpressiveShape = true
            )

            Column(
                modifier = Modifier
                    .weight(1f)
                    .padding(horizontal = 12.dp)
            ) {
                Text(
                    text = title,
                    style = MaterialTheme.typography.bodyLarge,
                    fontWeight = FontWeight.Medium,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis,
                    color = MaterialTheme.colorScheme.onSurface
                )

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = subtitle,
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )

                Spacer(modifier = Modifier.height(4.dp))

                Surface(
                    color = if (mode == "STREAMING")
                        MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.16f)
                    else
                        MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.16f),
                    shape = RoundedCornerShape(999.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        Icon(
                            imageVector = if (mode == "STREAMING") MaterialSymbolIcon("cloud", filled = true) else RhythmIcons.Folder,
                            contentDescription = null,
                            modifier = Modifier.size(12.dp),
                            tint = if (mode == "STREAMING")
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.secondary
                        )
                        Text(
                            text = if (mode == "STREAMING") "Streaming" else "Local",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                            color = if (mode == "STREAMING")
                                MaterialTheme.colorScheme.primary
                            else
                                MaterialTheme.colorScheme.secondary
                        )
                    }
                }
            }

            FilledIconButton(
                onClick = {
                    HapticUtils.performHapticFeedback(context, haptics, HapticType.HEAVY)
                    onMoreClick()
                },
                modifier = Modifier
                    .width(32.dp)
                    .height(44.dp),
                shape = RoundedCornerShape(50),
                colors = IconButtonDefaults.filledIconButtonColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer,
                    contentColor = MaterialTheme.colorScheme.onPrimaryContainer
                )
            ) {
                Icon(
                    imageVector = RhythmIcons.More,
                    contentDescription = stringResource(R.string.content_desc_more_options),
                    modifier = Modifier.size(22.dp)
                )
            }
        }
    }
}

@Composable
private fun SearchGridCard(
    item: SearchGridItem,
    haptics: androidx.compose.ui.hapticfeedback.HapticFeedback,
    context: android.content.Context,
    isAlbum: Boolean,
    modifier: Modifier = Modifier
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.92f else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessLow
        ),
        label = "grid_card_scale"
    )

    val expressiveShape = RoundedCornerShape(
        topStart = 28.dp,
        topEnd = 8.dp,
        bottomEnd = 28.dp,
        bottomStart = 8.dp
    )

    Card(
        onClick = {
            HapticUtils.performHapticFeedback(context, haptics, HapticType.LIGHT)
            item.onClick()
        },
        modifier = modifier
            .width(if (isAlbum) 160.dp else 140.dp)
            .graphicsLayer {
                scaleX = scale
                scaleY = scale
            },
        shape = expressiveShape,
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceContainer
        ),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 0.dp,
            pressedElevation = 0.dp
        ),
        interactionSource = interactionSource
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            if (isAlbum) {
                M3ImageUtils.AlbumArt(
                    imageUrl = item.artworkUrl,
                    albumName = item.title,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1f),
                    applyExpressiveShape = true
                )
            } else {
                M3ImageUtils.ArtistImage(
                    imageUrl = item.artworkUrl,
                    artistName = item.title,
                    modifier = Modifier
                        .size(120.dp),
                    applyExpressiveShape = true
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = item.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.SemiBold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = item.subtitle,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(6.dp))

            Surface(
                color = if (item.mode == "STREAMING")
                    MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.16f)
                else
                    MaterialTheme.colorScheme.secondaryContainer.copy(alpha = 0.16f),
                shape = RoundedCornerShape(999.dp),
                modifier = Modifier.align(Alignment.Start)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Icon(
                        imageVector = if (item.mode == "STREAMING") MaterialSymbolIcon("cloud", filled = true) else RhythmIcons.Folder,
                        contentDescription = null,
                        modifier = Modifier.size(12.dp),
                        tint = if (item.mode == "STREAMING")
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.secondary
                    )
                    Text(
                        text = if (item.mode == "STREAMING") "Streaming" else "Local",
                        style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, fontWeight = FontWeight.Bold),
                        color = if (item.mode == "STREAMING")
                            MaterialTheme.colorScheme.primary
                        else
                            MaterialTheme.colorScheme.secondary
                    )
                }
            }
        }
    }
}


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UniversalAllSongsPage(
    localSongs: List<Song>,
    streamingSongs: List<StreamingSong>,
    onBack: () -> Unit,
    onOptionsClick: (Any) -> Unit,
    onLocalSongClick: (Song) -> Unit,
    onStreamingSongClick: (StreamingSong) -> Unit,
    haptics: androidx.compose.ui.hapticfeedback.HapticFeedback
) {
    val context = LocalContext.current
    val allSongs = buildList {
        localSongs.forEach { add(it to "LOCAL") }
        streamingSongs.forEach { add(it to "STREAMING") }
    }

    val miniPlayerBottomPadding = LocalMiniPlayerPadding.current.calculateBottomPadding()
    val contentBottomPadding = (miniPlayerBottomPadding + 20.dp).coerceAtLeast(96.dp)
    val isTablet = windowScreenWidthDp() >= 600
    val horizontalPadding = if (isTablet) 32.dp else 24.dp

    CollapsibleHeaderScreen(
        title = stringResource(R.string.settings_tab_songs),
        showBackButton = true,
        onBackClick = onBack,
        containerColor = MaterialTheme.colorScheme.background
    ) { modifier ->
        LazyColumn(
            modifier = modifier,
            contentPadding = PaddingValues(
                start = horizontalPadding,
                end = horizontalPadding,
                top = 12.dp,
                bottom = contentBottomPadding
            ),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            item(key = "header_spacer") {
                Spacer(modifier = Modifier.height(16.dp))
            }
            itemsIndexed(
                items = allSongs,
                key = { index, _ -> "song_$index" }
            ) { index, item ->
                val isLocal = item.second == "LOCAL"
                val title = if (isLocal) (item.first as Song).title else (item.first as StreamingSong).title
                val artist = if (isLocal) (item.first as Song).artist else (item.first as StreamingSong).artist
                val album = if (isLocal) (item.first as Song).album else (item.first as StreamingSong).album
                val artworkUri = if (isLocal) (item.first as Song).artworkUri else (item.first as StreamingSong).artworkUri

                UniversalSearchSongItem(
                    title = title,
                    subtitle = "$artist • $album",
                    artworkUri = artworkUri,
                    mode = item.second,
                    onClick = {
                        if (isLocal) onLocalSongClick(item.first as Song)
                        else onStreamingSongClick(item.first as StreamingSong)
                    },
                    onMoreClick = {
                        onOptionsClick(item.first)
                    },
                    haptics = haptics,
                    index = index,
                    totalCount = allSongs.size
                )
            }
        }
    }
}

@Composable
private fun UniversalGenreBrowseSection(
    genres: List<String>,
    genreSongCounts: Map<String, Int>,
    isGenreDetectionComplete: Boolean,
    onGenreClick: (String) -> Unit
) {
    val context = LocalContext.current
    val isActuallyLoading = !isGenreDetectionComplete && genres.isEmpty()

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 12.dp)
            .animateContentSize(spring(stiffness = Spring.StiffnessMediumLow))
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.padding(horizontal = 4.dp).padding(bottom = 16.dp)
        ) {
            Icon(
                imageVector = RhythmIcons.AutoAwesome,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.tertiary,
                modifier = Modifier.size(32.dp)
            )
            Text(
                text = stringResource(R.string.search_browse_by_genre),
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.Black,
                color = MaterialTheme.colorScheme.onSurface,
                modifier = Modifier.padding(start = 12.dp)
            )
        }

        if (isActuallyLoading) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                contentAlignment = Alignment.Center
            ) {
                M3CircularLoader(
                    modifier = Modifier.size(36.dp),
                    color = MaterialTheme.colorScheme.tertiary,
                    strokeWidth = 3f
                )
            }
        } else if (genres.isNotEmpty()) {
            val isTablet = windowScreenWidthDp() >= 600
            val columnsCount = if (isTablet) 3 else 2
            val rows = remember(genres, columnsCount) { genres.chunked(columnsCount) }
            Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                rows.forEachIndexed { rowIndex, rowGenres ->
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        rowGenres.forEachIndexed { colIndex, genre ->
                            val itemIndex = rowIndex * columnsCount + colIndex
                            UniversalGenreBrowseItemCard(
                                genre = genre,
                                songCount = genreSongCounts[genre] ?: 0,
                                index = itemIndex,
                                totalItems = genres.size,
                                columnsCount = columnsCount,
                                onClick = { onGenreClick(genre) },
                                modifier = Modifier.weight(1f)
                            )
                        }
                        if (rowGenres.size < columnsCount) {
                            repeat(columnsCount - rowGenres.size) {
                                Spacer(modifier = Modifier.weight(1f))
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun getUniversalResponsiveGridItemShape(index: Int, totalItems: Int, columnsCount: Int): RoundedCornerShape {
    if (totalItems <= 1) return RoundedCornerShape(24.dp)
    val totalRows = (totalItems + columnsCount - 1) / columnsCount
    val r = index / columnsCount
    val c = index % columnsCount
    val isTopRow = r == 0
    val isBottomRow = r == totalRows - 1
    val isLeftColumn = c == 0
    val isRightColumn = c == columnsCount - 1 || index == totalItems - 1
    val topStart = if (isTopRow && isLeftColumn) 24.dp else 8.dp
    val topEnd = if (isTopRow && isRightColumn) 24.dp else 8.dp
    val bottomStart = if (isBottomRow && isLeftColumn) 24.dp else 8.dp
    val bottomEnd = if (isBottomRow && isRightColumn) 24.dp else 8.dp
    return RoundedCornerShape(topStart = topStart, topEnd = topEnd, bottomStart = bottomStart, bottomEnd = bottomEnd)
}

@Composable
private fun UniversalGenreBrowseItemCard(
    genre: String,
    songCount: Int,
    index: Int,
    totalItems: Int,
    columnsCount: Int,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val shape = remember(index, totalItems, columnsCount) {
        getUniversalResponsiveGridItemShape(index, totalItems, columnsCount)
    }

    val colorPair = when (index % 3) {
        0 -> MaterialTheme.colorScheme.primaryContainer to MaterialTheme.colorScheme.onPrimaryContainer
        1 -> MaterialTheme.colorScheme.secondaryContainer to MaterialTheme.colorScheme.onSecondaryContainer
        else -> MaterialTheme.colorScheme.tertiaryContainer to MaterialTheme.colorScheme.onTertiaryContainer
    }

    Card(
        onClick = onClick,
        shape = shape,
        colors = CardDefaults.cardColors(containerColor = colorPair.first),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        modifier = modifier.height(115.dp)
    ) {
        Box(modifier = Modifier.fillMaxSize()) {
            Icon(
                imageVector = universalGenreIconFor(genre),
                contentDescription = null,
                tint = colorPair.second.copy(alpha = 0.06f),
                modifier = Modifier
                    .size(96.dp)
                    .align(Alignment.BottomEnd)
                    .offset(x = 24.dp, y = 24.dp)
                    .graphicsLayer { rotationZ = -18f }
            )

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.Bottom
            ) {
                Text(
                    text = genre,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Black,
                    color = colorPair.second,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
                Text(
                    text = "$songCount songs",
                    style = MaterialTheme.typography.labelSmall,
                    color = colorPair.second.copy(alpha = 0.75f),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }
    }
}

private fun universalGenreIconFor(genre: String): app.needle.player.shared.presentation.components.icons.MaterialSymbolIcon {
    val normalized = genre.lowercase()
    return when {
        normalized.contains("hip hop") || normalized.contains("hip-hop") || normalized.contains("rap") || normalized.contains("trap") ->
            MaterialSymbolIcon("mic")

        normalized.contains("rock") || normalized.contains("metal") || normalized.contains("punk") || normalized.contains("grunge") ->
            RhythmIcons.Music.Audiotrack

        normalized.contains("electronic") || normalized.contains("edm") || normalized.contains("house") || normalized.contains("techno") || normalized.contains("trance") || normalized.contains("synth") ->
            RhythmIcons.Player.Equalizer

        normalized.contains("classical") || normalized.contains("instrumental") || normalized.contains("orchestra") || normalized.contains("opera") ->
            RhythmIcons.Music.Album

        normalized.contains("jazz") || normalized.contains("blues") || normalized.contains("soul") || normalized.contains("r&b") || normalized.contains("funk") ->
            RhythmIcons.Actions.Favorite

        normalized.contains("ambient") || normalized.contains("chill") || normalized.contains("lofi") || normalized.contains("lo-fi") || normalized.contains("acoustic") ->
            MaterialSymbolIcon("headphones")

        normalized.contains("pop") || normalized.contains("dance") || normalized.contains("disco") || normalized.contains("k-pop") || normalized.contains("j-pop") ->
            RhythmIcons.Music.MusicNote

        normalized.contains("country") || normalized.contains("folk") ->
            RhythmIcons.Music.Audiotrack

        else -> RhythmIcons.Music.MusicNote
    }
}
