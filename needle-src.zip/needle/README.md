# Needle

A personal, offline-first Android music player with its own look. Built on top of
[Rhythm](https://github.com/cromaguy/Rhythm) by Anjishnu Nandi, used under the GPL-3.0 license.

- App ID: `app.needle.player` (installs next to Rhythm)
- Build: GitHub Actions, "Needle build" workflow, APK in the run's Artifacts
- License: GPL-3.0 (see LICENSE). Original copyright notices in the source are kept.
