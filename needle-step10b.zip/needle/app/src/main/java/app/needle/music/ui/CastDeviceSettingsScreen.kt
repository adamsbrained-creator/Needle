package app.needle.music.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.cast.CastDevice
import app.needle.music.cast.CastHub
import app.needle.music.cast.CastSettings
import kotlinx.coroutines.launch

private val volumeSteps = listOf(1, 2, 5, 10, 20)

@Composable
private fun SettingRow(
    title: String,
    modifier: Modifier = Modifier,
    note: String? = null,
    onClick: (() -> Unit)? = null,
    trailing: @Composable () -> Unit
) {
    val shape = RoundedCornerShape(20.dp)
    Row(
        modifier
            .fillMaxWidth()
            .padding(bottom = 8.dp)
            .glass(shape)
            .then(if (onClick != null) Modifier.clickable(onClick = onClick) else Modifier)
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f)) {
            Text(title, color = Palette.Text, fontSize = 14.5.sp, fontWeight = FontWeight.Medium)
            if (note != null) Text(note, color = Palette.Muted, fontSize = 11.5.sp, lineHeight = 15.sp)
        }
        Spacer(Modifier.width(12.dp))
        trailing()
    }
}

/** "Cast device": the options for one DLNA / UPnP device. Saved per device. */
@Composable
fun CastDeviceSettingsScreen(
    device: CastDevice?,
    settings: CastSettings,
    connected: Boolean,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onChange: ((CastSettings) -> CastSettings) -> Unit,
    onRestore: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var showHelp by remember { mutableStateOf(false) }
    var testing by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }

    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
            RoundIconButton(NeedleIcon.HELP, { showHelp = true }, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
        }
        Spacer(Modifier.height(16.dp))
        Text(device?.name ?: "Cast device", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 30.sp, lineHeight = 36.sp)
        Text(
            if (device == null) "Not visible right now. Go back and refresh."
            else "${device.subtitle} · ${if (connected) "Connected" else "Not connected"}",
            color = Palette.Muted, fontSize = 13.sp
        )
        Spacer(Modifier.height(18.dp))

        SettingRow(
            "Volume step size",
            onClick = {
                val next = volumeSteps[(volumeSteps.indexOf(settings.volumeStep) + 1) % volumeSteps.size]
                onChange { it.copy(volumeStep = next) }
            }
        ) { Text("${settings.volumeStep}", color = Palette.Accent, fontSize = 15.sp, fontWeight = FontWeight.SemiBold) }

        SettingRow("Maximum bitrate", note = "Lower limits need transcoding, which comes in a later step.") {
            Text("Original", color = Palette.Muted, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
        }

        SettingRow("Use formats the device reports", note = "Decides what plays directly. Turn off if some tracks fail.") {
            NeedleSwitch(settings.reportedFormats) { v -> onChange { it.copy(reportedFormats = v) } }
        }
        SettingRow("Gapless playback", note = "Queues the next song on the device so there is no pause between songs.") {
            NeedleSwitch(settings.gapless) { v -> onChange { it.copy(gapless = v) } }
        }
        SettingRow("Stop casting when playback ends") {
            NeedleSwitch(settings.stopWhenEnds) { v -> onChange { it.copy(stopWhenEnds = v) } }
        }
        SettingRow("Stop if someone else takes over", note = "Only when the device says what it is playing.") {
            NeedleSwitch(settings.stopIfTakenOver) { v -> onChange { it.copy(stopIfTakenOver = v) } }
        }
        SettingRow("Alternative compatibility mode", note = "Switches the playback flags some devices need.") {
            NeedleSwitch(settings.altCompat) { v -> onChange { it.copy(altCompat = v) } }
        }

        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            PillButton(
                if (testing) "Testing…" else "Test connection",
                onClick = {
                    if (device != null && !testing) {
                        testing = true
                        testResult = null
                        scope.launch {
                            testResult = CastHub.testConnection(device)
                            testing = false
                        }
                    }
                },
                modifier = Modifier.weight(1f),
                filled = true
            )
            PillButton("Restore defaults", onClick = { onRestore(); testResult = null }, modifier = Modifier.weight(1f))
        }
        testResult?.let {
            Spacer(Modifier.height(10.dp))
            Text(it, color = Palette.Muted, fontSize = 12.5.sp, lineHeight = 17.sp, modifier = Modifier.padding(horizontal = 4.dp))
        }
        Spacer(Modifier.height(14.dp))
        Text(
            "Copy debug log",
            color = Palette.Muted,
            fontSize = 12.sp,
            modifier = Modifier
                .clickable {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    cm.setPrimaryClip(ClipData.newPlainText("Needle cast log", CastHub.logText()))
                    CastHub.post("Debug log copied")
                }
                .padding(horizontal = 4.dp, vertical = 6.dp)
        )
    }

    if (showHelp) {
        AlertDialog(
            onDismissRequest = { showHelp = false },
            containerColor = Palette.Surface,
            titleContentColor = Palette.Text,
            textContentColor = Palette.Muted,
            title = { Text("Cast device settings") },
            text = {
                Text(
                    "These options are saved for this device only.\n\n" +
                        "If songs don't start or the device stops, try turning off \"Use formats the device reports\", " +
                        "then try the alternative compatibility mode. \"Test connection\" checks that Needle can reach the device."
                )
            },
            confirmButton = { TextButton(onClick = { showHelp = false }) { Text("Got it", color = Palette.Accent) } }
        )
    }
}
