package app.needle.music.data

import android.Manifest
import android.app.Application
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class LibraryViewModel(private val app: Application) : AndroidViewModel(app) {

    private val dao = NeedleDatabase.get(app).songDao()

    /** null = still loading from the database, empty = nothing found. */
    val songs: StateFlow<List<Song>?> =
        dao.observeAll().stateIn(viewModelScope, SharingStarted.Eagerly, null)

    var isScanning by mutableStateOf(false); private set

    val audioPermission: String =
        if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    var hasPermission by mutableStateOf(checkPermission()); private set

    fun refreshPermission() {
        hasPermission = checkPermission()
    }

    fun scan() {
        if (isScanning || !hasPermission) return
        viewModelScope.launch {
            isScanning = true
            try {
                val found = withContext(Dispatchers.IO) { MediaStoreScanner.scan(app) }
                dao.replaceAll(found)
            } finally {
                isScanning = false
            }
        }
    }

    private fun checkPermission() =
        ContextCompat.checkSelfPermission(app, audioPermission) == PackageManager.PERMISSION_GRANTED
}
