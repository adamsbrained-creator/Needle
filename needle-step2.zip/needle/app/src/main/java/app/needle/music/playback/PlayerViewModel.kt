package app.needle.music.playback

import android.app.Application
import android.content.ComponentName
import android.graphics.BitmapFactory
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableLongStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import app.needle.music.data.Song

/**
 * The bridge between the UI and the playback service.
 * The UI only reads these state fields and calls the functions below, which is what
 * keeps the skin easy to redesign later.
 */
class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    var isPlaying by mutableStateOf(false); private set
    var hasMedia by mutableStateOf(false); private set
    var currentMediaId by mutableStateOf<String?>(null); private set
    var title by mutableStateOf<String?>(null); private set
    var artist by mutableStateOf<String?>(null); private set
    var artwork by mutableStateOf<ImageBitmap?>(null); private set
    var positionMs by mutableLongStateOf(0L); private set
    var durationMs by mutableLongStateOf(0L); private set

    private var controller: MediaController? = null
    private var pending: Pair<List<MediaItem>, Int>? = null
    private var lastArtData: ByteArray? = null

    private val listener = object : Player.Listener {
        override fun onEvents(player: Player, events: Player.Events) = sync(player)
    }

    private val future = MediaController.Builder(
        app,
        SessionToken(app, ComponentName(app, PlaybackService::class.java))
    ).buildAsync()

    init {
        future.addListener({
            runCatching { future.get() }.onSuccess { c ->
                controller = c
                c.addListener(listener)
                sync(c)
                pending?.let { (items, index) -> start(c, items, index); pending = null }
            }
        }, ContextCompat.getMainExecutor(app))
    }

    /**
     * Play [songs] starting at [index].
     * For now only a window around the tapped song is queued (50 before, 250 after) to keep
     * the message to the service small. A real queue lives in the service in step 3.
     */
    fun playSongs(songs: List<Song>, index: Int) {
        if (index !in songs.indices) return
        val from = (index - 50).coerceAtLeast(0)
        val to = (index + 250).coerceAtMost(songs.size)
        val items = songs.subList(from, to).map { it.toMediaItem() }
        val start = index - from
        val c = controller
        if (c == null) pending = items to start else start(c, items, start)
    }

    fun togglePlay() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() { controller?.seekToNext() }

    fun previous() { controller?.seekToPrevious() }

    fun seekTo(ms: Long) {
        controller?.seekTo(ms)
        refreshPosition()
    }

    /** Called by the UI a few times per second while the player screen is open and playing. */
    fun refreshPosition() {
        controller?.let {
            positionMs = it.currentPosition
            durationMs = if (it.duration == C.TIME_UNSET) 0L else it.duration
        }
    }

    private fun start(c: MediaController, items: List<MediaItem>, startIndex: Int) {
        c.setMediaItems(items, startIndex, C.TIME_UNSET)
        c.prepare()
        c.play()
    }

    private fun Song.toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            // No artwork here on purpose: the player reads the cover embedded in the file.
            MediaMetadata.Builder().setTitle(title).setArtist(artist).setAlbumTitle(album).build()
        )
        .build()

    private fun sync(p: Player) {
        isPlaying = p.isPlaying
        hasMedia = p.currentMediaItem != null
        currentMediaId = p.currentMediaItem?.mediaId
        val md = p.mediaMetadata
        title = md.title?.toString()
        artist = md.artist?.toString() ?: md.albumArtist?.toString()
        val data = md.artworkData
        if (data !== lastArtData) {
            lastArtData = data
            artwork = data?.let {
                runCatching { BitmapFactory.decodeByteArray(it, 0, it.size)?.asImageBitmap() }.getOrNull()
            }
        }
        positionMs = p.currentPosition
        durationMs = if (p.duration == C.TIME_UNSET) 0L else p.duration
    }

    override fun onCleared() {
        controller?.removeListener(listener)
        MediaController.releaseFuture(future)
        super.onCleared()
    }
}
