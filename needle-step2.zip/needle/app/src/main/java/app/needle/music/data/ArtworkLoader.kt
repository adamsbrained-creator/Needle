package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

/** Small cover thumbnails for list rows. Cached per album so a list of 5000 songs stays light. */
object ArtworkLoader {
    private val NONE = Any()
    private val cache = LruCache<Long, Any>(300)

    suspend fun load(context: Context, song: Song, sizePx: Int = 144): ImageBitmap? {
        val key = if (song.albumId > 0) song.albumId else -song.id
        cache.get(key)?.let { return if (it === NONE) null else it as ImageBitmap }

        val bitmap = withContext(Dispatchers.IO) {
            runCatching {
                if (Build.VERSION.SDK_INT >= 29) {
                    context.contentResolver.loadThumbnail(song.uri, Size(sizePx, sizePx), null)
                } else {
                    val art = ContentUris.withAppendedId(
                        Uri.parse("content://media/external/audio/albumart"), song.albumId
                    )
                    context.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
                }
            }.getOrNull()?.asImageBitmap()
        }
        cache.put(key, bitmap ?: NONE)
        return bitmap
    }
}
