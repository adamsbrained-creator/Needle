package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectHorizontalDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.Song

/** Pink-to-purple gradient with an orange disc, straight from the mockups. Scales to any size. */
@Composable
fun ArtworkPlaceholder(modifier: Modifier = Modifier) {
    Canvas(modifier) {
        drawRect(Brush.verticalGradient(listOf(Color(0xFFF4B6C8), Color(0xFF6B3F8F))))
        drawCircle(Color(0xFFF08A4B), radius = size.minDimension * 0.19f, center = center)
    }
}

/** Cover for a song row, loaded lazily and cached per album. */
@Composable
fun SongArtwork(song: Song, size: Dp, modifier: Modifier = Modifier, corner: Dp = 12.dp) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(null, song.id) {
        value = ArtworkLoader.load(context, song)
    }
    Box(modifier.size(size).clip(RoundedCornerShape(corner))) {
        val bitmap = art
        if (bitmap != null) {
            Image(bitmap, null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
        } else {
            ArtworkPlaceholder(Modifier.fillMaxSize())
        }
    }
}

@Composable
fun PlayPauseButton(
    isPlaying: Boolean,
    enabled: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    size: Dp = 72.dp,
    iconSize: Dp = 28.dp
) {
    Box(
        modifier = modifier
            .size(size)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = if (enabled) 1f else 0.3f))
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(iconSize)) {
            val ink = Palette.Bg
            if (isPlaying) {
                val barW = this.size.width * 0.3f
                val radius = CornerRadius(3.dp.toPx())
                drawRoundRect(ink, Offset(this.size.width * 0.12f, 0f), Size(barW, this.size.height), radius)
                drawRoundRect(ink, Offset(this.size.width * 0.58f, 0f), Size(barW, this.size.height), radius)
            } else {
                val tri = Path().apply {
                    moveTo(this@Canvas.size.width * 0.18f, 0f)
                    lineTo(this@Canvas.size.width, this@Canvas.size.height / 2f)
                    lineTo(this@Canvas.size.width * 0.18f, this@Canvas.size.height)
                    close()
                }
                drawPath(tri, ink)
            }
        }
    }
}

@Composable
fun SkipButton(next: Boolean, enabled: Boolean, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier
            .size(56.dp)
            .clip(CircleShape)
            .clickable(enabled = enabled, onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(24.dp)) {
            val c = Palette.Text.copy(alpha = if (enabled) 1f else 0.3f)
            val w = size.width
            val h = size.height
            val barW = w * 0.14f
            val tri = Path().apply {
                if (next) {
                    moveTo(0f, 0f); lineTo(w * 0.8f, h / 2f); lineTo(0f, h)
                } else {
                    moveTo(w, 0f); lineTo(w * 0.2f, h / 2f); lineTo(w, h)
                }
                close()
            }
            drawPath(tri, c)
            drawRect(c, Offset(if (next) w - barW else 0f, 0f), Size(barW, h))
        }
    }
}

@Composable
fun ChevronDownButton(onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier = modifier.size(44.dp).clip(CircleShape).clickable(onClick = onClick),
        contentAlignment = Alignment.Center
    ) {
        Canvas(Modifier.size(20.dp)) {
            val p = Path().apply {
                moveTo(size.width * 0.15f, size.height * 0.35f)
                lineTo(size.width * 0.5f, size.height * 0.68f)
                lineTo(size.width * 0.85f, size.height * 0.35f)
            }
            drawPath(
                p, Palette.Text,
                style = Stroke(width = 2.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
            )
        }
    }
}

/** Pill button: filled (white) or outlined. */
@Composable
fun PillButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier, filled: Boolean = false) {
    val base = modifier.clip(CircleShape)
    val styled = if (filled) base.background(Color.White) else base.border(1.dp, Palette.Muted, CircleShape)
    Box(styled.clickable(onClick = onClick).padding(horizontal = 22.dp, vertical = 12.dp), contentAlignment = Alignment.Center) {
        Text(
            text,
            color = if (filled) Palette.Bg else Palette.Text,
            fontSize = 15.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

/**
 * Thin line with a small round dot, as in the mockups. Tap or drag to seek.
 * [onSeek] receives a fraction from 0 to 1.
 */
@Composable
fun NeedleProgressBar(
    progress: Float,
    enabled: Boolean,
    onSeek: (Float) -> Unit,
    modifier: Modifier = Modifier
) {
    var dragFraction by remember { mutableStateOf<Float?>(null) }
    val shown = dragFraction ?: progress

    Box(
        modifier
            .height(28.dp)
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val pad = 6.dp.toPx()
                detectTapGestures { o ->
                    onSeek(((o.x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f))
                }
            }
            .pointerInput(enabled) {
                if (!enabled) return@pointerInput
                val pad = 6.dp.toPx()
                fun frac(x: Float) = ((x - pad) / (size.width - 2 * pad)).coerceIn(0f, 1f)
                detectHorizontalDragGestures(
                    onDragStart = { dragFraction = frac(it.x) },
                    onHorizontalDrag = { change, _ ->
                        change.consume()
                        dragFraction = frac(change.position.x)
                    },
                    onDragEnd = {
                        dragFraction?.let(onSeek)
                        dragFraction = null
                    },
                    onDragCancel = { dragFraction = null }
                )
            }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val trackH = 4.dp.toPx()
            val r = 6.dp.toPx()
            val y = size.height / 2f
            val x0 = r
            val x1 = size.width - r
            val x = x0 + (x1 - x0) * shown
            val alpha = if (enabled) 1f else 0.35f
            drawLine(Color.White.copy(alpha = 0.2f * alpha), Offset(x0, y), Offset(x1, y), trackH, StrokeCap.Round)
            drawLine(Color.White.copy(alpha = alpha), Offset(x0, y), Offset(x, y), trackH, StrokeCap.Round)
            drawCircle(Color.White.copy(alpha = alpha), r, Offset(x, y))
        }
    }
}
