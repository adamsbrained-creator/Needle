package app.needle.music.data

import android.content.Context
import android.content.SharedPreferences
import androidx.compose.runtime.mutableStateOf

/** How albums with several discs are shown. Remembered. */
object AlbumPrefs {
    private var prefs: SharedPreferences? = null

    /** On: disc 1, 2, 3 are called Side A, B, C (for vinyl rips, where each disc number is a side of a record). */
    val discsAsSides = mutableStateOf(false)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        discsAsSides.value = p.getBoolean("discs_as_sides", false)
    }

    fun setDiscsAsSides(value: Boolean) {
        discsAsSides.value = value
        prefs?.edit()?.putBoolean("discs_as_sides", value)?.apply()
    }
}

/** The disc (or side) a song is on, from its Disc tag ("2" or "2/4"). Songs without the tag count as disc 1. */
fun discOf(extras: Map<String, String>?): Int =
    extras?.get("DISCNUMBER")?.substringBefore('/')?.trim()?.toIntOrNull()?.takeIf { it > 0 } ?: 1

/** "Disc 2", or "Side B" when discs are shown as sides. */
fun discLabel(disc: Int, asSides: Boolean): String = when {
    !asSides -> "Disc $disc"
    disc in 1..26 -> "Side ${'A' + (disc - 1)}"
    else -> "Side $disc"
}
