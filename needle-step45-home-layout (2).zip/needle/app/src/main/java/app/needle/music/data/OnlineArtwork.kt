package app.needle.music.data

import android.content.Context
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import java.util.Locale

/** Tiny HTTP helper for the online artwork lookups. [code] is -1 when the request itself failed. */
private class Reply(val code: Int, val body: ByteArray?)

private const val UA = "Needle/1.0 (Android music player)"
private const val MAX_BYTES = 8 * 1024 * 1024
private const val RETRY_AFTER_MS = 7L * 24 * 60 * 60 * 1000

private fun httpGet(url: String): Reply {
    val c = URL(url).openConnection() as HttpURLConnection
    return try {
        c.connectTimeout = 15_000
        c.readTimeout = 25_000
        c.setRequestProperty("User-Agent", UA)
        val code = c.responseCode
        if (code != 200) Reply(code, null)
        else Reply(code, c.inputStream.use { it.readBytes() }.takeIf { it.size in 1..MAX_BYTES })
    } catch (e: IOException) {
        Reply(-1, null)
    } finally {
        c.disconnect()
    }
}

private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")
private fun norm(s: String) = s.lowercase(Locale.ROOT).filter { it.isLetterOrDigit() }
private fun sameish(a: String, b: String): Boolean {
    val x = norm(a); val y = norm(b)
    return x.isNotEmpty() && y.isNotEmpty() && (x == y || x.contains(y) || y.contains(x))
}
private fun md5(s: String) = MessageDigest.getInstance("MD5").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }

/**
 * Covers for songs that have none inside the file, from iTunes and then Deezer (both free, no key).
 * Saved on the phone, so each album is looked up once; a miss is remembered for a week.
 */
object OnlineCovers {
    private val lock = Mutex()

    suspend fun get(context: Context, song: Song): File? = withContext(Dispatchers.IO) {
        if (!NeedleSettings.fetchMissingCovers.value || !isKnownArtist(song.artist)) return@withContext null
        val hasAlbum = song.album.isNotBlank() && song.album != "Unknown album"
        val key = song.artist.lowercase(Locale.ROOT) + "|" + (if (hasAlbum) song.album else song.title).lowercase(Locale.ROOT)
        val dir = File(context.filesDir, "online_covers").apply { mkdirs() }
        val jpg = File(dir, md5(key) + ".jpg")
        val none = File(dir, md5(key) + ".none")
        if (jpg.exists()) return@withContext jpg
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < RETRY_AFTER_MS) return@withContext null
        if (!networkAllowsAnimatedCovers(context, wifiOnly = false)) return@withContext null

        lock.withLock {
            if (jpg.exists()) return@withLock jpg
            try {
                val bytes = fromItunes(song, hasAlbum) ?: fromDeezer(song, hasAlbum)
                delay(400) // be gentle with the services
                if (bytes != null) {
                    jpg.writeBytes(bytes)
                    jpg
                } else {
                    none.writeText("")
                    none.setLastModified(System.currentTimeMillis())
                    null
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null // offline or a hiccup: try again next time, no marker
            }
        }
    }

    private fun fromItunes(song: Song, hasAlbum: Boolean): ByteArray? {
        val term = enc(if (hasAlbum) "${song.artist} ${song.album}" else "${song.artist} ${song.title}")
        val url = "https://itunes.apple.com/search?term=$term&media=music&entity=${if (hasAlbum) "album" else "song"}&limit=8"
        val body = httpGet(url).body ?: return null
        val results = JSONObject(String(body)).optJSONArray("results") ?: return null
        for (i in 0 until results.length()) {
            val r = results.optJSONObject(i) ?: continue
            if (!sameish(r.optString("artistName"), song.artist)) continue
            if (hasAlbum && !sameish(r.optString("collectionName"), song.album)) continue
            val art = r.optString("artworkUrl100").takeIf { it.isNotBlank() } ?: continue
            return httpGet(art.replace(Regex("/\\d+x\\d+bb"), "/600x600bb")).body
        }
        return null
    }

    private fun fromDeezer(song: Song, hasAlbum: Boolean): ByteArray? {
        val q = if (hasAlbum) "artist:\"${song.artist}\" album:\"${song.album}\"" else "artist:\"${song.artist}\" track:\"${song.title}\""
        val url = "https://api.deezer.com/search/${if (hasAlbum) "album" else "track"}?q=${enc(q)}&limit=8"
        val body = httpGet(url).body ?: return null
        val data = JSONObject(String(body)).optJSONArray("data") ?: return null
        for (i in 0 until data.length()) {
            val r = data.optJSONObject(i) ?: continue
            if (!sameish(r.optJSONObject("artist")?.optString("name").orEmpty(), song.artist)) continue
            val cover = (if (hasAlbum) r.optString("cover_xl") else r.optJSONObject("album")?.optString("cover_xl").orEmpty())
            if (cover.isBlank() || cover.contains("/images/cover//")) continue // Deezer's "no cover" placeholder
            return httpGet(cover).body
        }
        return null
    }
}

/**
 * Artist background pictures from Fanart.tv (needs the person's own free API key). The artist is first matched to a
 * MusicBrainz id. Saved on the phone, so each artist is looked up once; a miss is remembered for a week.
 */
object ArtistBackgrounds {
    private val lock = Mutex()

    suspend fun find(context: Context, artist: String): File? = withContext(Dispatchers.IO) {
        val apiKey = NeedleSettings.fanartKey.value.trim()
        val name = artist.substringBefore(';').trim()
        if (!NeedleSettings.artistBackgrounds.value || apiKey.isEmpty() || !isKnownArtist(name)) return@withContext null
        val dir = File(context.filesDir, "artist_bg").apply { mkdirs() }
        val id = md5(name.lowercase(Locale.ROOT))
        val jpg = File(dir, "$id.jpg")
        val none = File(dir, "$id.none")
        if (jpg.exists()) return@withContext jpg
        if (none.exists() && System.currentTimeMillis() - none.lastModified() < RETRY_AFTER_MS) return@withContext null
        if (!networkAllowsAnimatedCovers(context, wifiOnly = false)) return@withContext null

        lock.withLock {
            if (jpg.exists()) return@withLock jpg
            try {
                var bytes: ByteArray? = null
                var definitelyNone = false
                val mbid = musicBrainzId(name)
                delay(1100) // MusicBrainz allows about one request a second
                if (mbid == null) {
                    definitelyNone = true
                } else {
                    val reply = httpGet("https://webservice.fanart.tv/v3/music/$mbid?api_key=${enc(apiKey)}")
                    when {
                        reply.code == 404 -> definitelyNone = true
                        reply.code == 200 && reply.body != null -> {
                            val list = JSONObject(String(reply.body)).optJSONArray("artistbackground")
                            var best: String? = null
                            var bestLikes = -1
                            if (list != null) for (i in 0 until list.length()) {
                                val o = list.optJSONObject(i) ?: continue
                                val likes = o.optString("likes").toIntOrNull() ?: 0
                                val url = o.optString("url")
                                if (url.isNotBlank() && likes > bestLikes) { best = url; bestLikes = likes }
                            }
                            if (best == null) definitelyNone = true
                            else bytes = httpGet(best.replace("http://", "https://")).body
                        }
                        // 401/403 (wrong key), server errors or no network: keep trying later
                    }
                }
                if (bytes != null) {
                    jpg.writeBytes(bytes)
                    jpg
                } else {
                    if (definitelyNone) { none.writeText(""); none.setLastModified(System.currentTimeMillis()) }
                    null
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                null
            }
        }
    }

    private fun musicBrainzId(name: String): String? {
        val url = "https://musicbrainz.org/ws/2/artist/?query=${enc("artist:\"$name\"")}&fmt=json&limit=3"
        val body = httpGet(url).body ?: return null
        val artists = JSONObject(String(body)).optJSONArray("artists") ?: return null
        for (i in 0 until artists.length()) {
            val a = artists.optJSONObject(i) ?: continue
            if (a.optString("name").equals(name, ignoreCase = true) && a.optInt("score", 0) >= 90) {
                return a.optString("id").takeIf { it.isNotBlank() }
            }
        }
        return null
    }
}
