package app.needle.music.ui

import app.needle.music.data.HomeAlbum
import app.needle.music.data.PlaylistData
import app.needle.music.data.Song
import app.needle.music.data.artistKey
import app.needle.music.data.isKnownArtist

/** What a tap on a part of the Now playing page does. More actions (and a settings page to pick them) can be added here later. */
enum class NowPlayingAction { NONE, OPEN_ALBUM, OPEN_ARTIST, OPEN_QUEUE_SOURCE, OPEN_QUEUE }

/** Which action each part of the Now playing page runs. These are the defaults; a settings page can replace them later. */
data class NowPlayingGestures(
    val onTitle: NowPlayingAction = NowPlayingAction.OPEN_ALBUM,
    val onArtist: NowPlayingAction = NowPlayingAction.OPEN_ARTIST,
    val onHeader: NowPlayingAction = NowPlayingAction.OPEN_QUEUE_SOURCE
)

/** Where the queue came from, for the header. [open] is null when there is no page for it (a tap opens the queue instead). */
class QueueSource(val title: String, val open: (() -> Unit)?)

/**
 * Works out the name of the queue from what is in it: a playlist, an album, one artist, or the whole library.
 * (The player does not remember where a queue was started, so this reads the queue itself.)
 */
fun inferQueueSource(
    ids: List<Long>,
    songs: List<Song>,
    albums: List<HomeAlbum>,
    playlists: List<PlaylistData>,
    openPlaylist: (Long) -> Unit,
    openAlbum: (Song) -> Unit,
    openArtist: (String) -> Unit
): QueueSource? {
    if (ids.isEmpty()) return null
    val queued = ids.toSet()

    playlists.firstOrNull { it.songIds.toSet() == queued }?.let { p ->
        return QueueSource(if (p.liked) "Liked songs" else p.name) { openPlaylist(p.id) }
    }

    val byId = songs.associateBy { it.id }
    val inQueue = ids.mapNotNull { byId[it] }
    if (inQueue.isEmpty()) return QueueSource("Your queue", null)

    val first = inQueue.first()
    if (inQueue.all { it.albumId == first.albumId }) {
        val title = albums.firstOrNull { it.id == first.albumId }?.title
            ?: if (first.album != "Unknown album") first.album else first.title
        return QueueSource(title) { openAlbum(first) }
    }
    if (isKnownArtist(first.artist) && inQueue.all { artistKey(it.artist) == artistKey(first.artist) }) {
        return QueueSource(first.artist) { openArtist(first.artist) }
    }
    if (queued.size == songs.size) return QueueSource("All songs", null)
    return QueueSource("Your queue", null)
}
