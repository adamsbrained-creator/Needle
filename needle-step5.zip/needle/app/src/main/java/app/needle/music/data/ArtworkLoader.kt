package app.needle.music.data

import android.content.ContentUris
import android.content.Context
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.util.LruCache
import android.util.Size
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

/**
 * Cover images for lists and cards.
 * - Cached per song (albums can hold different covers per file).
 * - At most 4 images load at once, so a fast fling doesn't flood the media provider.
 * - Two sizes: small thumbnails for list rows, large ones for the Home cards.
 */
object ArtworkLoader {
    private const val SMALL_PX = 144
    private const val LARGE_PX = 512
    private const val HERO_PX = 960

    private val NONE = Any()
    private val small = LruCache<Long, Any>(400)
    private val large = LruCache<Long, Any>(30)
    private val hero = LruCache<Long, Any>(4)
    private val gate = Semaphore(4)

    /** Instant cache lookup, safe to call while composing. Null means "not loaded (yet)". */
    fun peek(song: Song): ImageBitmap? = small.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun load(context: Context, song: Song, sizePx: Int = SMALL_PX): ImageBitmap? =
        load(small, context, song, sizePx)

    fun peekLarge(song: Song): ImageBitmap? = large.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun loadLarge(context: Context, song: Song): ImageBitmap? =
        load(large, context, song, LARGE_PX)

    /** Extra-sharp version for the big card at the top of the New page. */
    fun peekHero(song: Song): ImageBitmap? = hero.get(song.id)?.takeIf { it !== NONE } as ImageBitmap?

    suspend fun loadHero(context: Context, song: Song): ImageBitmap? =
        load(hero, context, song, HERO_PX)

    private suspend fun load(cache: LruCache<Long, Any>, context: Context, song: Song, sizePx: Int): ImageBitmap? {
        cache.get(song.id)?.let { return if (it === NONE) null else it as ImageBitmap }

        val bitmap = gate.withPermit {
            withContext(Dispatchers.IO) {
                runCatching {
                    if (Build.VERSION.SDK_INT >= 29) {
                        context.contentResolver.loadThumbnail(song.uri, Size(sizePx, sizePx), null)
                    } else {
                        val art = ContentUris.withAppendedId(
                            Uri.parse("content://media/external/audio/albumart"), song.albumId
                        )
                        context.contentResolver.openInputStream(art)?.use { BitmapFactory.decodeStream(it) }
                    }
                }.getOrNull()?.asImageBitmap()
            }
        }
        cache.put(song.id, bitmap ?: NONE)
        return bitmap
    }
}
