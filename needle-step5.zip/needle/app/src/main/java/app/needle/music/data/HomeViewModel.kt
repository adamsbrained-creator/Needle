package app.needle.music.data

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.flowOn
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import java.util.concurrent.TimeUnit

/** Feeds the Home screen. Rebuilds whenever the library or the play history changes. */
class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val db = NeedleDatabase.get(app)

    private val inputs = combine(db.songDao().observeAll(), db.playDao().observeAll()) { songs, plays -> songs to plays }

    /** The Popular page. null = still loading. */
    val home: StateFlow<HomeState?> =
        inputs
            .map { (songs, plays) ->
                val now = System.currentTimeMillis()
                buildHome(songs, plays, now, seed = now / TimeUnit.DAYS.toMillis(1))
            }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)

    /** The New page. null = still loading. */
    val newState: StateFlow<NewState?> =
        inputs
            .map { (songs, plays) -> buildNew(songs, plays, System.currentTimeMillis()) }
            .flowOn(Dispatchers.Default)
            .stateIn(viewModelScope, SharingStarted.Eagerly, null)
}
