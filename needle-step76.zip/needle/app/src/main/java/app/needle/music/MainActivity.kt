package app.needle.music

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.KeyEvent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModelProvider
import app.needle.music.cast.CastHub
import app.needle.music.data.FileAccess
import app.needle.music.data.HomeLayout
import app.needle.music.data.NeedleSettings
import app.needle.music.data.LyricsPrefs
import app.needle.music.playback.EqState
import app.needle.music.data.AlbumPrefs
import app.needle.music.data.ExcludedFolders
import app.needle.music.data.GenrePrefs
import app.needle.music.data.HiddenSongs
import app.needle.music.data.LyricsTranslations
import app.needle.music.data.MixPrefs
import app.needle.music.data.MomentNotes
import app.needle.music.data.Onboarding
import app.needle.music.data.PinnedArtists
import app.needle.music.data.SmartPlaylists
import app.needle.music.data.RecentSearches
import app.needle.music.playback.SpeedPrefs
import app.needle.music.data.WritePrefs
import app.needle.music.ui.GlowSettings
import app.needle.music.data.LibraryViewModel
import app.needle.music.ui.NeedleApp
import app.needle.music.ui.NeedleTheme

class MainActivity : ComponentActivity() {

    private val notificationPermission =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* nothing to do */ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        CastHub.init(this)
        GlowSettings.init(this)
        NeedleSettings.init(this)
        HomeLayout.init(this)
        FileAccess.refresh()
        LyricsPrefs.init(this)
        WritePrefs.init(this)
        AlbumPrefs.init(this)
        GenrePrefs.init(this)
        RecentSearches.init(this)
        PinnedArtists.init(this)
        HiddenSongs.init(this)
        ExcludedFolders.init(this)
        Onboarding.init(this)
        MixPrefs.init(this)
        MomentNotes.init(this)
        SmartPlaylists.init(this)
        LyricsTranslations.init(this)
        SpeedPrefs.init(this)
        EqState.init(this)

        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
            != PackageManager.PERMISSION_GRANTED
        ) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        }

        setContent {
            NeedleTheme {
                NeedleApp()
            }
        }
    }

    override fun onResume() {
        super.onResume()
        // The person may have granted music access in system settings while we were in the background.
        ViewModelProvider(this)[LibraryViewModel::class.java].refreshPermission()
        CastHub.refreshPermission()
        FileAccess.refresh()
    }

    /** While casting, the phone's volume buttons change the volume of the device instead. */
    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (CastHub.isConnected() && (keyCode == KeyEvent.KEYCODE_VOLUME_UP || keyCode == KeyEvent.KEYCODE_VOLUME_DOWN)) {
            CastHub.stepVolume(if (keyCode == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1, announce = true)
            return true
        }
        return super.onKeyDown(keyCode, event)
    }
}
