package app.needle.music.ui

import android.os.Build
import androidx.compose.ui.draw.blur
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.platform.LocalContext
import android.content.Context
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import app.needle.music.data.NeedleSettings
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.graphicsLayer

/**
 * The moving glow behind every page, taken from the Needle player's background:
 * a violet wash from the top corner and three soft colour blobs (violet, pink, green) that drift slowly.
 *
 * Change [GLOW_STRENGTH] to make the whole thing stronger or calmer: 1 = as in the player,
 * 0.6 = quieter, 0 = off (plain dark background).
 */
private const val GLOW_STRENGTH = 1f

private val WashViolet = Color(0xFF4B3A72) // violet, the player's "primary container"

/** The "Moving background" switch in Settings. Saved, and read while drawing so toggling never recomposes pages. */
object GlowSettings {
    private var prefs: android.content.SharedPreferences? = null

    val enabled = mutableStateOf(true)

    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("needle_ui", Context.MODE_PRIVATE)
        prefs = p
        enabled.value = p.getBoolean("moving_background", true)
    }

    fun set(on: Boolean) {
        enabled.value = on
        prefs?.edit()?.putBoolean("moving_background", on)?.apply()
    }
}

/** The four colors of the glow: the corner wash and the three drifting blobs. */
class GlowPalette(val wash: Color, val a: Color, val b: Color, val c: Color)

/** The glow's usual colors: the accent (or your own glow colors from Settings > Customization > Colors & themes), pink and green. */
internal fun defaultGlow(base: Color): GlowPalette {
    val accent = Palette.Glow1
    val wash = if (NeedleSettings.accentIndex.intValue == 0 && NeedleSettings.glow1.intValue == 0) WashViolet else lerp(base, accent, 0.4f)
    return GlowPalette(wash, accent, Palette.Glow2, Palette.Glow3)
}

/** The color the Now playing cards lean towards while the glow follows the song (null = the usual accent tint). */
object NowGlowTint {
    var color by mutableStateOf<Color?>(null)
}

private val StillDrift = mutableStateOf(0f)

/** One shared clock, so the root background and the pages sliding over it always show the same motion. */
private val LocalGlowDrift = staticCompositionLocalOf<State<Float>> { StillDrift }

@Composable
fun GlowProvider(content: @Composable () -> Unit) {
    // The wallpaper (if one is chosen) is read once here and shared by every page's background.
    val context = LocalContext.current
    LaunchedEffect(NeedleSettings.wallpaperUri.value) { Wallpaper.load(context, NeedleSettings.wallpaperUri.value) }
    val transition = rememberInfiniteTransition(label = "needle_glow")
    // When the glow is off nothing animates at all.
    val drift: State<Float> = if (GlowSettings.enabled.value && !NeedleSettings.reduceMotion.value) {
        transition.animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(tween(9000, easing = LinearEasing), RepeatMode.Reverse),
            label = "drift"
        )
    } else {
        StillDrift
    }
    CompositionLocalProvider(LocalGlowDrift provides drift) { content() }
}

/**
 * The glow itself: dark base plus the drifting blobs, in a layer of its own. Put it as the first child of a
 * box ([matchParentSize]) so it sits behind the content. Because it is a separate layer, the animation only
 * redraws the glow and never the page on top of it. The drift is read while drawing, so nothing recomposes.
 */
@Composable
fun GlowLayer(modifier: Modifier = Modifier, palette: State<GlowPalette>? = null) {
    val drift = LocalGlowDrift.current
    // A wallpaper goes behind every page; a page that brings its own glow from a cover (Now playing) keeps that.
    val wallpaper = if (palette == null) Wallpaper.bitmap.value else null
    val dim = when (NeedleSettings.wallpaperDim.intValue) { 0 -> 0.35f; 2 -> 0.78f; else -> 0.56f }
    val blur = wallpaper != null && NeedleSettings.wallpaperBlur.value && Build.VERSION.SDK_INT >= 31
    Box(
        modifier
            .graphicsLayer { }
            .background(Palette.Bg)
            .then(if (blur) Modifier.blur(18.dp) else Modifier)
            .drawBehind {
                if (wallpaper != null) {
                    // The picture fills the page (cropped from the middle), then a dark veil keeps the text readable.
                    val scale = maxOf(size.width / wallpaper.width, size.height / wallpaper.height)
                    val srcW = size.width / scale
                    val srcH = size.height / scale
                    drawImage(
                        wallpaper,
                        srcOffset = IntOffset(((wallpaper.width - srcW) / 2f).toInt(), ((wallpaper.height - srcH) / 2f).toInt()),
                        srcSize = IntSize(srcW.toInt().coerceAtLeast(1), srcH.toInt().coerceAtLeast(1)),
                        dstSize = IntSize(size.width.toInt().coerceAtLeast(1), size.height.toInt().coerceAtLeast(1))
                    )
                    drawRect(Palette.Bg.copy(alpha = dim))
                } else if (GlowSettings.enabled.value) {
                    drawGlow(drift.value, Palette.Bg, palette?.value)
                }
            }
    )
}

/** A full page (or a page that slides over others) with the glow behind it. */
@Composable
fun GlowSurface(modifier: Modifier = Modifier, palette: State<GlowPalette>? = null, content: @Composable () -> Unit) {
    Box(modifier) {
        GlowLayer(Modifier.matchParentSize(), palette)
        content()
    }
}

private fun DrawScope.drawGlow(drift: Float, base: Color, palette: GlowPalette?) {
    val strength = GLOW_STRENGTH * NeedleSettings.glowStrength.floatValue
    if (strength <= 0f) return
    val w = size.width
    val h = size.height
    fun a(alpha: Float) = (alpha * strength).coerceIn(0f, 1f)

    val g = palette ?: defaultGlow(base)
    drawRect(Brush.linearGradient(listOf(g.wash.copy(alpha = a(0.55f)), base), start = Offset(0f, 0f), end = Offset(w, h)))
    val c1 = Offset(w * (0.1f + 0.3f * drift), h * 0.3f)
    drawRect(Brush.radialGradient(listOf(g.a.copy(alpha = a(0.45f)), Color.Transparent), center = c1, radius = w * 0.9f))
    val c2 = Offset(w * (0.95f - 0.3f * drift), h * 0.55f)
    drawRect(Brush.radialGradient(listOf(g.b.copy(alpha = a(0.30f)), Color.Transparent), center = c2, radius = w * 0.8f))
    val c3 = Offset(w * 0.4f, h * (0.85f - 0.1f * drift))
    drawRect(Brush.radialGradient(listOf(g.c.copy(alpha = a(0.25f)), Color.Transparent), center = c3, radius = w * 0.7f))
    // Settle back to the plain background at the bottom, behind the dock.
    drawRect(Brush.verticalGradient(listOf(Color.Transparent, base), startY = h * 0.85f, endY = h))
}
