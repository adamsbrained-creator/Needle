package app.needle.music.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

/**
 * Settings, opened from the avatar on Home. Only the options that exist today are listed;
 * the rest of the mockup's list (Playback, Equalizer, Library...) joins as those pages are built.
 */
@Composable
fun SettingsScreen(
    glowOn: Boolean,
    onGlowChange: (Boolean) -> Unit,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onOpenCast: () -> Unit,
    onOpenLyricsSettings: () -> Unit,
    tagsRead: Int,
    songCount: Int,
    tagProgress: Pair<Int, Int>?,
    onRereadTags: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier
            .verticalScroll(rememberScrollState())
            .padding(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        Row(
            Modifier.fillMaxWidth().padding(top = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            RoundIconButton(NeedleIcon.BACK, onBack, size = 42.dp, iconSize = 22.dp, background = Palette.Card2)
        }
        Spacer(Modifier.height(16.dp))
        Text("Settings", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 34.sp)
        Text("Appearance, library and devices.", color = Palette.Muted, fontSize = 13.sp)
        Spacer(Modifier.height(22.dp))

        Label("Appearance")
        SettingRow(
            "Moving background",
            note = "The slowly drifting glow behind every page. Off gives a plain dark background and saves a little battery."
        ) { NeedleSwitch(glowOn, onGlowChange) }

        Spacer(Modifier.height(14.dp))
        Label("Library")
        SettingRow(
            "Tags in your files",
            note = if (tagProgress != null) "Reading ${tagProgress.first} of ${tagProgress.second} songs..."
            else "Needle reads composer, comment, lyrics and the other tags inside each file once. " +
                "$tagsRead of $songCount songs read. Tap to read them all again, for example after changing files on a computer.",
            onClick = if (tagProgress == null) onRereadTags else null
        ) {
            Text(
                if (tagProgress == null) "Re-read" else "",
                color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold
            )
        }

        Spacer(Modifier.height(14.dp))
        Label("Lyrics")
        SettingRow("Lyrics", note = "Sources, size, sync", onClick = onOpenLyricsSettings) {
            Text("Open", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(14.dp))
        Label("Devices")
        SettingRow("Cast devices", note = "Play on a TV, Xbox or PC · DLNA / UPnP", onClick = onOpenCast) {
            Text("Open", color = Palette.Accent, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
        }

        Spacer(Modifier.height(16.dp))
        Text(
            "More settings will appear here as their pages are built.",
            color = Palette.Muted, fontSize = 12.sp, modifier = Modifier.padding(horizontal = 4.dp)
        )
    }
}

@Composable
private fun Label(text: String) {
    Text(
        text, color = Palette.Muted, fontSize = 12.sp, fontWeight = FontWeight.SemiBold,
        modifier = Modifier.padding(start = 4.dp, bottom = 8.dp)
    )
}
