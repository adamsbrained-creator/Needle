package app.needle.music.ui

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.ArtworkLoader
import app.needle.music.data.HomeAlbum
import app.needle.music.data.Song

/** One album: big cover, Play / Shuffle, and the track list. */
@Composable
fun AlbumScreen(
    album: HomeAlbum,
    currentMediaId: String?,
    bottomPadding: Dp,
    onBack: () -> Unit,
    onTrack: (Int) -> Unit,
    onPlay: () -> Unit,
    onShuffle: () -> Unit,
    onPlayNext: () -> Unit,
    onAddToQueue: () -> Unit,
    onEditTags: (List<Song>) -> Unit,
    onEditTrack: (Song) -> Unit,
    modifier: Modifier = Modifier
) {
    val year = album.songs.maxOf { it.year }
    val meta = listOfNotNull(
        year.takeIf { it > 0 }?.toString(),
        "${album.songs.size} tracks",
        "${album.songs.sumOf { it.durationMs } / 60_000} min"
    ).joinToString(" · ")

    LazyColumn(
        modifier.fillMaxSize(),
        contentPadding = PaddingValues(start = 16.dp, end = 16.dp, bottom = bottomPadding)
    ) {
        item {
            Row(Modifier.fillMaxWidth().padding(top = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(
                    Modifier.size(38.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f)).clickable(onClick = onBack),
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.BACK, Palette.Text) }
                Spacer(Modifier.weight(1f))
                Box(
                    Modifier.size(38.dp).clip(CircleShape)
                        .background(Color.White.copy(alpha = 0.12f)).clickable { onEditTags(album.songs) },
                    contentAlignment = Alignment.Center
                ) { NeedleIconView(NeedleIcon.TAG, Palette.Text, size = 20.dp) }
            }
        }
        item {
            Column(Modifier.fillMaxWidth().padding(top = 16.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                AlbumArt(
                    album.cover,
                    Modifier.fillMaxWidth(0.8f).aspectRatio(1f).clip(RoundedCornerShape(26.dp))
                )
                Spacer(Modifier.height(20.dp))
                Text(
                    album.title, color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 28.sp,
                    lineHeight = 32.sp, textAlign = TextAlign.Center, maxLines = 3, overflow = TextOverflow.Ellipsis
                )
                Spacer(Modifier.height(4.dp))
                Text(
                    album.artist, color = Palette.Muted, fontSize = 16.sp,
                    maxLines = 1, overflow = TextOverflow.Ellipsis
                )
                Text(meta, color = Palette.Muted, fontSize = 13.sp)
                Spacer(Modifier.height(18.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    PillButton("Play", onPlay, filled = true)
                    PillButton("Shuffle", onShuffle)
                }
                // The whole album, in album order, after the song that is playing or at the end of the queue.
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    QueuePill(NeedleIcon.PLAY_NEXT, "Play next", onPlayNext)
                    QueuePill(NeedleIcon.ADD_QUEUE, "Add to queue", onAddToQueue)
                }
                Spacer(Modifier.height(16.dp))
            }
        }
        itemsIndexed(album.songs, key = { _, s -> s.id }) { index, song ->
            TrackRow(
                number = if (song.trackNumber > 0) song.trackNumber else index + 1,
                song = song,
                showArtist = song.artist != album.artist,
                isCurrent = song.id.toString() == currentMediaId,
                onClick = { onTrack(index) },
                onLongClick = { onEditTrack(song) }
            )
        }
    }
}

@Composable
private fun QueuePill(icon: NeedleIcon, text: String, onClick: () -> Unit) {
    Row(
        Modifier
            .height(40.dp)
            .clip(CircleShape)
            .background(Color.White.copy(alpha = 0.1f))
            .clickable(onClick = onClick)
            .padding(horizontal = 16.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(7.dp)
    ) {
        NeedleIconView(icon, Palette.Text, size = 17.dp)
        Text(text, color = Palette.Text, fontSize = 13.5.sp)
    }
}

/** Sharp cover for the page; shows the Home-size one straight away while the sharper one loads. */
@Composable
private fun AlbumArt(song: Song, modifier: Modifier) {
    val context = LocalContext.current
    val art by produceState<ImageBitmap?>(ArtworkLoader.peekHero(song), song.id, ArtworkLoader.version) {
        value = ArtworkLoader.peekHero(song) ?: ArtworkLoader.loadHero(context, song)
    }
    val bitmap = art
    if (bitmap != null) {
        Image(bitmap, null, modifier, contentScale = ContentScale.Crop)
    } else {
        Cover(song, modifier)
    }
}

@Composable
private fun TrackRow(
    number: Int, song: Song, showArtist: Boolean, isCurrent: Boolean, onClick: () -> Unit, onLongClick: () -> Unit
) {
    Row(
        Modifier
            .fillMaxWidth()
            .tapOrHold(onClick = onClick, onLongClick = onLongClick)
            .padding(horizontal = 8.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            "$number", Modifier.width(32.dp),
            color = if (isCurrent) Palette.Accent else Palette.Muted, fontSize = 14.sp
        )
        Column(Modifier.weight(1f)) {
            Text(
                song.title,
                color = if (isCurrent) Palette.Accent else Palette.Text,
                fontSize = 16.sp, fontWeight = FontWeight.Medium,
                maxLines = 1, overflow = TextOverflow.Ellipsis
            )
            if (showArtist) {
                Text(song.artist, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
        }
        Text(formatTime(song.durationMs), color = Palette.Muted, fontSize = 13.sp)
    }
}
