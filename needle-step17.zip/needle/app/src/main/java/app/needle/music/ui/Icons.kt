package app.needle.music.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.scale
import androidx.compose.ui.graphics.vector.PathParser
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/** The line icons from the mockups, drawn with paths so no icon library is needed. */
enum class NeedleIcon { SEARCH, HOME, SONGS, ALBUMS, LIBRARY, SHUFFLE, PLAY, BACK, IMAGE, TAG, CHECK, CLOSE, PLUS,
    REFRESH, INFO, HELP, PHONE, TV, PC, SPEAKER, GEAR, EYE, EYE_OFF, CAST, MINUS,
    CHEVRON_DOWN, LOCK, UNLOCK, SHARE, PENCIL, FOLDER, PLAY_NEXT, ADD_QUEUE }

@Composable
fun NeedleIconView(icon: NeedleIcon, tint: Color, modifier: Modifier = Modifier, size: Dp = 22.dp) {
    Canvas(modifier.size(size)) { drawNeedleIcon(icon, tint) }
}

/** Coordinates below are the mockups' 24x24 icon grid. */
private fun DrawScope.drawNeedleIcon(icon: NeedleIcon, color: Color) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f * k, cap = StrokeCap.Round, join = StrokeJoin.Round)
    fun line(x1: Float, y1: Float, x2: Float, y2: Float) =
        drawLine(color, Offset(x1 * k, y1 * k), Offset(x2 * k, y2 * k), strokeWidth = 1.8f * k, cap = StrokeCap.Round)

    when (icon) {
        NeedleIcon.SEARCH -> {
            drawCircle(color, radius = 7f * k, center = Offset(11f * k, 11f * k), style = stroke)
            line(20f, 20f, 16.5f, 16.5f)
        }
        NeedleIcon.HOME -> {
            val p = Path().apply {
                moveTo(4f * k, 11f * k); lineTo(12f * k, 4f * k); lineTo(20f * k, 11f * k)
                lineTo(20f * k, 20f * k); lineTo(15f * k, 20f * k); lineTo(15f * k, 14f * k)
                lineTo(9f * k, 14f * k); lineTo(9f * k, 20f * k); lineTo(4f * k, 20f * k)
                close()
            }
            drawPath(p, color, style = stroke)
        }
        NeedleIcon.SONGS -> {
            val p = Path().apply {
                moveTo(9f * k, 18f * k); lineTo(9f * k, 5f * k); lineTo(20f * k, 3f * k); lineTo(20f * k, 16f * k)
            }
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(6.5f * k, 18f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(17.5f * k, 16f * k), style = stroke)
        }
        NeedleIcon.ALBUMS -> {
            drawCircle(color, radius = 9f * k, center = Offset(12f * k, 12f * k), style = stroke)
            drawCircle(color, radius = 2.5f * k, center = Offset(12f * k, 12f * k), style = stroke)
        }
        NeedleIcon.SHUFFLE -> {
            val top = Path().apply {
                moveTo(3f * k, 7f * k); lineTo(6f * k, 7f * k)
                cubicTo(11f * k, 7f * k, 12f * k, 17f * k, 17f * k, 17f * k)
                lineTo(21f * k, 17f * k)
            }
            val bottomLeft = Path().apply {
                moveTo(3f * k, 17f * k); lineTo(6f * k, 17f * k)
                cubicTo(7.6f * k, 17f * k, 8.7f * k, 16.1f * k, 9.6f * k, 14.8f * k)
            }
            val topRight = Path().apply {
                moveTo(14.4f * k, 9.2f * k)
                cubicTo(15.3f * k, 7.9f * k, 16.4f * k, 7f * k, 18f * k, 7f * k)
                lineTo(21f * k, 7f * k)
            }
            val headTop = Path().apply { moveTo(18f * k, 4f * k); lineTo(21f * k, 7f * k); lineTo(18f * k, 10f * k) }
            val headBottom = Path().apply { moveTo(18f * k, 14f * k); lineTo(21f * k, 17f * k); lineTo(18f * k, 20f * k) }
            for (p in listOf(top, bottomLeft, topRight, headTop, headBottom)) drawPath(p, color, style = stroke)
        }
        NeedleIcon.IMAGE -> {
            drawRoundRect(
                color, topLeft = Offset(3f * k, 4f * k), size = Size(18f * k, 16f * k),
                cornerRadius = CornerRadius(3f * k), style = stroke
            )
            drawCircle(color, radius = 1.6f * k, center = Offset(9f * k, 10f * k), style = stroke)
            val hills = Path().apply {
                moveTo(4f * k, 18f * k); lineTo(9f * k, 13f * k); lineTo(13f * k, 17f * k)
                lineTo(16f * k, 14f * k); lineTo(20f * k, 18f * k)
            }
            drawPath(hills, color, style = stroke)
        }
        NeedleIcon.TAG -> {
            val p = Path().apply {
                moveTo(3f * k, 12f * k); lineTo(3f * k, 4f * k); lineTo(11f * k, 4f * k)
                lineTo(21f * k, 14f * k); lineTo(13f * k, 22f * k)
                close()
            }
            drawPath(p, color, style = stroke)
            drawCircle(color, radius = 1f * k, center = Offset(7.5f * k, 8.5f * k), style = stroke)
        }
        NeedleIcon.CHECK -> {
            val p = Path().apply { moveTo(5f * k, 12.5f * k); lineTo(9.5f * k, 17f * k); lineTo(19f * k, 7.5f * k) }
            drawPath(p, color, style = Stroke(width = 2.4f * k, cap = StrokeCap.Round, join = StrokeJoin.Round))
        }
        NeedleIcon.PLUS -> {
            line(12f, 5f, 12f, 19f)
            line(5f, 12f, 19f, 12f)
        }
        NeedleIcon.CLOSE -> {
            line(6f, 6f, 18f, 18f)
            line(18f, 6f, 6f, 18f)
        }
        NeedleIcon.BACK -> {
            line(19f, 12f, 5f, 12f)
            val head = Path().apply { moveTo(11f * k, 6f * k); lineTo(5f * k, 12f * k); lineTo(11f * k, 18f * k) }
            drawPath(head, color, style = stroke)
        }
        NeedleIcon.PLAY -> {
            val p = Path().apply {
                moveTo(7f * k, 4f * k); lineTo(7f * k, 20f * k); lineTo(20f * k, 12f * k); close()
            }
            drawPath(p, color)
        }
        NeedleIcon.LIBRARY -> {
            line(4f, 7f, 16f, 7f)
            line(4f, 12f, 16f, 12f)
            line(4f, 17f, 12f, 17f)
            line(19f, 14f, 19f, 20f)
            val arrow = Path().apply {
                moveTo(16f * k, 17f * k); lineTo(19f * k, 14f * k); lineTo(22f * k, 17f * k)
            }
            drawPath(arrow, color, style = stroke)
        }
        else -> drawSvgIcon(icon, color)
    }
}

private val svgPaths = HashMap<String, Path>()
private fun svgPath(d: String): Path = svgPaths.getOrPut(d) { PathParser().parsePathString(d).toPath() }

private const val EYE_PATH = "M2 12 s4 -7 10 -7 s10 7 10 7 s-4 7 -10 7 s-10 -7 -10 -7 z"

/** The casting icons, taken straight from the mockup's SVG shapes (24x24 grid). */
private fun DrawScope.drawSvgIcon(icon: NeedleIcon, color: Color) {
    val k = size.width / 24f
    val stroke = Stroke(width = 1.8f, cap = StrokeCap.Round, join = StrokeJoin.Round)
    scale(k, Offset.Zero) {
        fun p(d: String) = drawPath(svgPath(d), color, style = stroke)
        fun circle(cx: Float, cy: Float, r: Float) = drawCircle(color, r, Offset(cx, cy), style = stroke)
        fun box(x: Float, y: Float, w: Float, h: Float, r: Float) =
            drawRoundRect(color, Offset(x, y), Size(w, h), CornerRadius(r, r), style = stroke)
        when (icon) {
            NeedleIcon.REFRESH -> p("M20 12 a8 8 0 1 1 -2.5 -5.8 M20 4 v5 h-5")
            NeedleIcon.INFO -> { circle(12f, 12f, 9f); p("M12 11 v6 M12 7.5 v0.1") }
            NeedleIcon.HELP -> { circle(12f, 12f, 9f); p("M9.5 9.5 a2.5 2.5 0 1 1 3.5 2.3 c-0.7 0.4 -1 0.9 -1 1.7 M12 17 v0.1") }
            NeedleIcon.PHONE -> { box(7f, 2.5f, 10f, 19f, 2.5f); p("M11 18.5 h2") }
            NeedleIcon.TV -> { box(3f, 4f, 18f, 12f, 2f); p("M8 20 h8 M12 16 v4") }
            NeedleIcon.PC -> { box(3f, 3f, 18f, 13f, 2f); p("M2 20 h20 M9 16 v4 M15 16 v4") }
            NeedleIcon.SPEAKER -> { box(6f, 2.5f, 12f, 19f, 3f); circle(12f, 14.5f, 3.5f); circle(12f, 7f, 0.6f) }
            NeedleIcon.GEAR -> {
                circle(12f, 12f, 3f)
                p("M12 2 v3 M12 19 v3 M2 12 h3 M19 12 h3 M4.9 4.9 L7 7 M17 17 l2.1 2.1 M4.9 19.1 L7 17 M17 7 l2.1 -2.1")
            }
            NeedleIcon.EYE -> { p(EYE_PATH); circle(12f, 12f, 3f) }
            NeedleIcon.EYE_OFF -> { p(EYE_PATH); p("M4 4 l16 16") }
            NeedleIcon.CAST -> p("M3 18 a3 3 0 0 1 3 3 M3 14 a7 7 0 0 1 7 7 M3 10 a11 11 0 0 1 11 11 M3 6 h18 v14 h-5")
            NeedleIcon.MINUS -> p("M5 12 h14")
            NeedleIcon.CHEVRON_DOWN -> p("M6 9 l6 6 6 -6")
            NeedleIcon.LOCK -> { box(5f, 11f, 14f, 10f, 2f); p("M8 11 V8 a4 4 0 0 1 8 0 v3") }
            NeedleIcon.UNLOCK -> { box(5f, 11f, 14f, 10f, 2f); p("M8 11 V8 a4 4 0 0 1 7.5 -1.5") }
            NeedleIcon.PLAY_NEXT -> p("M4 7 h10 M4 12 h10 M4 17 h6 M16 13 l5 3.5 -5 3.5 z")
            NeedleIcon.ADD_QUEUE -> p("M4 7 h12 M4 12 h12 M4 17 h7 M18 14 v6 M15 17 h6")
            NeedleIcon.PENCIL -> p("M4 20 h4 L19 9 l-4 -4 L4 16 z")
            NeedleIcon.FOLDER -> p("M3 6 a2 2 0 0 1 2 -2 h4 l2 2 h8 a2 2 0 0 1 2 2 v10 a2 2 0 0 1 -2 2 H5 a2 2 0 0 1 -2 -2 z")
            NeedleIcon.SHARE -> p("M12 3 v12 M7 8 l5 -5 5 5 M5 14 v5 a2 2 0 0 0 2 2 h10 a2 2 0 0 0 2 -2 v-5")
            else -> Unit
        }
    }
}
