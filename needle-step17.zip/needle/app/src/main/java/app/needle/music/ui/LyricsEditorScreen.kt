package app.needle.music.ui

import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.defaultMinSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawingPadding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import app.needle.music.data.LrcParser
import app.needle.music.data.Lyrics
import app.needle.music.data.LyricsQuery
import app.needle.music.data.LyricsSource
import app.needle.music.data.LyricsViewModel
import app.needle.music.data.Song
import app.needle.music.playback.PlayerViewModel
import kotlinx.coroutines.delay

private class EditLine(val text: String, val timeMs: Long?)

private enum class EditMode { PLAIN, SYNCED }

private fun mmss(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

/** "00:17.4" as shown on the rows. */
private fun rowStamp(ms: Long): String {
    val t = ms / 100
    return "%02d:%02d.%d".format(t / 600, (t / 10) % 60, t % 10)
}

/** "[00:17.43]" as written to the lyrics. */
private fun lrcStamp(ms: Long): String {
    val cs = ms / 10
    return "%02d:%02d.%02d".format(cs / 6000, (cs / 100) % 60, cs % 100)
}

/**
 * The lyrics editor from the mockup. Plain mode is a text box. Synced mode is a list of lines: play the song,
 * select a line and tap Stamp when it is sung, and Needle moves on to the next line.
 * Saving writes the Lyrics tag of the song (the same one the tag editor shows).
 */
@Composable
fun LyricsEditorScreen(
    song: Song,
    player: PlayerViewModel,
    lyricsVm: LyricsViewModel,
    onClose: () -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var mode by remember { mutableStateOf(EditMode.PLAIN) }
    var plain by remember { mutableStateOf("") }
    val lines = remember { mutableStateListOf<EditLine>() }
    var selected by remember { mutableIntStateOf(0) }
    var dirty by remember { mutableStateOf(false) }
    var loaded by remember { mutableStateOf(false) }
    var showDiscard by remember { mutableStateOf(false) }
    var showUnstamped by remember { mutableStateOf(false) }
    var editIndex by remember { mutableIntStateOf(-1) }

    val isThisSong = player.currentMediaId == song.id.toString()
    val listState = rememberLazyListState()

    fun toast(message: String) = Toast.makeText(context, message, Toast.LENGTH_SHORT).show()

    fun loadLyrics(l: Lyrics) {
        plain = l.plainText()
        lines.clear()
        if (l.synced) {
            l.lines.forEach { lines.add(EditLine(it.text, it.timeMs)) }
            mode = EditMode.SYNCED
        } else {
            mode = EditMode.PLAIN
        }
        selected = 0
    }

    /** Text from a .lrc file or the clipboard. */
    fun applyRaw(raw: String) {
        val parsed = LrcParser.parse(raw, LyricsSource.TAGS)
        if (parsed == null) { toast("Nothing to use in that text"); return }
        loadLyrics(parsed)
        dirty = true
    }

    fun toPlain() {
        if (mode == EditMode.PLAIN) return
        plain = lines.joinToString("\n") { it.text }
        mode = EditMode.PLAIN
    }

    /** Plain -> Synced keeps the times of lines that did not change, matched by their words. */
    fun toSynced() {
        if (mode == EditMode.SYNCED) return
        val texts = plain.replace("\r", "").split('\n').map { it.trim() }
            .dropWhile { it.isEmpty() }.dropLastWhile { it.isEmpty() }
        val old = lines.toList()
        val used = BooleanArray(old.size)
        val next = texts.mapIndexed { i, t ->
            var time: Long? = null
            if (i < old.size && !used[i] && old[i].text == t) {
                time = old[i].timeMs; used[i] = true
            } else {
                val j = old.indices.firstOrNull { !used[it] && old[it].text == t }
                if (j != null) { time = old[j].timeMs; used[j] = true }
            }
            EditLine(t, time)
        }
        lines.clear()
        lines.addAll(next)
        selected = 0
        mode = EditMode.SYNCED
    }

    fun buildOutput(): String =
        if (mode == EditMode.PLAIN) plain.trim()
        else lines.filter { it.timeMs != null }.joinToString("\n") { "[${lrcStamp(it.timeMs!!)}]${it.text}" }

    fun unstamped(): Int = lines.count { it.timeMs == null && it.text.isNotBlank() }

    fun save() {
        lyricsVm.saveEdited(song.id, buildOutput()) { onClose() }
    }

    fun requestSave() {
        if (mode == EditMode.SYNCED && unstamped() > 0) showUnstamped = true else save()
    }

    fun requestClose() { if (dirty) showDiscard = true else onClose() }

    fun stampNow() {
        if (!isThisSong) { toast("Play this song first"); return }
        if (lines.isEmpty()) return
        val i = selected.coerceIn(0, lines.lastIndex)
        lines[i] = EditLine(lines[i].text, player.positionMs.coerceAtLeast(0))
        if (i < lines.lastIndex) selected = i + 1
        dirty = true
    }

    fun shiftAll(deltaMs: Long) {
        for (i in lines.indices) {
            val t = lines[i].timeMs ?: continue
            lines[i] = EditLine(lines[i].text, (t + deltaMs).coerceAtLeast(0))
        }
        dirty = true
    }

    fun seekBy(deltaMs: Long) {
        if (!isThisSong) { toast("Play this song first"); return }
        player.seekTo((player.positionMs + deltaMs).coerceAtLeast(0))
    }

    val importLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val text = runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            }.getOrNull()
            if (text.isNullOrBlank()) toast("Couldn't read that file") else applyRaw(text)
        }
    }

    BackHandler { requestClose() }

    // Start from the lyrics the song has now.
    LaunchedEffect(song.id) {
        val q = LyricsQuery(song.id, song.title, song.artist, song.album, song.durationMs)
        lyricsVm.initialFor(q)?.let { loadLyrics(it) }
        loaded = true
    }
    // Keep the playing position fresh while the song plays.
    LaunchedEffect(isThisSong, player.isPlaying) {
        if (isThisSong) {
            player.refreshPosition()
            while (player.isPlaying) {
                player.refreshPosition()
                delay(150)
            }
        }
    }
    LaunchedEffect(selected, mode) {
        if (mode == EditMode.SYNCED && lines.isNotEmpty()) {
            listState.animateScrollToItem(selected.coerceIn(0, lines.lastIndex), -(listState.layoutInfo.viewportSize.height / 3))
        }
    }

    val playingIndex by remember(isThisSong) {
        derivedStateOf {
            if (!isThisSong || mode != EditMode.SYNCED) -1
            else {
                val p = player.positionMs
                var r = -1
                for (i in lines.indices) {
                    val t = lines[i].timeMs
                    if (t != null && t <= p) r = i
                }
                r
            }
        }
    }

    Column(modifier.fillMaxSize().safeDrawingPadding()) {
        // ---- header ----
        Row(
            Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            RoundIconButton(NeedleIcon.CLOSE, { requestClose() }, size = 42.dp, iconSize = 21.dp, background = Color.White.copy(alpha = 0.12f))
            Column(Modifier.weight(1f)) {
                Text("Edit lyrics", color = Palette.Text, fontFamily = FontFamily.Serif, fontSize = 24.sp)
                Text(song.title, color = Palette.Muted, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            }
            Box(
                Modifier.size(42.dp).clip(CircleShape).background(Color.White).clickable { requestSave() },
                contentAlignment = Alignment.Center
            ) { NeedleIconView(NeedleIcon.CHECK, Color.Black, size = 22.dp) }
        }

        // ---- Plain | Synced ----
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.Center) {
            Row(Modifier.clip(RoundedCornerShape(99.dp)).background(Color.White.copy(alpha = 0.1f)).padding(3.dp)) {
                SegmentLabel("Plain", mode == EditMode.PLAIN) { toPlain() }
                SegmentLabel("Synced", mode == EditMode.SYNCED) { toSynced() }
            }
        }

        // ---- the text ----
        Box(Modifier.weight(1f).fillMaxWidth().padding(horizontal = 14.dp, vertical = 8.dp)) {
            if (mode == EditMode.PLAIN) {
                Box(
                    Modifier.fillMaxSize().glass(RoundedCornerShape(22.dp)).verticalScroll(rememberScrollState()).padding(16.dp)
                ) {
                    BasicTextField(
                        value = plain,
                        onValueChange = { plain = it; dirty = true },
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp, lineHeight = 24.sp),
                        cursorBrush = SolidColor(Palette.Accent),
                        modifier = Modifier.fillMaxWidth().defaultMinSize(minHeight = 200.dp),
                        decorationBox = { inner ->
                            if (plain.isEmpty() && loaded) {
                                Text("Type or paste the lyrics, one line per row.", color = Palette.Muted, fontSize = 16.sp)
                            }
                            inner()
                        }
                    )
                }
            } else if (lines.isEmpty()) {
                Text(
                    "No lines yet. Switch to Plain to type the lyrics, or use Import .lrc or Paste.",
                    color = Palette.Muted, fontSize = 14.sp, lineHeight = 20.sp, modifier = Modifier.padding(16.dp)
                )
            } else {
                LazyColumn(state = listState, modifier = Modifier.fillMaxSize()) {
                    itemsIndexed(lines, key = { i, _ -> i }) { i, line ->
                        val sel = i == selected
                        Row(
                            Modifier
                                .fillMaxWidth()
                                .padding(vertical = 2.dp)
                                .clip(RoundedCornerShape(14.dp))
                                .background(if (sel) Palette.Accent.copy(alpha = 0.28f) else Color.Transparent)
                                .clickable {
                                    selected = i
                                    val t = line.timeMs
                                    if (t != null && isThisSong) player.seekTo(t)
                                }
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                if (line.timeMs != null) rowStamp(line.timeMs) else "--:--.-",
                                color = if (i == playingIndex) Palette.Accent else Palette.Muted,
                                fontFamily = FontFamily.Monospace, fontSize = 12.sp,
                                modifier = Modifier.width(66.dp)
                            )
                            Text(
                                line.text.ifEmpty { "(empty line)" },
                                color = if (line.timeMs == null) Palette.Muted else Color.White,
                                fontSize = 15.sp, modifier = Modifier.weight(1f)
                            )
                            if (sel) {
                                Box(
                                    Modifier.size(32.dp).clip(CircleShape).clickable { editIndex = i },
                                    contentAlignment = Alignment.Center
                                ) { NeedleIconView(NeedleIcon.PENCIL, Palette.Text, size = 17.dp) }
                            }
                        }
                    }
                }
            }
        }

        // ---- play + stamp + tools ----
        Column(Modifier.fillMaxWidth().padding(horizontal = 14.dp).padding(bottom = 12.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            if (isThisSong) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(mmss(player.positionMs), color = Palette.Muted, fontSize = 12.sp)
                    Box(Modifier.weight(1f).height(4.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.2f))) {
                        val frac = if (player.durationMs > 0) (player.positionMs.toFloat() / player.durationMs).coerceIn(0f, 1f) else 0f
                        Box(Modifier.fillMaxHeight().fillMaxWidth(frac).background(Color.White))
                    }
                    Text(mmss(player.durationMs), color = Palette.Muted, fontSize = 12.sp)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (isThisSong) {
                    EditorChip("−5 s", { seekBy(-5000) })
                    EditorChip(if (player.isPlaying) "Pause" else "Play", { player.togglePlay() }, filled = true)
                    EditorChip("+5 s", { seekBy(5000) })
                } else {
                    EditorChip("Play this song to sync", { player.playSongs(listOf(song), 0, shuffle = false) }, filled = true)
                }
                if (mode == EditMode.SYNCED && isThisSong) {
                    Spacer(Modifier.weight(1f))
                    EditorChip("Stamp line", { stampNow() }, filled = true)
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                if (mode == EditMode.SYNCED) {
                    Text("Offset", color = Palette.Muted, fontSize = 12.sp)
                    EditorChip("−0.1 s", { shiftAll(-100) })
                    EditorChip("+0.1 s", { shiftAll(100) })
                }
                EditorChip("Import .lrc", { importLauncher.launch(arrayOf("*/*")) })
                EditorChip("Paste", {
                    val cm = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                    val text = cm.primaryClip?.takeIf { it.itemCount > 0 }?.getItemAt(0)?.coerceToText(context)?.toString()
                    if (text.isNullOrBlank()) toast("The clipboard is empty") else applyRaw(text)
                })
            }
        }
    }

    // ---- dialogs ----
    if (showDiscard) {
        AlertDialog(
            onDismissRequest = { showDiscard = false },
            containerColor = Palette.Surface, titleContentColor = Palette.Text, textContentColor = Palette.Muted,
            title = { Text("Discard changes?") },
            text = { Text("The lyrics you changed here have not been saved.") },
            confirmButton = { TextButton(onClick = { showDiscard = false; onClose() }) { Text("Discard", color = Palette.Accent) } },
            dismissButton = { TextButton(onClick = { showDiscard = false }) { Text("Keep editing", color = Palette.Accent) } }
        )
    }
    if (showUnstamped) {
        AlertDialog(
            onDismissRequest = { showUnstamped = false },
            containerColor = Palette.Surface, titleContentColor = Palette.Text, textContentColor = Palette.Muted,
            title = { Text("Some lines have no time") },
            text = { Text("${unstamped()} lines have no time yet and would be left out of the synced lyrics. Save without them?") },
            confirmButton = { TextButton(onClick = { showUnstamped = false; save() }) { Text("Save anyway", color = Palette.Accent) } },
            dismissButton = { TextButton(onClick = { showUnstamped = false }) { Text("Keep editing", color = Palette.Accent) } }
        )
    }
    if (editIndex in lines.indices) {
        val index = editIndex
        var text by remember(index) { mutableStateOf(lines[index].text) }
        AlertDialog(
            onDismissRequest = { editIndex = -1 },
            containerColor = Palette.Surface, titleContentColor = Palette.Text, textContentColor = Palette.Muted,
            title = { Text("Edit line") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    BasicTextField(
                        value = text,
                        onValueChange = { text = it },
                        textStyle = TextStyle(color = Color.White, fontSize = 16.sp, lineHeight = 22.sp),
                        cursorBrush = SolidColor(Palette.Accent),
                        modifier = Modifier.fillMaxWidth().glass(RoundedCornerShape(14.dp)).padding(12.dp)
                    )
                    TextButton(onClick = {
                        lines[index] = EditLine(text.trim(), lines[index].timeMs)
                        lines.add(index + 1, EditLine("", null))
                        selected = index + 1
                        dirty = true
                        editIndex = index + 1
                    }) { Text("Add a line below", color = Palette.Accent) }
                    if (lines[index].timeMs != null) {
                        TextButton(onClick = {
                            lines[index] = EditLine(text.trim(), null)
                            dirty = true
                            editIndex = -1
                        }) { Text("Clear this line's time", color = Palette.Accent) }
                    }
                    TextButton(onClick = {
                        lines.removeAt(index)
                        selected = selected.coerceIn(0, (lines.size - 1).coerceAtLeast(0))
                        dirty = true
                        editIndex = -1
                    }) { Text("Delete this line", color = Palette.Accent) }
                }
            },
            confirmButton = {
                TextButton(onClick = {
                    lines[index] = EditLine(text.trim(), lines[index].timeMs)
                    dirty = true
                    editIndex = -1
                }) { Text("Done", color = Palette.Accent) }
            },
            dismissButton = { TextButton(onClick = { editIndex = -1 }) { Text("Cancel", color = Palette.Accent) } }
        )
    }
}

@Composable
private fun SegmentLabel(label: String, on: Boolean, onClick: () -> Unit) {
    Box(
        Modifier
            .clip(RoundedCornerShape(99.dp))
            .background(if (on) Color.White else Color.Transparent)
            .clickable(onClick = onClick)
            .padding(horizontal = 22.dp, vertical = 8.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (on) Palette.Bg else Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun EditorChip(label: String, onClick: () -> Unit, filled: Boolean = false) {
    Box(
        Modifier
            .height(38.dp)
            .clip(RoundedCornerShape(99.dp))
            .background(if (filled) Color.White else Color.White.copy(alpha = 0.12f))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) {
        Text(label, color = if (filled) Palette.Bg else Palette.Text, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
    }
}
